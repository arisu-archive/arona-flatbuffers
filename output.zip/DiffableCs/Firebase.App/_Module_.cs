//Type is in global namespace

[Token(Token = "0x2000001")]
internal class <Module>
{

}

