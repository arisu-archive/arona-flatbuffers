namespace Firebase;

[Token(Token = "0x2000021")]
internal class AppUtil
{

	[Address(RVA = "0x3BE7BA8", Offset = "0x3BE7BA8", Length = "0xB4")]
	[Token(Token = "0x60000D2")]
	internal static void AppEnableLogCallback(bool arg0) { }

	[Address(RVA = "0x3BEFBEC", Offset = "0x3BEFBEC", Length = "0xB8")]
	[Token(Token = "0x60000D7")]
	public static GooglePlayServicesAvailability CheckAndroidDependencies() { }

	[Address(RVA = "0x3BF0AE8", Offset = "0x3BF0AE8", Length = "0x9C")]
	[Token(Token = "0x60000D8")]
	public static Task FixAndroidDependenciesAsync() { }

	[Address(RVA = "0x3BEEB80", Offset = "0x3BEEB80", Length = "0xC0")]
	[Token(Token = "0x60000D5")]
	internal static bool GetEnabledAppCallbackByName(string arg0) { }

	[Address(RVA = "0x3BEFF40", Offset = "0x3BEFF40", Length = "0xAC")]
	[Token(Token = "0x60000D9")]
	internal static void InitializePlayServicesInternal() { }

	[Address(RVA = "0x3BF2730", Offset = "0x3BF2730", Length = "0xAC")]
	[Token(Token = "0x60000D1")]
	internal static void PollCallbacks() { }

	[Address(RVA = "0x3BEEACC", Offset = "0x3BEEACC", Length = "0xB4")]
	[Token(Token = "0x60000D3")]
	internal static void SetEnabledAllAppCallbacks(bool arg0) { }

	[Address(RVA = "0x3BEEC40", Offset = "0x3BEEC40", Length = "0xC4")]
	[Token(Token = "0x60000D4")]
	internal static void SetEnabledAppCallbackByName(string arg0, bool arg1) { }

	[Address(RVA = "0x3BE7DD0", Offset = "0x3BE7DD0", Length = "0xB4")]
	[Token(Token = "0x60000D6")]
	internal static void SetLogFunction(LogMessageDelegate arg0) { }

	[Address(RVA = "0x3BF0054", Offset = "0x3BF0054", Length = "0xAC")]
	[Token(Token = "0x60000DA")]
	internal static void TerminatePlayServicesInternal() { }

}

