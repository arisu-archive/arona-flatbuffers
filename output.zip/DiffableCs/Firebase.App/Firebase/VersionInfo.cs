namespace Firebase;

[Token(Token = "0x2000022")]
internal class VersionInfo
{

	[Token(Token = "0x17000016")]
	internal static string BuildSource
	{
		[Address(RVA = "0x3BEF068", Offset = "0x3BEF068", Length = "0x40")]
		[Token(Token = "0x60000DC")]
		internal get { } //Length: 64
	}

	[Token(Token = "0x17000015")]
	internal static string SdkVersion
	{
		[Address(RVA = "0x3BEF028", Offset = "0x3BEF028", Length = "0x40")]
		[Token(Token = "0x60000DB")]
		internal get { } //Length: 64
	}

	[Address(RVA = "0x3BEF068", Offset = "0x3BEF068", Length = "0x40")]
	[Token(Token = "0x60000DC")]
	internal static string get_BuildSource() { }

	[Address(RVA = "0x3BEF028", Offset = "0x3BEF028", Length = "0x40")]
	[Token(Token = "0x60000DB")]
	internal static string get_SdkVersion() { }

}

