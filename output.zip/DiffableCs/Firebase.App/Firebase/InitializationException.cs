namespace Firebase;

[Token(Token = "0x2000004")]
public sealed class InitializationException : Exception
{
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState::Never (0))]
	[FieldOffset(Offset = "0x8C")]
	[Token(Token = "0x400000B")]
	private InitResult <InitResult>k__BackingField; //Field offset: 0x8C

	[Token(Token = "0x17000002")]
	public private InitResult InitResult
	{
		[Address(RVA = "0x3BE7484", Offset = "0x3BE7484", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6000003")]
		 get { } //Length: 8
		[Address(RVA = "0x3BE748C", Offset = "0x3BE748C", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6000004")]
		private set { } //Length: 8
	}

	[Address(RVA = "0x3BE7494", Offset = "0x3BE7494", Length = "0x74")]
	[Token(Token = "0x6000005")]
	public InitializationException(InitResult result, string message) { }

	[Address(RVA = "0x3BE7508", Offset = "0x3BE7508", Length = "0x84")]
	[Token(Token = "0x6000006")]
	public InitializationException(InitResult result, string message, Exception inner) { }

	[Address(RVA = "0x3BE7484", Offset = "0x3BE7484", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6000003")]
	public InitResult get_InitResult() { }

	[Address(RVA = "0x3BE748C", Offset = "0x3BE748C", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6000004")]
	private void set_InitResult(InitResult value) { }

}

