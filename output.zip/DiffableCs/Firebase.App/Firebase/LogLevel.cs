namespace Firebase;

[Token(Token = "0x2000018")]
public enum LogLevel
{
	Verbose = 0,
	Debug = 1,
	Info = 2,
	Warning = 3,
	Error = 4,
	Assert = 5,
}

