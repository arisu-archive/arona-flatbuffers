namespace Firebase;

[Token(Token = "0x2000011")]
public enum InitResult
{
	Success = 0,
	FailedMissingDependency = 1,
}

