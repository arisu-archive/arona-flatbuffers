namespace Firebase;

[Token(Token = "0x2000009")]
internal enum FutureStatus
{
	Complete = 0,
	Pending = 1,
	Invalid = 2,
}

