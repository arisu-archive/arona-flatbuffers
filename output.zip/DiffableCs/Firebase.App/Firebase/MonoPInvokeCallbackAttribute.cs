namespace Firebase;

[AttributeUsage(AttributeTargets::Method (64))]
[Token(Token = "0x2000008")]
internal sealed class MonoPInvokeCallbackAttribute : Attribute
{

	[Address(RVA = "0x3BE7FF0", Offset = "0x3BE7FF0", Length = "0x8")]
	[Token(Token = "0x6000016")]
	public MonoPInvokeCallbackAttribute(Type t) { }

}

