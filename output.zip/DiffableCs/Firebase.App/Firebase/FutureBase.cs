namespace Firebase;

[Token(Token = "0x200000A")]
internal class FutureBase : IDisposable
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000019")]
	private HandleRef swigCPtr; //Field offset: 0x10
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400001A")]
	protected bool swigCMemOwn; //Field offset: 0x20

	[Address(RVA = "0x3BE7FF8", Offset = "0x3BE7FF8", Length = "0x60")]
	[Token(Token = "0x6000017")]
	internal FutureBase(IntPtr cPtr, bool cMemoryOwn) { }

	[Address(RVA = "0x3BE80E4", Offset = "0x3BE80E4", Length = "0x6C")]
	[Token(Token = "0x6000019")]
	public override void Dispose() { }

	[Address(RVA = "0x3BE8150", Offset = "0x3BE8150", Length = "0x1D4")]
	[Token(Token = "0x600001A")]
	public override void Dispose(bool disposing) { }

	[Address(RVA = "0x3BE86E8", Offset = "0x3BE86E8", Length = "0xC8")]
	[Token(Token = "0x600001C")]
	public int error() { }

	[Address(RVA = "0x3BE882C", Offset = "0x3BE882C", Length = "0xC8")]
	[Token(Token = "0x600001D")]
	public string error_message() { }

	[Address(RVA = "0x3BE8058", Offset = "0x3BE8058", Length = "0x8C")]
	[Token(Token = "0x6000018")]
	protected virtual void Finalize() { }

	[Address(RVA = "0x3BE83A0", Offset = "0x3BE83A0", Length = "0xC8")]
	[Token(Token = "0x600001B")]
	public FutureStatus status() { }

}

