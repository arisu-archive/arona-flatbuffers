namespace Firebase;

[DefaultMember("Item")]
[Token(Token = "0x200000B")]
internal class StringStringMap : IDisposable, IDictionary<String, String>, ICollection<KeyValuePair`2<String, String>>, IEnumerable<KeyValuePair`2<String, String>>, IEnumerable
{
	[Token(Token = "0x200000C")]
	internal sealed class StringStringMapEnumerator : IEnumerator, IEnumerator<KeyValuePair`2<String, String>>, IDisposable
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x400001D")]
		private StringStringMap collectionRef; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400001E")]
		private IList<String> keyCollection; //Field offset: 0x18
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400001F")]
		private int currentIndex; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000020")]
		private object currentObject; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000021")]
		private int currentSize; //Field offset: 0x30

		[Token(Token = "0x1700000A")]
		public override KeyValuePair<String, String> Current
		{
			[Address(RVA = "0x3BE9790", Offset = "0x3BE9790", Length = "0x11C")]
			[Token(Token = "0x600003D")]
			 get { } //Length: 284
		}

		[Token(Token = "0x1700000B")]
		private override object global::System.Collections.IEnumerator.Current
		{
			[Address(RVA = "0x3BEAA04", Offset = "0x3BEAA04", Length = "0x64")]
			[Token(Token = "0x600003E")]
			private get { } //Length: 100
		}

		[Address(RVA = "0x3BEA0D4", Offset = "0x3BEA0D4", Length = "0xE8")]
		[Token(Token = "0x600003C")]
		public StringStringMapEnumerator(StringStringMap collection) { }

		[Address(RVA = "0x3BEAB04", Offset = "0x3BEAB04", Length = "0x14")]
		[Token(Token = "0x6000041")]
		public override void Dispose() { }

		[Address(RVA = "0x3BE9790", Offset = "0x3BE9790", Length = "0x11C")]
		[Token(Token = "0x600003D")]
		public override KeyValuePair<String, String> get_Current() { }

		[Address(RVA = "0x3BEAA04", Offset = "0x3BEAA04", Length = "0x64")]
		[Token(Token = "0x600003E")]
		private override object global::System.Collections.IEnumerator.get_Current() { }

		[Address(RVA = "0x3BE98AC", Offset = "0x3BE98AC", Length = "0x174")]
		[Token(Token = "0x600003F")]
		public override bool MoveNext() { }

		[Address(RVA = "0x3BEAA68", Offset = "0x3BEAA68", Length = "0x9C")]
		[Token(Token = "0x6000040")]
		public override void Reset() { }

	}

	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x400001B")]
	private HandleRef swigCPtr; //Field offset: 0x10
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400001C")]
	protected bool swigCMemOwn; //Field offset: 0x20

	[Token(Token = "0x17000006")]
	public override int Count
	{
		[Address(RVA = "0x3BE9098", Offset = "0x3BE9098", Length = "0x4")]
		[Token(Token = "0x6000026")]
		 get { } //Length: 4
	}

	[Token(Token = "0x17000007")]
	public override bool IsReadOnly
	{
		[Address(RVA = "0x3BE9164", Offset = "0x3BE9164", Length = "0x8")]
		[Token(Token = "0x6000027")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000005")]
	public override string Item
	{
		[Address(RVA = "0x3BE8DB0", Offset = "0x3BE8DB0", Length = "0x4")]
		[Token(Token = "0x6000023")]
		 get { } //Length: 4
		[Address(RVA = "0x3BE8E8C", Offset = "0x3BE8E8C", Length = "0x4")]
		[Token(Token = "0x6000024")]
		 set { } //Length: 4
	}

	[Token(Token = "0x17000008")]
	public override ICollection<String> Keys
	{
		[Address(RVA = "0x3BE916C", Offset = "0x3BE916C", Length = "0x144")]
		[Token(Token = "0x6000028")]
		 get { } //Length: 324
	}

	[Token(Token = "0x17000009")]
	public override ICollection<String> Values
	{
		[Address(RVA = "0x3BE951C", Offset = "0x3BE951C", Length = "0x214")]
		[Token(Token = "0x6000029")]
		 get { } //Length: 532
	}

	[Address(RVA = "0x3BE8988", Offset = "0x3BE8988", Length = "0x60")]
	[Token(Token = "0x600001E")]
	internal StringStringMap(IntPtr cPtr, bool cMemoryOwn) { }

	[Address(RVA = "0x3BEA21C", Offset = "0x3BEA21C", Length = "0xC0")]
	[Token(Token = "0x6000031")]
	public StringStringMap() { }

	[Address(RVA = "0x3BE9A80", Offset = "0x3BE9A80", Length = "0xD4")]
	[Token(Token = "0x6000037")]
	public override void Add(string key, string value) { }

	[Address(RVA = "0x3BE9A20", Offset = "0x3BE9A20", Length = "0x60")]
	[Token(Token = "0x600002A")]
	public override void Add(KeyValuePair<String, String> item) { }

	[Address(RVA = "0x3BEA3C0", Offset = "0x3BEA3C0", Length = "0xBC")]
	[Token(Token = "0x6000033")]
	public override void Clear() { }

	[Address(RVA = "0x3BE9BCC", Offset = "0x3BE9BCC", Length = "0x68")]
	[Token(Token = "0x600002C")]
	public override bool Contains(KeyValuePair<String, String> item) { }

	[Address(RVA = "0x3BE8FC0", Offset = "0x3BE8FC0", Length = "0xD8")]
	[Token(Token = "0x6000036")]
	public override bool ContainsKey(string key) { }

	[Address(RVA = "0x3BE9D0C", Offset = "0x3BE9D0C", Length = "0x368")]
	[Token(Token = "0x600002D")]
	public override void CopyTo(KeyValuePair<String, String>[] array, int arrayIndex) { }

	[Address(RVA = "0x3BE92B0", Offset = "0x3BE92B0", Length = "0xC8")]
	[Token(Token = "0x6000039")]
	private IntPtr create_iterator_begin() { }

	[Address(RVA = "0x3BE9450", Offset = "0x3BE9450", Length = "0xCC")]
	[Token(Token = "0x600003B")]
	private void destroy_iterator(IntPtr swigiterator) { }

	[Address(RVA = "0x3BE8B60", Offset = "0x3BE8B60", Length = "0x1D4")]
	[Token(Token = "0x6000022")]
	public override void Dispose(bool disposing) { }

	[Address(RVA = "0x3BE8AF0", Offset = "0x3BE8AF0", Length = "0x70")]
	[Token(Token = "0x6000021")]
	public override void Dispose() { }

	[Address(RVA = "0x3BE8A60", Offset = "0x3BE8A60", Length = "0x90")]
	[Token(Token = "0x6000020")]
	protected virtual void Finalize() { }

	[Address(RVA = "0x3BE9098", Offset = "0x3BE9098", Length = "0x4")]
	[Token(Token = "0x6000026")]
	public override int get_Count() { }

	[Address(RVA = "0x3BE9164", Offset = "0x3BE9164", Length = "0x8")]
	[Token(Token = "0x6000027")]
	public override bool get_IsReadOnly() { }

	[Address(RVA = "0x3BE8DB0", Offset = "0x3BE8DB0", Length = "0x4")]
	[Token(Token = "0x6000023")]
	public override string get_Item(string key) { }

	[Address(RVA = "0x3BE916C", Offset = "0x3BE916C", Length = "0x144")]
	[Token(Token = "0x6000028")]
	public override ICollection<String> get_Keys() { }

	[Address(RVA = "0x3BE9378", Offset = "0x3BE9378", Length = "0xD8")]
	[Token(Token = "0x600003A")]
	private string get_next_key(IntPtr swigiterator) { }

	[Address(RVA = "0x3BE951C", Offset = "0x3BE951C", Length = "0x214")]
	[Token(Token = "0x6000029")]
	public override ICollection<String> get_Values() { }

	[Address(RVA = "0x3BE89E8", Offset = "0x3BE89E8", Length = "0x78")]
	[Token(Token = "0x600001F")]
	internal static HandleRef getCPtr(StringStringMap obj) { }

	[Address(RVA = "0x3BE9730", Offset = "0x3BE9730", Length = "0x60")]
	[Token(Token = "0x6000030")]
	public StringStringMapEnumerator GetEnumerator() { }

	[Address(RVA = "0x3BE8DB4", Offset = "0x3BE8DB4", Length = "0xD8")]
	[Token(Token = "0x6000034")]
	private string getitem(string key) { }

	[Address(RVA = "0x3BEA074", Offset = "0x3BEA074", Length = "0x60")]
	[Token(Token = "0x600002E")]
	private override IEnumerator<KeyValuePair`2<String, String>> global::System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<System.String,System.String>>.GetEnumerator() { }

	[Address(RVA = "0x3BEA1BC", Offset = "0x3BEA1BC", Length = "0x60")]
	[Token(Token = "0x600002F")]
	private override IEnumerator global::System.Collections.IEnumerable.GetEnumerator() { }

	[Address(RVA = "0x3BE9B54", Offset = "0x3BE9B54", Length = "0x78")]
	[Token(Token = "0x600002B")]
	public override bool Remove(KeyValuePair<String, String> item) { }

	[Address(RVA = "0x3BE9C34", Offset = "0x3BE9C34", Length = "0xD8")]
	[Token(Token = "0x6000038")]
	public override bool Remove(string key) { }

	[Address(RVA = "0x3BE8E8C", Offset = "0x3BE8E8C", Length = "0x4")]
	[Token(Token = "0x6000024")]
	public override void set_Item(string key, string value) { }

	[Address(RVA = "0x3BE8E90", Offset = "0x3BE8E90", Length = "0xD4")]
	[Token(Token = "0x6000035")]
	private void setitem(string key, string x) { }

	[Address(RVA = "0x3BE909C", Offset = "0x3BE909C", Length = "0xC8")]
	[Token(Token = "0x6000032")]
	private uint size() { }

	[Address(RVA = "0x3BE8F64", Offset = "0x3BE8F64", Length = "0x5C")]
	[Token(Token = "0x6000025")]
	public override bool TryGetValue(string key, out string value) { }

}

