namespace Firebase;

[Token(Token = "0x2000012")]
public sealed class FirebaseApp : IDisposable
{
	[CompilerGenerated]
	[Token(Token = "0x2000015")]
	private sealed class <>c
	{
		[Token(Token = "0x400003F")]
		public static readonly <>c <>9; //Field offset: 0x0
		[Token(Token = "0x4000040")]
		public static CreateDelegate <>9__15_0; //Field offset: 0x8
		[Token(Token = "0x4000041")]
		public static Func<Boolean> <>9__48_0; //Field offset: 0x10
		[Token(Token = "0x4000042")]
		public static Func<DependencyStatus> <>9__56_0; //Field offset: 0x18
		[Token(Token = "0x4000043")]
		public static Func<Task, Task`1<DependencyStatus>> <>9__57_1; //Field offset: 0x20
		[Token(Token = "0x4000044")]
		public static Func<Task`1<DependencyStatus>, Task`1<DependencyStatus>> <>9__57_0; //Field offset: 0x28
		[Token(Token = "0x4000045")]
		public static Action<Task> <>9__60_1; //Field offset: 0x30

		[Address(RVA = "0x3BF0578", Offset = "0x3BF0578", Length = "0x70")]
		[Token(Token = "0x600007E")]
		private static <>c() { }

		[Address(RVA = "0x3BF05E8", Offset = "0x3BF05E8", Length = "0x8")]
		[Token(Token = "0x600007F")]
		public <>c() { }

		[Address(RVA = "0x3BF0708", Offset = "0x3BF0708", Length = "0x190")]
		[Token(Token = "0x6000083")]
		internal Task<DependencyStatus> <CheckAndFixDependenciesAsync>b__57_0(Task<DependencyStatus> checkTask) { }

		[Address(RVA = "0x3BF0898", Offset = "0x3BF0898", Length = "0x4C")]
		[Token(Token = "0x6000084")]
		internal Task<DependencyStatus> <CheckAndFixDependenciesAsync>b__57_1(Task t) { }

		[Address(RVA = "0x3BF0688", Offset = "0x3BF0688", Length = "0x80")]
		[Token(Token = "0x6000082")]
		internal DependencyStatus <CheckDependenciesAsync>b__56_0() { }

		[Address(RVA = "0x3BF05F0", Offset = "0x3BF05F0", Length = "0x4C")]
		[Token(Token = "0x6000080")]
		internal FirebaseApp <Create>b__15_0() { }

		[Address(RVA = "0x3BF063C", Offset = "0x3BF063C", Length = "0x4C")]
		[Token(Token = "0x6000081")]
		internal bool <CreateAndTrack>b__48_0() { }

		[Address(RVA = "0x3BF08E4", Offset = "0x3BF08E4", Length = "0x98")]
		[Token(Token = "0x6000085")]
		internal void <FixDependenciesAsync>b__60_1(Task t) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x2000016")]
	private sealed class <>c__DisplayClass58_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000046")]
		public DependencyStatus status; //Field offset: 0x10

		[Address(RVA = "0x3BEF9DC", Offset = "0x3BEF9DC", Length = "0x8")]
		[Token(Token = "0x6000086")]
		public <>c__DisplayClass58_0() { }

		[Address(RVA = "0x3BF097C", Offset = "0x3BF097C", Length = "0x58")]
		[Token(Token = "0x6000087")]
		internal void <CheckDependencies>b__0() { }

	}

	[CompilerGenerated]
	[Token(Token = "0x2000017")]
	private sealed class <>c__DisplayClass60_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000047")]
		public Task task; //Field offset: 0x10

		[Address(RVA = "0x3BEFD90", Offset = "0x3BEFD90", Length = "0x8")]
		[Token(Token = "0x6000088")]
		public <>c__DisplayClass60_0() { }

		[Address(RVA = "0x3BF09D4", Offset = "0x3BF09D4", Length = "0x114")]
		[Token(Token = "0x6000089")]
		internal void <FixDependenciesAsync>b__0() { }

	}

	[Token(Token = "0x2000014")]
	private sealed class CreateDelegate : MulticastDelegate
	{

		[Address(RVA = "0x3BECD94", Offset = "0x3BECD94", Length = "0xD0")]
		[Token(Token = "0x600007C")]
		public CreateDelegate(object object, IntPtr method) { }

		[Address(RVA = "0x3BF0564", Offset = "0x3BF0564", Length = "0x14")]
		[Token(Token = "0x600007D")]
		public override FirebaseApp Invoke() { }

	}

	[Token(Token = "0x2000013")]
	internal class EnableModuleParams
	{
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState::Never (0))]
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x400003C")]
		private string <CppModuleName>k__BackingField; //Field offset: 0x10
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState::Never (0))]
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400003D")]
		private string <CSharpClassName>k__BackingField; //Field offset: 0x18
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState::Never (0))]
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400003E")]
		private bool <AlwaysEnable>k__BackingField; //Field offset: 0x20

		[Token(Token = "0x17000013")]
		public bool AlwaysEnable
		{
			[Address(RVA = "0x3BF0554", Offset = "0x3BF0554", Length = "0x8")]
			[CompilerGenerated]
			[Token(Token = "0x6000079")]
			 get { } //Length: 8
			[Address(RVA = "0x3BF055C", Offset = "0x3BF055C", Length = "0x8")]
			[CompilerGenerated]
			[Token(Token = "0x600007A")]
			 set { } //Length: 8
		}

		[Token(Token = "0x17000011")]
		public string CppModuleName
		{
			[Address(RVA = "0x3BF0534", Offset = "0x3BF0534", Length = "0x8")]
			[CompilerGenerated]
			[Token(Token = "0x6000075")]
			 get { } //Length: 8
			[Address(RVA = "0x3BF053C", Offset = "0x3BF053C", Length = "0x8")]
			[CompilerGenerated]
			[Token(Token = "0x6000076")]
			 set { } //Length: 8
		}

		[Token(Token = "0x17000012")]
		public string CSharpClassName
		{
			[Address(RVA = "0x3BF0544", Offset = "0x3BF0544", Length = "0x8")]
			[CompilerGenerated]
			[Token(Token = "0x6000077")]
			 get { } //Length: 8
			[Address(RVA = "0x3BF054C", Offset = "0x3BF054C", Length = "0x8")]
			[CompilerGenerated]
			[Token(Token = "0x6000078")]
			 set { } //Length: 8
		}

		[Address(RVA = "0x3BEEA74", Offset = "0x3BEEA74", Length = "0x58")]
		[Token(Token = "0x600007B")]
		public EnableModuleParams(string csharp, string cpp, bool always = false) { }

		[Address(RVA = "0x3BF0554", Offset = "0x3BF0554", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6000079")]
		public bool get_AlwaysEnable() { }

		[Address(RVA = "0x3BF0534", Offset = "0x3BF0534", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6000075")]
		public string get_CppModuleName() { }

		[Address(RVA = "0x3BF0544", Offset = "0x3BF0544", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6000077")]
		public string get_CSharpClassName() { }

		[Address(RVA = "0x3BF055C", Offset = "0x3BF055C", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x600007A")]
		public void set_AlwaysEnable(bool value) { }

		[Address(RVA = "0x3BF053C", Offset = "0x3BF053C", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6000076")]
		public void set_CppModuleName(string value) { }

		[Address(RVA = "0x3BF054C", Offset = "0x3BF054C", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6000078")]
		public void set_CSharpClassName(string value) { }

	}

	[Token(Token = "0x400002F")]
	internal static readonly object disposeLock; //Field offset: 0x0
	[Token(Token = "0x4000032")]
	private static Dictionary<String, FirebaseApp> nameToProxy; //Field offset: 0x8
	[Token(Token = "0x4000033")]
	private static Dictionary<IntPtr, FirebaseApp> cPtrToProxy; //Field offset: 0x10
	[Token(Token = "0x4000034")]
	private static bool AppUtilCallbacksInitialized; //Field offset: 0x18
	[Token(Token = "0x4000035")]
	private static object AppUtilCallbacksLock; //Field offset: 0x20
	[Token(Token = "0x4000036")]
	private static bool PreventOnAllAppsDestroyed; //Field offset: 0x28
	[Token(Token = "0x4000037")]
	private static bool crashlyticsInitializationAttempted; //Field offset: 0x29
	[Token(Token = "0x4000038")]
	private static bool userAgentRegistered; //Field offset: 0x2A
	[Token(Token = "0x4000039")]
	private static int CheckDependenciesThread; //Field offset: 0x2C
	[Token(Token = "0x400003A")]
	private static object CheckDependenciesThreadLock; //Field offset: 0x30
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x400002D")]
	private HandleRef swigCPtr; //Field offset: 0x10
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400002E")]
	private bool swigCMemOwn; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000030")]
	private string name; //Field offset: 0x28
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState::Never (0))]
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000031")]
	private EventHandler AppDisposed; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400003B")]
	private FirebaseAppPlatform appPlatform; //Field offset: 0x38

	[Token(Token = "0x1700000C")]
	public static FirebaseApp DefaultInstance
	{
		[Address(RVA = "0x3BEC818", Offset = "0x3BEC818", Length = "0x74")]
		[Token(Token = "0x6000059")]
		 get { } //Length: 116
	}

	[Token(Token = "0x17000010")]
	public static string DefaultName
	{
		[Address(RVA = "0x3BEC88C", Offset = "0x3BEC88C", Length = "0xB8")]
		[Token(Token = "0x6000074")]
		 get { } //Length: 184
	}

	[Token(Token = "0x1700000E")]
	public static LogLevel LogLevel
	{
		[Address(RVA = "0x3BED974", Offset = "0x3BED974", Length = "0x4C")]
		[Token(Token = "0x600005D")]
		 get { } //Length: 76
	}

	[Token(Token = "0x1700000D")]
	public string Name
	{
		[Address(RVA = "0x3BED884", Offset = "0x3BED884", Length = "0x48")]
		[Token(Token = "0x600005C")]
		 get { } //Length: 72
	}

	[Token(Token = "0x1700000F")]
	internal string NameInternal
	{
		[Address(RVA = "0x3BEC14C", Offset = "0x3BEC14C", Length = "0xC8")]
		[Token(Token = "0x600006E")]
		internal get { } //Length: 200
	}

	[Address(RVA = "0x3BEC4EC", Offset = "0x3BEC4EC", Length = "0x1D8")]
	[Token(Token = "0x6000057")]
	private static FirebaseApp() { }

	[Address(RVA = "0x3BEBEC0", Offset = "0x3BEBEC0", Length = "0x70")]
	[Token(Token = "0x6000052")]
	internal FirebaseApp(IntPtr cPtr, bool cMemoryOwn) { }

	[Address(RVA = "0x3BEDA28", Offset = "0x3BEDA28", Length = "0x188")]
	[Token(Token = "0x600005E")]
	private void AddReference() { }

	[Address(RVA = "0x3BEF170", Offset = "0x3BEF170", Length = "0xB4")]
	[Token(Token = "0x6000073")]
	internal static void AppSetDefaultConfigPath(string path) { }

	[Address(RVA = "0x3BEF7B8", Offset = "0x3BEF7B8", Length = "0x150")]
	[Token(Token = "0x6000069")]
	public static Task<DependencyStatus> CheckAndFixDependenciesAsync() { }

	[Address(RVA = "0x3BEF908", Offset = "0x3BEF908", Length = "0xD4")]
	[Token(Token = "0x600006A")]
	private static DependencyStatus CheckDependencies() { }

	[Address(RVA = "0x3BEF614", Offset = "0x3BEF614", Length = "0x1A4")]
	[Token(Token = "0x6000068")]
	public static Task<DependencyStatus> CheckDependenciesAsync() { }

	[Address(RVA = "0x3BEF9E4", Offset = "0x3BEF9E4", Length = "0x208")]
	[Token(Token = "0x600006B")]
	private static DependencyStatus CheckDependenciesInternal() { }

	[Address(RVA = "0x3BECAF0", Offset = "0x3BECAF0", Length = "0x104")]
	[Token(Token = "0x600005B")]
	public static FirebaseApp Create() { }

	[Address(RVA = "0x3BECE64", Offset = "0x3BECE64", Length = "0xA20")]
	[Token(Token = "0x6000064")]
	private static FirebaseApp CreateAndTrack(CreateDelegate createDelegate, FirebaseApp existingProxy) { }

	[Address(RVA = "0x3BF0194", Offset = "0x3BF0194", Length = "0x118")]
	[Token(Token = "0x600006F")]
	internal static FirebaseApp CreateInternal() { }

	[Address(RVA = "0x3BEC0E8", Offset = "0x3BEC0E8", Length = "0x64")]
	[Token(Token = "0x6000055")]
	public override void Dispose() { }

	[Address(RVA = "0x3BEC02C", Offset = "0x3BEC02C", Length = "0xBC")]
	[Token(Token = "0x6000056")]
	public void Dispose(bool disposing) { }

	[Address(RVA = "0x3BEBFA8", Offset = "0x3BEBFA8", Length = "0x84")]
	[Token(Token = "0x6000054")]
	protected virtual void Finalize() { }

	[Address(RVA = "0x3BEFCA4", Offset = "0x3BEFCA4", Length = "0xEC")]
	[Token(Token = "0x600006C")]
	public static Task FixDependenciesAsync() { }

	[Address(RVA = "0x3BEC818", Offset = "0x3BEC818", Length = "0x74")]
	[Token(Token = "0x6000059")]
	public static FirebaseApp get_DefaultInstance() { }

	[Address(RVA = "0x3BEC88C", Offset = "0x3BEC88C", Length = "0xB8")]
	[Token(Token = "0x6000074")]
	public static string get_DefaultName() { }

	[Address(RVA = "0x3BED974", Offset = "0x3BED974", Length = "0x4C")]
	[Token(Token = "0x600005D")]
	public static LogLevel get_LogLevel() { }

	[Address(RVA = "0x3BED884", Offset = "0x3BED884", Length = "0x48")]
	[Token(Token = "0x600005C")]
	public string get_Name() { }

	[Address(RVA = "0x3BEC14C", Offset = "0x3BEC14C", Length = "0xC8")]
	[Token(Token = "0x600006E")]
	internal string get_NameInternal() { }

	[Address(RVA = "0x3BEBF30", Offset = "0x3BEBF30", Length = "0x78")]
	[Token(Token = "0x6000053")]
	internal static HandleRef getCPtr(FirebaseApp obj) { }

	[Address(RVA = "0x3BEC944", Offset = "0x3BEC944", Length = "0x1AC")]
	[Token(Token = "0x600005A")]
	public static FirebaseApp GetInstance(string name) { }

	[Address(RVA = "0x3BEDE44", Offset = "0x3BEDE44", Length = "0xC30")]
	[Token(Token = "0x6000061")]
	private static void InitializeAppUtilCallbacks() { }

	[Address(RVA = "0x3BEED04", Offset = "0x3BEED04", Length = "0x2CC")]
	[Token(Token = "0x6000063")]
	private static bool InitializeCrashlyticsIfPresent() { }

	[Address(RVA = "0x3BEF310", Offset = "0x3BEF310", Length = "0x110")]
	[Token(Token = "0x6000067")]
	private static bool IsCheckDependenciesRunning() { }

	[Address(RVA = "0x3BEF224", Offset = "0x3BEF224", Length = "0xEC")]
	[Token(Token = "0x6000072")]
	internal static void LogHeartbeatInternal(FirebaseApp app) { }

	[Address(RVA = "0x3BEDC9C", Offset = "0x3BEDC9C", Length = "0x1A8")]
	[Token(Token = "0x6000062")]
	private static void OnAllAppsDestroyed() { }

	[Address(RVA = "0x3BEF0A8", Offset = "0x3BEF0A8", Length = "0xC8")]
	[Token(Token = "0x6000071")]
	internal static void RegisterLibrariesInternal(StringStringMap libraries) { }

	[Address(RVA = "0x3BEDBB0", Offset = "0x3BEDBB0", Length = "0xEC")]
	[Token(Token = "0x6000070")]
	internal static void ReleaseReferenceInternal(FirebaseApp app) { }

	[Address(RVA = "0x3BEC214", Offset = "0x3BEC214", Length = "0x2D8")]
	[Token(Token = "0x600005F")]
	private void RemoveReference() { }

	[Address(RVA = "0x3BEFD98", Offset = "0x3BEFD98", Length = "0x1A8")]
	[Token(Token = "0x600006D")]
	private static void ResetDefaultAppCPtr() { }

	[Address(RVA = "0x3BEF420", Offset = "0x3BEF420", Length = "0x1F4")]
	[Token(Token = "0x6000065")]
	private static void SetCheckDependenciesThread(int threadId) { }

	[Address(RVA = "0x3BECBF4", Offset = "0x3BECBF4", Length = "0x1A0")]
	[Token(Token = "0x6000066")]
	private static void ThrowIfCheckDependenciesRunning() { }

	[Address(RVA = "0x3BED8CC", Offset = "0x3BED8CC", Length = "0xA8")]
	[Token(Token = "0x6000060")]
	private void ThrowIfNull() { }

	[Address(RVA = "0x3BEC6C4", Offset = "0x3BEC6C4", Length = "0x154")]
	[Token(Token = "0x6000058")]
	internal static void TranslateDllNotFoundException(Action closureToExecute) { }

}

