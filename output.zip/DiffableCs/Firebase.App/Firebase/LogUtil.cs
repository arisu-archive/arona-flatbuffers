namespace Firebase;

[Token(Token = "0x2000006")]
internal sealed class LogUtil : IDisposable
{
	[Token(Token = "0x2000007")]
	public sealed class LogMessageDelegate : MulticastDelegate
	{

		[Address(RVA = "0x3BE7CF8", Offset = "0x3BE7CF8", Length = "0xD8")]
		[Token(Token = "0x6000014")]
		public LogMessageDelegate(object object, IntPtr method) { }

		[Address(RVA = "0x3BE7FDC", Offset = "0x3BE7FDC", Length = "0x14")]
		[Token(Token = "0x6000015")]
		public override void Invoke(LogLevel log_level, string message) { }

	}

	[Token(Token = "0x4000012")]
	private static LogUtil _instance; //Field offset: 0x0
	[Token(Token = "0x4000013")]
	private static object InitializeLoggingLock; //Field offset: 0x8
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000014")]
	private bool _disposed; //Field offset: 0x10

	[Address(RVA = "0x3BE7904", Offset = "0x3BE7904", Length = "0xC8")]
	[Token(Token = "0x600000A")]
	private static LogUtil() { }

	[Address(RVA = "0x3BE79CC", Offset = "0x3BE79CC", Length = "0xF0")]
	[Token(Token = "0x600000F")]
	public LogUtil() { }

	[Address(RVA = "0x3BE7FB4", Offset = "0x3BE7FB4", Length = "0x28")]
	[CompilerGenerated]
	[Token(Token = "0x6000013")]
	private void <.ctor>b__9_0(object sender, EventArgs e) { }

	[Address(RVA = "0x3BE7C5C", Offset = "0x3BE7C5C", Length = "0xC")]
	[Token(Token = "0x600000C")]
	internal static PlatformLogLevel ConvertLogLevel(LogLevel logLevel) { }

	[Address(RVA = "0x3BE7F44", Offset = "0x3BE7F44", Length = "0x70")]
	[Token(Token = "0x6000011")]
	public override void Dispose() { }

	[Address(RVA = "0x3BE7F1C", Offset = "0x3BE7F1C", Length = "0x28")]
	[Token(Token = "0x6000012")]
	protected void Dispose(bool disposing) { }

	[Address(RVA = "0x3BE7E84", Offset = "0x3BE7E84", Length = "0x98")]
	[Token(Token = "0x6000010")]
	protected virtual void Finalize() { }

	[Address(RVA = "0x3BE7ABC", Offset = "0x3BE7ABC", Length = "0xEC")]
	[Token(Token = "0x600000B")]
	public static void InitializeLogging() { }

	[Address(RVA = "0x3BE7C68", Offset = "0x3BE7C68", Length = "0x90")]
	[Token(Token = "0x600000D")]
	internal static void LogMessage(LogLevel logLevel, string message) { }

	[Address(RVA = "0x3BE7860", Offset = "0x3BE7860", Length = "0xA4")]
	[MonoPInvokeCallback(typeof(LogMessageDelegate))]
	[Token(Token = "0x600000E")]
	internal static void LogMessageFromCallback(LogLevel logLevel, string message) { }

}

