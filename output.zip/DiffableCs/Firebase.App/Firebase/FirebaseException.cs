namespace Firebase;

[Token(Token = "0x2000003")]
public sealed class FirebaseException : Exception
{
	[CompilerGenerated]
	[DebuggerBrowsable(DebuggerBrowsableState::Never (0))]
	[FieldOffset(Offset = "0x8C")]
	[Token(Token = "0x400000A")]
	private int <ErrorCode>k__BackingField; //Field offset: 0x8C

	[Token(Token = "0x17000001")]
	private int ErrorCode
	{
		[Address(RVA = "0x3BE747C", Offset = "0x3BE747C", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6000002")]
		private set { } //Length: 8
	}

	[Address(RVA = "0x3BE7408", Offset = "0x3BE7408", Length = "0x74")]
	[Token(Token = "0x6000001")]
	public FirebaseException(int errorCode, string message) { }

	[Address(RVA = "0x3BE747C", Offset = "0x3BE747C", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6000002")]
	private void set_ErrorCode(int value) { }

}

