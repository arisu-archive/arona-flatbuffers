namespace Firebase;

[Token(Token = "0x2000005")]
internal class ErrorMessages
{
	[Token(Token = "0x400000C")]
	private static string DEPENDENCY_NOT_FOUND_ERROR_ANDROID; //Field offset: 0x0
	[Token(Token = "0x400000D")]
	private static string DEPENDENCY_NOT_FOUND_ERROR_IOS; //Field offset: 0x8
	[Token(Token = "0x400000E")]
	private static string DEPENDENCY_NOT_FOUND_ERROR_GENERIC; //Field offset: 0x10
	[Token(Token = "0x400000F")]
	private static string DLL_NOT_FOUND_ERROR_ANDROID; //Field offset: 0x18
	[Token(Token = "0x4000010")]
	private static string DLL_NOT_FOUND_ERROR_IOS; //Field offset: 0x20
	[Token(Token = "0x4000011")]
	private static string DLL_NOT_FOUND_ERROR_GENERIC; //Field offset: 0x28

	[Token(Token = "0x17000003")]
	internal static string DependencyNotFoundErrorMessage
	{
		[Address(RVA = "0x3BE758C", Offset = "0x3BE758C", Length = "0xB0")]
		[Token(Token = "0x6000007")]
		internal get { } //Length: 176
	}

	[Token(Token = "0x17000004")]
	internal static string DllNotFoundExceptionErrorMessage
	{
		[Address(RVA = "0x3BE763C", Offset = "0x3BE763C", Length = "0xD8")]
		[Token(Token = "0x6000008")]
		internal get { } //Length: 216
	}

	[Address(RVA = "0x3BE7714", Offset = "0x3BE7714", Length = "0x14C")]
	[Token(Token = "0x6000009")]
	private static ErrorMessages() { }

	[Address(RVA = "0x3BE758C", Offset = "0x3BE758C", Length = "0xB0")]
	[Token(Token = "0x6000007")]
	internal static string get_DependencyNotFoundErrorMessage() { }

	[Address(RVA = "0x3BE763C", Offset = "0x3BE763C", Length = "0xD8")]
	[Token(Token = "0x6000008")]
	internal static string get_DllNotFoundExceptionErrorMessage() { }

}

