namespace Firebase.Platform;

[Token(Token = "0x2000024")]
internal class FirebaseAppPlatform
{

}

