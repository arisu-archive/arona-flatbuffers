namespace Firebase.Platform;

[Token(Token = "0x2000023")]
internal class FirebaseAppUtils : IFirebaseAppUtils
{
	[Token(Token = "0x400006C")]
	private static FirebaseAppUtils instance; //Field offset: 0x0

	[Token(Token = "0x17000017")]
	public static FirebaseAppUtils Instance
	{
		[Address(RVA = "0x3BEEFD0", Offset = "0x3BEEFD0", Length = "0x58")]
		[Token(Token = "0x60000DD")]
		 get { } //Length: 88
	}

	[Address(RVA = "0x3BF2934", Offset = "0x3BF2934", Length = "0x70")]
	[Token(Token = "0x60000E2")]
	private static FirebaseAppUtils() { }

	[Address(RVA = "0x3BF292C", Offset = "0x3BF292C", Length = "0x8")]
	[Token(Token = "0x60000E1")]
	public FirebaseAppUtils() { }

	[Address(RVA = "0x3BEEFD0", Offset = "0x3BEEFD0", Length = "0x58")]
	[Token(Token = "0x60000DD")]
	public static FirebaseAppUtils get_Instance() { }

	[Address(RVA = "0x3BF2834", Offset = "0x3BF2834", Length = "0xF8")]
	[Token(Token = "0x60000E0")]
	public override PlatformLogLevel GetLogLevel() { }

	[Address(RVA = "0x3BF2830", Offset = "0x3BF2830", Length = "0x4")]
	[Token(Token = "0x60000DF")]
	public override void PollCallbacks() { }

	[Address(RVA = "0x3BF27DC", Offset = "0x3BF27DC", Length = "0x54")]
	[Token(Token = "0x60000DE")]
	public override void TranslateDllNotFoundException(Action action) { }

}

