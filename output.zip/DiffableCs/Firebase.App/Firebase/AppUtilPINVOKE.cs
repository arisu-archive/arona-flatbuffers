namespace Firebase;

[Token(Token = "0x200001A")]
internal class AppUtilPINVOKE
{
	[Token(Token = "0x200001B")]
	internal class SWIGExceptionHelper
	{
		[Token(Token = "0x200001D")]
		internal sealed class ExceptionArgumentDelegate : MulticastDelegate
		{

			[Address(RVA = "0x3BF2340", Offset = "0x3BF2340", Length = "0xEC")]
			[Token(Token = "0x60000C5")]
			public ExceptionArgumentDelegate(object object, IntPtr method) { }

			[Address(RVA = "0x3BF2440", Offset = "0x3BF2440", Length = "0x14")]
			[Token(Token = "0x60000C6")]
			public override void Invoke(string message, string paramName) { }

		}

		[Token(Token = "0x200001C")]
		internal sealed class ExceptionDelegate : MulticastDelegate
		{

			[Address(RVA = "0x3BF2258", Offset = "0x3BF2258", Length = "0xE8")]
			[Token(Token = "0x60000C3")]
			public ExceptionDelegate(object object, IntPtr method) { }

			[Address(RVA = "0x3BF242C", Offset = "0x3BF242C", Length = "0x14")]
			[Token(Token = "0x60000C4")]
			public override void Invoke(string message) { }

		}

		[Token(Token = "0x400005A")]
		private static ExceptionDelegate applicationDelegate; //Field offset: 0x0
		[Token(Token = "0x400005B")]
		private static ExceptionDelegate arithmeticDelegate; //Field offset: 0x8
		[Token(Token = "0x400005C")]
		private static ExceptionDelegate divideByZeroDelegate; //Field offset: 0x10
		[Token(Token = "0x400005D")]
		private static ExceptionDelegate indexOutOfRangeDelegate; //Field offset: 0x18
		[Token(Token = "0x400005E")]
		private static ExceptionDelegate invalidCastDelegate; //Field offset: 0x20
		[Token(Token = "0x400005F")]
		private static ExceptionDelegate invalidOperationDelegate; //Field offset: 0x28
		[Token(Token = "0x4000060")]
		private static ExceptionDelegate ioDelegate; //Field offset: 0x30
		[Token(Token = "0x4000061")]
		private static ExceptionDelegate nullReferenceDelegate; //Field offset: 0x38
		[Token(Token = "0x4000062")]
		private static ExceptionDelegate outOfMemoryDelegate; //Field offset: 0x40
		[Token(Token = "0x4000063")]
		private static ExceptionDelegate overflowDelegate; //Field offset: 0x48
		[Token(Token = "0x4000064")]
		private static ExceptionDelegate systemDelegate; //Field offset: 0x50
		[Token(Token = "0x4000065")]
		private static ExceptionArgumentDelegate argumentDelegate; //Field offset: 0x58
		[Token(Token = "0x4000066")]
		private static ExceptionArgumentDelegate argumentNullDelegate; //Field offset: 0x60
		[Token(Token = "0x4000067")]
		private static ExceptionArgumentDelegate argumentOutOfRangeDelegate; //Field offset: 0x68

		[Address(RVA = "0x3BF1DEC", Offset = "0x3BF1DEC", Length = "0x46C")]
		[Token(Token = "0x60000C1")]
		private static SWIGExceptionHelper() { }

		[Address(RVA = "0x3BF0C48", Offset = "0x3BF0C48", Length = "0x8")]
		[Token(Token = "0x60000C2")]
		public SWIGExceptionHelper() { }

		[Address(RVA = "0x3BF10F8", Offset = "0x3BF10F8", Length = "0x94")]
		[MonoPInvokeCallback(typeof(ExceptionDelegate))]
		[Token(Token = "0x60000B3")]
		private static void SetPendingApplicationException(string message) { }

		[Address(RVA = "0x3BF1754", Offset = "0x3BF1754", Length = "0xA4")]
		[MonoPInvokeCallback(typeof(ExceptionArgumentDelegate))]
		[Token(Token = "0x60000BE")]
		private static void SetPendingArgumentException(string message, string paramName) { }

		[Address(RVA = "0x3BF17F8", Offset = "0x3BF17F8", Length = "0xE8")]
		[MonoPInvokeCallback(typeof(ExceptionArgumentDelegate))]
		[Token(Token = "0x60000BF")]
		private static void SetPendingArgumentNullException(string message, string paramName) { }

		[Address(RVA = "0x3BF18E0", Offset = "0x3BF18E0", Length = "0xE8")]
		[MonoPInvokeCallback(typeof(ExceptionArgumentDelegate))]
		[Token(Token = "0x60000C0")]
		private static void SetPendingArgumentOutOfRangeException(string message, string paramName) { }

		[Address(RVA = "0x3BF118C", Offset = "0x3BF118C", Length = "0x94")]
		[MonoPInvokeCallback(typeof(ExceptionDelegate))]
		[Token(Token = "0x60000B4")]
		private static void SetPendingArithmeticException(string message) { }

		[Address(RVA = "0x3BF1220", Offset = "0x3BF1220", Length = "0x94")]
		[MonoPInvokeCallback(typeof(ExceptionDelegate))]
		[Token(Token = "0x60000B5")]
		private static void SetPendingDivideByZeroException(string message) { }

		[Address(RVA = "0x3BF12B4", Offset = "0x3BF12B4", Length = "0x94")]
		[MonoPInvokeCallback(typeof(ExceptionDelegate))]
		[Token(Token = "0x60000B6")]
		private static void SetPendingIndexOutOfRangeException(string message) { }

		[Address(RVA = "0x3BF1348", Offset = "0x3BF1348", Length = "0x94")]
		[MonoPInvokeCallback(typeof(ExceptionDelegate))]
		[Token(Token = "0x60000B7")]
		private static void SetPendingInvalidCastException(string message) { }

		[Address(RVA = "0x3BF13DC", Offset = "0x3BF13DC", Length = "0x94")]
		[MonoPInvokeCallback(typeof(ExceptionDelegate))]
		[Token(Token = "0x60000B8")]
		private static void SetPendingInvalidOperationException(string message) { }

		[Address(RVA = "0x3BF1470", Offset = "0x3BF1470", Length = "0x94")]
		[MonoPInvokeCallback(typeof(ExceptionDelegate))]
		[Token(Token = "0x60000B9")]
		private static void SetPendingIOException(string message) { }

		[Address(RVA = "0x3BF1504", Offset = "0x3BF1504", Length = "0x94")]
		[MonoPInvokeCallback(typeof(ExceptionDelegate))]
		[Token(Token = "0x60000BA")]
		private static void SetPendingNullReferenceException(string message) { }

		[Address(RVA = "0x3BF1598", Offset = "0x3BF1598", Length = "0x94")]
		[MonoPInvokeCallback(typeof(ExceptionDelegate))]
		[Token(Token = "0x60000BB")]
		private static void SetPendingOutOfMemoryException(string message) { }

		[Address(RVA = "0x3BF162C", Offset = "0x3BF162C", Length = "0x94")]
		[MonoPInvokeCallback(typeof(ExceptionDelegate))]
		[Token(Token = "0x60000BC")]
		private static void SetPendingOverflowException(string message) { }

		[Address(RVA = "0x3BF16C0", Offset = "0x3BF16C0", Length = "0x94")]
		[MonoPInvokeCallback(typeof(ExceptionDelegate))]
		[Token(Token = "0x60000BD")]
		private static void SetPendingSystemException(string message) { }

		[Address(RVA = "0x3BF19C8", Offset = "0x3BF19C8", Length = "0x170")]
		[Token(Token = "0x60000B1")]
		public static void SWIGRegisterExceptionCallbacks_AppUtil(ExceptionDelegate applicationDelegate, ExceptionDelegate arithmeticDelegate, ExceptionDelegate divideByZeroDelegate, ExceptionDelegate indexOutOfRangeDelegate, ExceptionDelegate invalidCastDelegate, ExceptionDelegate invalidOperationDelegate, ExceptionDelegate ioDelegate, ExceptionDelegate nullReferenceDelegate, ExceptionDelegate outOfMemoryDelegate, ExceptionDelegate overflowDelegate, ExceptionDelegate systemExceptionDelegate) { }

		[Address(RVA = "0x3BF1B38", Offset = "0x3BF1B38", Length = "0xB4")]
		[Token(Token = "0x60000B2")]
		public static void SWIGRegisterExceptionCallbacksArgument_AppUtil(ExceptionArgumentDelegate argumentDelegate, ExceptionArgumentDelegate argumentNullDelegate, ExceptionArgumentDelegate argumentOutOfRangeDelegate) { }

	}

	[Token(Token = "0x200001E")]
	internal class SWIGPendingException
	{
		[ThreadStatic]
		[Token(Token = "0x4000068")]
		private static Exception pendingException; //Field offset: 0x80000000
		[Token(Token = "0x4000069")]
		private static int numExceptionsPending; //Field offset: 0x0
		[Token(Token = "0x400006A")]
		private static object exceptionsLock; //Field offset: 0x8

		[Token(Token = "0x17000014")]
		public static bool Pending
		{
			[Address(RVA = "0x3BE84E4", Offset = "0x3BE84E4", Length = "0x88")]
			[Token(Token = "0x60000C7")]
			 get { } //Length: 136
		}

		[Address(RVA = "0x3BF2454", Offset = "0x3BF2454", Length = "0xB0")]
		[Token(Token = "0x60000CA")]
		private static SWIGPendingException() { }

		[Address(RVA = "0x3BE84E4", Offset = "0x3BE84E4", Length = "0x88")]
		[Token(Token = "0x60000C7")]
		public static bool get_Pending() { }

		[Address(RVA = "0x3BE856C", Offset = "0x3BE856C", Length = "0x17C")]
		[Token(Token = "0x60000C9")]
		public static Exception Retrieve() { }

		[Address(RVA = "0x3BF1BEC", Offset = "0x3BF1BEC", Length = "0x200")]
		[Token(Token = "0x60000C8")]
		public static void Set(Exception e) { }

	}

	[Token(Token = "0x200001F")]
	internal class SWIGStringHelper
	{
		[Token(Token = "0x2000020")]
		internal sealed class SWIGStringDelegate : MulticastDelegate
		{

			[Address(RVA = "0x3BF2634", Offset = "0x3BF2634", Length = "0xE8")]
			[Token(Token = "0x60000CF")]
			public SWIGStringDelegate(object object, IntPtr method) { }

			[Address(RVA = "0x3BF271C", Offset = "0x3BF271C", Length = "0x14")]
			[Token(Token = "0x60000D0")]
			public override string Invoke(string message) { }

		}

		[Token(Token = "0x400006B")]
		private static SWIGStringDelegate stringDelegate; //Field offset: 0x0

		[Address(RVA = "0x3BF2588", Offset = "0x3BF2588", Length = "0xAC")]
		[Token(Token = "0x60000CD")]
		private static SWIGStringHelper() { }

		[Address(RVA = "0x3BF0C50", Offset = "0x3BF0C50", Length = "0x8")]
		[Token(Token = "0x60000CE")]
		public SWIGStringHelper() { }

		[Address(RVA = "0x3BF2504", Offset = "0x3BF2504", Length = "0x4")]
		[MonoPInvokeCallback(typeof(SWIGStringDelegate))]
		[Token(Token = "0x60000CC")]
		private static string CreateString(string cString) { }

		[Address(RVA = "0x3BF2508", Offset = "0x3BF2508", Length = "0x80")]
		[Token(Token = "0x60000CB")]
		public static void SWIGRegisterStringCallback_AppUtil(SWIGStringDelegate stringDelegate) { }

	}

	[Token(Token = "0x4000058")]
	protected static SWIGExceptionHelper swigExceptionHelper; //Field offset: 0x0
	[Token(Token = "0x4000059")]
	protected static SWIGStringHelper swigStringHelper; //Field offset: 0x8

	[Address(RVA = "0x3BF0B84", Offset = "0x3BF0B84", Length = "0xC4")]
	[Token(Token = "0x600008A")]
	private static AppUtilPINVOKE() { }

	[Address(RVA = "0x3BF0CBC", Offset = "0x3BF0CBC", Length = "0x7C")]
	[Token(Token = "0x60000A7")]
	public static void AppEnableLogCallback(bool jarg1) { }

	[Address(RVA = "0x3BF0F60", Offset = "0x3BF0F60", Length = "0x68")]
	[Token(Token = "0x60000AC")]
	public static int CheckAndroidDependencies() { }

	[Address(RVA = "0x3BE8324", Offset = "0x3BE8324", Length = "0x7C")]
	[Token(Token = "0x600008B")]
	public static void delete_FutureBase(HandleRef jarg1) { }

	[Address(RVA = "0x3BEB1DC", Offset = "0x3BEB1DC", Length = "0x7C")]
	[Token(Token = "0x600009D")]
	public static void delete_FutureVoid(HandleRef jarg1) { }

	[Address(RVA = "0x3BE8D34", Offset = "0x3BE8D34", Length = "0x7C")]
	[Token(Token = "0x600009A")]
	public static void delete_StringStringMap(HandleRef jarg1) { }

	[Address(RVA = "0x3BF0420", Offset = "0x3BF0420", Length = "0x8C")]
	[Token(Token = "0x60000A4")]
	public static void FirebaseApp_AppSetDefaultConfigPath(string jarg1) { }

	[Address(RVA = "0x3BEFFEC", Offset = "0x3BEFFEC", Length = "0x68")]
	[Token(Token = "0x600009F")]
	public static IntPtr FirebaseApp_CreateInternal__SWIG_0() { }

	[Address(RVA = "0x3BF04AC", Offset = "0x3BF04AC", Length = "0x88")]
	[Token(Token = "0x60000A5")]
	public static string FirebaseApp_DefaultName_get() { }

	[Address(RVA = "0x3BED9C0", Offset = "0x3BED9C0", Length = "0x68")]
	[Token(Token = "0x60000A1")]
	internal static int FirebaseApp_GetLogLevelInternal() { }

	[Address(RVA = "0x3BF03A4", Offset = "0x3BF03A4", Length = "0x7C")]
	[Token(Token = "0x60000A3")]
	internal static void FirebaseApp_LogHeartbeatInternal(HandleRef jarg1) { }

	[Address(RVA = "0x3BF0100", Offset = "0x3BF0100", Length = "0x94")]
	[Token(Token = "0x600009E")]
	public static string FirebaseApp_NameInternal_get(HandleRef jarg1) { }

	[Address(RVA = "0x3BF0328", Offset = "0x3BF0328", Length = "0x7C")]
	[Token(Token = "0x60000A2")]
	internal static void FirebaseApp_RegisterLibrariesInternal(HandleRef jarg1) { }

	[Address(RVA = "0x3BF02AC", Offset = "0x3BF02AC", Length = "0x7C")]
	[Token(Token = "0x60000A0")]
	internal static void FirebaseApp_ReleaseReferenceInternal(HandleRef jarg1) { }

	[Address(RVA = "0x3BF0FC8", Offset = "0x3BF0FC8", Length = "0x68")]
	[Token(Token = "0x60000AD")]
	public static IntPtr FixAndroidDependencies() { }

	[Address(RVA = "0x3BE87B0", Offset = "0x3BE87B0", Length = "0x7C")]
	[Token(Token = "0x600008D")]
	public static int FutureBase_error(HandleRef jarg1) { }

	[Address(RVA = "0x3BE88F4", Offset = "0x3BE88F4", Length = "0x94")]
	[Token(Token = "0x600008E")]
	public static string FutureBase_error_message(HandleRef jarg1) { }

	[Address(RVA = "0x3BE8468", Offset = "0x3BE8468", Length = "0x7C")]
	[Token(Token = "0x600008C")]
	public static int FutureBase_status(HandleRef jarg1) { }

	[Address(RVA = "0x3BEBB7C", Offset = "0x3BEBB7C", Length = "0x7C")]
	[Token(Token = "0x600009C")]
	public static void FutureVoid_SWIG_FreeCompletionData(IntPtr jarg1) { }

	[Address(RVA = "0x3BEBAE0", Offset = "0x3BEBAE0", Length = "0x9C")]
	[Token(Token = "0x600009B")]
	public static IntPtr FutureVoid_SWIG_OnCompletion(HandleRef jarg1, SWIG_CompletionDelegate jarg2, int jarg3) { }

	[Address(RVA = "0x3BEADDC", Offset = "0x3BEADDC", Length = "0x7C")]
	[Token(Token = "0x60000B0")]
	public static IntPtr FutureVoid_SWIGUpcast(IntPtr jarg1) { }

	[Address(RVA = "0x3BF0E48", Offset = "0x3BF0E48", Length = "0x98")]
	[Token(Token = "0x60000AA")]
	public static bool GetEnabledAppCallbackByName(string jarg1) { }

	[Address(RVA = "0x3BF1030", Offset = "0x3BF1030", Length = "0x64")]
	[Token(Token = "0x60000AE")]
	internal static void InitializePlayServicesInternal() { }

	[Address(RVA = "0x3BEA2DC", Offset = "0x3BEA2DC", Length = "0x68")]
	[Token(Token = "0x600008F")]
	public static IntPtr new_StringStringMap__SWIG_0() { }

	[Address(RVA = "0x3BF0C58", Offset = "0x3BF0C58", Length = "0x64")]
	[Token(Token = "0x60000A6")]
	public static void PollCallbacks() { }

	[Address(RVA = "0x3BF0D38", Offset = "0x3BF0D38", Length = "0x7C")]
	[Token(Token = "0x60000A8")]
	public static void SetEnabledAllAppCallbacks(bool jarg1) { }

	[Address(RVA = "0x3BF0DB4", Offset = "0x3BF0DB4", Length = "0x94")]
	[Token(Token = "0x60000A9")]
	public static void SetEnabledAppCallbackByName(string jarg1, bool jarg2) { }

	[Address(RVA = "0x3BF0EE0", Offset = "0x3BF0EE0", Length = "0x80")]
	[Token(Token = "0x60000AB")]
	public static void SetLogFunction(LogMessageDelegate jarg1) { }

	[Address(RVA = "0x3BEA708", Offset = "0x3BEA708", Length = "0xBC")]
	[Token(Token = "0x6000095")]
	public static void StringStringMap_Add(HandleRef jarg1, string jarg2, string jarg3) { }

	[Address(RVA = "0x3BEA47C", Offset = "0x3BEA47C", Length = "0x7C")]
	[Token(Token = "0x6000091")]
	public static void StringStringMap_Clear(HandleRef jarg1) { }

	[Address(RVA = "0x3BEA664", Offset = "0x3BEA664", Length = "0xA4")]
	[Token(Token = "0x6000094")]
	public static bool StringStringMap_ContainsKey(HandleRef jarg1, string jarg2) { }

	[Address(RVA = "0x3BEA868", Offset = "0x3BEA868", Length = "0x7C")]
	[Token(Token = "0x6000097")]
	public static IntPtr StringStringMap_create_iterator_begin(HandleRef jarg1) { }

	[Address(RVA = "0x3BEA980", Offset = "0x3BEA980", Length = "0x84")]
	[Token(Token = "0x6000099")]
	public static void StringStringMap_destroy_iterator(HandleRef jarg1, IntPtr jarg2) { }

	[Address(RVA = "0x3BEA8E4", Offset = "0x3BEA8E4", Length = "0x9C")]
	[Token(Token = "0x6000098")]
	public static string StringStringMap_get_next_key(HandleRef jarg1, IntPtr jarg2) { }

	[Address(RVA = "0x3BEA4F8", Offset = "0x3BEA4F8", Length = "0xB0")]
	[Token(Token = "0x6000092")]
	public static string StringStringMap_getitem(HandleRef jarg1, string jarg2) { }

	[Address(RVA = "0x3BEA7C4", Offset = "0x3BEA7C4", Length = "0xA4")]
	[Token(Token = "0x6000096")]
	public static bool StringStringMap_Remove(HandleRef jarg1, string jarg2) { }

	[Address(RVA = "0x3BEA5A8", Offset = "0x3BEA5A8", Length = "0xBC")]
	[Token(Token = "0x6000093")]
	public static void StringStringMap_setitem(HandleRef jarg1, string jarg2, string jarg3) { }

	[Address(RVA = "0x3BEA344", Offset = "0x3BEA344", Length = "0x7C")]
	[Token(Token = "0x6000090")]
	public static uint StringStringMap_size(HandleRef jarg1) { }

	[Address(RVA = "0x3BF1094", Offset = "0x3BF1094", Length = "0x64")]
	[Token(Token = "0x60000AF")]
	internal static void TerminatePlayServicesInternal() { }

}

