namespace Firebase;

[Token(Token = "0x200000D")]
internal class FutureVoid : FutureBase
{
	[CompilerGenerated]
	[Token(Token = "0x2000010")]
	private sealed class <>c__DisplayClass5_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000028")]
		public FutureVoid fu; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000029")]
		public TaskCompletionSource<Int32> tcs; //Field offset: 0x18

		[Address(RVA = "0x3BEB474", Offset = "0x3BEB474", Length = "0x8")]
		[Token(Token = "0x6000050")]
		public <>c__DisplayClass5_0() { }

		[Address(RVA = "0x3BEBCA8", Offset = "0x3BEBCA8", Length = "0x218")]
		[Token(Token = "0x6000051")]
		internal void <GetTask>b__0() { }

	}

	[Token(Token = "0x200000E")]
	internal sealed class Action : MulticastDelegate
	{

		[Address(RVA = "0x3BEB47C", Offset = "0x3BEB47C", Length = "0xD0")]
		[Token(Token = "0x600004C")]
		public Action(object object, IntPtr method) { }

		[Address(RVA = "0x3BEBC80", Offset = "0x3BEBC80", Length = "0x14")]
		[Token(Token = "0x600004D")]
		public override void Invoke() { }

	}

	[Token(Token = "0x200000F")]
	public sealed class SWIG_CompletionDelegate : MulticastDelegate
	{

		[Address(RVA = "0x3BEB874", Offset = "0x3BEB874", Length = "0xD8")]
		[Token(Token = "0x600004E")]
		public SWIG_CompletionDelegate(object object, IntPtr method) { }

		[Address(RVA = "0x3BEBC94", Offset = "0x3BEBC94", Length = "0x14")]
		[Token(Token = "0x600004F")]
		public override void Invoke(int index) { }

	}

	[Token(Token = "0x4000023")]
	private static Dictionary<Int32, Action> Callbacks; //Field offset: 0x0
	[Token(Token = "0x4000024")]
	private static int CallbackIndex; //Field offset: 0x8
	[Token(Token = "0x4000025")]
	private static object CallbackLock; //Field offset: 0x10
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000022")]
	private HandleRef swigCPtr; //Field offset: 0x28
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000026")]
	private IntPtr callbackData; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000027")]
	private SWIG_CompletionDelegate SWIG_CompletionCB; //Field offset: 0x40

	[Address(RVA = "0x3BEBBF8", Offset = "0x3BEBBF8", Length = "0x88")]
	[Token(Token = "0x600004B")]
	private static FutureVoid() { }

	[Address(RVA = "0x3BEACF4", Offset = "0x3BEACF4", Length = "0xE8")]
	[Token(Token = "0x6000042")]
	internal FutureVoid(IntPtr cPtr, bool cMemoryOwn) { }

	[Address(RVA = "0x3BEAE58", Offset = "0x3BEAE58", Length = "0x200")]
	[Token(Token = "0x6000043")]
	public virtual void Dispose(bool disposing) { }

	[Address(RVA = "0x3BEB258", Offset = "0x3BEB258", Length = "0x21C")]
	[Token(Token = "0x6000044")]
	public static Task GetTask(FutureVoid fu) { }

	[Address(RVA = "0x3BEB058", Offset = "0x3BEB058", Length = "0x184")]
	[Token(Token = "0x6000047")]
	private void SetCompletionData(IntPtr data) { }

	[Address(RVA = "0x3BEB54C", Offset = "0x3BEB54C", Length = "0x280")]
	[Token(Token = "0x6000046")]
	public void SetOnCompletionCallback(Action userCompletionCallback) { }

	[Address(RVA = "0x3BEAB18", Offset = "0x3BEAB18", Length = "0x1DC")]
	[MonoPInvokeCallback(typeof(SWIG_CompletionDelegate))]
	[Token(Token = "0x6000048")]
	private static void SWIG_CompletionDispatcher(int key) { }

	[Address(RVA = "0x3BEBA2C", Offset = "0x3BEBA2C", Length = "0xB4")]
	[Token(Token = "0x600004A")]
	public static void SWIG_FreeCompletionData(IntPtr data) { }

	[Address(RVA = "0x3BEB94C", Offset = "0x3BEB94C", Length = "0xE0")]
	[Token(Token = "0x6000049")]
	internal IntPtr SWIG_OnCompletion(SWIG_CompletionDelegate cs_callback, int cs_key) { }

	[Address(RVA = "0x3BEB7CC", Offset = "0x3BEB7CC", Length = "0xA8")]
	[Token(Token = "0x6000045")]
	private void ThrowIfDisposed() { }

}

