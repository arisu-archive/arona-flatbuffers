namespace Nexon.Pub;

[Token(Token = "0x2000002")]
public class NXPatcherAndroid : MonoBehaviour, INXPatcher
{
	[CompilerGenerated]
	[Token(Token = "0x2000017")]
	private sealed class <>c__DisplayClass48_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x400004B")]
		public bool isSuccess; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400004C")]
		public Error error; //Field offset: 0x18

		[Address(RVA = "0x75EFDE8", Offset = "0x75EFDE8", Length = "0x8")]
		[Token(Token = "0x6000068")]
		public <>c__DisplayClass48_0() { }

		[Address(RVA = "0x75F8170", Offset = "0x75F8170", Length = "0x70")]
		[Token(Token = "0x6000069")]
		internal void <OnInitResult>b__0() { }

	}

	[CompilerGenerated]
	[Token(Token = "0x2000018")]
	private sealed class <>c__DisplayClass51_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x400004D")]
		public BuildStatus _buildStatus; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400004E")]
		public Error error; //Field offset: 0x18

		[Address(RVA = "0x75EFE70", Offset = "0x75EFE70", Length = "0x8")]
		[Token(Token = "0x600006A")]
		public <>c__DisplayClass51_0() { }

		[Address(RVA = "0x75F81E0", Offset = "0x75F81E0", Length = "0x6C")]
		[Token(Token = "0x600006B")]
		internal void <OnCheckBuildResult>b__0() { }

	}

	[CompilerGenerated]
	[Token(Token = "0x2000019")]
	private sealed class <>c__DisplayClass55_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x400004F")]
		public int verifiedCount; //Field offset: 0x10
		[FieldOffset(Offset = "0x14")]
		[Token(Token = "0x4000050")]
		public int totalCount; //Field offset: 0x14

		[Address(RVA = "0x75EFF10", Offset = "0x75EFF10", Length = "0x8")]
		[Token(Token = "0x600006C")]
		public <>c__DisplayClass55_0() { }

		[Address(RVA = "0x75F824C", Offset = "0x75F824C", Length = "0x6C")]
		[Token(Token = "0x600006D")]
		internal void <OnCheckResourceProgress>b__0() { }

	}

	[CompilerGenerated]
	[Token(Token = "0x200001A")]
	private sealed class <>c__DisplayClass56_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000051")]
		public PatchStatus _patchStatus; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000052")]
		public DownloadInformation downloadInformation; //Field offset: 0x18
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000053")]
		public Error error; //Field offset: 0x20

		[Address(RVA = "0x75EFF18", Offset = "0x75EFF18", Length = "0x8")]
		[Token(Token = "0x600006E")]
		public <>c__DisplayClass56_0() { }

		[Address(RVA = "0x75F82B8", Offset = "0x75F82B8", Length = "0x70")]
		[Token(Token = "0x600006F")]
		internal void <OnCheckResourceResult>b__0() { }

	}

	[CompilerGenerated]
	[Token(Token = "0x200001B")]
	private sealed class <>c__DisplayClass61_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000054")]
		public DownloadInformation downloadInformation; //Field offset: 0x10

		[Address(RVA = "0x75EFFD4", Offset = "0x75EFFD4", Length = "0x8")]
		[Token(Token = "0x6000070")]
		public <>c__DisplayClass61_0() { }

		[Address(RVA = "0x75F8328", Offset = "0x75F8328", Length = "0x6C")]
		[Token(Token = "0x6000071")]
		internal void <OnDownloadProgress>b__0() { }

	}

	[CompilerGenerated]
	[Token(Token = "0x200001C")]
	private sealed class <>c__DisplayClass62_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000055")]
		public string _filename; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000056")]
		public string _path; //Field offset: 0x18

		[Address(RVA = "0x75EFFDC", Offset = "0x75EFFDC", Length = "0x8")]
		[Token(Token = "0x6000072")]
		public <>c__DisplayClass62_0() { }

		[Address(RVA = "0x75F8394", Offset = "0x75F8394", Length = "0x6C")]
		[Token(Token = "0x6000073")]
		internal void <OnFileDownloaded>b__0() { }

	}

	[CompilerGenerated]
	[Token(Token = "0x200001D")]
	private sealed class <>c__DisplayClass63_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000057")]
		public Dictionary<String, String> files; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000058")]
		public int patchVersion; //Field offset: 0x18
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000059")]
		public Error error; //Field offset: 0x20

		[Address(RVA = "0x75EFFE4", Offset = "0x75EFFE4", Length = "0x8")]
		[Token(Token = "0x6000074")]
		public <>c__DisplayClass63_0() { }

		[Address(RVA = "0x75F8400", Offset = "0x75F8400", Length = "0x74")]
		[Token(Token = "0x6000075")]
		internal void <OnComplete>b__0() { }

	}

	[CompilerGenerated]
	[Token(Token = "0x200001E")]
	private sealed class <>c__DisplayClass66_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x400005A")]
		public PatchStatus _patchStatus; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400005B")]
		public Error error; //Field offset: 0x18

		[Address(RVA = "0x75F006C", Offset = "0x75F006C", Length = "0x8")]
		[Token(Token = "0x6000076")]
		public <>c__DisplayClass66_0() { }

		[Address(RVA = "0x75F8474", Offset = "0x75F8474", Length = "0x6C")]
		[Token(Token = "0x6000077")]
		internal void <OnCheckPatchVersionResult>b__0() { }

	}

	[CompilerGenerated]
	[Token(Token = "0x200001F")]
	private sealed class <>c__DisplayClass70_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x400005C")]
		public int validatedCount; //Field offset: 0x10
		[FieldOffset(Offset = "0x14")]
		[Token(Token = "0x400005D")]
		public int totalCount; //Field offset: 0x14

		[Address(RVA = "0x75F010C", Offset = "0x75F010C", Length = "0x8")]
		[Token(Token = "0x6000078")]
		public <>c__DisplayClass70_0() { }

		[Address(RVA = "0x75F84E0", Offset = "0x75F84E0", Length = "0x6C")]
		[Token(Token = "0x6000079")]
		internal void <OnValidateResourceProgress>b__0() { }

	}

	[CompilerGenerated]
	[Token(Token = "0x2000020")]
	private sealed class <>c__DisplayClass71_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x400005E")]
		public Error error; //Field offset: 0x10

		[Address(RVA = "0x75F0114", Offset = "0x75F0114", Length = "0x8")]
		[Token(Token = "0x600007A")]
		public <>c__DisplayClass71_0() { }

		[Address(RVA = "0x75F854C", Offset = "0x75F854C", Length = "0x6C")]
		[Token(Token = "0x600007B")]
		internal void <OnValidateResourceResult>b__0() { }

	}

	[Token(Token = "0x2000004")]
	private sealed class CheckBuildResultHandler : MulticastDelegate
	{

		[Address(RVA = "0x75F3B78", Offset = "0x75F3B78", Length = "0xD8")]
		[Token(Token = "0x600003B")]
		public CheckBuildResultHandler(object object, IntPtr method) { }

		[Address(RVA = "0x75F680C", Offset = "0x75F680C", Length = "0x14")]
		[Token(Token = "0x600003C")]
		public override void Invoke(int buildStatus, int errorCode, IntPtr errorMessage) { }

	}

	[Token(Token = "0x200000A")]
	private sealed class CheckPatchVersionResultHandler : MulticastDelegate
	{

		[Address(RVA = "0x75F5198", Offset = "0x75F5198", Length = "0xD8")]
		[Token(Token = "0x6000047")]
		public CheckPatchVersionResultHandler(object object, IntPtr method) { }

		[Address(RVA = "0x75F68D0", Offset = "0x75F68D0", Length = "0x14")]
		[Token(Token = "0x6000048")]
		public override void Invoke(int patchStatus, int errorCode, IntPtr errorMessage) { }

	}

	[Token(Token = "0x2000005")]
	private sealed class CheckResourceProgressHandler : MulticastDelegate
	{

		[Address(RVA = "0x75F3C50", Offset = "0x75F3C50", Length = "0xD8")]
		[Token(Token = "0x600003D")]
		public CheckResourceProgressHandler(object object, IntPtr method) { }

		[Address(RVA = "0x75F6820", Offset = "0x75F6820", Length = "0x14")]
		[Token(Token = "0x600003E")]
		public override void Invoke(int verifiedCount, int totalCount) { }

	}

	[Token(Token = "0x2000006")]
	private sealed class CheckResourceResultHandler : MulticastDelegate
	{

		[Address(RVA = "0x75F3D28", Offset = "0x75F3D28", Length = "0xD8")]
		[Token(Token = "0x600003F")]
		public CheckResourceResultHandler(object object, IntPtr method) { }

		[Address(RVA = "0x75F6834", Offset = "0x75F6834", Length = "0x44")]
		[Token(Token = "0x6000040")]
		public override void Invoke(int patchStatus, long tTotalByte, long tDownloadedByte, int tTotalFileCount, int tDownloadedFileCount, long cTotalByte, long cDownloadedByte, int cTotalFileCount, int cDownloadedFileCount, IntPtr downloadGroupList, IntPtr patchVersionList, int targetPatchVersion, int errorCode, IntPtr errorMessage) { }

	}

	[Token(Token = "0x200000D")]
	private class CheckVersionResultHandler : AndroidJavaProxy
	{
		[CompilerGenerated]
		[Token(Token = "0x200000E")]
		private sealed class <>c__DisplayClass5_0
		{
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x4000033")]
			public CheckVersionResultHandler <>4__this; //Field offset: 0x10
			[FieldOffset(Offset = "0x18")]
			[Token(Token = "0x4000034")]
			public PatchInformation patchInformation; //Field offset: 0x18

			[Address(RVA = "0x75F6E80", Offset = "0x75F6E80", Length = "0x8")]
			[Token(Token = "0x6000051")]
			public <>c__DisplayClass5_0() { }

			[Address(RVA = "0x75F7178", Offset = "0x75F7178", Length = "0x30")]
			[Token(Token = "0x6000052")]
			internal void <onResult>b__0() { }

		}

		[CompilerGenerated]
		[Token(Token = "0x200000F")]
		private sealed class <>c__DisplayClass6_0
		{
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x4000035")]
			public CheckVersionResultHandler <>4__this; //Field offset: 0x10
			[FieldOffset(Offset = "0x18")]
			[Token(Token = "0x4000036")]
			public int verifiedCount; //Field offset: 0x18
			[FieldOffset(Offset = "0x1C")]
			[Token(Token = "0x4000037")]
			public int totalCount; //Field offset: 0x1C

			[Address(RVA = "0x75F6F80", Offset = "0x75F6F80", Length = "0x8")]
			[Token(Token = "0x6000053")]
			public <>c__DisplayClass6_0() { }

			[Address(RVA = "0x75F71A8", Offset = "0x75F71A8", Length = "0x30")]
			[Token(Token = "0x6000054")]
			internal void <onProgress>b__0() { }

		}

		[CompilerGenerated]
		[Token(Token = "0x2000010")]
		private sealed class <>c__DisplayClass7_0
		{
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x4000038")]
			public CheckVersionResultHandler <>4__this; //Field offset: 0x10
			[FieldOffset(Offset = "0x18")]
			[Token(Token = "0x4000039")]
			public Error _error; //Field offset: 0x18

			[Address(RVA = "0x75F7170", Offset = "0x75F7170", Length = "0x8")]
			[Token(Token = "0x6000055")]
			public <>c__DisplayClass7_0() { }

			[Address(RVA = "0x75F71D8", Offset = "0x75F71D8", Length = "0x30")]
			[Token(Token = "0x6000056")]
			internal void <onError>b__0() { }

		}

		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400002F")]
		private Action<PatchInformation> onResultCallback; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000030")]
		private Action<Int32, Int32> onProgressCallback; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000031")]
		private Action<Error> onErrorCallback; //Field offset: 0x30
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000032")]
		private NXPatcherThreadExecutor threadExecutor; //Field offset: 0x38

		[Address(RVA = "0x75F1250", Offset = "0x75F1250", Length = "0xD0")]
		[Token(Token = "0x600004D")]
		public CheckVersionResultHandler(Action<PatchInformation> onResultCallback, Action<Int32, Int32> onProgressCallback, Action<Error> onErrorCallback, NXPatcherThreadExecutor threadExecutor) { }

		[Address(RVA = "0x75F6F88", Offset = "0x75F6F88", Length = "0x1E8")]
		[Token(Token = "0x6000050")]
		public void onError(AndroidJavaObject error) { }

		[Address(RVA = "0x75F6E88", Offset = "0x75F6E88", Length = "0xF8")]
		[Token(Token = "0x600004F")]
		public void onProgress(int verifiedCount, int totalCount) { }

		[Address(RVA = "0x75F690C", Offset = "0x75F690C", Length = "0x574")]
		[Token(Token = "0x600004E")]
		public void onResult(AndroidJavaObject info) { }

	}

	[Token(Token = "0x2000009")]
	private sealed class DownloadCompleteHandler : MulticastDelegate
	{

		[Address(RVA = "0x75F3FB0", Offset = "0x75F3FB0", Length = "0xD8")]
		[Token(Token = "0x6000045")]
		public DownloadCompleteHandler(object object, IntPtr method) { }

		[Address(RVA = "0x75F68BC", Offset = "0x75F68BC", Length = "0x14")]
		[Token(Token = "0x6000046")]
		public override void Invoke(IntPtr keys, IntPtr values, int patchVersion, int errorCode, IntPtr errorMessage) { }

	}

	[Token(Token = "0x2000007")]
	private sealed class DownloadProgressHandler : MulticastDelegate
	{

		[Address(RVA = "0x75F3E00", Offset = "0x75F3E00", Length = "0xD8")]
		[Token(Token = "0x6000041")]
		public DownloadProgressHandler(object object, IntPtr method) { }

		[Address(RVA = "0x75F6878", Offset = "0x75F6878", Length = "0x30")]
		[Token(Token = "0x6000042")]
		public override void Invoke(long tTotalByte, long tDownloadeByte, int tTotalFileCount, int tDownloadedFileCount, long cTotalByte, long cDownloadedByte, int cTotalFileCount, int cDownloadedFileCount, IntPtr downloadGroupList, IntPtr patchVersionList, int targetPatchVersion) { }

	}

	[Token(Token = "0x2000011")]
	private class DownloadResultHandler : AndroidJavaProxy
	{
		[CompilerGenerated]
		[Token(Token = "0x2000015")]
		private sealed class <>c__DisplayClass11_0
		{
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x4000047")]
			public DownloadResultHandler <>4__this; //Field offset: 0x10
			[FieldOffset(Offset = "0x18")]
			[Token(Token = "0x4000048")]
			public Error _error; //Field offset: 0x18

			[Address(RVA = "0x75F803C", Offset = "0x75F803C", Length = "0x8")]
			[Token(Token = "0x6000064")]
			public <>c__DisplayClass11_0() { }

			[Address(RVA = "0x75F8100", Offset = "0x75F8100", Length = "0x34")]
			[Token(Token = "0x6000065")]
			internal void <onError>b__0() { }

		}

		[CompilerGenerated]
		[Token(Token = "0x2000016")]
		private sealed class <>c__DisplayClass11_1
		{
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x4000049")]
			public FilesInfo _filesInfo; //Field offset: 0x10
			[FieldOffset(Offset = "0x18")]
			[Token(Token = "0x400004A")]
			public <>c__DisplayClass11_0 CS$<>8__locals1; //Field offset: 0x18

			[Address(RVA = "0x75F8044", Offset = "0x75F8044", Length = "0x8")]
			[Token(Token = "0x6000066")]
			public <>c__DisplayClass11_1() { }

			[Address(RVA = "0x75F8134", Offset = "0x75F8134", Length = "0x3C")]
			[Token(Token = "0x6000067")]
			internal void <onError>b__1() { }

		}

		[CompilerGenerated]
		[Token(Token = "0x2000012")]
		private sealed class <>c__DisplayClass7_0
		{
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x4000040")]
			public DownloadResultHandler <>4__this; //Field offset: 0x10
			[FieldOffset(Offset = "0x18")]
			[Token(Token = "0x4000041")]
			public PatchInformation patchInformation; //Field offset: 0x18

			[Address(RVA = "0x75F777C", Offset = "0x75F777C", Length = "0x8")]
			[Token(Token = "0x600005E")]
			public <>c__DisplayClass7_0() { }

			[Address(RVA = "0x75F8070", Offset = "0x75F8070", Length = "0x30")]
			[Token(Token = "0x600005F")]
			internal void <onProgress>b__0() { }

		}

		[CompilerGenerated]
		[Token(Token = "0x2000013")]
		private sealed class <>c__DisplayClass8_0
		{
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x4000042")]
			public DownloadResultHandler <>4__this; //Field offset: 0x10
			[FieldOffset(Offset = "0x18")]
			[Token(Token = "0x4000043")]
			public string filename; //Field offset: 0x18
			[FieldOffset(Offset = "0x20")]
			[Token(Token = "0x4000044")]
			public string path; //Field offset: 0x20

			[Address(RVA = "0x75F78C4", Offset = "0x75F78C4", Length = "0x8")]
			[Token(Token = "0x6000060")]
			public <>c__DisplayClass8_0() { }

			[Address(RVA = "0x75F80A0", Offset = "0x75F80A0", Length = "0x30")]
			[Token(Token = "0x6000061")]
			internal void <onDownloaded>b__0() { }

		}

		[CompilerGenerated]
		[Token(Token = "0x2000014")]
		private sealed class <>c__DisplayClass9_0
		{
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x4000045")]
			public DownloadResultHandler <>4__this; //Field offset: 0x10
			[FieldOffset(Offset = "0x18")]
			[Token(Token = "0x4000046")]
			public Dictionary<String, String> data; //Field offset: 0x18

			[Address(RVA = "0x75F7C5C", Offset = "0x75F7C5C", Length = "0x8")]
			[Token(Token = "0x6000062")]
			public <>c__DisplayClass9_0() { }

			[Address(RVA = "0x75F80D0", Offset = "0x75F80D0", Length = "0x30")]
			[Token(Token = "0x6000063")]
			internal void <onComplete>b__0() { }

		}

		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400003A")]
		private Action<PatchInformation> onProgressCallback; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x400003B")]
		private Action<String, String> onDownloadedCallback; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x400003C")]
		private Action<Dictionary`2<String, String>> onCompleteCallback; //Field offset: 0x30
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x400003D")]
		private Action onStopCallback; //Field offset: 0x38
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x400003E")]
		private Action<Error, FilesInfo> onErrorCallback; //Field offset: 0x40
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x400003F")]
		private NXPatcherThreadExecutor threadExecutor; //Field offset: 0x48

		[Address(RVA = "0x75F1320", Offset = "0x75F1320", Length = "0x100")]
		[Token(Token = "0x6000057")]
		public DownloadResultHandler(Action<PatchInformation> onProgressCallback, Action<String, String> onDownloadedCallback, Action<Dictionary`2<String, String>> onCompleteCallback, Action onStopCallback, Action<Error, FilesInfo> onErrorCallback, NXPatcherThreadExecutor threadExecutor) { }

		[Address(RVA = "0x75F804C", Offset = "0x75F804C", Length = "0x24")]
		[CompilerGenerated]
		[Token(Token = "0x600005D")]
		private void <onStop>b__10_0() { }

		[Address(RVA = "0x75F78CC", Offset = "0x75F78CC", Length = "0x390")]
		[Token(Token = "0x600005A")]
		public void onComplete(AndroidJavaObject files) { }

		[Address(RVA = "0x75F7784", Offset = "0x75F7784", Length = "0x140")]
		[Token(Token = "0x6000059")]
		public void onDownloaded(string filename, string path) { }

		[Address(RVA = "0x75F7D04", Offset = "0x75F7D04", Length = "0x338")]
		[Token(Token = "0x600005C")]
		public void onError(AndroidJavaObject error, AndroidJavaObject filesInfo) { }

		[Address(RVA = "0x75F7208", Offset = "0x75F7208", Length = "0x574")]
		[Token(Token = "0x6000058")]
		public void onProgress(AndroidJavaObject patchInfo) { }

		[Address(RVA = "0x75F7C64", Offset = "0x75F7C64", Length = "0xA0")]
		[Token(Token = "0x600005B")]
		public void onStop() { }

	}

	[Token(Token = "0x2000008")]
	private sealed class FileDownloadedHandler : MulticastDelegate
	{

		[Address(RVA = "0x75F3ED8", Offset = "0x75F3ED8", Length = "0xD8")]
		[Token(Token = "0x6000043")]
		public FileDownloadedHandler(object object, IntPtr method) { }

		[Address(RVA = "0x75F68A8", Offset = "0x75F68A8", Length = "0x14")]
		[Token(Token = "0x6000044")]
		public override void Invoke(IntPtr filename, IntPtr path) { }

	}

	[Token(Token = "0x2000003")]
	internal sealed class InitResultHandler : MulticastDelegate
	{

		[Address(RVA = "0x75F3AA0", Offset = "0x75F3AA0", Length = "0xD8")]
		[Token(Token = "0x6000039")]
		public InitResultHandler(object object, IntPtr method) { }

		[Address(RVA = "0x75F67F8", Offset = "0x75F67F8", Length = "0x14")]
		[Token(Token = "0x600003A")]
		public override void Invoke(bool isSuccess, int errorCode, IntPtr errorMessage) { }

	}

	[Token(Token = "0x200000B")]
	private sealed class ValidateResourceProgressHandler : MulticastDelegate
	{

		[Address(RVA = "0x75F6490", Offset = "0x75F6490", Length = "0xD8")]
		[Token(Token = "0x6000049")]
		public ValidateResourceProgressHandler(object object, IntPtr method) { }

		[Address(RVA = "0x75F68E4", Offset = "0x75F68E4", Length = "0x14")]
		[Token(Token = "0x600004A")]
		public override void Invoke(int validatedCount, int totalCount) { }

	}

	[Token(Token = "0x200000C")]
	private sealed class ValidateResourceResultHandler : MulticastDelegate
	{

		[Address(RVA = "0x75F6568", Offset = "0x75F6568", Length = "0xD8")]
		[Token(Token = "0x600004B")]
		public ValidateResourceResultHandler(object object, IntPtr method) { }

		[Address(RVA = "0x75F68F8", Offset = "0x75F68F8", Length = "0x14")]
		[Token(Token = "0x600004C")]
		public override void Invoke(int errorCode, IntPtr errorMessage) { }

	}

	[Token(Token = "0x4000001")]
	private const string GetCode = "getCode"; //Field offset: 0x0
	[Token(Token = "0x4000015")]
	private const string SetUseNewApi = "setUseNewApi"; //Field offset: 0x0
	[Token(Token = "0x4000016")]
	private const string SetMarketUrl = "setMarketUrl"; //Field offset: 0x0
	[Token(Token = "0x4000018")]
	private const string GetDownloadedByte = "getDownloadedByte"; //Field offset: 0x0
	[Token(Token = "0x4000019")]
	private const string GetTotalFileCount = "getTotalFileCount"; //Field offset: 0x0
	[Token(Token = "0x400001A")]
	private const string GetDownloadedFileCount = "getDownloadedFileCount"; //Field offset: 0x0
	[Token(Token = "0x400001B")]
	private const string GetBuildStatus = "getBuildStatus"; //Field offset: 0x0
	[Token(Token = "0x400001C")]
	private const string GetPatchStatus = "getPatchStatus"; //Field offset: 0x0
	[Token(Token = "0x400001D")]
	private const string GetCurrentDownloadSize = "getCurrentDownloadSize"; //Field offset: 0x0
	[Token(Token = "0x400001E")]
	private const string AndroidJavaClassNXPatcher = "com.nexon.pub.bar.NXPatcher"; //Field offset: 0x0
	[Token(Token = "0x400001F")]
	private const string AndroidJavaClassNXPatcherConfig = "com.nexon.pub.bar.NXPatcher$Config"; //Field offset: 0x0
	[Token(Token = "0x4000020")]
	private const string AndroidJavaClassNXPatcherCheckVersionResultHandler = "com.nexon.pub.bar.NXPatcher$ICheckVersionResultHandler"; //Field offset: 0x0
	[Token(Token = "0x4000021")]
	private const string AndroidJavaClassNXPatcherDownloadResultHandler = "com.nexon.pub.bar.NXPatcher$IDownloadResultHandler"; //Field offset: 0x0
	[Token(Token = "0x4000022")]
	private const string AndroidResourceFilePath = "/PUB/Resource"; //Field offset: 0x0
	[Token(Token = "0x4000023")]
	private const string NXPatcher = "NXPatcher"; //Field offset: 0x0
	[Token(Token = "0x400002C")]
	private static NXPatcherConfig _config; //Field offset: 0x0
	[Token(Token = "0x4000014")]
	private const string SetStorageRate = "setStorageRate"; //Field offset: 0x0
	[Token(Token = "0x4000013")]
	private const string SetStreamingAssetsPath = "setStreamingAssetsPath"; //Field offset: 0x0
	[Token(Token = "0x4000017")]
	private const string GetTotalByte = "getTotalByte"; //Field offset: 0x0
	[Token(Token = "0x4000011")]
	private const string SetTextureFormat = "setTextureFormat"; //Field offset: 0x0
	[Token(Token = "0x4000002")]
	private const string GetMsg = "getMessage"; //Field offset: 0x0
	[Token(Token = "0x4000003")]
	private const string GetSize = "getSize"; //Field offset: 0x0
	[Token(Token = "0x4000004")]
	private const string GetCount = "getCount"; //Field offset: 0x0
	[Token(Token = "0x4000012")]
	private const string SetQualityLevel = "setQualityLevel"; //Field offset: 0x0
	[Token(Token = "0x4000006")]
	private const string SetAppId = "setAppId"; //Field offset: 0x0
	[Token(Token = "0x4000007")]
	private const string SetDebugMode = "setDebugMode"; //Field offset: 0x0
	[Token(Token = "0x4000008")]
	private const string SetConcurrentNumber = "setConcurrentNumber"; //Field offset: 0x0
	[Token(Token = "0x4000009")]
	private const string SetAllowCellular = "setAllowCellular"; //Field offset: 0x0
	[Token(Token = "0x4000005")]
	private const string SetAutoMoveToMarket = "setAutoMoveToMarket"; //Field offset: 0x0
	[Token(Token = "0x400000B")]
	private const string SetDownloadProgressMessage = "setDownloadProgressMessage"; //Field offset: 0x0
	[Token(Token = "0x400000C")]
	private const string SetDownloadFailedMessage = "setDownloadFailedMessage"; //Field offset: 0x0
	[Token(Token = "0x400000D")]
	private const string SetFileRoot = "setFileRoot"; //Field offset: 0x0
	[Token(Token = "0x400000E")]
	private const string SetNXPatcherConfig = "setConfig"; //Field offset: 0x0
	[Token(Token = "0x400000F")]
	private const string GetNXPatcherConfig = "getConfig"; //Field offset: 0x0
	[Token(Token = "0x400000A")]
	private const string SetDownloadCompletedMessage = "setDownloadCompletedMessage"; //Field offset: 0x0
	[Token(Token = "0x4000010")]
	private const string SetLanguage = "setLanguage"; //Field offset: 0x0
	[Token(Token = "0x400002D")]
	private static NXPatcherThreadExecutor threadExecutor; //Field offset: 0x8
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000024")]
	private AndroidJavaClass ajcNXPatcher; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000025")]
	private AndroidJavaObject ajoCurrentActivity; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000026")]
	private AndroidJavaObject ajoNXPatcherConfig; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000027")]
	private CheckVersionResultHandler onCheckVersionResultHandler; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000028")]
	private DownloadResultHandler onDownloadResultHandler; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000029")]
	private GameObject patcherCommonObject; //Field offset: 0x40
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x400002A")]
	private NXPatcherCommon nxPatcherCommon; //Field offset: 0x48
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x400002B")]
	private GameObject threadExecutorObject; //Field offset: 0x50
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x400002E")]
	private bool isNewApiInit; //Field offset: 0x58

	[Address(RVA = "0x75EFDF0", Offset = "0x75EFDF0", Length = "0x80")]
	[Token(Token = "0x6000003")]
	private static void _ConnectCheckBuildHandler(CheckBuildResultHandler handler) { }

	[Address(RVA = "0x75EFFEC", Offset = "0x75EFFEC", Length = "0x80")]
	[Token(Token = "0x600000C")]
	private static void _ConnectCheckPatchVersionHandler(CheckPatchVersionResultHandler resultHandler) { }

	[Address(RVA = "0x75EFE78", Offset = "0x75EFE78", Length = "0x98")]
	[Token(Token = "0x6000005")]
	private static void _ConnectCheckResourceHandler(CheckResourceProgressHandler progressHandler, CheckResourceResultHandler resultHandler) { }

	[Address(RVA = "0x75EFF20", Offset = "0x75EFF20", Length = "0xB4")]
	[Token(Token = "0x6000008")]
	private static void _ConnectDownloadHandler(DownloadProgressHandler downloadProgressHandler, FileDownloadedHandler fileDownloadedHandler, DownloadCompleteHandler downloadCompleteHandler) { }

	[Address(RVA = "0x75EFD68", Offset = "0x75EFD68", Length = "0x80")]
	[Token(Token = "0x6000001")]
	private static void _ConnectInitHandler(InitResultHandler handler) { }

	[Address(RVA = "0x75F0074", Offset = "0x75F0074", Length = "0x98")]
	[Token(Token = "0x600000E")]
	private static void _ConnectValidateResourceHandler(ValidateResourceProgressHandler progressHandler, ValidateResourceResultHandler resultHandler) { }

	[Address(RVA = "0x75F67F0", Offset = "0x75F67F0", Length = "0x8")]
	[Token(Token = "0x6000038")]
	public NXPatcherAndroid() { }

	[Address(RVA = "0x75F011C", Offset = "0x75F011C", Length = "0x3A8")]
	[Token(Token = "0x6000011")]
	private void Awake() { }

	[Address(RVA = "0x75F423C", Offset = "0x75F423C", Length = "0x104")]
	[Token(Token = "0x6000027")]
	public override void CheckBuild() { }

	[Address(RVA = "0x75F55E8", Offset = "0x75F55E8", Length = "0x1F0")]
	[Token(Token = "0x6000030")]
	public override void CheckPatchVersion(List<String> groupList, Action<PatchStatus, Error> action) { }

	[Address(RVA = "0x75F5420", Offset = "0x75F5420", Length = "0x1C8")]
	[Token(Token = "0x600002F")]
	public override void CheckPatchVersion(string group, Action<PatchStatus, Error> action) { }

	[Address(RVA = "0x75F5008", Offset = "0x75F5008", Length = "0x190")]
	[Token(Token = "0x600002E")]
	public override void CheckPatchVersion(Action<PatchStatus, Error> action) { }

	[Address(RVA = "0x75F47A4", Offset = "0x75F47A4", Length = "0x17C")]
	[Token(Token = "0x6000029")]
	public override void CheckResource(bool needVerify) { }

	[Address(RVA = "0x75F44F0", Offset = "0x75F44F0", Length = "0x104")]
	[Token(Token = "0x6000028")]
	public override void CheckResource() { }

	[Address(RVA = "0x75F4920", Offset = "0x75F4920", Length = "0x198")]
	[Token(Token = "0x600002A")]
	public override void CheckResource(string group) { }

	[Address(RVA = "0x75F4AB8", Offset = "0x75F4AB8", Length = "0x208")]
	[Token(Token = "0x600002B")]
	public override void CheckResource(string group, bool needVerify) { }

	[Address(RVA = "0x75F4E2C", Offset = "0x75F4E2C", Length = "0x1DC")]
	[Token(Token = "0x600002D")]
	public override void CheckResource(List<String> groupList, bool needVerify) { }

	[Address(RVA = "0x75F4CC0", Offset = "0x75F4CC0", Length = "0x16C")]
	[Token(Token = "0x600002C")]
	public override void CheckResource(List<String> groupList) { }

	[Address(RVA = "0x75F2148", Offset = "0x75F2148", Length = "0x108")]
	[Token(Token = "0x6000018")]
	public override void CheckVersion() { }

	[Address(RVA = "0x75F2250", Offset = "0x75F2250", Length = "0x178")]
	[Token(Token = "0x6000019")]
	public override void CheckVersion(bool needVerify) { }

	[Address(RVA = "0x75F23C8", Offset = "0x75F23C8", Length = "0x140")]
	[Token(Token = "0x600001A")]
	public override void CheckVersion(string group) { }

	[Address(RVA = "0x75F2508", Offset = "0x75F2508", Length = "0x1B0")]
	[Token(Token = "0x600001B")]
	public override void CheckVersion(string group, bool needVerify) { }

	[Address(RVA = "0x75F2ADC", Offset = "0x75F2ADC", Length = "0x30")]
	[Token(Token = "0x6000023")]
	public override void GetAssetBundle(string fileName) { }

	[Address(RVA = "0x75F2B0C", Offset = "0x75F2B0C", Length = "0x1C")]
	[Token(Token = "0x6000024")]
	public override void GetAssetBundleManifest(out AssetBundleManifest assetBundleManifest) { }

	[Address(RVA = "0x75F4340", Offset = "0x75F4340", Length = "0x1B0")]
	[Token(Token = "0x6000033")]
	private AndroidJavaObject GetCheckBuildHandler() { }

	[Address(RVA = "0x75F5270", Offset = "0x75F5270", Length = "0x1B0")]
	[Token(Token = "0x6000036")]
	private AndroidJavaObject GetCheckPatchVersionHandler() { }

	[Address(RVA = "0x75F45F4", Offset = "0x75F45F4", Length = "0x1B0")]
	[Token(Token = "0x6000034")]
	private AndroidJavaObject GetCheckResourceHandler() { }

	[Address(RVA = "0x75F1420", Offset = "0x75F1420", Length = "0x6B4")]
	[Token(Token = "0x6000013")]
	public override NXPatcherConfig GetConfig() { }

	[Address(RVA = "0x75F1C28", Offset = "0x75F1C28", Length = "0x1B0")]
	[Token(Token = "0x6000035")]
	private AndroidJavaObject GetDownloadHandler() { }

	[Address(RVA = "0x75F28B0", Offset = "0x75F28B0", Length = "0xE0")]
	[Token(Token = "0x600001E")]
	public override List<String> GetFileList() { }

	[Address(RVA = "0x75F2794", Offset = "0x75F2794", Length = "0x11C")]
	[Token(Token = "0x600001D")]
	public override string GetFilePath(string fileName) { }

	[Address(RVA = "0x75F4088", Offset = "0x75F4088", Length = "0x1B0")]
	[Token(Token = "0x6000032")]
	private AndroidJavaObject GetInitHandler() { }

	[Address(RVA = "0x75F6640", Offset = "0x75F6640", Length = "0x1B0")]
	[Token(Token = "0x6000037")]
	private AndroidJavaObject GetValidateResourceHandler() { }

	[Address(RVA = "0x75F4238", Offset = "0x75F4238", Length = "0x4")]
	[Token(Token = "0x6000026")]
	public override void Init(NXPatcherConfig config, string buildVersion, int buildNumber) { }

	[Address(RVA = "0x75F2B28", Offset = "0x75F2B28", Length = "0xF78")]
	[Token(Token = "0x6000025")]
	public override void Init(NXPatcherConfig config) { }

	[Address(RVA = "0x75F2AA4", Offset = "0x75F2AA4", Length = "0x1C")]
	[Token(Token = "0x6000021")]
	public override List<AssetBundle> LoadAssetBundleFromFile(List<String> fileNameList) { }

	[Address(RVA = "0x75F2A88", Offset = "0x75F2A88", Length = "0x1C")]
	[Token(Token = "0x6000020")]
	public override AssetBundle LoadAssetBundleFromFile(string fileName) { }

	[Address(RVA = "0x75F2AC0", Offset = "0x75F2AC0", Length = "0x1C")]
	[Token(Token = "0x6000022")]
	public override void LoadFromFile(string fileName, out AssetBundle assetBundle) { }

	[Address(RVA = "0x75F26B8", Offset = "0x75F26B8", Length = "0xDC")]
	[Token(Token = "0x600001C")]
	public override void MoveToMarket() { }

	[Address(RVA = "0x75EE95C", Offset = "0x75EE95C", Length = "0x1E8")]
	[MonoPInvokeCallback(typeof(CheckBuildResultHandler))]
	[Token(Token = "0x6000004")]
	private static void OnCheckBuildResult(int buildStatus, int errorCode, IntPtr errorMessage) { }

	[Address(RVA = "0x75EF8D8", Offset = "0x75EF8D8", Length = "0x1E8")]
	[MonoPInvokeCallback(typeof(CheckPatchVersionResultHandler))]
	[Token(Token = "0x600000D")]
	private static void OnCheckPatchVersionResult(int patchStatus, int errorCode, IntPtr errorMessage) { }

	[Address(RVA = "0x75EEB44", Offset = "0x75EEB44", Length = "0x104")]
	[MonoPInvokeCallback(typeof(CheckResourceProgressHandler))]
	[Token(Token = "0x6000006")]
	private static void OnCheckResourceProgress(int verifiedCount, int totalCount) { }

	[Address(RVA = "0x75EEC48", Offset = "0x75EEC48", Length = "0x468")]
	[MonoPInvokeCallback(typeof(CheckResourceResultHandler))]
	[Token(Token = "0x6000007")]
	private static void OnCheckResourceResult(int patchStatus, long tTotalByte, long tDownloadedByte, int tTotalFileCount, int tDownloadedFileCount, long cTotalByte, long cDownloadedByte, int cTotalFileCount, int cDownloadedFileCount, IntPtr downloadGroupList, IntPtr patchVersionList, int targetPatchVersion, int errorCode, IntPtr errorMessage) { }

	[Address(RVA = "0x75EF578", Offset = "0x75EF578", Length = "0x360")]
	[MonoPInvokeCallback(typeof(DownloadCompleteHandler))]
	[Token(Token = "0x600000B")]
	private static void OnComplete(IntPtr keys, IntPtr values, int patchVersion, int errorCode, IntPtr errorMessage) { }

	[Address(RVA = "0x75EF0B0", Offset = "0x75EF0B0", Length = "0x364")]
	[MonoPInvokeCallback(typeof(DownloadProgressHandler))]
	[Token(Token = "0x6000009")]
	private static void OnDownloadProgress(long tTotalByte, long tDownloadedByte, int tTotalFileCount, int tDownloadedFileCount, long cTotalByte, long cDownloadedByte, int cTotalFileCount, int cDownloadedFileCount, IntPtr downloadGroupList, IntPtr patchVersionList, int targetPatchVersion) { }

	[Address(RVA = "0x75EF414", Offset = "0x75EF414", Length = "0x164")]
	[MonoPInvokeCallback(typeof(FileDownloadedHandler))]
	[Token(Token = "0x600000A")]
	private static void OnFileDownloaded(IntPtr filename, IntPtr path) { }

	[Address(RVA = "0x75EE7AC", Offset = "0x75EE7AC", Length = "0x1B0")]
	[MonoPInvokeCallback(typeof(InitResultHandler))]
	[Token(Token = "0x6000002")]
	private static void OnInitResult(bool isSuccess, int errorCode, IntPtr errorMessage) { }

	[Address(RVA = "0x75EFAC0", Offset = "0x75EFAC0", Length = "0x104")]
	[MonoPInvokeCallback(typeof(ValidateResourceProgressHandler))]
	[Token(Token = "0x600000F")]
	private static void OnValidateResourceProgress(int validatedCount, int totalCount) { }

	[Address(RVA = "0x75EFBC4", Offset = "0x75EFBC4", Length = "0x1A4")]
	[MonoPInvokeCallback(typeof(ValidateResourceResultHandler))]
	[Token(Token = "0x6000010")]
	private static void OnValidateResourceResult(int errorCode, IntPtr errorMessage) { }

	[Address(RVA = "0x75F2080", Offset = "0x75F2080", Length = "0xC8")]
	[Token(Token = "0x6000017")]
	public override void RemoveAllPatch() { }

	[Address(RVA = "0x75F1DD8", Offset = "0x75F1DD8", Length = "0x154")]
	[Token(Token = "0x6000015")]
	public override void ResumeDownload() { }

	[Address(RVA = "0x75F04C4", Offset = "0x75F04C4", Length = "0xD8C")]
	[Token(Token = "0x6000012")]
	public override void SetConfig(NXPatcherConfig nxPatcherConfig) { }

	[Address(RVA = "0x75F2990", Offset = "0x75F2990", Length = "0xF8")]
	[Token(Token = "0x600001F")]
	public override void SetFileList(List<String> fileList) { }

	[Address(RVA = "0x75F1AD4", Offset = "0x75F1AD4", Length = "0x154")]
	[Token(Token = "0x6000014")]
	public override void StartDownload() { }

	[Address(RVA = "0x75F1F2C", Offset = "0x75F1F2C", Length = "0x154")]
	[Token(Token = "0x6000016")]
	public override void StopDownload() { }

	[Address(RVA = "0x75F57D8", Offset = "0x75F57D8", Length = "0xCB8")]
	[Token(Token = "0x6000031")]
	public override void ValidateResource(NXPatcherConfig config) { }

}

