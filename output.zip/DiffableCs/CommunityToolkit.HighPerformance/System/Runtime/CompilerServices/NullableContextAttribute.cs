namespace System.Runtime.CompilerServices;

[AttributeUsage(5196, AllowMultiple = False, Inherited = False)]
[CompilerGenerated]
[Embedded]
[Token(Token = "0x2000004")]
internal sealed class NullableContextAttribute : Attribute
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000002")]
	public readonly byte Flag; //Field offset: 0x10

	[Address(RVA = "0x3BD11A0", Offset = "0x3BD11A0", Length = "0x28")]
	[Token(Token = "0x6000004")]
	public NullableContextAttribute(byte unnamed_param_0) { }

}

