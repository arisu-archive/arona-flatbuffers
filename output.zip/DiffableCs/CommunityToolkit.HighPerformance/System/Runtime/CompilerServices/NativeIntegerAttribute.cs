namespace System.Runtime.CompilerServices;

[AttributeUsage(27524, AllowMultiple = False, Inherited = False)]
[CompilerGenerated]
[Embedded]
[Token(Token = "0x2000005")]
internal sealed class NativeIntegerAttribute : Attribute
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000003")]
	public readonly Boolean[] TransformFlags; //Field offset: 0x10

	[Address(RVA = "0x3BD11C8", Offset = "0x3BD11C8", Length = "0x80")]
	[Token(Token = "0x6000005")]
	public NativeIntegerAttribute() { }

}

