namespace System.Runtime.CompilerServices;

[AttributeUsage(1774, Inherited = False)]
[Token(Token = "0x2000007")]
internal sealed class SkipLocalsInitAttribute : Attribute
{

	[Address(RVA = "0x3BD1270", Offset = "0x3BD1270", Length = "0x8")]
	[Token(Token = "0x6000007")]
	public SkipLocalsInitAttribute() { }

}

