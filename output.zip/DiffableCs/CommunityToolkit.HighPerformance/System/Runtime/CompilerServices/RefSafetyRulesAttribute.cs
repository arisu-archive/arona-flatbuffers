namespace System.Runtime.CompilerServices;

[AttributeUsage(AttributeTargets::Module (2), AllowMultiple = False, Inherited = False)]
[CompilerGenerated]
[Embedded]
[Token(Token = "0x2000006")]
internal sealed class RefSafetyRulesAttribute : Attribute
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000004")]
	public readonly int Version; //Field offset: 0x10

	[Address(RVA = "0x3BD1248", Offset = "0x3BD1248", Length = "0x28")]
	[Token(Token = "0x6000006")]
	public RefSafetyRulesAttribute(int unnamed_param_0) { }

}

