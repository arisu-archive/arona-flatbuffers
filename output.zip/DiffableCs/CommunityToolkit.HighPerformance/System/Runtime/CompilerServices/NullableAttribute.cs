namespace System.Runtime.CompilerServices;

[AttributeUsage(27524, AllowMultiple = False, Inherited = False)]
[CompilerGenerated]
[Embedded]
[Token(Token = "0x2000003")]
internal sealed class NullableAttribute : Attribute
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000001")]
	public readonly Byte[] NullableFlags; //Field offset: 0x10

	[Address(RVA = "0x3BD10E8", Offset = "0x3BD10E8", Length = "0x88")]
	[Token(Token = "0x6000002")]
	public NullableAttribute(byte unnamed_param_0) { }

	[Address(RVA = "0x3BD1170", Offset = "0x3BD1170", Length = "0x30")]
	[Token(Token = "0x6000003")]
	public NullableAttribute(Byte[] unnamed_param_0) { }

}

