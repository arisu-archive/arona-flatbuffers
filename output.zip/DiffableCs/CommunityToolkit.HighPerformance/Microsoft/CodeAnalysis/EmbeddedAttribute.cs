namespace Microsoft.CodeAnalysis;

[CompilerGenerated]
[Embedded]
[Token(Token = "0x2000002")]
internal sealed class EmbeddedAttribute : Attribute
{

	[Address(RVA = "0x3BD10E0", Offset = "0x3BD10E0", Length = "0x8")]
	[Token(Token = "0x6000001")]
	public EmbeddedAttribute() { }

}

