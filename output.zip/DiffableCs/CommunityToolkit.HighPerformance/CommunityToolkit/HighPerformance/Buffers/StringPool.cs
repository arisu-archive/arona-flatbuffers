namespace CommunityToolkit.HighPerformance.Buffers;

[Nullable(0)]
[NullableContext(1)]
[Token(Token = "0x2000010")]
public sealed class StringPool
{
	[Nullable(0)]
	[Token(Token = "0x2000011")]
	private struct FixedSizePriorityMap
	{
		[NullableContext(0)]
		[Token(Token = "0x2000013")]
		private struct HeapEntry
		{
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x4000016")]
			public uint Timestamp; //Field offset: 0x0
			[FieldOffset(Offset = "0x4")]
			[Token(Token = "0x4000017")]
			public int MapIndex; //Field offset: 0x4

		}

		[NullableContext(0)]
		[Token(Token = "0x2000012")]
		private struct MapEntry
		{
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x4000012")]
			public int HashCode; //Field offset: 0x0
			[FieldOffset(Offset = "0x8")]
			[Nullable(2)]
			[Token(Token = "0x4000013")]
			public string Value; //Field offset: 0x8
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x4000014")]
			public int NextIndex; //Field offset: 0x10
			[FieldOffset(Offset = "0x14")]
			[Token(Token = "0x4000015")]
			public int HeapIndex; //Field offset: 0x14

		}

		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x400000D")]
		private readonly Int32[] buckets; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x400000E")]
		private readonly MapEntry[] mapEntries; //Field offset: 0x8
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x400000F")]
		private readonly HeapEntry[] heapEntries; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000010")]
		private int count; //Field offset: 0x18
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4000011")]
		private uint timestamp; //Field offset: 0x1C

		[Token(Token = "0x17000002")]
		public object SyncRoot
		{
			[Address(RVA = "0x3BD2C60", Offset = "0x3BD2C60", Length = "0x8")]
			[Token(Token = "0x600001F")]
			 get { } //Length: 8
		}

		[Address(RVA = "0x3BD26E4", Offset = "0x3BD26E4", Length = "0xD4")]
		[Token(Token = "0x600001E")]
		public FixedSizePriorityMap(int capacity) { }

		[Address(RVA = "0x3BD2C60", Offset = "0x3BD2C60", Length = "0x8")]
		[Token(Token = "0x600001F")]
		public object get_SyncRoot() { }

		[Address(RVA = "0x3BD2C68", Offset = "0x3BD2C68", Length = "0xA4")]
		[NullableContext(0)]
		[Token(Token = "0x6000020")]
		public string GetOrAdd(ReadOnlySpan<Char> span, int hashcode) { }

		[Address(RVA = "0x3BD2FA4", Offset = "0x3BD2FA4", Length = "0x1C8")]
		[Token(Token = "0x6000022")]
		private void Insert(string value, int hashcode) { }

		[Address(RVA = "0x3BD330C", Offset = "0x3BD330C", Length = "0x18C")]
		[Token(Token = "0x6000023")]
		private void Remove(int hashcode, int mapIndex) { }

		[Address(RVA = "0x3BD2D0C", Offset = "0x3BD2D0C", Length = "0x298")]
		[NullableContext(0)]
		[Token(Token = "0x6000021")]
		private string TryGet(ReadOnlySpan<Char> span, int hashcode) { }

		[Address(RVA = "0x3BD3498", Offset = "0x3BD3498", Length = "0x90")]
		[Token(Token = "0x6000025")]
		private void UpdateAllTimestamps() { }

		[Address(RVA = "0x3BD316C", Offset = "0x3BD316C", Length = "0x1A0")]
		[Token(Token = "0x6000024")]
		private void UpdateTimestamp(ref int heapIndex) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x400000B")]
	private static readonly StringPool <Shared>k__BackingField; //Field offset: 0x0
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000009")]
	private readonly FixedSizePriorityMap[] maps; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400000A")]
	private readonly int numberOfMaps; //Field offset: 0x18
	[CompilerGenerated]
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x400000C")]
	private readonly int <Size>k__BackingField; //Field offset: 0x1C

	[Token(Token = "0x17000001")]
	public static StringPool Shared
	{
		[Address(RVA = "0x3BD27B8", Offset = "0x3BD27B8", Length = "0x58")]
		[CompilerGenerated]
		[Token(Token = "0x6000018")]
		 get { } //Length: 88
	}

	[Address(RVA = "0x3BD2BF0", Offset = "0x3BD2BF0", Length = "0x70")]
	[Token(Token = "0x600001C")]
	private static StringPool() { }

	[Address(RVA = "0x3BD23A8", Offset = "0x3BD23A8", Length = "0x8")]
	[Token(Token = "0x6000016")]
	public StringPool() { }

	[Address(RVA = "0x3BD23B0", Offset = "0x3BD23B0", Length = "0x1F8")]
	[Token(Token = "0x6000017")]
	public StringPool(int minimumSize) { }

	[Address(RVA = "0x3BD2610", Offset = "0x3BD2610", Length = "0xD4")]
	[CompilerGenerated]
	[Token(Token = "0x600001D")]
	internal static void <.ctor>g__FindFactors|5_0(int size, int factor, out uint x, out uint y) { }

	[Address(RVA = "0x3BD27B8", Offset = "0x3BD27B8", Length = "0x58")]
	[CompilerGenerated]
	[Token(Token = "0x6000018")]
	public static StringPool get_Shared() { }

	[Address(RVA = "0x3BD2AF8", Offset = "0x3BD2AF8", Length = "0xF8")]
	[NullableContext(0)]
	[Token(Token = "0x600001A")]
	private static int GetHashCode(ReadOnlySpan<Char> span) { }

	[Address(RVA = "0x3BD2810", Offset = "0x3BD2810", Length = "0x2E8")]
	[NullableContext(0)]
	[Token(Token = "0x6000019")]
	public string GetOrAdd(ReadOnlySpan<Char> span) { }

	[Address(RVA = "0x3BD25A8", Offset = "0x3BD25A8", Length = "0x68")]
	[Token(Token = "0x600001B")]
	private static void ThrowArgumentOutOfRangeException() { }

}

