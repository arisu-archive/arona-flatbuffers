namespace CommunityToolkit.HighPerformance;

[Extension]
[Nullable(0)]
[NullableContext(1)]
[Token(Token = "0x2000008")]
public static class ArrayExtensions
{

	[Address(RVA = "0x416E5E8", Offset = "0x416E5E8", Length = "0x40")]
	[Extension]
	[Token(Token = "0x6000008")]
	public static T DangerousGetReference(T[] array) { }

	[Address(RVA = "0x416E6E8", Offset = "0x416E6E8", Length = "0x4C")]
	[Extension]
	[Token(Token = "0x6000009")]
	public static T DangerousGetReferenceAt(T[] array, int i) { }

}

