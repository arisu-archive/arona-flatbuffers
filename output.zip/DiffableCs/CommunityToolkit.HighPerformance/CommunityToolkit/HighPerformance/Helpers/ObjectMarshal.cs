namespace CommunityToolkit.HighPerformance.Helpers;

[Extension]
[Token(Token = "0x200000A")]
public static class ObjectMarshal
{
	[Token(Token = "0x200000B")]
	private sealed class RawObjectData
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000005")]
		public byte Data; //Field offset: 0x10

	}


	[Address(RVA = "0x43EE248", Offset = "0x43EE248", Length = "0x18")]
	[NullableContext(1)]
	[Token(Token = "0x600000C")]
	public static IntPtr DangerousGetObjectDataByteOffset(object obj, ref T data) { }

	[Address(RVA = "0x43EE2C0", Offset = "0x43EE2C0", Length = "0x18")]
	[NullableContext(1)]
	[Token(Token = "0x600000D")]
	public static T DangerousGetObjectDataReferenceAt(object obj, IntPtr offset) { }

}

