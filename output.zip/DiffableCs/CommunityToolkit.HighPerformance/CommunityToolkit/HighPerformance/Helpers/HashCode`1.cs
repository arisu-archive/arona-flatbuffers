namespace CommunityToolkit.HighPerformance.Helpers;

[Token(Token = "0x2000009")]
public struct HashCode
{

	[Address(RVA = "0x4E78D4C", Offset = "0x4E78D4C", Length = "0xD0")]
	[Token(Token = "0x600000A")]
	public static int Combine(ReadOnlySpan<T> span) { }

	[Address(RVA = "0x4E78E1C", Offset = "0x4E78E1C", Length = "0xA4")]
	[Token(Token = "0x600000B")]
	internal static int CombineValues(ReadOnlySpan<T> span) { }

}

