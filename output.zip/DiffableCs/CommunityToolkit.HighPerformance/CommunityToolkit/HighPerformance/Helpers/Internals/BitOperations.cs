namespace CommunityToolkit.HighPerformance.Helpers.Internals;

[Token(Token = "0x200000C")]
internal static class BitOperations
{

	[Address(RVA = "0x3BD1278", Offset = "0x3BD1278", Length = "0x20")]
	[Token(Token = "0x600000E")]
	public static uint RoundUpToPowerOf2(uint value) { }

}

