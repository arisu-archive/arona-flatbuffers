namespace CommunityToolkit.HighPerformance.Helpers.Internals;

[Token(Token = "0x200000F")]
internal static class SpanHelper
{

	[Address(RVA = "0x444BA1C", Offset = "0x444BA1C", Length = "0x248")]
	[NullableContext(1)]
	[Token(Token = "0x6000014")]
	public static int GetDjb2HashCode(ref T r0, IntPtr length) { }

	[Address(RVA = "0x3BD1298", Offset = "0x3BD1298", Length = "0x1110")]
	[Token(Token = "0x6000015")]
	public static int GetDjb2LikeByteHash(ref byte r0, IntPtr length) { }

}

