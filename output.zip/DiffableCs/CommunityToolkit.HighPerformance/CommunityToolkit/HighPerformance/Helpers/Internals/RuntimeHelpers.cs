namespace CommunityToolkit.HighPerformance.Helpers.Internals;

[Token(Token = "0x200000D")]
internal static class RuntimeHelpers
{
	[Token(Token = "0x200000E")]
	private static class TypeInfo
	{
		[Token(Token = "0x4000006")]
		public static readonly IntPtr ArrayDataByteOffset; //Field offset: 0x0
		[Token(Token = "0x4000007")]
		public static readonly IntPtr Array2DDataByteOffset; //Field offset: 0x0
		[Token(Token = "0x4000008")]
		public static readonly IntPtr Array3DDataByteOffset; //Field offset: 0x0

		[Address(RVA = "0x5FCE27C", Offset = "0x5FCE27C", Length = "0x18C")]
		[Token(Token = "0x6000013")]
		private static TypeInfo`1() { }

		[Address(RVA = "0x5FCE0D4", Offset = "0x5FCE0D4", Length = "0xCC")]
		[Token(Token = "0x6000011")]
		private static IntPtr MeasureArray2DDataByteOffset() { }

		[Address(RVA = "0x5FCE1A0", Offset = "0x5FCE1A0", Length = "0xDC")]
		[Token(Token = "0x6000012")]
		private static IntPtr MeasureArray3DDataByteOffset() { }

		[Address(RVA = "0x5FCE034", Offset = "0x5FCE034", Length = "0xA0")]
		[Token(Token = "0x6000010")]
		private static IntPtr MeasureArrayDataByteOffset() { }

	}


	[Address(RVA = "0x43F95D0", Offset = "0x43F95D0", Length = "0x4C")]
	[NullableContext(2)]
	[Token(Token = "0x600000F")]
	public static IntPtr GetArrayDataByteOffset() { }

}

