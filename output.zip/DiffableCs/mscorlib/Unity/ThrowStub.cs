namespace Unity;

[Token(Token = "0x2000713")]
internal sealed class ThrowStub : ObjectDisposedException
{

	[Address(RVA = "0x73D7C90", Offset = "0x73D7C90", Length = "0x40")]
	[Token(Token = "0x6003611")]
	public static void ThrowNotSupportedException() { }

}

