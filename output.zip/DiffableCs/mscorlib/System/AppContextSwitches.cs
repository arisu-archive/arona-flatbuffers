namespace System;

[Token(Token = "0x200015D")]
internal static class AppContextSwitches
{
	[Token(Token = "0x4000543")]
	public static readonly bool SetActorAsReferenceWhenCopyingClaimsIdentity; //Field offset: 0x0
	[Token(Token = "0x4000544")]
	public static readonly bool NoAsyncCurrentCulture; //Field offset: 0x1
	[Token(Token = "0x4000545")]
	public static readonly bool EnforceJapaneseEraYearRanges; //Field offset: 0x2
	[Token(Token = "0x4000546")]
	public static readonly bool FormatJapaneseFirstYearAsANumber; //Field offset: 0x3
	[Token(Token = "0x4000547")]
	public static readonly bool EnforceLegacyJapaneseDateParsing; //Field offset: 0x4

}

