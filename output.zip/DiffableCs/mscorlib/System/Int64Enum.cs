namespace System;

[Token(Token = "0x2000196")]
internal enum Int64Enum
{
}

