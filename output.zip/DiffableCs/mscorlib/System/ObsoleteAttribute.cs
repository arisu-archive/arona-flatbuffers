namespace System;

[AttributeUsage(6140, Inherited = False)]
[Token(Token = "0x20000FC")]
public sealed class ObsoleteAttribute : Attribute
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40003A8")]
	private string _message; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40003A9")]
	private bool _error; //Field offset: 0x18

	[Token(Token = "0x170000A1")]
	public string Message
	{
		[Address(RVA = "0x740BE70", Offset = "0x740BE70", Length = "0x8")]
		[Token(Token = "0x6000976")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x740BDD0", Offset = "0x740BDD0", Length = "0x2C")]
	[Token(Token = "0x6000973")]
	public ObsoleteAttribute() { }

	[Address(RVA = "0x740BDFC", Offset = "0x740BDFC", Length = "0x38")]
	[Token(Token = "0x6000974")]
	public ObsoleteAttribute(string message) { }

	[Address(RVA = "0x740BE34", Offset = "0x740BE34", Length = "0x3C")]
	[Token(Token = "0x6000975")]
	public ObsoleteAttribute(string message, bool error) { }

	[Address(RVA = "0x740BE70", Offset = "0x740BE70", Length = "0x8")]
	[Token(Token = "0x6000976")]
	public string get_Message() { }

}

