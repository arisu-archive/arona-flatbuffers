namespace System;

[Extension]
[Token(Token = "0x200010E")]
internal static class SpanHelpers
{

	[Address(RVA = "0x7413388", Offset = "0x7413388", Length = "0x234")]
	[Token(Token = "0x6000A43")]
	public static void ClearWithoutReferences(ref byte b, ulong byteLength) { }

	[Address(RVA = "0x74135BC", Offset = "0x74135BC", Length = "0x150")]
	[Token(Token = "0x6000A44")]
	public static void ClearWithReferences(ref IntPtr ip, ulong pointerSizeLength) { }

	[Address(RVA = "0x7412F84", Offset = "0x7412F84", Length = "0x200")]
	[Token(Token = "0x6000A40")]
	public static bool EndsWithCultureHelper(ReadOnlySpan<Char> span, ReadOnlySpan<Char> value, CompareInfo compareInfo) { }

	[Address(RVA = "0x7413184", Offset = "0x7413184", Length = "0x120")]
	[Token(Token = "0x6000A41")]
	public static bool EndsWithCultureIgnoreCaseHelper(ReadOnlySpan<Char> span, ReadOnlySpan<Char> value, CompareInfo compareInfo) { }

	[Address(RVA = "0x74132A4", Offset = "0x74132A4", Length = "0xE4")]
	[Token(Token = "0x6000A42")]
	public static bool EndsWithOrdinalIgnoreCaseHelper(ReadOnlySpan<Char> span, ReadOnlySpan<Char> value) { }

	[Address(RVA = "0x444DDDC", Offset = "0x444DDDC", Length = "0xBC")]
	[Token(Token = "0x6000A36")]
	public static int IndexOf(ref T searchSpace, int searchSpaceLength, ref T value, int valueLength) { }

	[Address(RVA = "0x444BEDC", Offset = "0x444BEDC", Length = "0x1308")]
	[Token(Token = "0x6000A37")]
	public static int IndexOf(ref T searchSpace, T value, int length) { }

	[Address(RVA = "0x7410B10", Offset = "0x7410B10", Length = "0xD0")]
	[Token(Token = "0x6000A2B")]
	public static int IndexOf(ref byte searchSpace, int searchSpaceLength, ref byte value, int valueLength) { }

	[Address(RVA = "0x7410BE0", Offset = "0x7410BE0", Length = "0x2AC")]
	[Token(Token = "0x6000A2D")]
	public static int IndexOf(ref byte searchSpace, byte value, int length) { }

	[Address(RVA = "0x7411610", Offset = "0x7411610", Length = "0x744")]
	[Token(Token = "0x6000A30")]
	public static int IndexOf(ref char searchSpace, char value, int length) { }

	[Address(RVA = "0x7410E8C", Offset = "0x7410E8C", Length = "0x80")]
	[Token(Token = "0x6000A2C")]
	public static int IndexOfAny(ref byte searchSpace, int searchSpaceLength, ref byte value, int valueLength) { }

	[Address(RVA = "0x444DF54", Offset = "0x444DF54", Length = "0x98")]
	[Token(Token = "0x6000A38")]
	public static int IndexOfAny(ref T searchSpace, int searchSpaceLength, ref T value, int valueLength) { }

	[Address(RVA = "0x7412824", Offset = "0x7412824", Length = "0x124")]
	[Token(Token = "0x6000A3A")]
	public static int IndexOfCultureHelper(ReadOnlySpan<Char> span, ReadOnlySpan<Char> value, CompareInfo compareInfo) { }

	[Address(RVA = "0x7412948", Offset = "0x7412948", Length = "0x124")]
	[Token(Token = "0x6000A3B")]
	public static int IndexOfCultureIgnoreCaseHelper(ReadOnlySpan<Char> span, ReadOnlySpan<Char> value, CompareInfo compareInfo) { }

	[Address(RVA = "0x7412A6C", Offset = "0x7412A6C", Length = "0x134")]
	[Token(Token = "0x6000A3C")]
	public static int IndexOfOrdinalHelper(ReadOnlySpan<Char> span, ReadOnlySpan<Char> value, bool ignoreCase) { }

	[Address(RVA = "0x7411D54", Offset = "0x7411D54", Length = "0x6EC")]
	[Token(Token = "0x6000A31")]
	public static int LastIndexOf(ref char searchSpace, char value, int length) { }

	[Address(RVA = "0x741260C", Offset = "0x741260C", Length = "0x20")]
	[Token(Token = "0x6000A33")]
	private static int LocateFirstFoundChar(ulong match) { }

	[Address(RVA = "0x7412440", Offset = "0x7412440", Length = "0x1CC")]
	[Token(Token = "0x6000A32")]
	private static int LocateFirstFoundChar(Vector<UInt16> match) { }

	[Address(RVA = "0x74127F8", Offset = "0x74127F8", Length = "0x2C")]
	[Token(Token = "0x6000A35")]
	private static int LocateLastFoundChar(ulong match) { }

	[Address(RVA = "0x741262C", Offset = "0x741262C", Length = "0x1CC")]
	[Token(Token = "0x6000A34")]
	private static int LocateLastFoundChar(Vector<UInt16> match) { }

	[Address(RVA = "0x74110F8", Offset = "0x74110F8", Length = "0x518")]
	[Token(Token = "0x6000A2F")]
	public static int SequenceCompareTo(ref char first, int firstLength, ref char second, int secondLength) { }

	[Address(RVA = "0x444E084", Offset = "0x444E084", Length = "0x380")]
	[Token(Token = "0x6000A39")]
	public static bool SequenceEqual(ref T first, ref T second, int length) { }

	[Address(RVA = "0x7410F0C", Offset = "0x7410F0C", Length = "0x1EC")]
	[Token(Token = "0x6000A2E")]
	public static bool SequenceEqual(ref byte first, ref byte second, ulong length) { }

	[Address(RVA = "0x7412BA0", Offset = "0x7412BA0", Length = "0x1F0")]
	[Token(Token = "0x6000A3D")]
	public static bool StartsWithCultureHelper(ReadOnlySpan<Char> span, ReadOnlySpan<Char> value, CompareInfo compareInfo) { }

	[Address(RVA = "0x7412D90", Offset = "0x7412D90", Length = "0x120")]
	[Token(Token = "0x6000A3E")]
	public static bool StartsWithCultureIgnoreCaseHelper(ReadOnlySpan<Char> span, ReadOnlySpan<Char> value, CompareInfo compareInfo) { }

	[Address(RVA = "0x7412EB0", Offset = "0x7412EB0", Length = "0xD4")]
	[Token(Token = "0x6000A3F")]
	public static bool StartsWithOrdinalIgnoreCaseHelper(ReadOnlySpan<Char> span, ReadOnlySpan<Char> value) { }

}

