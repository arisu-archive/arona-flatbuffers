namespace System.Collections.Generic;

[Token(Token = "0x2000689")]
public interface IEnumerator : IDisposable, IEnumerator
{

	[Token(Token = "0x1700087A")]
	public T Current
	{
		[Token(Token = "0x600340D")]
		 get { } //Length: 0
	}

	[Token(Token = "0x600340D")]
	public T get_Current() { }

}

