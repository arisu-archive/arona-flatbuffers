namespace System.Collections.Generic;

[Token(Token = "0x2000697")]
internal struct LargeArrayBuilder
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C1B")]
	private readonly int _maxCapacity; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C1C")]
	private T[] _first; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C1D")]
	private ArrayBuilder<T[]> _buffers; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C1E")]
	private T[] _current; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C1F")]
	private int _index; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C20")]
	private int _count; //Field offset: 0x0

	[Address(RVA = "0x516BA80", Offset = "0x516BA80", Length = "0x38")]
	[Token(Token = "0x600347A")]
	public LargeArrayBuilder`1(bool initialize) { }

	[Address(RVA = "0x516BAB8", Offset = "0x516BAB8", Length = "0x98")]
	[Token(Token = "0x600347B")]
	public LargeArrayBuilder`1(int maxCapacity) { }

	[Address(RVA = "0x516BB50", Offset = "0x516BB50", Length = "0x348")]
	[Token(Token = "0x600347C")]
	public void AddRange(IEnumerable<T> items) { }

	[Address(RVA = "0x516BE98", Offset = "0x516BE98", Length = "0xA8")]
	[Token(Token = "0x600347D")]
	private void AddWithBufferAllocation(T item, ref T[] destination, ref int index) { }

	[Address(RVA = "0x516C1B0", Offset = "0x516C1B0", Length = "0x1C0")]
	[Token(Token = "0x6003482")]
	private void AllocateBuffer() { }

	[Address(RVA = "0x516BF40", Offset = "0x516BF40", Length = "0xF8")]
	[Token(Token = "0x600347E")]
	public void CopyTo(T[] array, int arrayIndex, int count) { }

	[Address(RVA = "0x516C038", Offset = "0x516C038", Length = "0x80")]
	[Token(Token = "0x600347F")]
	public T[] GetBuffer(int index) { }

	[Address(RVA = "0x516C0B8", Offset = "0x516C0B8", Length = "0xB8")]
	[Token(Token = "0x6003480")]
	public T[] ToArray() { }

	[Address(RVA = "0x516C170", Offset = "0x516C170", Length = "0x40")]
	[Token(Token = "0x6003481")]
	public bool TryMove(out T[] array) { }

}

