namespace System.Collections.Generic;

[Token(Token = "0x200069E")]
internal sealed class QueueDebugView
{

}

