namespace System.Collections.Generic;

[Token(Token = "0x20006A1")]
internal sealed class StackDebugView
{

}

