namespace System.Collections.Generic;

[DebuggerDisplay("Count = {Count}")]
[DebuggerTypeProxy(typeof(ICollectionDebugView`1))]
[DefaultMember("Item")]
[Token(Token = "0x2000692")]
public class List : IList<T>, ICollection<T>, IEnumerable<T>, IEnumerable, IList, ICollection, IReadOnlyList<T>, IReadOnlyCollection<T>
{
	[Token(Token = "0x2000693")]
	internal struct Enumerator : IEnumerator<T>, IDisposable, IEnumerator
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C12")]
		private List<T> _list; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C13")]
		private int _index; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C14")]
		private int _version; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C15")]
		private T _current; //Field offset: 0x0

		[Token(Token = "0x1700088C")]
		public override T Current
		{
			[Address(RVA = "0x482EC34", Offset = "0x482EC34", Length = "0xC")]
			[Token(Token = "0x6003469")]
			 get { } //Length: 12
		}

		[Token(Token = "0x1700088D")]
		private override object System.Collections.IEnumerator.Current
		{
			[Address(RVA = "0x482EC40", Offset = "0x482EC40", Length = "0x94")]
			[Token(Token = "0x600346A")]
			private get { } //Length: 148
		}

		[Address(RVA = "0x482EB08", Offset = "0x482EB08", Length = "0x3C")]
		[Token(Token = "0x6003465")]
		internal Enumerator(List<T> list) { }

		[Address(RVA = "0x482EB44", Offset = "0x482EB44", Length = "0x4")]
		[Token(Token = "0x6003466")]
		public override void Dispose() { }

		[Address(RVA = "0x482EC34", Offset = "0x482EC34", Length = "0xC")]
		[Token(Token = "0x6003469")]
		public override T get_Current() { }

		[Address(RVA = "0x482EB48", Offset = "0x482EB48", Length = "0x9C")]
		[Token(Token = "0x6003467")]
		public override bool MoveNext() { }

		[Address(RVA = "0x482EBE4", Offset = "0x482EBE4", Length = "0x50")]
		[Token(Token = "0x6003468")]
		private bool MoveNextRare() { }

		[Address(RVA = "0x482EC40", Offset = "0x482EC40", Length = "0x94")]
		[Token(Token = "0x600346A")]
		private override object System.Collections.IEnumerator.get_Current() { }

		[Address(RVA = "0x482ECD4", Offset = "0x482ECD4", Length = "0x3C")]
		[Token(Token = "0x600346B")]
		private override void System.Collections.IEnumerator.Reset() { }

	}

	[Token(Token = "0x4001C0C")]
	private const int DefaultCapacity = 4; //Field offset: 0x0
	[Token(Token = "0x4001C11")]
	private static readonly T[] s_emptyArray; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C0D")]
	private T[] _items; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C0E")]
	private int _size; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C0F")]
	private int _version; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C10")]
	private object _syncRoot; //Field offset: 0x0

	[Token(Token = "0x17000883")]
	public int Capacity
	{
		[Address(RVA = "0x51908B4", Offset = "0x51908B4", Length = "0x1C")]
		[Token(Token = "0x6003428")]
		 get { } //Length: 28
		[Address(RVA = "0x51908D0", Offset = "0x51908D0", Length = "0x10C")]
		[Token(Token = "0x6003429")]
		 set { } //Length: 268
	}

	[Token(Token = "0x17000884")]
	public override int Count
	{
		[Address(RVA = "0x51909DC", Offset = "0x51909DC", Length = "0x8")]
		[Token(Token = "0x600342A")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700088A")]
	public override T Item
	{
		[Address(RVA = "0x5190A7C", Offset = "0x5190A7C", Length = "0x54")]
		[Token(Token = "0x6003430")]
		 get { } //Length: 84
		[Address(RVA = "0x5190AD0", Offset = "0x5190AD0", Length = "0x78")]
		[Token(Token = "0x6003431")]
		 set { } //Length: 120
	}

	[Token(Token = "0x17000886")]
	private override bool System.Collections.Generic.ICollection<T>.IsReadOnly
	{
		[Address(RVA = "0x51909EC", Offset = "0x51909EC", Length = "0x8")]
		[Token(Token = "0x600342C")]
		private get { } //Length: 8
	}

	[Token(Token = "0x17000888")]
	private override bool System.Collections.ICollection.IsSynchronized
	{
		[Address(RVA = "0x51909FC", Offset = "0x51909FC", Length = "0x8")]
		[Token(Token = "0x600342E")]
		private get { } //Length: 8
	}

	[Token(Token = "0x17000889")]
	private override object System.Collections.ICollection.SyncRoot
	{
		[Address(RVA = "0x5190A04", Offset = "0x5190A04", Length = "0x78")]
		[Token(Token = "0x600342F")]
		private get { } //Length: 120
	}

	[Token(Token = "0x17000885")]
	private override bool System.Collections.IList.IsFixedSize
	{
		[Address(RVA = "0x51909E4", Offset = "0x51909E4", Length = "0x8")]
		[Token(Token = "0x600342B")]
		private get { } //Length: 8
	}

	[Token(Token = "0x17000887")]
	private override bool System.Collections.IList.IsReadOnly
	{
		[Address(RVA = "0x51909F4", Offset = "0x51909F4", Length = "0x8")]
		[Token(Token = "0x600342D")]
		private get { } //Length: 8
	}

	[Token(Token = "0x1700088B")]
	private override object System.Collections.IList.Item
	{
		[Address(RVA = "0x5190BF8", Offset = "0x5190BF8", Length = "0x50")]
		[Token(Token = "0x6003433")]
		private get { } //Length: 80
		[Address(RVA = "0x5190C48", Offset = "0x5190C48", Length = "0x170")]
		[Token(Token = "0x6003434")]
		private set { } //Length: 368
	}

	[Address(RVA = "0x5192FB0", Offset = "0x5192FB0", Length = "0xA8")]
	[Token(Token = "0x6003464")]
	private static List`1() { }

	[Address(RVA = "0x519063C", Offset = "0x519063C", Length = "0x278")]
	[Token(Token = "0x6003427")]
	public List`1(IEnumerable<T> collection) { }

	[Address(RVA = "0x5190514", Offset = "0x5190514", Length = "0x70")]
	[Token(Token = "0x6003425")]
	public List`1() { }

	[Address(RVA = "0x5190584", Offset = "0x5190584", Length = "0xB8")]
	[Token(Token = "0x6003426")]
	public List`1(int capacity) { }

	[Address(RVA = "0x5190DB8", Offset = "0x5190DB8", Length = "0x68")]
	[Token(Token = "0x6003435")]
	public override void Add(T item) { }

	[Address(RVA = "0x5192C6C", Offset = "0x5192C6C", Length = "0x344")]
	[Token(Token = "0x6003463")]
	private void AddEnumerable(IEnumerable<T> enumerable) { }

	[Address(RVA = "0x5191010", Offset = "0x5191010", Length = "0x20")]
	[Token(Token = "0x6003438")]
	public void AddRange(IEnumerable<T> collection) { }

	[Address(RVA = "0x5190E20", Offset = "0x5190E20", Length = "0x74")]
	[Token(Token = "0x6003436")]
	private void AddWithResize(T item) { }

	[Address(RVA = "0x5191030", Offset = "0x5191030", Length = "0x6C")]
	[Token(Token = "0x6003439")]
	public ReadOnlyCollection<T> AsReadOnly() { }

	[Address(RVA = "0x519109C", Offset = "0x519109C", Length = "0x28")]
	[Token(Token = "0x600343A")]
	public override void Clear() { }

	[Address(RVA = "0x51910C4", Offset = "0x51910C4", Length = "0x38")]
	[Token(Token = "0x600343B")]
	public override bool Contains(T item) { }

	[Address(RVA = "0x3D67450", Offset = "0x3D67450", Length = "0xFC")]
	[Token(Token = "0x600343D")]
	public List<TOutput> ConvertAll(Converter<T, TOutput> converter) { }

	[Address(RVA = "0x51912E4", Offset = "0x51912E4", Length = "0x64")]
	[Token(Token = "0x6003440")]
	public void CopyTo(int index, T[] array, int arrayIndex, int count) { }

	[Address(RVA = "0x5191348", Offset = "0x5191348", Length = "0x20")]
	[Token(Token = "0x6003441")]
	public override void CopyTo(T[] array, int arrayIndex) { }

	[Address(RVA = "0x51911F0", Offset = "0x51911F0", Length = "0x18")]
	[Token(Token = "0x600343E")]
	public void CopyTo(T[] array) { }

	[Address(RVA = "0x5191368", Offset = "0x5191368", Length = "0x60")]
	[Token(Token = "0x6003442")]
	private void EnsureCapacity(int min) { }

	[Address(RVA = "0x51913C8", Offset = "0x51913C8", Length = "0x28")]
	[Token(Token = "0x6003443")]
	public bool Exists(Predicate<T> match) { }

	[Address(RVA = "0x51913F0", Offset = "0x51913F0", Length = "0xC8")]
	[Token(Token = "0x6003444")]
	public T Find(Predicate<T> match) { }

	[Address(RVA = "0x51914B8", Offset = "0x51914B8", Length = "0x118")]
	[Token(Token = "0x6003445")]
	public List<T> FindAll(Predicate<T> match) { }

	[Address(RVA = "0x51915F0", Offset = "0x51915F0", Length = "0xE4")]
	[Token(Token = "0x6003447")]
	public int FindIndex(int startIndex, int count, Predicate<T> match) { }

	[Address(RVA = "0x51915D0", Offset = "0x51915D0", Length = "0x20")]
	[Token(Token = "0x6003446")]
	public int FindIndex(Predicate<T> match) { }

	[Address(RVA = "0x51916D4", Offset = "0x51916D4", Length = "0xAC")]
	[Token(Token = "0x6003448")]
	public T FindLast(Predicate<T> match) { }

	[Address(RVA = "0x51917A4", Offset = "0x51917A4", Length = "0xF0")]
	[Token(Token = "0x600344A")]
	public int FindLastIndex(int startIndex, int count, Predicate<T> match) { }

	[Address(RVA = "0x5191780", Offset = "0x5191780", Length = "0x24")]
	[Token(Token = "0x6003449")]
	public int FindLastIndex(Predicate<T> match) { }

	[Address(RVA = "0x5191894", Offset = "0x5191894", Length = "0xD8")]
	[Token(Token = "0x600344B")]
	public void ForEach(Action<T> action) { }

	[Address(RVA = "0x51908B4", Offset = "0x51908B4", Length = "0x1C")]
	[Token(Token = "0x6003428")]
	public int get_Capacity() { }

	[Address(RVA = "0x51909DC", Offset = "0x51909DC", Length = "0x8")]
	[Token(Token = "0x600342A")]
	public override int get_Count() { }

	[Address(RVA = "0x5190A7C", Offset = "0x5190A7C", Length = "0x54")]
	[Token(Token = "0x6003430")]
	public override T get_Item(int index) { }

	[Address(RVA = "0x519196C", Offset = "0x519196C", Length = "0x24")]
	[Token(Token = "0x600344C")]
	public Enumerator<T> GetEnumerator() { }

	[Address(RVA = "0x5191A50", Offset = "0x5191A50", Length = "0xD4")]
	[Token(Token = "0x600344F")]
	public List<T> GetRange(int index, int count) { }

	[Address(RVA = "0x5191B24", Offset = "0x5191B24", Length = "0x24")]
	[Token(Token = "0x6003450")]
	public override int IndexOf(T item) { }

	[Address(RVA = "0x5191C3C", Offset = "0x5191C3C", Length = "0xE0")]
	[Token(Token = "0x6003452")]
	public override void Insert(int index, T item) { }

	[Address(RVA = "0x5191E8C", Offset = "0x5191E8C", Length = "0x514")]
	[Token(Token = "0x6003454")]
	public void InsertRange(int index, IEnumerable<T> collection) { }

	[Address(RVA = "0x5190B48", Offset = "0x5190B48", Length = "0xB0")]
	[Token(Token = "0x6003432")]
	private static bool IsCompatibleObject(object value) { }

	[Address(RVA = "0x51923A0", Offset = "0x51923A0", Length = "0x5C")]
	[Token(Token = "0x6003455")]
	public override bool Remove(T item) { }

	[Address(RVA = "0x51924EC", Offset = "0x51924EC", Length = "0x198")]
	[Token(Token = "0x6003457")]
	public int RemoveAll(Predicate<T> match) { }

	[Address(RVA = "0x5192684", Offset = "0x5192684", Length = "0x98")]
	[Token(Token = "0x6003458")]
	public override void RemoveAt(int index) { }

	[Address(RVA = "0x519271C", Offset = "0x519271C", Length = "0xC0")]
	[Token(Token = "0x6003459")]
	public void RemoveRange(int index, int count) { }

	[Address(RVA = "0x5192828", Offset = "0x5192828", Length = "0xA4")]
	[Token(Token = "0x600345B")]
	public void Reverse(int index, int count) { }

	[Address(RVA = "0x51927DC", Offset = "0x51927DC", Length = "0x4C")]
	[Token(Token = "0x600345A")]
	public void Reverse() { }

	[Address(RVA = "0x51908D0", Offset = "0x51908D0", Length = "0x10C")]
	[Token(Token = "0x6003429")]
	public void set_Capacity(int value) { }

	[Address(RVA = "0x5190AD0", Offset = "0x5190AD0", Length = "0x78")]
	[Token(Token = "0x6003431")]
	public override void set_Item(int index, T value) { }

	[Address(RVA = "0x51928CC", Offset = "0x51928CC", Length = "0x50")]
	[Token(Token = "0x600345C")]
	public void Sort() { }

	[Address(RVA = "0x5192A1C", Offset = "0x5192A1C", Length = "0x98")]
	[Token(Token = "0x600345F")]
	public void Sort(Comparison<T> comparison) { }

	[Address(RVA = "0x5192970", Offset = "0x5192970", Length = "0xAC")]
	[Token(Token = "0x600345E")]
	public void Sort(int index, int count, IComparer<T> comparer) { }

	[Address(RVA = "0x519291C", Offset = "0x519291C", Length = "0x54")]
	[Token(Token = "0x600345D")]
	public void Sort(IComparer<T> comparer) { }

	[Address(RVA = "0x51909EC", Offset = "0x51909EC", Length = "0x8")]
	[Token(Token = "0x600342C")]
	private override bool System.Collections.Generic.ICollection<T>.get_IsReadOnly() { }

	[Address(RVA = "0x5191990", Offset = "0x5191990", Length = "0x60")]
	[Token(Token = "0x600344D")]
	private override IEnumerator<T> System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	[Address(RVA = "0x5191208", Offset = "0x5191208", Length = "0xDC")]
	[Token(Token = "0x600343F")]
	private override void System.Collections.ICollection.CopyTo(Array array, int arrayIndex) { }

	[Address(RVA = "0x51909FC", Offset = "0x51909FC", Length = "0x8")]
	[Token(Token = "0x600342E")]
	private override bool System.Collections.ICollection.get_IsSynchronized() { }

	[Address(RVA = "0x5190A04", Offset = "0x5190A04", Length = "0x78")]
	[Token(Token = "0x600342F")]
	private override object System.Collections.ICollection.get_SyncRoot() { }

	[Address(RVA = "0x51919F0", Offset = "0x51919F0", Length = "0x60")]
	[Token(Token = "0x600344E")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	[Address(RVA = "0x5190E94", Offset = "0x5190E94", Length = "0x17C")]
	[Token(Token = "0x6003437")]
	private override int System.Collections.IList.Add(object item) { }

	[Address(RVA = "0x51910FC", Offset = "0x51910FC", Length = "0xF4")]
	[Token(Token = "0x600343C")]
	private override bool System.Collections.IList.Contains(object item) { }

	[Address(RVA = "0x51909E4", Offset = "0x51909E4", Length = "0x8")]
	[Token(Token = "0x600342B")]
	private override bool System.Collections.IList.get_IsFixedSize() { }

	[Address(RVA = "0x51909F4", Offset = "0x51909F4", Length = "0x8")]
	[Token(Token = "0x600342D")]
	private override bool System.Collections.IList.get_IsReadOnly() { }

	[Address(RVA = "0x5190BF8", Offset = "0x5190BF8", Length = "0x50")]
	[Token(Token = "0x6003433")]
	private override object System.Collections.IList.get_Item(int index) { }

	[Address(RVA = "0x5191B48", Offset = "0x5191B48", Length = "0xF4")]
	[Token(Token = "0x6003451")]
	private override int System.Collections.IList.IndexOf(object item) { }

	[Address(RVA = "0x5191D1C", Offset = "0x5191D1C", Length = "0x170")]
	[Token(Token = "0x6003453")]
	private override void System.Collections.IList.Insert(int index, object item) { }

	[Address(RVA = "0x51923FC", Offset = "0x51923FC", Length = "0xF0")]
	[Token(Token = "0x6003456")]
	private override void System.Collections.IList.Remove(object item) { }

	[Address(RVA = "0x5190C48", Offset = "0x5190C48", Length = "0x170")]
	[Token(Token = "0x6003434")]
	private override void System.Collections.IList.set_Item(int index, object value) { }

	[Address(RVA = "0x5192AB4", Offset = "0x5192AB4", Length = "0xA8")]
	[Token(Token = "0x6003460")]
	public T[] ToArray() { }

	[Address(RVA = "0x5192B5C", Offset = "0x5192B5C", Length = "0x64")]
	[Token(Token = "0x6003461")]
	public void TrimExcess() { }

	[Address(RVA = "0x5192BC0", Offset = "0x5192BC0", Length = "0xAC")]
	[Token(Token = "0x6003462")]
	public bool TrueForAll(Predicate<T> match) { }

}

