namespace System.Collections.Generic;

[Token(Token = "0x2000688")]
public interface IEnumerable : IEnumerable
{

	[Token(Token = "0x600340C")]
	public IEnumerator<T> GetEnumerator() { }

}

