namespace System.Collections.Generic;

[Token(Token = "0x2000681")]
public interface ICollection : IEnumerable<T>, IEnumerable
{

	[Token(Token = "0x17000875")]
	public int Count
	{
		[Token(Token = "0x60033FC")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000876")]
	public bool IsReadOnly
	{
		[Token(Token = "0x60033FD")]
		 get { } //Length: 0
	}

	[Token(Token = "0x60033FE")]
	public void Add(T item) { }

	[Token(Token = "0x60033FF")]
	public void Clear() { }

	[Token(Token = "0x6003400")]
	public bool Contains(T item) { }

	[Token(Token = "0x6003401")]
	public void CopyTo(T[] array, int arrayIndex) { }

	[Token(Token = "0x60033FC")]
	public int get_Count() { }

	[Token(Token = "0x60033FD")]
	public bool get_IsReadOnly() { }

	[Token(Token = "0x6003402")]
	public bool Remove(T item) { }

}

