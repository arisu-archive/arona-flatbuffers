namespace System.Collections.Generic;

[DebuggerDisplay("Count = {Count}")]
[DebuggerTypeProxy(typeof(StackDebugView`1))]
[Token(Token = "0x200069F")]
[TypeForwardedFrom("System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")]
public class Stack : IEnumerable<T>, IEnumerable, ICollection, IReadOnlyCollection<T>
{
	[Token(Token = "0x20006A0")]
	internal struct Enumerator : IEnumerator<T>, IDisposable, IEnumerator
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C39")]
		private readonly Stack<T> _stack; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C3A")]
		private readonly int _version; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C3B")]
		private int _index; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C3C")]
		private T _currentElement; //Field offset: 0x0

		[Token(Token = "0x1700089B")]
		public override T Current
		{
			[Address(RVA = "0x4887CF8", Offset = "0x4887CF8", Length = "0x34")]
			[Token(Token = "0x60034C2")]
			 get { } //Length: 52
		}

		[Token(Token = "0x1700089C")]
		private override object System.Collections.IEnumerator.Current
		{
			[Address(RVA = "0x4887D98", Offset = "0x4887D98", Length = "0x78")]
			[Token(Token = "0x60034C4")]
			private get { } //Length: 120
		}

		[Address(RVA = "0x4887BC8", Offset = "0x4887BC8", Length = "0x40")]
		[Token(Token = "0x60034BF")]
		internal Enumerator(Stack<T> stack) { }

		[Address(RVA = "0x4887C08", Offset = "0x4887C08", Length = "0xC")]
		[Token(Token = "0x60034C0")]
		public override void Dispose() { }

		[Address(RVA = "0x4887CF8", Offset = "0x4887CF8", Length = "0x34")]
		[Token(Token = "0x60034C2")]
		public override T get_Current() { }

		[Address(RVA = "0x4887C14", Offset = "0x4887C14", Length = "0xE4")]
		[Token(Token = "0x60034C1")]
		public override bool MoveNext() { }

		[Address(RVA = "0x4887D98", Offset = "0x4887D98", Length = "0x78")]
		[Token(Token = "0x60034C4")]
		private override object System.Collections.IEnumerator.get_Current() { }

		[Address(RVA = "0x4887E10", Offset = "0x4887E10", Length = "0x80")]
		[Token(Token = "0x60034C5")]
		private override void System.Collections.IEnumerator.Reset() { }

		[Address(RVA = "0x4887D2C", Offset = "0x4887D2C", Length = "0x6C")]
		[Token(Token = "0x60034C3")]
		private void ThrowEnumerationNotStartedOrEnded() { }

	}

	[Token(Token = "0x4001C38")]
	private const int DefaultCapacity = 4; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C34")]
	private T[] _array; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C35")]
	private int _size; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C36")]
	private int _version; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C37")]
	private object _syncRoot; //Field offset: 0x0

	[Token(Token = "0x17000898")]
	public override int Count
	{
		[Address(RVA = "0x5F1D0D0", Offset = "0x5F1D0D0", Length = "0x8")]
		[Token(Token = "0x60034B0")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000899")]
	private override bool System.Collections.ICollection.IsSynchronized
	{
		[Address(RVA = "0x5F1D0D8", Offset = "0x5F1D0D8", Length = "0x8")]
		[Token(Token = "0x60034B1")]
		private get { } //Length: 8
	}

	[Token(Token = "0x1700089A")]
	private override object System.Collections.ICollection.SyncRoot
	{
		[Address(RVA = "0x5F1D0E0", Offset = "0x5F1D0E0", Length = "0x78")]
		[Token(Token = "0x60034B2")]
		private get { } //Length: 120
	}

	[Address(RVA = "0x5F1CF0C", Offset = "0x5F1CF0C", Length = "0x44")]
	[Token(Token = "0x60034AD")]
	public Stack`1() { }

	[Address(RVA = "0x5F1CF50", Offset = "0x5F1CF50", Length = "0xE0")]
	[Token(Token = "0x60034AE")]
	public Stack`1(int capacity) { }

	[Address(RVA = "0x5F1D030", Offset = "0x5F1D030", Length = "0xA0")]
	[Token(Token = "0x60034AF")]
	public Stack`1(IEnumerable<T> collection) { }

	[Address(RVA = "0x5F1D158", Offset = "0x5F1D158", Length = "0x10")]
	[Token(Token = "0x60034B3")]
	public void Clear() { }

	[Address(RVA = "0x5F1D0D0", Offset = "0x5F1D0D0", Length = "0x8")]
	[Token(Token = "0x60034B0")]
	public override int get_Count() { }

	[Address(RVA = "0x5F1D424", Offset = "0x5F1D424", Length = "0x24")]
	[Token(Token = "0x60034B5")]
	public Enumerator<T> GetEnumerator() { }

	[Address(RVA = "0x5F1D518", Offset = "0x5F1D518", Length = "0x60")]
	[Token(Token = "0x60034B8")]
	public T Peek() { }

	[Address(RVA = "0x5F1D578", Offset = "0x5F1D578", Length = "0x74")]
	[Token(Token = "0x60034B9")]
	public T Pop() { }

	[Address(RVA = "0x5F1D640", Offset = "0x5F1D640", Length = "0x58")]
	[Token(Token = "0x60034BB")]
	public void Push(T item) { }

	[Address(RVA = "0x5F1D698", Offset = "0x5F1D698", Length = "0x84")]
	[Token(Token = "0x60034BC")]
	private void PushWithResize(T item) { }

	[Address(RVA = "0x5F1D448", Offset = "0x5F1D448", Length = "0x68")]
	[Token(Token = "0x60034B6")]
	private override IEnumerator<T> System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	[Address(RVA = "0x5F1D168", Offset = "0x5F1D168", Length = "0x2BC")]
	[Token(Token = "0x60034B4")]
	private override void System.Collections.ICollection.CopyTo(Array array, int arrayIndex) { }

	[Address(RVA = "0x5F1D0D8", Offset = "0x5F1D0D8", Length = "0x8")]
	[Token(Token = "0x60034B1")]
	private override bool System.Collections.ICollection.get_IsSynchronized() { }

	[Address(RVA = "0x5F1D0E0", Offset = "0x5F1D0E0", Length = "0x78")]
	[Token(Token = "0x60034B2")]
	private override object System.Collections.ICollection.get_SyncRoot() { }

	[Address(RVA = "0x5F1D4B0", Offset = "0x5F1D4B0", Length = "0x68")]
	[Token(Token = "0x60034B7")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	[Address(RVA = "0x5F1D7E0", Offset = "0x5F1D7E0", Length = "0x50")]
	[Token(Token = "0x60034BE")]
	private void ThrowForEmptyStack() { }

	[Address(RVA = "0x5F1D71C", Offset = "0x5F1D71C", Length = "0xC4")]
	[Token(Token = "0x60034BD")]
	public T[] ToArray() { }

	[Address(RVA = "0x5F1D5EC", Offset = "0x5F1D5EC", Length = "0x54")]
	[Token(Token = "0x60034BA")]
	public bool TryPop(out T result) { }

}

