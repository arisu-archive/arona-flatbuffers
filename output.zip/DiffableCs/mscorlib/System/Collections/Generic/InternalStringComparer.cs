namespace System.Collections.Generic;

[Token(Token = "0x20006B8")]
internal sealed class InternalStringComparer : EqualityComparer<String>
{

	[Address(RVA = "0x73CB8B8", Offset = "0x73CB8B8", Length = "0x48")]
	[Token(Token = "0x6003553")]
	public InternalStringComparer() { }

	[Address(RVA = "0x73CB820", Offset = "0x73CB820", Length = "0x30")]
	[Token(Token = "0x6003551")]
	public virtual bool Equals(string x, string y) { }

	[Address(RVA = "0x73CB800", Offset = "0x73CB800", Length = "0x20")]
	[Token(Token = "0x6003550")]
	public virtual int GetHashCode(string obj) { }

	[Address(RVA = "0x73CB850", Offset = "0x73CB850", Length = "0x68")]
	[Token(Token = "0x6003552")]
	internal virtual int IndexOf(String[] array, string value, int startIndex, int count) { }

}

