namespace System.Collections.Generic;

[Token(Token = "0x20006AE")]
internal class ComparisonComparer : Comparer<T>
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C49")]
	private readonly Comparison<T> _comparison; //Field offset: 0x0

	[Address(RVA = "0x6DB1BEC", Offset = "0x6DB1BEC", Length = "0x3C")]
	[Token(Token = "0x6003515")]
	public ComparisonComparer`1(Comparison<T> comparison) { }

	[Address(RVA = "0x6DB1C28", Offset = "0x6DB1C28", Length = "0x28")]
	[Token(Token = "0x6003516")]
	public virtual int Compare(T x, T y) { }

}

