namespace System.Collections.Generic;

[Token(Token = "0x2000686")]
internal sealed class DictionaryKeyCollectionDebugView
{

}

