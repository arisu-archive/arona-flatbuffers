namespace System.Collections.Generic;

[Token(Token = "0x20006AC")]
internal class NullableComparer : Comparer<Nullable`1<T>>
{

	[Address(RVA = "0x596CAFC", Offset = "0x596CAFC", Length = "0x14")]
	[Token(Token = "0x6003510")]
	public NullableComparer`1() { }

	[Address(RVA = "0x596CA28", Offset = "0x596CA28", Length = "0x3C")]
	[Token(Token = "0x600350D")]
	public virtual int Compare(Nullable<T> x, Nullable<T> y) { }

	[Address(RVA = "0x596CA64", Offset = "0x596CA64", Length = "0x5C")]
	[Token(Token = "0x600350E")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x596CAC0", Offset = "0x596CAC0", Length = "0x3C")]
	[Token(Token = "0x600350F")]
	public virtual int GetHashCode() { }

}

