namespace System.Collections.Generic;

[DebuggerDisplay("Count = {Count}")]
[DebuggerTypeProxy(typeof(IDictionaryDebugView`2))]
[DefaultMember("Item")]
[Token(Token = "0x200067A")]
public class Dictionary : IDictionary<TKey, TValue>, ICollection<KeyValuePair`2<TKey, TValue>>, IEnumerable<KeyValuePair`2<TKey, TValue>>, IEnumerable, IDictionary, ICollection, IReadOnlyDictionary<TKey, TValue>, IReadOnlyCollection<KeyValuePair`2<TKey, TValue>>, ISerializable, IDeserializationCallback
{
	[Token(Token = "0x200067B")]
	private struct Entry
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BF7")]
		public int hashCode; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BF8")]
		public int next; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BF9")]
		public TKey key; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BFA")]
		public TValue value; //Field offset: 0x0

	}

	[Token(Token = "0x200067C")]
	internal struct Enumerator : IEnumerator<KeyValuePair`2<TKey, TValue>>, IDisposable, IEnumerator, IDictionaryEnumerator
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BFB")]
		private Dictionary<TKey, TValue> _dictionary; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BFC")]
		private int _version; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BFD")]
		private int _index; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BFE")]
		private KeyValuePair<TKey, TValue> _current; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BFF")]
		private int _getEnumeratorRetType; //Field offset: 0x0

		[Token(Token = "0x17000864")]
		public override KeyValuePair<TKey, TValue> Current
		{
			[Address(RVA = "0x48B8AE8", Offset = "0x48B8AE8", Length = "0xC")]
			[Token(Token = "0x60033CD")]
			 get { } //Length: 12
		}

		[Token(Token = "0x17000866")]
		private override DictionaryEntry System.Collections.IDictionaryEnumerator.Entry
		{
			[Address(RVA = "0x48B8CFC", Offset = "0x48B8CFC", Length = "0xD4")]
			[Token(Token = "0x60033D1")]
			private get { } //Length: 212
		}

		[Token(Token = "0x17000867")]
		private override object System.Collections.IDictionaryEnumerator.Key
		{
			[Address(RVA = "0x48B8DD0", Offset = "0x48B8DD0", Length = "0xA0")]
			[Token(Token = "0x60033D2")]
			private get { } //Length: 160
		}

		[Token(Token = "0x17000868")]
		private override object System.Collections.IDictionaryEnumerator.Value
		{
			[Address(RVA = "0x48B8E70", Offset = "0x48B8E70", Length = "0x5C")]
			[Token(Token = "0x60033D3")]
			private get { } //Length: 92
		}

		[Token(Token = "0x17000865")]
		private override object System.Collections.IEnumerator.Current
		{
			[Address(RVA = "0x48B8AF8", Offset = "0x48B8AF8", Length = "0x1C0")]
			[Token(Token = "0x60033CF")]
			private get { } //Length: 448
		}

		[Address(RVA = "0x48B896C", Offset = "0x48B896C", Length = "0x44")]
		[Token(Token = "0x60033CB")]
		internal Enumerator(Dictionary<TKey, TValue> dictionary, int getEnumeratorRetType) { }

		[Address(RVA = "0x48B8AF4", Offset = "0x48B8AF4", Length = "0x4")]
		[Token(Token = "0x60033CE")]
		public override void Dispose() { }

		[Address(RVA = "0x48B8AE8", Offset = "0x48B8AE8", Length = "0xC")]
		[Token(Token = "0x60033CD")]
		public override KeyValuePair<TKey, TValue> get_Current() { }

		[Address(RVA = "0x48B89B0", Offset = "0x48B89B0", Length = "0x138")]
		[Token(Token = "0x60033CC")]
		public override bool MoveNext() { }

		[Address(RVA = "0x48B8CFC", Offset = "0x48B8CFC", Length = "0xD4")]
		[Token(Token = "0x60033D1")]
		private override DictionaryEntry System.Collections.IDictionaryEnumerator.get_Entry() { }

		[Address(RVA = "0x48B8DD0", Offset = "0x48B8DD0", Length = "0xA0")]
		[Token(Token = "0x60033D2")]
		private override object System.Collections.IDictionaryEnumerator.get_Key() { }

		[Address(RVA = "0x48B8E70", Offset = "0x48B8E70", Length = "0x5C")]
		[Token(Token = "0x60033D3")]
		private override object System.Collections.IDictionaryEnumerator.get_Value() { }

		[Address(RVA = "0x48B8AF8", Offset = "0x48B8AF8", Length = "0x1C0")]
		[Token(Token = "0x60033CF")]
		private override object System.Collections.IEnumerator.get_Current() { }

		[Address(RVA = "0x48B8CB8", Offset = "0x48B8CB8", Length = "0x44")]
		[Token(Token = "0x60033D0")]
		private override void System.Collections.IEnumerator.Reset() { }

	}

	[DebuggerDisplay("Count = {Count}")]
	[DebuggerTypeProxy(typeof(DictionaryKeyCollectionDebugView`2))]
	[Token(Token = "0x200067D")]
	internal sealed class KeyCollection : ICollection<TKey>, IEnumerable<TKey>, IEnumerable, ICollection, IReadOnlyCollection<TKey>
	{
		[Token(Token = "0x200067E")]
		internal struct Enumerator : IEnumerator<TKey>, IDisposable, IEnumerator
		{
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x4001C01")]
			private Dictionary<TKey, TValue> _dictionary; //Field offset: 0x0
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x4001C02")]
			private int _index; //Field offset: 0x0
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x4001C03")]
			private int _version; //Field offset: 0x0
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x4001C04")]
			private TKey _currentKey; //Field offset: 0x0

			[Token(Token = "0x1700086D")]
			public override TKey Current
			{
				[Address(RVA = "0x48B8FE4", Offset = "0x48B8FE4", Length = "0x14")]
				[Token(Token = "0x60033E5")]
				 get { } //Length: 20
			}

			[Token(Token = "0x1700086E")]
			private override object System.Collections.IEnumerator.Current
			{
				[Address(RVA = "0x48B8FF8", Offset = "0x48B8FF8", Length = "0x8C")]
				[Token(Token = "0x60033E6")]
				private get { } //Length: 140
			}

			[Address(RVA = "0x48B8ECC", Offset = "0x48B8ECC", Length = "0x3C")]
			[Token(Token = "0x60033E2")]
			internal Enumerator(Dictionary<TKey, TValue> dictionary) { }

			[Address(RVA = "0x48B8F08", Offset = "0x48B8F08", Length = "0x4")]
			[Token(Token = "0x60033E3")]
			public override void Dispose() { }

			[Address(RVA = "0x48B8FE4", Offset = "0x48B8FE4", Length = "0x14")]
			[Token(Token = "0x60033E5")]
			public override TKey get_Current() { }

			[Address(RVA = "0x48B8F0C", Offset = "0x48B8F0C", Length = "0xD8")]
			[Token(Token = "0x60033E4")]
			public override bool MoveNext() { }

			[Address(RVA = "0x48B8FF8", Offset = "0x48B8FF8", Length = "0x8C")]
			[Token(Token = "0x60033E6")]
			private override object System.Collections.IEnumerator.get_Current() { }

			[Address(RVA = "0x48B9084", Offset = "0x48B9084", Length = "0x40")]
			[Token(Token = "0x60033E7")]
			private override void System.Collections.IEnumerator.Reset() { }

		}

		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C00")]
		private Dictionary<TKey, TValue> _dictionary; //Field offset: 0x0

		[Token(Token = "0x17000869")]
		public override int Count
		{
			[Address(RVA = "0x508517C", Offset = "0x508517C", Length = "0x28")]
			[Token(Token = "0x60033D7")]
			 get { } //Length: 40
		}

		[Token(Token = "0x1700086A")]
		private override bool System.Collections.Generic.ICollection<TKey>.IsReadOnly
		{
			[Address(RVA = "0x50851A4", Offset = "0x50851A4", Length = "0x8")]
			[Token(Token = "0x60033D8")]
			private get { } //Length: 8
		}

		[Token(Token = "0x1700086B")]
		private override bool System.Collections.ICollection.IsSynchronized
		{
			[Address(RVA = "0x5085610", Offset = "0x5085610", Length = "0x8")]
			[Token(Token = "0x60033E0")]
			private get { } //Length: 8
		}

		[Token(Token = "0x1700086C")]
		private override object System.Collections.ICollection.SyncRoot
		{
			[Address(RVA = "0x5085618", Offset = "0x5085618", Length = "0xA4")]
			[Token(Token = "0x60033E1")]
			private get { } //Length: 164
		}

		[Address(RVA = "0x5084FE8", Offset = "0x5084FE8", Length = "0x40")]
		[Token(Token = "0x60033D4")]
		public KeyCollection(Dictionary<TKey, TValue> dictionary) { }

		[Address(RVA = "0x508504C", Offset = "0x508504C", Length = "0x130")]
		[Token(Token = "0x60033D6")]
		public override void CopyTo(TKey[] array, int index) { }

		[Address(RVA = "0x508517C", Offset = "0x508517C", Length = "0x28")]
		[Token(Token = "0x60033D7")]
		public override int get_Count() { }

		[Address(RVA = "0x5085028", Offset = "0x5085028", Length = "0x24")]
		[Token(Token = "0x60033D5")]
		public Enumerator<TKey, TValue> GetEnumerator() { }

		[Address(RVA = "0x50851AC", Offset = "0x50851AC", Length = "0xC")]
		[Token(Token = "0x60033D9")]
		private override void System.Collections.Generic.ICollection<TKey>.Add(TKey item) { }

		[Address(RVA = "0x50851B8", Offset = "0x50851B8", Length = "0xC")]
		[Token(Token = "0x60033DA")]
		private override void System.Collections.Generic.ICollection<TKey>.Clear() { }

		[Address(RVA = "0x50851C4", Offset = "0x50851C4", Length = "0x50")]
		[Token(Token = "0x60033DB")]
		private override bool System.Collections.Generic.ICollection<TKey>.Contains(TKey item) { }

		[Address(RVA = "0x50851A4", Offset = "0x50851A4", Length = "0x8")]
		[Token(Token = "0x60033D8")]
		private override bool System.Collections.Generic.ICollection<TKey>.get_IsReadOnly() { }

		[Address(RVA = "0x5085214", Offset = "0x5085214", Length = "0x1C")]
		[Token(Token = "0x60033DC")]
		private override bool System.Collections.Generic.ICollection<TKey>.Remove(TKey item) { }

		[Address(RVA = "0x5085230", Offset = "0x5085230", Length = "0x6C")]
		[Token(Token = "0x60033DD")]
		private override IEnumerator<TKey> System.Collections.Generic.IEnumerable<TKey>.GetEnumerator() { }

		[Address(RVA = "0x5085308", Offset = "0x5085308", Length = "0x308")]
		[Token(Token = "0x60033DF")]
		private override void System.Collections.ICollection.CopyTo(Array array, int index) { }

		[Address(RVA = "0x5085610", Offset = "0x5085610", Length = "0x8")]
		[Token(Token = "0x60033E0")]
		private override bool System.Collections.ICollection.get_IsSynchronized() { }

		[Address(RVA = "0x5085618", Offset = "0x5085618", Length = "0xA4")]
		[Token(Token = "0x60033E1")]
		private override object System.Collections.ICollection.get_SyncRoot() { }

		[Address(RVA = "0x508529C", Offset = "0x508529C", Length = "0x6C")]
		[Token(Token = "0x60033DE")]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	}

	[DebuggerDisplay("Count = {Count}")]
	[DebuggerTypeProxy(typeof(DictionaryValueCollectionDebugView`2))]
	[Token(Token = "0x200067F")]
	internal sealed class ValueCollection : ICollection<TValue>, IEnumerable<TValue>, IEnumerable, ICollection, IReadOnlyCollection<TValue>
	{
		[Token(Token = "0x2000680")]
		internal struct Enumerator : IEnumerator<TValue>, IDisposable, IEnumerator
		{
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x4001C06")]
			private Dictionary<TKey, TValue> _dictionary; //Field offset: 0x0
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x4001C07")]
			private int _index; //Field offset: 0x0
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x4001C08")]
			private int _version; //Field offset: 0x0
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x4001C09")]
			private TValue _currentValue; //Field offset: 0x0

			[Token(Token = "0x17000873")]
			public override TValue Current
			{
				[Address(RVA = "0x48B91C8", Offset = "0x48B91C8", Length = "0x8")]
				[Token(Token = "0x60033F9")]
				 get { } //Length: 8
			}

			[Token(Token = "0x17000874")]
			private override object System.Collections.IEnumerator.Current
			{
				[Address(RVA = "0x48B91D0", Offset = "0x48B91D0", Length = "0x40")]
				[Token(Token = "0x60033FA")]
				private get { } //Length: 64
			}

			[Address(RVA = "0x48B90C4", Offset = "0x48B90C4", Length = "0x38")]
			[Token(Token = "0x60033F6")]
			internal Enumerator(Dictionary<TKey, TValue> dictionary) { }

			[Address(RVA = "0x48B90FC", Offset = "0x48B90FC", Length = "0x4")]
			[Token(Token = "0x60033F7")]
			public override void Dispose() { }

			[Address(RVA = "0x48B91C8", Offset = "0x48B91C8", Length = "0x8")]
			[Token(Token = "0x60033F9")]
			public override TValue get_Current() { }

			[Address(RVA = "0x48B9100", Offset = "0x48B9100", Length = "0xC8")]
			[Token(Token = "0x60033F8")]
			public override bool MoveNext() { }

			[Address(RVA = "0x48B91D0", Offset = "0x48B91D0", Length = "0x40")]
			[Token(Token = "0x60033FA")]
			private override object System.Collections.IEnumerator.get_Current() { }

			[Address(RVA = "0x48B9210", Offset = "0x48B9210", Length = "0x3C")]
			[Token(Token = "0x60033FB")]
			private override void System.Collections.IEnumerator.Reset() { }

		}

		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C05")]
		private Dictionary<TKey, TValue> _dictionary; //Field offset: 0x0

		[Token(Token = "0x1700086F")]
		public override int Count
		{
			[Address(RVA = "0x6092280", Offset = "0x6092280", Length = "0x28")]
			[Token(Token = "0x60033EB")]
			 get { } //Length: 40
		}

		[Token(Token = "0x17000870")]
		private override bool System.Collections.Generic.ICollection<TValue>.IsReadOnly
		{
			[Address(RVA = "0x60922A8", Offset = "0x60922A8", Length = "0x8")]
			[Token(Token = "0x60033EC")]
			private get { } //Length: 8
		}

		[Token(Token = "0x17000871")]
		private override bool System.Collections.ICollection.IsSynchronized
		{
			[Address(RVA = "0x60926B0", Offset = "0x60926B0", Length = "0x8")]
			[Token(Token = "0x60033F4")]
			private get { } //Length: 8
		}

		[Token(Token = "0x17000872")]
		private override object System.Collections.ICollection.SyncRoot
		{
			[Address(RVA = "0x60926B8", Offset = "0x60926B8", Length = "0xA4")]
			[Token(Token = "0x60033F5")]
			private get { } //Length: 164
		}

		[Address(RVA = "0x6092100", Offset = "0x6092100", Length = "0x40")]
		[Token(Token = "0x60033E8")]
		public ValueCollection(Dictionary<TKey, TValue> dictionary) { }

		[Address(RVA = "0x6092160", Offset = "0x6092160", Length = "0x120")]
		[Token(Token = "0x60033EA")]
		public override void CopyTo(TValue[] array, int index) { }

		[Address(RVA = "0x6092280", Offset = "0x6092280", Length = "0x28")]
		[Token(Token = "0x60033EB")]
		public override int get_Count() { }

		[Address(RVA = "0x6092140", Offset = "0x6092140", Length = "0x20")]
		[Token(Token = "0x60033E9")]
		public Enumerator<TKey, TValue> GetEnumerator() { }

		[Address(RVA = "0x60922B0", Offset = "0x60922B0", Length = "0xC")]
		[Token(Token = "0x60033ED")]
		private override void System.Collections.Generic.ICollection<TValue>.Add(TValue item) { }

		[Address(RVA = "0x60922D8", Offset = "0x60922D8", Length = "0xC")]
		[Token(Token = "0x60033EF")]
		private override void System.Collections.Generic.ICollection<TValue>.Clear() { }

		[Address(RVA = "0x60922E4", Offset = "0x60922E4", Length = "0x28")]
		[Token(Token = "0x60033F0")]
		private override bool System.Collections.Generic.ICollection<TValue>.Contains(TValue item) { }

		[Address(RVA = "0x60922A8", Offset = "0x60922A8", Length = "0x8")]
		[Token(Token = "0x60033EC")]
		private override bool System.Collections.Generic.ICollection<TValue>.get_IsReadOnly() { }

		[Address(RVA = "0x60922BC", Offset = "0x60922BC", Length = "0x1C")]
		[Token(Token = "0x60033EE")]
		private override bool System.Collections.Generic.ICollection<TValue>.Remove(TValue item) { }

		[Address(RVA = "0x609230C", Offset = "0x609230C", Length = "0x68")]
		[Token(Token = "0x60033F1")]
		private override IEnumerator<TValue> System.Collections.Generic.IEnumerable<TValue>.GetEnumerator() { }

		[Address(RVA = "0x60923DC", Offset = "0x60923DC", Length = "0x2D4")]
		[Token(Token = "0x60033F3")]
		private override void System.Collections.ICollection.CopyTo(Array array, int index) { }

		[Address(RVA = "0x60926B0", Offset = "0x60926B0", Length = "0x8")]
		[Token(Token = "0x60033F4")]
		private override bool System.Collections.ICollection.get_IsSynchronized() { }

		[Address(RVA = "0x60926B8", Offset = "0x60926B8", Length = "0xA4")]
		[Token(Token = "0x60033F5")]
		private override object System.Collections.ICollection.get_SyncRoot() { }

		[Address(RVA = "0x6092374", Offset = "0x6092374", Length = "0x68")]
		[Token(Token = "0x60033F2")]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	}

	[Token(Token = "0x4001BF3")]
	private const string VersionName = "Version"; //Field offset: 0x0
	[Token(Token = "0x4001BF4")]
	private const string HashSizeName = "HashSize"; //Field offset: 0x0
	[Token(Token = "0x4001BF5")]
	private const string KeyValuePairsName = "KeyValuePairs"; //Field offset: 0x0
	[Token(Token = "0x4001BF6")]
	private const string ComparerName = "Comparer"; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BE9")]
	private Int32[] _buckets; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BEA")]
	private Entry<TKey, TValue>[] _entries; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BEB")]
	private int _count; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BEC")]
	private int _freeList; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BED")]
	private int _freeCount; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BEE")]
	private int _version; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BEF")]
	private IEqualityComparer<TKey> _comparer; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BF0")]
	private KeyCollection<TKey, TValue> _keys; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BF1")]
	private ValueCollection<TKey, TValue> _values; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BF2")]
	private object _syncRoot; //Field offset: 0x0

	[Token(Token = "0x17000853")]
	public IEqualityComparer<TKey> Comparer
	{
		[Address(RVA = "0x6E480BC", Offset = "0x6E480BC", Length = "0x20")]
		[Token(Token = "0x600339C")]
		 get { } //Length: 32
	}

	[Token(Token = "0x17000854")]
	public override int Count
	{
		[Address(RVA = "0x6E480DC", Offset = "0x6E480DC", Length = "0x10")]
		[Token(Token = "0x600339D")]
		 get { } //Length: 16
	}

	[Token(Token = "0x1700085B")]
	public override TValue Item
	{
		[Address(RVA = "0x6E48404", Offset = "0x6E48404", Length = "0xC0")]
		[Token(Token = "0x60033A4")]
		 get { } //Length: 192
		[Address(RVA = "0x6E484C4", Offset = "0x6E484C4", Length = "0x44")]
		[Token(Token = "0x60033A5")]
		 set { } //Length: 68
	}

	[Token(Token = "0x17000855")]
	public KeyCollection<TKey, TValue> Keys
	{
		[Address(RVA = "0x6E480EC", Offset = "0x6E480EC", Length = "0x84")]
		[Token(Token = "0x600339E")]
		 get { } //Length: 132
	}

	[Token(Token = "0x1700085C")]
	private override bool System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.IsReadOnly
	{
		[Address(RVA = "0x6E4A18C", Offset = "0x6E4A18C", Length = "0x8")]
		[Token(Token = "0x60033BA")]
		private get { } //Length: 8
	}

	[Token(Token = "0x17000856")]
	private override ICollection<TKey> System.Collections.Generic.IDictionary<TKey,TValue>.Keys
	{
		[Address(RVA = "0x6E48170", Offset = "0x6E48170", Length = "0x84")]
		[Token(Token = "0x600339F")]
		private get { } //Length: 132
	}

	[Token(Token = "0x17000859")]
	private override ICollection<TValue> System.Collections.Generic.IDictionary<TKey,TValue>.Values
	{
		[Address(RVA = "0x6E482FC", Offset = "0x6E482FC", Length = "0x84")]
		[Token(Token = "0x60033A2")]
		private get { } //Length: 132
	}

	[Token(Token = "0x17000857")]
	private override IEnumerable<TKey> System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.Keys
	{
		[Address(RVA = "0x6E481F4", Offset = "0x6E481F4", Length = "0x84")]
		[Token(Token = "0x60033A0")]
		private get { } //Length: 132
	}

	[Token(Token = "0x1700085A")]
	private override IEnumerable<TValue> System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.Values
	{
		[Address(RVA = "0x6E48380", Offset = "0x6E48380", Length = "0x84")]
		[Token(Token = "0x60033A3")]
		private get { } //Length: 132
	}

	[Token(Token = "0x1700085D")]
	private override bool System.Collections.ICollection.IsSynchronized
	{
		[Address(RVA = "0x6E4A648", Offset = "0x6E4A648", Length = "0x8")]
		[Token(Token = "0x60033BE")]
		private get { } //Length: 8
	}

	[Token(Token = "0x1700085E")]
	private override object System.Collections.ICollection.SyncRoot
	{
		[Address(RVA = "0x6E4A650", Offset = "0x6E4A650", Length = "0x78")]
		[Token(Token = "0x60033BF")]
		private get { } //Length: 120
	}

	[Token(Token = "0x1700085F")]
	private override bool System.Collections.IDictionary.IsFixedSize
	{
		[Address(RVA = "0x6E4A6C8", Offset = "0x6E4A6C8", Length = "0x8")]
		[Token(Token = "0x60033C0")]
		private get { } //Length: 8
	}

	[Token(Token = "0x17000860")]
	private override bool System.Collections.IDictionary.IsReadOnly
	{
		[Address(RVA = "0x6E4A6D0", Offset = "0x6E4A6D0", Length = "0x8")]
		[Token(Token = "0x60033C1")]
		private get { } //Length: 8
	}

	[Token(Token = "0x17000863")]
	private override object System.Collections.IDictionary.Item
	{
		[Address(RVA = "0x6E4A700", Offset = "0x6E4A700", Length = "0xF0")]
		[Token(Token = "0x60033C4")]
		private get { } //Length: 240
		[Address(RVA = "0x6E4A7F0", Offset = "0x6E4A7F0", Length = "0x2A4")]
		[Token(Token = "0x60033C5")]
		private set { } //Length: 676
	}

	[Token(Token = "0x17000861")]
	private override ICollection System.Collections.IDictionary.Keys
	{
		[Address(RVA = "0x6E4A6D8", Offset = "0x6E4A6D8", Length = "0x14")]
		[Token(Token = "0x60033C2")]
		private get { } //Length: 20
	}

	[Token(Token = "0x17000862")]
	private override ICollection System.Collections.IDictionary.Values
	{
		[Address(RVA = "0x6E4A6EC", Offset = "0x6E4A6EC", Length = "0x14")]
		[Token(Token = "0x60033C3")]
		private get { } //Length: 20
	}

	[Token(Token = "0x17000858")]
	public ValueCollection<TKey, TValue> Values
	{
		[Address(RVA = "0x6E48278", Offset = "0x6E48278", Length = "0x84")]
		[Token(Token = "0x60033A1")]
		 get { } //Length: 132
	}

	[Address(RVA = "0x6E47660", Offset = "0x6E47660", Length = "0x1C")]
	[Token(Token = "0x6003393")]
	public Dictionary`2() { }

	[Address(RVA = "0x6E4767C", Offset = "0x6E4767C", Length = "0x18")]
	[Token(Token = "0x6003394")]
	public Dictionary`2(int capacity) { }

	[Address(RVA = "0x6E47694", Offset = "0x6E47694", Length = "0x1C")]
	[Token(Token = "0x6003395")]
	public Dictionary`2(IEqualityComparer<TKey> comparer) { }

	[Address(RVA = "0x6E476B0", Offset = "0x6E476B0", Length = "0xA0")]
	[Token(Token = "0x6003396")]
	public Dictionary`2(int capacity, IEqualityComparer<TKey> comparer) { }

	[Address(RVA = "0x6E47750", Offset = "0x6E47750", Length = "0x18")]
	[Token(Token = "0x6003397")]
	public Dictionary`2(IDictionary<TKey, TValue> dictionary) { }

	[Address(RVA = "0x6E47768", Offset = "0x6E47768", Length = "0x4D0")]
	[Token(Token = "0x6003398")]
	public Dictionary`2(IDictionary<TKey, TValue> dictionary, IEqualityComparer<TKey> comparer) { }

	[Address(RVA = "0x6E47C38", Offset = "0x6E47C38", Length = "0x18")]
	[Token(Token = "0x6003399")]
	public Dictionary`2(IEnumerable<KeyValuePair`2<TKey, TValue>> collection) { }

	[Address(RVA = "0x6E47C50", Offset = "0x6E47C50", Length = "0x3D4")]
	[Token(Token = "0x600339A")]
	public Dictionary`2(IEnumerable<KeyValuePair`2<TKey, TValue>> collection, IEqualityComparer<TKey> comparer) { }

	[Address(RVA = "0x6E48024", Offset = "0x6E48024", Length = "0x98")]
	[Token(Token = "0x600339B")]
	protected Dictionary`2(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x6E48508", Offset = "0x6E48508", Length = "0x44")]
	[Token(Token = "0x60033A6")]
	public override void Add(TKey key, TValue value) { }

	[Address(RVA = "0x6E4874C", Offset = "0x6E4874C", Length = "0x6C")]
	[Token(Token = "0x60033AA")]
	public override void Clear() { }

	[Address(RVA = "0x6E487B8", Offset = "0x6E487B8", Length = "0x48")]
	[Token(Token = "0x60033AB")]
	public override bool ContainsKey(TKey key) { }

	[Address(RVA = "0x6E48800", Offset = "0x6E48800", Length = "0x100")]
	[Token(Token = "0x60033AC")]
	public bool ContainsValue(TValue value) { }

	[Address(RVA = "0x6E48900", Offset = "0x6E48900", Length = "0x148")]
	[Token(Token = "0x60033AD")]
	private void CopyTo(KeyValuePair<TKey, TValue>[] array, int index) { }

	[Address(RVA = "0x6E48D18", Offset = "0x6E48D18", Length = "0x378")]
	[Token(Token = "0x60033B1")]
	private int FindEntry(TKey key) { }

	[Address(RVA = "0x6E480BC", Offset = "0x6E480BC", Length = "0x20")]
	[Token(Token = "0x600339C")]
	public IEqualityComparer<TKey> get_Comparer() { }

	[Address(RVA = "0x6E480DC", Offset = "0x6E480DC", Length = "0x10")]
	[Token(Token = "0x600339D")]
	public override int get_Count() { }

	[Address(RVA = "0x6E48404", Offset = "0x6E48404", Length = "0xC0")]
	[Token(Token = "0x60033A4")]
	public override TValue get_Item(TKey key) { }

	[Address(RVA = "0x6E480EC", Offset = "0x6E480EC", Length = "0x84")]
	[Token(Token = "0x600339E")]
	public KeyCollection<TKey, TValue> get_Keys() { }

	[Address(RVA = "0x6E48278", Offset = "0x6E48278", Length = "0x84")]
	[Token(Token = "0x60033A1")]
	public ValueCollection<TKey, TValue> get_Values() { }

	[Address(RVA = "0x6E48A48", Offset = "0x6E48A48", Length = "0x2C")]
	[Token(Token = "0x60033AE")]
	public Enumerator<TKey, TValue> GetEnumerator() { }

	[Address(RVA = "0x6E48AF0", Offset = "0x6E48AF0", Length = "0x228")]
	[Token(Token = "0x60033B0")]
	public override void GetObjectData(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x6E49090", Offset = "0x6E49090", Length = "0xDC")]
	[Token(Token = "0x60033B2")]
	private int Initialize(int capacity) { }

	[Address(RVA = "0x6E4AA94", Offset = "0x6E4AA94", Length = "0x68")]
	[Token(Token = "0x60033C6")]
	private static bool IsCompatibleKey(object key) { }

	[Address(RVA = "0x6E496E8", Offset = "0x6E496E8", Length = "0x3A0")]
	[Token(Token = "0x60033B4")]
	public override void OnDeserialization(object sender) { }

	[Address(RVA = "0x6E49D0C", Offset = "0x6E49D0C", Length = "0x39C")]
	[Token(Token = "0x60033B7")]
	public override bool Remove(TKey key) { }

	[Address(RVA = "0x6E49B10", Offset = "0x6E49B10", Length = "0x1FC")]
	[Token(Token = "0x60033B6")]
	private void Resize(int newSize, bool forceNewHashCodes) { }

	[Address(RVA = "0x6E49A88", Offset = "0x6E49A88", Length = "0x88")]
	[Token(Token = "0x60033B5")]
	private void Resize() { }

	[Address(RVA = "0x6E484C4", Offset = "0x6E484C4", Length = "0x44")]
	[Token(Token = "0x60033A5")]
	public override void set_Item(TKey key, TValue value) { }

	[Address(RVA = "0x6E4854C", Offset = "0x6E4854C", Length = "0x40")]
	[Token(Token = "0x60033A7")]
	private override void System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Add(KeyValuePair<TKey, TValue> keyValuePair) { }

	[Address(RVA = "0x6E4858C", Offset = "0x6E4858C", Length = "0xC8")]
	[Token(Token = "0x60033A8")]
	private override bool System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Contains(KeyValuePair<TKey, TValue> keyValuePair) { }

	[Address(RVA = "0x6E4A194", Offset = "0x6E4A194", Length = "0x14")]
	[Token(Token = "0x60033BB")]
	private override void System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.CopyTo(KeyValuePair<TKey, TValue>[] array, int index) { }

	[Address(RVA = "0x6E4A18C", Offset = "0x6E4A18C", Length = "0x8")]
	[Token(Token = "0x60033BA")]
	private override bool System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.get_IsReadOnly() { }

	[Address(RVA = "0x6E48654", Offset = "0x6E48654", Length = "0xF8")]
	[Token(Token = "0x60033A9")]
	private override bool System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Remove(KeyValuePair<TKey, TValue> keyValuePair) { }

	[Address(RVA = "0x6E48170", Offset = "0x6E48170", Length = "0x84")]
	[Token(Token = "0x600339F")]
	private override ICollection<TKey> System.Collections.Generic.IDictionary<TKey,TValue>.get_Keys() { }

	[Address(RVA = "0x6E482FC", Offset = "0x6E482FC", Length = "0x84")]
	[Token(Token = "0x60033A2")]
	private override ICollection<TValue> System.Collections.Generic.IDictionary<TKey,TValue>.get_Values() { }

	[Address(RVA = "0x6E48A74", Offset = "0x6E48A74", Length = "0x7C")]
	[Token(Token = "0x60033AF")]
	private override IEnumerator<KeyValuePair`2<TKey, TValue>> System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<TKey,TValue>>.GetEnumerator() { }

	[Address(RVA = "0x6E481F4", Offset = "0x6E481F4", Length = "0x84")]
	[Token(Token = "0x60033A0")]
	private override IEnumerable<TKey> System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.get_Keys() { }

	[Address(RVA = "0x6E48380", Offset = "0x6E48380", Length = "0x84")]
	[Token(Token = "0x60033A3")]
	private override IEnumerable<TValue> System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.get_Values() { }

	[Address(RVA = "0x6E4A1A8", Offset = "0x6E4A1A8", Length = "0x424")]
	[Token(Token = "0x60033BC")]
	private override void System.Collections.ICollection.CopyTo(Array array, int index) { }

	[Address(RVA = "0x6E4A648", Offset = "0x6E4A648", Length = "0x8")]
	[Token(Token = "0x60033BE")]
	private override bool System.Collections.ICollection.get_IsSynchronized() { }

	[Address(RVA = "0x6E4A650", Offset = "0x6E4A650", Length = "0x78")]
	[Token(Token = "0x60033BF")]
	private override object System.Collections.ICollection.get_SyncRoot() { }

	[Address(RVA = "0x6E4AAFC", Offset = "0x6E4AAFC", Length = "0x2A4")]
	[Token(Token = "0x60033C7")]
	private override void System.Collections.IDictionary.Add(object key, object value) { }

	[Address(RVA = "0x6E4ADA0", Offset = "0x6E4ADA0", Length = "0xD0")]
	[Token(Token = "0x60033C8")]
	private override bool System.Collections.IDictionary.Contains(object key) { }

	[Address(RVA = "0x6E4A6C8", Offset = "0x6E4A6C8", Length = "0x8")]
	[Token(Token = "0x60033C0")]
	private override bool System.Collections.IDictionary.get_IsFixedSize() { }

	[Address(RVA = "0x6E4A6D0", Offset = "0x6E4A6D0", Length = "0x8")]
	[Token(Token = "0x60033C1")]
	private override bool System.Collections.IDictionary.get_IsReadOnly() { }

	[Address(RVA = "0x6E4A700", Offset = "0x6E4A700", Length = "0xF0")]
	[Token(Token = "0x60033C4")]
	private override object System.Collections.IDictionary.get_Item(object key) { }

	[Address(RVA = "0x6E4A6D8", Offset = "0x6E4A6D8", Length = "0x14")]
	[Token(Token = "0x60033C2")]
	private override ICollection System.Collections.IDictionary.get_Keys() { }

	[Address(RVA = "0x6E4A6EC", Offset = "0x6E4A6EC", Length = "0x14")]
	[Token(Token = "0x60033C3")]
	private override ICollection System.Collections.IDictionary.get_Values() { }

	[Address(RVA = "0x6E4AE70", Offset = "0x6E4AE70", Length = "0x7C")]
	[Token(Token = "0x60033C9")]
	private override IDictionaryEnumerator System.Collections.IDictionary.GetEnumerator() { }

	[Address(RVA = "0x6E4AEEC", Offset = "0x6E4AEEC", Length = "0xC4")]
	[Token(Token = "0x60033CA")]
	private override void System.Collections.IDictionary.Remove(object key) { }

	[Address(RVA = "0x6E4A7F0", Offset = "0x6E4A7F0", Length = "0x2A4")]
	[Token(Token = "0x60033C5")]
	private override void System.Collections.IDictionary.set_Item(object key, object value) { }

	[Address(RVA = "0x6E4A5CC", Offset = "0x6E4A5CC", Length = "0x7C")]
	[Token(Token = "0x60033BD")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	[Address(RVA = "0x6E4A144", Offset = "0x6E4A144", Length = "0x48")]
	[Token(Token = "0x60033B9")]
	public bool TryAdd(TKey key, TValue value) { }

	[Address(RVA = "0x6E4A0A8", Offset = "0x6E4A0A8", Length = "0x9C")]
	[Token(Token = "0x60033B8")]
	public override bool TryGetValue(TKey key, out TValue value) { }

	[Address(RVA = "0x6E4916C", Offset = "0x6E4916C", Length = "0x57C")]
	[Token(Token = "0x60033B3")]
	private bool TryInsert(TKey key, TValue value, InsertionBehavior behavior) { }

}

