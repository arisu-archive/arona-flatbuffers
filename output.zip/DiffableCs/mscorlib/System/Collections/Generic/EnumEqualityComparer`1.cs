namespace System.Collections.Generic;

[Token(Token = "0x20006B4")]
internal class EnumEqualityComparer : EqualityComparer<T>, ISerializable
{

	[Address(RVA = "0x47F29DC", Offset = "0x47F29DC", Length = "0x14")]
	[Token(Token = "0x600353E")]
	public EnumEqualityComparer`1() { }

	[Address(RVA = "0x47F29F0", Offset = "0x47F29F0", Length = "0x14")]
	[Token(Token = "0x600353F")]
	protected EnumEqualityComparer`1(SerializationInfo information, StreamingContext context) { }

	[Address(RVA = "0x47F2950", Offset = "0x47F2950", Length = "0x58")]
	[Token(Token = "0x600353C")]
	public virtual bool Equals(T x, T y) { }

	[Address(RVA = "0x47F2B0C", Offset = "0x47F2B0C", Length = "0x5C")]
	[Token(Token = "0x6003541")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x47F29A8", Offset = "0x47F29A8", Length = "0x34")]
	[Token(Token = "0x600353D")]
	public virtual int GetHashCode(T obj) { }

	[Address(RVA = "0x47F2B68", Offset = "0x47F2B68", Length = "0x3C")]
	[Token(Token = "0x6003542")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x47F2A04", Offset = "0x47F2A04", Length = "0x108")]
	[Token(Token = "0x6003540")]
	public override void GetObjectData(SerializationInfo info, StreamingContext context) { }

}

