namespace System.Collections.Generic;

[Token(Token = "0x20006A3")]
internal sealed class DictionaryDebugView
{

}

