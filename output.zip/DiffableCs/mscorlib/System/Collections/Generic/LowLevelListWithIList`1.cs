namespace System.Collections.Generic;

[Token(Token = "0x20006A5")]
internal sealed class LowLevelListWithIList : LowLevelList<T>, IList<T>, ICollection<T>, IEnumerable<T>, IEnumerable
{
	[Token(Token = "0x20006A6")]
	private struct Enumerator : IEnumerator<T>, IDisposable, IEnumerator
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C42")]
		private LowLevelListWithIList<T> _list; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C43")]
		private int _index; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C44")]
		private int _version; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C45")]
		private T _current; //Field offset: 0x0

		[Token(Token = "0x170008A1")]
		public override T Current
		{
			[Address(RVA = "0x4894124", Offset = "0x4894124", Length = "0x8")]
			[Token(Token = "0x60034E3")]
			 get { } //Length: 8
		}

		[Token(Token = "0x170008A2")]
		private override object System.Collections.IEnumerator.Current
		{
			[Address(RVA = "0x489412C", Offset = "0x489412C", Length = "0x84")]
			[Token(Token = "0x60034E4")]
			private get { } //Length: 132
		}

		[Address(RVA = "0x4893FD0", Offset = "0x4893FD0", Length = "0x3C")]
		[Token(Token = "0x60034DF")]
		internal Enumerator(LowLevelListWithIList<T> list) { }

		[Address(RVA = "0x489400C", Offset = "0x489400C", Length = "0x4")]
		[Token(Token = "0x60034E0")]
		public override void Dispose() { }

		[Address(RVA = "0x4894124", Offset = "0x4894124", Length = "0x8")]
		[Token(Token = "0x60034E3")]
		public override T get_Current() { }

		[Address(RVA = "0x4894010", Offset = "0x4894010", Length = "0x98")]
		[Token(Token = "0x60034E1")]
		public override bool MoveNext() { }

		[Address(RVA = "0x48940A8", Offset = "0x48940A8", Length = "0x7C")]
		[Token(Token = "0x60034E2")]
		private bool MoveNextRare() { }

		[Address(RVA = "0x489412C", Offset = "0x489412C", Length = "0x84")]
		[Token(Token = "0x60034E4")]
		private override object System.Collections.IEnumerator.get_Current() { }

		[Address(RVA = "0x48941B0", Offset = "0x48941B0", Length = "0x6C")]
		[Token(Token = "0x60034E5")]
		private override void System.Collections.IEnumerator.Reset() { }

	}


	[Token(Token = "0x170008A0")]
	private override bool System.Collections.Generic.ICollection<T>.IsReadOnly
	{
		[Address(RVA = "0x588D694", Offset = "0x588D694", Length = "0x8")]
		[Token(Token = "0x60034DC")]
		private get { } //Length: 8
	}

	[Address(RVA = "0x588D5CC", Offset = "0x588D5CC", Length = "0x60")]
	[Token(Token = "0x60034DA")]
	public LowLevelListWithIList`1() { }

	[Address(RVA = "0x588D62C", Offset = "0x588D62C", Length = "0x68")]
	[Token(Token = "0x60034DB")]
	public LowLevelListWithIList`1(int capacity) { }

	[Address(RVA = "0x588D694", Offset = "0x588D694", Length = "0x8")]
	[Token(Token = "0x60034DC")]
	private override bool System.Collections.Generic.ICollection<T>.get_IsReadOnly() { }

	[Address(RVA = "0x588D69C", Offset = "0x588D69C", Length = "0x68")]
	[Token(Token = "0x60034DD")]
	private override IEnumerator<T> System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	[Address(RVA = "0x588D704", Offset = "0x588D704", Length = "0x68")]
	[Token(Token = "0x60034DE")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

