namespace System.Collections.Generic;

[Token(Token = "0x200068F")]
public class KeyNotFoundException : SystemException
{

	[Address(RVA = "0x73CB2FC", Offset = "0x73CB2FC", Length = "0x5C")]
	[Token(Token = "0x600341C")]
	public KeyNotFoundException() { }

	[Address(RVA = "0x73CB358", Offset = "0x73CB358", Length = "0x24")]
	[Token(Token = "0x600341D")]
	public KeyNotFoundException(string message) { }

	[Address(RVA = "0x73CB37C", Offset = "0x73CB37C", Length = "0x8")]
	[Token(Token = "0x600341E")]
	protected KeyNotFoundException(SerializationInfo info, StreamingContext context) { }

}

