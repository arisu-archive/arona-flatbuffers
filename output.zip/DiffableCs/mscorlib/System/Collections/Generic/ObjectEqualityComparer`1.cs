namespace System.Collections.Generic;

[Token(Token = "0x20006B2")]
internal class ObjectEqualityComparer : EqualityComparer<T>
{

	[Address(RVA = "0x5A4DD78", Offset = "0x5A4DD78", Length = "0x14")]
	[Token(Token = "0x6003534")]
	public ObjectEqualityComparer`1() { }

	[Address(RVA = "0x5A4D97C", Offset = "0x5A4D97C", Length = "0xB4")]
	[Token(Token = "0x600352E")]
	public virtual bool Equals(T x, T y) { }

	[Address(RVA = "0x5A4DCE0", Offset = "0x5A4DCE0", Length = "0x5C")]
	[Token(Token = "0x6003532")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x5A4DA30", Offset = "0x5A4DA30", Length = "0x70")]
	[Token(Token = "0x600352F")]
	public virtual int GetHashCode(T obj) { }

	[Address(RVA = "0x5A4DD3C", Offset = "0x5A4DD3C", Length = "0x3C")]
	[Token(Token = "0x6003533")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x5A4DAA0", Offset = "0x5A4DAA0", Length = "0x124")]
	[Token(Token = "0x6003530")]
	internal virtual int IndexOf(T[] array, T value, int startIndex, int count) { }

	[Address(RVA = "0x5A4DBC4", Offset = "0x5A4DBC4", Length = "0x11C")]
	[Token(Token = "0x6003531")]
	internal virtual int LastIndexOf(T[] array, T value, int startIndex, int count) { }

}

