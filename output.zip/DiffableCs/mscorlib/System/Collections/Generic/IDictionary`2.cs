namespace System.Collections.Generic;

[DefaultMember("Item")]
[Token(Token = "0x2000684")]
public interface IDictionary : ICollection<KeyValuePair`2<TKey, TValue>>, IEnumerable<KeyValuePair`2<TKey, TValue>>, IEnumerable
{

	[Token(Token = "0x17000877")]
	public TValue Item
	{
		[Token(Token = "0x6003404")]
		 get { } //Length: 0
		[Token(Token = "0x6003405")]
		 set { } //Length: 0
	}

	[Token(Token = "0x17000878")]
	public ICollection<TKey> Keys
	{
		[Token(Token = "0x6003406")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000879")]
	public ICollection<TValue> Values
	{
		[Token(Token = "0x6003407")]
		 get { } //Length: 0
	}

	[Token(Token = "0x6003409")]
	public void Add(TKey key, TValue value) { }

	[Token(Token = "0x6003408")]
	public bool ContainsKey(TKey key) { }

	[Token(Token = "0x6003404")]
	public TValue get_Item(TKey key) { }

	[Token(Token = "0x6003406")]
	public ICollection<TKey> get_Keys() { }

	[Token(Token = "0x6003407")]
	public ICollection<TValue> get_Values() { }

	[Token(Token = "0x600340A")]
	public bool Remove(TKey key) { }

	[Token(Token = "0x6003405")]
	public void set_Item(TKey key, TValue value) { }

	[Token(Token = "0x600340B")]
	public bool TryGetValue(TKey key, out TValue value) { }

}

