namespace System.Collections.Generic;

[Token(Token = "0x20006B6")]
internal sealed class ShortEnumEqualityComparer : EnumEqualityComparer<T>, ISerializable
{

	[Token(Token = "0x6003546")]
	public ShortEnumEqualityComparer`1() { }

	[Token(Token = "0x6003547")]
	public ShortEnumEqualityComparer`1(SerializationInfo information, StreamingContext context) { }

	[Token(Token = "0x6003548")]
	public virtual int GetHashCode(T obj) { }

}

