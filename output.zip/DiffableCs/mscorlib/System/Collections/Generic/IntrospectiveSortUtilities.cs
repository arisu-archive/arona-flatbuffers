namespace System.Collections.Generic;

[Token(Token = "0x20006A7")]
internal static class IntrospectiveSortUtilities
{

	[Address(RVA = "0x73CB444", Offset = "0x73CB444", Length = "0x30")]
	[Token(Token = "0x60034E6")]
	internal static int FloorLog2PlusOne(int n) { }

	[Address(RVA = "0x73CB474", Offset = "0x73CB474", Length = "0x68")]
	[Token(Token = "0x60034E7")]
	internal static void ThrowOrIgnoreBadComparer(object comparer) { }

}

