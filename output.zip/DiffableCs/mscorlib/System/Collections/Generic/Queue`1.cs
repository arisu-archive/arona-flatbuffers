namespace System.Collections.Generic;

[DebuggerDisplay("Count = {Count}")]
[DebuggerTypeProxy(typeof(QueueDebugView`1))]
[Token(Token = "0x200069C")]
[TypeForwardedFrom("System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")]
public class Queue : IEnumerable<T>, IEnumerable, ICollection, IReadOnlyCollection<T>
{
	[Token(Token = "0x200069D")]
	internal struct Enumerator : IEnumerator<T>, IDisposable, IEnumerator
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C30")]
		private readonly Queue<T> _q; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C31")]
		private readonly int _version; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C32")]
		private int _index; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C33")]
		private T _currentElement; //Field offset: 0x0

		[Token(Token = "0x17000896")]
		public override T Current
		{
			[Address(RVA = "0x482EE54", Offset = "0x482EE54", Length = "0x38")]
			[Token(Token = "0x60034A9")]
			 get { } //Length: 56
		}

		[Token(Token = "0x17000897")]
		private override object System.Collections.IEnumerator.Current
		{
			[Address(RVA = "0x482EEF8", Offset = "0x482EEF8", Length = "0x80")]
			[Token(Token = "0x60034AB")]
			private get { } //Length: 128
		}

		[Address(RVA = "0x482ED10", Offset = "0x482ED10", Length = "0x3C")]
		[Token(Token = "0x60034A6")]
		internal Enumerator(Queue<T> q) { }

		[Address(RVA = "0x482ED4C", Offset = "0x482ED4C", Length = "0x10")]
		[Token(Token = "0x60034A7")]
		public override void Dispose() { }

		[Address(RVA = "0x482EE54", Offset = "0x482EE54", Length = "0x38")]
		[Token(Token = "0x60034A9")]
		public override T get_Current() { }

		[Address(RVA = "0x482ED5C", Offset = "0x482ED5C", Length = "0xF8")]
		[Token(Token = "0x60034A8")]
		public override bool MoveNext() { }

		[Address(RVA = "0x482EEF8", Offset = "0x482EEF8", Length = "0x80")]
		[Token(Token = "0x60034AB")]
		private override object System.Collections.IEnumerator.get_Current() { }

		[Address(RVA = "0x482EF78", Offset = "0x482EF78", Length = "0x80")]
		[Token(Token = "0x60034AC")]
		private override void System.Collections.IEnumerator.Reset() { }

		[Address(RVA = "0x482EE8C", Offset = "0x482EE8C", Length = "0x6C")]
		[Token(Token = "0x60034AA")]
		private void ThrowEnumerationNotStartedOrEnded() { }

	}

	[Token(Token = "0x4001C2E")]
	private const int MinimumGrow = 4; //Field offset: 0x0
	[Token(Token = "0x4001C2F")]
	private const int GrowFactor = 200; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C28")]
	private T[] _array; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C29")]
	private int _head; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C2A")]
	private int _tail; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C2B")]
	private int _size; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C2C")]
	private int _version; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C2D")]
	private object _syncRoot; //Field offset: 0x0

	[Token(Token = "0x17000893")]
	public override int Count
	{
		[Address(RVA = "0x5BC6E60", Offset = "0x5BC6E60", Length = "0x8")]
		[Token(Token = "0x6003495")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000894")]
	private override bool System.Collections.ICollection.IsSynchronized
	{
		[Address(RVA = "0x5BC6E68", Offset = "0x5BC6E68", Length = "0x8")]
		[Token(Token = "0x6003496")]
		private get { } //Length: 8
	}

	[Token(Token = "0x17000895")]
	private override object System.Collections.ICollection.SyncRoot
	{
		[Address(RVA = "0x5BC6E70", Offset = "0x5BC6E70", Length = "0x78")]
		[Token(Token = "0x6003497")]
		private get { } //Length: 120
	}

	[Address(RVA = "0x5BC6C74", Offset = "0x5BC6C74", Length = "0x44")]
	[Token(Token = "0x6003492")]
	public Queue`1() { }

	[Address(RVA = "0x5BC6CB8", Offset = "0x5BC6CB8", Length = "0xE0")]
	[Token(Token = "0x6003493")]
	public Queue`1(int capacity) { }

	[Address(RVA = "0x5BC6D98", Offset = "0x5BC6D98", Length = "0xC8")]
	[Token(Token = "0x6003494")]
	public Queue`1(IEnumerable<T> collection) { }

	[Address(RVA = "0x5BC6EE8", Offset = "0x5BC6EE8", Length = "0x68")]
	[Token(Token = "0x6003498")]
	public void Clear() { }

	[Address(RVA = "0x5BC7640", Offset = "0x5BC7640", Length = "0xC4")]
	[Token(Token = "0x60034A2")]
	public bool Contains(T item) { }

	[Address(RVA = "0x5BC7400", Offset = "0x5BC7400", Length = "0xB4")]
	[Token(Token = "0x600349E")]
	public T Dequeue() { }

	[Address(RVA = "0x5BC7250", Offset = "0x5BC7250", Length = "0xCC")]
	[Token(Token = "0x600349A")]
	public void Enqueue(T item) { }

	[Address(RVA = "0x5BC6E60", Offset = "0x5BC6E60", Length = "0x8")]
	[Token(Token = "0x6003495")]
	public override int get_Count() { }

	[Address(RVA = "0x5BC731C", Offset = "0x5BC731C", Length = "0x24")]
	[Token(Token = "0x600349B")]
	public Enumerator<T> GetEnumerator() { }

	[Address(RVA = "0x5BC77E4", Offset = "0x5BC77E4", Length = "0x30")]
	[Token(Token = "0x60034A4")]
	private void MoveNext(ref int index) { }

	[Address(RVA = "0x5BC758C", Offset = "0x5BC758C", Length = "0x58")]
	[Token(Token = "0x60034A0")]
	public T Peek() { }

	[Address(RVA = "0x5BC7704", Offset = "0x5BC7704", Length = "0xE0")]
	[Token(Token = "0x60034A3")]
	private void SetCapacity(int capacity) { }

	[Address(RVA = "0x5BC7340", Offset = "0x5BC7340", Length = "0x60")]
	[Token(Token = "0x600349C")]
	private override IEnumerator<T> System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	[Address(RVA = "0x5BC6F50", Offset = "0x5BC6F50", Length = "0x300")]
	[Token(Token = "0x6003499")]
	private override void System.Collections.ICollection.CopyTo(Array array, int index) { }

	[Address(RVA = "0x5BC6E68", Offset = "0x5BC6E68", Length = "0x8")]
	[Token(Token = "0x6003496")]
	private override bool System.Collections.ICollection.get_IsSynchronized() { }

	[Address(RVA = "0x5BC6E70", Offset = "0x5BC6E70", Length = "0x78")]
	[Token(Token = "0x6003497")]
	private override object System.Collections.ICollection.get_SyncRoot() { }

	[Address(RVA = "0x5BC73A0", Offset = "0x5BC73A0", Length = "0x60")]
	[Token(Token = "0x600349D")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	[Address(RVA = "0x5BC7814", Offset = "0x5BC7814", Length = "0x50")]
	[Token(Token = "0x60034A5")]
	private void ThrowForEmptyQueue() { }

	[Address(RVA = "0x5BC74B4", Offset = "0x5BC74B4", Length = "0xD8")]
	[Token(Token = "0x600349F")]
	public bool TryDequeue(out T result) { }

	[Address(RVA = "0x5BC75E4", Offset = "0x5BC75E4", Length = "0x5C")]
	[Token(Token = "0x60034A1")]
	public bool TryPeek(out T result) { }

}

