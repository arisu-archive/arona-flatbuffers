namespace System.Collections.Generic;

[DebuggerDisplay("Count = {Count}")]
[DefaultMember("Item")]
[Token(Token = "0x20006A4")]
internal class LowLevelList
{
	[Token(Token = "0x4001C3D")]
	private const int _defaultCapacity = 4; //Field offset: 0x0
	[Token(Token = "0x4001C41")]
	private static readonly T[] s_emptyArray; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C3E")]
	protected T[] _items; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C3F")]
	protected int _size; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C40")]
	protected int _version; //Field offset: 0x0

	[Token(Token = "0x1700089D")]
	public int Capacity
	{
		[Address(RVA = "0x588D8C8", Offset = "0x588D8C8", Length = "0x1C")]
		[Token(Token = "0x60034C8")]
		 get { } //Length: 28
		[Address(RVA = "0x588D8E4", Offset = "0x588D8E4", Length = "0x140")]
		[Token(Token = "0x60034C9")]
		 set { } //Length: 320
	}

	[Token(Token = "0x1700089E")]
	public override int Count
	{
		[Address(RVA = "0x588DA24", Offset = "0x588DA24", Length = "0x8")]
		[Token(Token = "0x60034CA")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700089F")]
	public override T Item
	{
		[Address(RVA = "0x588DA2C", Offset = "0x588DA2C", Length = "0x78")]
		[Token(Token = "0x60034CB")]
		 get { } //Length: 120
		[Address(RVA = "0x588DAA4", Offset = "0x588DAA4", Length = "0x90")]
		[Token(Token = "0x60034CC")]
		 set { } //Length: 144
	}

	[Address(RVA = "0x588E6A8", Offset = "0x588E6A8", Length = "0xA8")]
	[Token(Token = "0x60034D9")]
	private static LowLevelList`1() { }

	[Address(RVA = "0x588D76C", Offset = "0x588D76C", Length = "0x70")]
	[Token(Token = "0x60034C6")]
	public LowLevelList`1() { }

	[Address(RVA = "0x588D7DC", Offset = "0x588D7DC", Length = "0xEC")]
	[Token(Token = "0x60034C7")]
	public LowLevelList`1(int capacity) { }

	[Address(RVA = "0x588DB34", Offset = "0x588DB34", Length = "0x9C")]
	[Token(Token = "0x60034CD")]
	public override void Add(T item) { }

	[Address(RVA = "0x588DC24", Offset = "0x588DC24", Length = "0x20")]
	[Token(Token = "0x60034CF")]
	public void AddRange(IEnumerable<T> collection) { }

	[Address(RVA = "0x588DC44", Offset = "0x588DC44", Length = "0x3C")]
	[Token(Token = "0x60034D0")]
	public override void Clear() { }

	[Address(RVA = "0x588DC80", Offset = "0x588DC80", Length = "0x80")]
	[Token(Token = "0x60034D1")]
	public override bool Contains(T item) { }

	[Address(RVA = "0x588DD00", Offset = "0x588DD00", Length = "0x20")]
	[Token(Token = "0x60034D2")]
	public override void CopyTo(T[] array, int arrayIndex) { }

	[Address(RVA = "0x588DBD0", Offset = "0x588DBD0", Length = "0x54")]
	[Token(Token = "0x60034CE")]
	private void EnsureCapacity(int min) { }

	[Address(RVA = "0x588D8C8", Offset = "0x588D8C8", Length = "0x1C")]
	[Token(Token = "0x60034C8")]
	public int get_Capacity() { }

	[Address(RVA = "0x588DA24", Offset = "0x588DA24", Length = "0x8")]
	[Token(Token = "0x60034CA")]
	public override int get_Count() { }

	[Address(RVA = "0x588DA2C", Offset = "0x588DA2C", Length = "0x78")]
	[Token(Token = "0x60034CB")]
	public override T get_Item(int index) { }

	[Address(RVA = "0x588DD20", Offset = "0x588DD20", Length = "0x24")]
	[Token(Token = "0x60034D3")]
	public override int IndexOf(T item) { }

	[Address(RVA = "0x588DD44", Offset = "0x588DD44", Length = "0x108")]
	[Token(Token = "0x60034D4")]
	public override void Insert(int index, T item) { }

	[Address(RVA = "0x588DE4C", Offset = "0x588DE4C", Length = "0x56C")]
	[Token(Token = "0x60034D5")]
	public void InsertRange(int index, IEnumerable<T> collection) { }

	[Address(RVA = "0x588E3B8", Offset = "0x588E3B8", Length = "0x5C")]
	[Token(Token = "0x60034D6")]
	public override bool Remove(T item) { }

	[Address(RVA = "0x588E414", Offset = "0x588E414", Length = "0x1C8")]
	[Token(Token = "0x60034D7")]
	public int RemoveAll(Predicate<T> match) { }

	[Address(RVA = "0x588E5DC", Offset = "0x588E5DC", Length = "0xCC")]
	[Token(Token = "0x60034D8")]
	public override void RemoveAt(int index) { }

	[Address(RVA = "0x588D8E4", Offset = "0x588D8E4", Length = "0x140")]
	[Token(Token = "0x60034C9")]
	public void set_Capacity(int value) { }

	[Address(RVA = "0x588DAA4", Offset = "0x588DAA4", Length = "0x90")]
	[Token(Token = "0x60034CC")]
	public override void set_Item(int index, T value) { }

}

