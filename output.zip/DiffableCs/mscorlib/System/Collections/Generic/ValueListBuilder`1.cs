namespace System.Collections.Generic;

[DefaultMember("Item")]
[IsByRefLike]
[Obsolete("Types with embedded references are not supported in this version of your compiler.", True)]
[Token(Token = "0x2000694")]
internal struct ValueListBuilder
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C16")]
	private Span<T> _span; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C17")]
	private T[] _arrayFromPool; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C18")]
	private int _pos; //Field offset: 0x0

	[Token(Token = "0x1700088E")]
	public int Length
	{
		[Address(RVA = "0x61452C0", Offset = "0x61452C0", Length = "0x8")]
		[Token(Token = "0x600346D")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x61452B0", Offset = "0x61452B0", Length = "0x10")]
	[Token(Token = "0x600346C")]
	public ValueListBuilder`1(Span<T> initialSpan) { }

	[Address(RVA = "0x61452C8", Offset = "0x61452C8", Length = "0x8C")]
	[Token(Token = "0x600346E")]
	public void Append(T item) { }

	[Address(RVA = "0x6145354", Offset = "0x6145354", Length = "0xC0")]
	[Token(Token = "0x600346F")]
	public ReadOnlySpan<T> AsSpan() { }

	[Address(RVA = "0x6145414", Offset = "0x6145414", Length = "0xB8")]
	[Token(Token = "0x6003470")]
	public void Dispose() { }

	[Address(RVA = "0x61452C0", Offset = "0x61452C0", Length = "0x8")]
	[Token(Token = "0x600346D")]
	public int get_Length() { }

	[Address(RVA = "0x61454CC", Offset = "0x61454CC", Length = "0x24C")]
	[Token(Token = "0x6003471")]
	private void Grow() { }

}

