namespace System.Collections.Generic;

[DefaultMember("Item")]
[Token(Token = "0x200068B")]
public interface IList : ICollection<T>, IEnumerable<T>, IEnumerable
{

	[Token(Token = "0x1700087B")]
	public T Item
	{
		[Token(Token = "0x6003410")]
		 get { } //Length: 0
		[Token(Token = "0x6003411")]
		 set { } //Length: 0
	}

	[Token(Token = "0x6003410")]
	public T get_Item(int index) { }

	[Token(Token = "0x6003412")]
	public int IndexOf(T item) { }

	[Token(Token = "0x6003413")]
	public void Insert(int index, T item) { }

	[Token(Token = "0x6003414")]
	public void RemoveAt(int index) { }

	[Token(Token = "0x6003411")]
	public void set_Item(int index, T value) { }

}

