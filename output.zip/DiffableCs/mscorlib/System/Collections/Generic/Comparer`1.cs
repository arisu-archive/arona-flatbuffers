namespace System.Collections.Generic;

[Token(Token = "0x20006AA")]
[TypeDependency("System.Collections.Generic.ObjectComparer`1")]
public abstract class Comparer : IComparer, IComparer<T>
{
	[Token(Token = "0x4001C48")]
	private static Comparer<T> defaultComparer; //Field offset: 0x0

	[Token(Token = "0x170008A5")]
	public static Comparer<T> Default
	{
		[Address(RVA = "0x6C0DE1C", Offset = "0x6C0DE1C", Length = "0xF8")]
		[Token(Token = "0x6003503")]
		 get { } //Length: 248
	}

	[Address(RVA = "0x6C0E578", Offset = "0x6C0E578", Length = "0x8")]
	[Token(Token = "0x6003508")]
	protected Comparer`1() { }

	[Token(Token = "0x6003506")]
	public abstract int Compare(T x, T y) { }

	[Address(RVA = "0x6C0DF14", Offset = "0x6C0DF14", Length = "0xF0")]
	[Token(Token = "0x6003504")]
	public static Comparer<T> Create(Comparison<T> comparison) { }

	[Address(RVA = "0x6C0E004", Offset = "0x6C0E004", Length = "0x41C")]
	[Token(Token = "0x6003505")]
	private static Comparer<T> CreateComparer() { }

	[Address(RVA = "0x6C0DE1C", Offset = "0x6C0DE1C", Length = "0xF8")]
	[Token(Token = "0x6003503")]
	public static Comparer<T> get_Default() { }

	[Address(RVA = "0x6C0E420", Offset = "0x6C0E420", Length = "0x158")]
	[Token(Token = "0x6003507")]
	private override int System.Collections.IComparer.Compare(object x, object y) { }

}

