namespace System.Collections.Generic;

[Token(Token = "0x20006AD")]
internal class ObjectComparer : Comparer<T>
{

	[Address(RVA = "0x59FB640", Offset = "0x59FB640", Length = "0x14")]
	[Token(Token = "0x6003514")]
	public ObjectComparer`1() { }

	[Address(RVA = "0x59FB4B0", Offset = "0x59FB4B0", Length = "0xF8")]
	[Token(Token = "0x6003511")]
	public virtual int Compare(T x, T y) { }

	[Address(RVA = "0x59FB5A8", Offset = "0x59FB5A8", Length = "0x5C")]
	[Token(Token = "0x6003512")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x59FB604", Offset = "0x59FB604", Length = "0x3C")]
	[Token(Token = "0x6003513")]
	public virtual int GetHashCode() { }

}

