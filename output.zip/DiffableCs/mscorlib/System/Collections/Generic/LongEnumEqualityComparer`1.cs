namespace System.Collections.Generic;

[Token(Token = "0x20006B7")]
internal sealed class LongEnumEqualityComparer : EqualityComparer<T>, ISerializable
{

	[Address(RVA = "0x58624B0", Offset = "0x58624B0", Length = "0x14")]
	[Token(Token = "0x600354D")]
	public LongEnumEqualityComparer`1() { }

	[Address(RVA = "0x58624C4", Offset = "0x58624C4", Length = "0x14")]
	[Token(Token = "0x600354E")]
	public LongEnumEqualityComparer`1(SerializationInfo information, StreamingContext context) { }

	[Address(RVA = "0x58623A8", Offset = "0x58623A8", Length = "0x58")]
	[Token(Token = "0x6003549")]
	public virtual bool Equals(T x, T y) { }

	[Address(RVA = "0x5862434", Offset = "0x5862434", Length = "0x40")]
	[Token(Token = "0x600354B")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x5862400", Offset = "0x5862400", Length = "0x34")]
	[Token(Token = "0x600354A")]
	public virtual int GetHashCode(T obj) { }

	[Address(RVA = "0x5862474", Offset = "0x5862474", Length = "0x3C")]
	[Token(Token = "0x600354C")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x58624D8", Offset = "0x58624D8", Length = "0x88")]
	[Token(Token = "0x600354F")]
	public override void GetObjectData(SerializationInfo info, StreamingContext context) { }

}

