namespace System.Collections.Generic;

[DefaultMember("Item")]
[Token(Token = "0x2000695")]
internal struct ArrayBuilder
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C19")]
	private T[] _array; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C1A")]
	private int _count; //Field offset: 0x0

	[Token(Token = "0x1700088F")]
	public int Capacity
	{
		[Address(RVA = "0x4FA6CD4", Offset = "0x4FA6CD4", Length = "0x18")]
		[Token(Token = "0x6003472")]
		 get { } //Length: 24
	}

	[Token(Token = "0x17000890")]
	public int Count
	{
		[Address(RVA = "0x4FA6CEC", Offset = "0x4FA6CEC", Length = "0x8")]
		[Token(Token = "0x6003473")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000891")]
	public T Item
	{
		[Address(RVA = "0x4FA6CF4", Offset = "0x4FA6CF4", Length = "0x30")]
		[Token(Token = "0x6003474")]
		 get { } //Length: 48
	}

	[Address(RVA = "0x4FA6D24", Offset = "0x4FA6D24", Length = "0x98")]
	[Token(Token = "0x6003475")]
	public void Add(T item) { }

	[Address(RVA = "0x4FA6DF8", Offset = "0x4FA6DF8", Length = "0x13C")]
	[Token(Token = "0x6003477")]
	private void EnsureCapacity(int minimum) { }

	[Address(RVA = "0x4FA6CD4", Offset = "0x4FA6CD4", Length = "0x18")]
	[Token(Token = "0x6003472")]
	public int get_Capacity() { }

	[Address(RVA = "0x4FA6CEC", Offset = "0x4FA6CEC", Length = "0x8")]
	[Token(Token = "0x6003473")]
	public int get_Count() { }

	[Address(RVA = "0x4FA6CF4", Offset = "0x4FA6CF4", Length = "0x30")]
	[Token(Token = "0x6003474")]
	public T get_Item(int index) { }

	[Address(RVA = "0x4FA6DBC", Offset = "0x4FA6DBC", Length = "0x3C")]
	[Token(Token = "0x6003476")]
	public void UncheckedAdd(T item) { }

}

