namespace System.Collections.Generic;

[Token(Token = "0x2000696")]
internal static class EnumerableHelpers
{

	[Address(RVA = "0x433BF98", Offset = "0x433BF98", Length = "0x1C8")]
	[Token(Token = "0x6003478")]
	internal static T[] ToArray(IEnumerable<T> source) { }

	[Address(RVA = "0x433C160", Offset = "0x433C160", Length = "0x618")]
	[Token(Token = "0x6003479")]
	internal static T[] ToArray(IEnumerable<T> source, out int length) { }

}

