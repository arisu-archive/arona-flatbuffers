namespace System.Collections.Generic;

[Token(Token = "0x2000687")]
internal sealed class DictionaryValueCollectionDebugView
{

}

