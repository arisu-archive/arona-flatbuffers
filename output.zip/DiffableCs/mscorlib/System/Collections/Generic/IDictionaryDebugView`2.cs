namespace System.Collections.Generic;

[Token(Token = "0x2000685")]
internal sealed class IDictionaryDebugView
{

}

