namespace System.Collections.Generic;

[Token(Token = "0x200068C")]
public interface IReadOnlyCollection : IEnumerable<T>, IEnumerable
{

	[Token(Token = "0x1700087C")]
	public int Count
	{
		[Token(Token = "0x6003415")]
		 get { } //Length: 0
	}

	[Token(Token = "0x6003415")]
	public int get_Count() { }

}

