namespace System.Collections.Generic;

[IsReadOnly]
[Token(Token = "0x2000691")]
public struct KeyValuePair
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C0A")]
	private readonly TKey key; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C0B")]
	private readonly TValue value; //Field offset: 0x0

	[Token(Token = "0x17000881")]
	public TKey Key
	{
		[Address(RVA = "0x5143A7C", Offset = "0x5143A7C", Length = "0x14")]
		[Token(Token = "0x6003421")]
		 get { } //Length: 20
	}

	[Token(Token = "0x17000882")]
	public TValue Value
	{
		[Address(RVA = "0x5143A90", Offset = "0x5143A90", Length = "0x8")]
		[Token(Token = "0x6003422")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x5143A3C", Offset = "0x5143A3C", Length = "0x40")]
	[Token(Token = "0x6003420")]
	public KeyValuePair`2(TKey key, TValue value) { }

	[Address(RVA = "0x5143B3C", Offset = "0x5143B3C", Length = "0x78")]
	[Token(Token = "0x6003424")]
	public void Deconstruct(out TKey key, out TValue value) { }

	[Address(RVA = "0x5143A7C", Offset = "0x5143A7C", Length = "0x14")]
	[Token(Token = "0x6003421")]
	public TKey get_Key() { }

	[Address(RVA = "0x5143A90", Offset = "0x5143A90", Length = "0x8")]
	[Token(Token = "0x6003422")]
	public TValue get_Value() { }

	[Address(RVA = "0x5143A98", Offset = "0x5143A98", Length = "0xA4")]
	[Token(Token = "0x6003423")]
	public virtual string ToString() { }

}

