namespace System.Collections.Generic;

[Extension]
[Token(Token = "0x200069B")]
public static class CollectionExtensions
{

	[Address(RVA = "0x4191328", Offset = "0x4191328", Length = "0x14")]
	[Extension]
	[Token(Token = "0x6003490")]
	public static TValue GetValueOrDefault(IReadOnlyDictionary<TKey, TValue> dictionary, TKey key) { }

	[Address(RVA = "0x4191350", Offset = "0x4191350", Length = "0x104")]
	[Extension]
	[Token(Token = "0x6003491")]
	public static TValue GetValueOrDefault(IReadOnlyDictionary<TKey, TValue> dictionary, TKey key, TValue defaultValue) { }

}

