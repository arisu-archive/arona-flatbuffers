namespace System.Collections.Generic;

[Token(Token = "0x20006B3")]
internal class ByteEqualityComparer : EqualityComparer<Byte>
{

	[Address(RVA = "0x73CB7B8", Offset = "0x73CB7B8", Length = "0x48")]
	[Token(Token = "0x600353B")]
	public ByteEqualityComparer() { }

	[Address(RVA = "0x73CB4DC", Offset = "0x73CB4DC", Length = "0x10")]
	[Token(Token = "0x6003535")]
	public virtual bool Equals(byte x, byte y) { }

	[Address(RVA = "0x73CB708", Offset = "0x73CB708", Length = "0x78")]
	[Token(Token = "0x6003539")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x73CB4EC", Offset = "0x73CB4EC", Length = "0x1C")]
	[Token(Token = "0x6003536")]
	public virtual int GetHashCode(byte b) { }

	[Address(RVA = "0x73CB780", Offset = "0x73CB780", Length = "0x38")]
	[Token(Token = "0x600353A")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x73CB508", Offset = "0x73CB508", Length = "0x1A4")]
	[Token(Token = "0x6003537")]
	internal virtual int IndexOf(Byte[] array, byte value, int startIndex, int count) { }

	[Address(RVA = "0x73CB6AC", Offset = "0x73CB6AC", Length = "0x5C")]
	[Token(Token = "0x6003538")]
	internal virtual int LastIndexOf(Byte[] array, byte value, int startIndex, int count) { }

}

