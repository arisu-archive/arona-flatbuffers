namespace System.Collections.Generic;

[DefaultMember("Item")]
[Token(Token = "0x200068D")]
public interface IReadOnlyDictionary : IReadOnlyCollection<KeyValuePair`2<TKey, TValue>>, IEnumerable<KeyValuePair`2<TKey, TValue>>, IEnumerable
{

	[Token(Token = "0x1700087D")]
	public TValue Item
	{
		[Token(Token = "0x6003418")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700087E")]
	public IEnumerable<TKey> Keys
	{
		[Token(Token = "0x6003419")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700087F")]
	public IEnumerable<TValue> Values
	{
		[Token(Token = "0x600341A")]
		 get { } //Length: 0
	}

	[Token(Token = "0x6003416")]
	public bool ContainsKey(TKey key) { }

	[Token(Token = "0x6003418")]
	public TValue get_Item(TKey key) { }

	[Token(Token = "0x6003419")]
	public IEnumerable<TKey> get_Keys() { }

	[Token(Token = "0x600341A")]
	public IEnumerable<TValue> get_Values() { }

	[Token(Token = "0x6003417")]
	public bool TryGetValue(TKey key, out TValue value) { }

}

