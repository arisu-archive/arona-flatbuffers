namespace System.Collections.Generic;

[Token(Token = "0x20006B0")]
internal class GenericEqualityComparer : EqualityComparer<T>
{

	[Address(RVA = "0x4E0BE30", Offset = "0x4E0BE30", Length = "0x14")]
	[Token(Token = "0x6003526")]
	public GenericEqualityComparer`1() { }

	[Address(RVA = "0x4E0BBF4", Offset = "0x4E0BBF4", Length = "0x3C")]
	[Token(Token = "0x6003520")]
	public virtual bool Equals(T x, T y) { }

	[Address(RVA = "0x4E0BD98", Offset = "0x4E0BD98", Length = "0x5C")]
	[Token(Token = "0x6003524")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x4E0BC30", Offset = "0x4E0BC30", Length = "0x2C")]
	[Token(Token = "0x6003521")]
	public virtual int GetHashCode(T obj) { }

	[Address(RVA = "0x4E0BDF4", Offset = "0x4E0BDF4", Length = "0x3C")]
	[Token(Token = "0x6003525")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x4E0BC5C", Offset = "0x4E0BC5C", Length = "0xA4")]
	[Token(Token = "0x6003522")]
	internal virtual int IndexOf(T[] array, T value, int startIndex, int count) { }

	[Address(RVA = "0x4E0BD00", Offset = "0x4E0BD00", Length = "0x98")]
	[Token(Token = "0x6003523")]
	internal virtual int LastIndexOf(T[] array, T value, int startIndex, int count) { }

}

