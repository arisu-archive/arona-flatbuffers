namespace System.Collections.Generic;

[DefaultMember("Item")]
[Token(Token = "0x2000698")]
internal class LowLevelDictionary
{
	[Token(Token = "0x200069A")]
	private sealed class DefaultComparer : IEqualityComparer<T>
	{

		[Address(RVA = "0x6E33B3C", Offset = "0x6E33B3C", Length = "0x8")]
		[Token(Token = "0x600348F")]
		public DefaultComparer`1() { }

		[Address(RVA = "0x6E339B8", Offset = "0x6E339B8", Length = "0x148")]
		[Token(Token = "0x600348D")]
		public override bool Equals(T x, T y) { }

		[Address(RVA = "0x6E33B00", Offset = "0x6E33B00", Length = "0x3C")]
		[Token(Token = "0x600348E")]
		public override int GetHashCode(T obj) { }

	}

	[Token(Token = "0x2000699")]
	private sealed class Entry
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C25")]
		public TKey _key; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C26")]
		public TValue _value; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001C27")]
		public Entry<TKey, TValue> _next; //Field offset: 0x0

		[Address(RVA = "0x47F267C", Offset = "0x47F267C", Length = "0x8")]
		[Token(Token = "0x600348C")]
		public Entry() { }

	}

	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C21")]
	private Entry<TKey, TValue>[] _buckets; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C22")]
	private int _numEntries; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C23")]
	private int _version; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001C24")]
	private IEqualityComparer<TKey> _comparer; //Field offset: 0x0

	[Token(Token = "0x17000892")]
	public TKey Item
	{
		[Address(RVA = "0x588C45C", Offset = "0x588C45C", Length = "0x84")]
		[Token(Token = "0x6003485")]
		 set { } //Length: 132
	}

	[Address(RVA = "0x588C380", Offset = "0x588C380", Length = "0x80")]
	[Token(Token = "0x6003483")]
	public LowLevelDictionary`2() { }

	[Address(RVA = "0x588C400", Offset = "0x588C400", Length = "0x5C")]
	[Token(Token = "0x6003484")]
	public LowLevelDictionary`2(int capacity, IEqualityComparer<TKey> comparer) { }

	[Address(RVA = "0x588C4E0", Offset = "0x588C4E0", Length = "0x5C")]
	[Token(Token = "0x6003486")]
	public void Clear(int capacity = 17) { }

	[Address(RVA = "0x588C948", Offset = "0x588C948", Length = "0x23C")]
	[Token(Token = "0x600348A")]
	private void ExpandBuckets() { }

	[Address(RVA = "0x588C6DC", Offset = "0x588C6DC", Length = "0x108")]
	[Token(Token = "0x6003488")]
	private Entry<TKey, TValue> Find(TKey key) { }

	[Address(RVA = "0x588CB84", Offset = "0x588CB84", Length = "0xCC")]
	[Token(Token = "0x600348B")]
	private int GetBucket(TKey key, int numBuckets = 0) { }

	[Address(RVA = "0x588C53C", Offset = "0x588C53C", Length = "0x1A0")]
	[Token(Token = "0x6003487")]
	public bool Remove(TKey key) { }

	[Address(RVA = "0x588C45C", Offset = "0x588C45C", Length = "0x84")]
	[Token(Token = "0x6003485")]
	public void set_Item(TKey key, TValue value) { }

	[Address(RVA = "0x588C7E4", Offset = "0x588C7E4", Length = "0x164")]
	[Token(Token = "0x6003489")]
	private Entry<TKey, TValue> UncheckedAdd(TKey key, TValue value) { }

}

