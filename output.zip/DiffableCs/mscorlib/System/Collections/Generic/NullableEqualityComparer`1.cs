namespace System.Collections.Generic;

[Token(Token = "0x20006B1")]
internal class NullableEqualityComparer : EqualityComparer<Nullable`1<T>>
{

	[Address(RVA = "0x596D330", Offset = "0x596D330", Length = "0x14")]
	[Token(Token = "0x600352D")]
	public NullableEqualityComparer`1() { }

	[Address(RVA = "0x596D064", Offset = "0x596D064", Length = "0x3C")]
	[Token(Token = "0x6003527")]
	public virtual bool Equals(Nullable<T> x, Nullable<T> y) { }

	[Address(RVA = "0x596D298", Offset = "0x596D298", Length = "0x5C")]
	[Token(Token = "0x600352B")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x596D0A0", Offset = "0x596D0A0", Length = "0x14")]
	[Token(Token = "0x6003528")]
	public virtual int GetHashCode(Nullable<T> obj) { }

	[Address(RVA = "0x596D2F4", Offset = "0x596D2F4", Length = "0x3C")]
	[Token(Token = "0x600352C")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x596D0B4", Offset = "0x596D0B4", Length = "0xF8")]
	[Token(Token = "0x6003529")]
	internal virtual int IndexOf(Nullable<T>[] array, Nullable<T> value, int startIndex, int count) { }

	[Address(RVA = "0x596D1AC", Offset = "0x596D1AC", Length = "0xEC")]
	[Token(Token = "0x600352A")]
	internal virtual int LastIndexOf(Nullable<T>[] array, Nullable<T> value, int startIndex, int count) { }

}

