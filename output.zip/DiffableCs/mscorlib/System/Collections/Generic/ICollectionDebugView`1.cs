namespace System.Collections.Generic;

[Token(Token = "0x2000682")]
internal sealed class ICollectionDebugView
{

}

