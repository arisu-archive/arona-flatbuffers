namespace System.Collections.Generic;

[Token(Token = "0x200068A")]
public interface IEqualityComparer
{

	[Token(Token = "0x600340E")]
	public bool Equals(T x, T y) { }

	[Token(Token = "0x600340F")]
	public int GetHashCode(T obj) { }

}

