namespace System.Collections.Generic;

[Token(Token = "0x2000690")]
public static class KeyValuePair
{

	[Address(RVA = "0x73CB384", Offset = "0x73CB384", Length = "0xC0")]
	[Token(Token = "0x600341F")]
	internal static string PairToString(object key, object value) { }

}

