namespace System.Collections.Generic;

[Token(Token = "0x20006A2")]
internal sealed class CollectionDebugView
{

}

