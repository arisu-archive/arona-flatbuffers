namespace System.Collections.Generic;

[Token(Token = "0x20006A8")]
internal class ArraySortHelper
{
	[Token(Token = "0x4001C46")]
	private static readonly ArraySortHelper<T> s_defaultArraySortHelper; //Field offset: 0x0

	[Token(Token = "0x170008A3")]
	public static ArraySortHelper<T> Default
	{
		[Address(RVA = "0x50F6958", Offset = "0x50F6958", Length = "0x6C")]
		[Token(Token = "0x60034F4")]
		 get { } //Length: 108
	}

	[Address(RVA = "0x50F69CC", Offset = "0x50F69CC", Length = "0xEC")]
	[Token(Token = "0x60034F6")]
	private static ArraySortHelper`1() { }

	[Address(RVA = "0x50F69C4", Offset = "0x50F69C4", Length = "0x8")]
	[Token(Token = "0x60034F5")]
	public ArraySortHelper`1() { }

	[Address(RVA = "0x50F53A0", Offset = "0x50F53A0", Length = "0x1A0")]
	[Token(Token = "0x60034E9")]
	public int BinarySearch(T[] array, int index, int length, T value, IComparer<T> comparer) { }

	[Address(RVA = "0x50F65AC", Offset = "0x50F65AC", Length = "0x224")]
	[Token(Token = "0x60034F2")]
	private static void DownHeap(T[] keys, int i, int n, int lo, Comparison<T> comparer) { }

	[Address(RVA = "0x50F6958", Offset = "0x50F6958", Length = "0x6C")]
	[Token(Token = "0x60034F4")]
	public static ArraySortHelper<T> get_Default() { }

	[Address(RVA = "0x50F63D0", Offset = "0x50F63D0", Length = "0x1DC")]
	[Token(Token = "0x60034F1")]
	private static void Heapsort(T[] keys, int lo, int hi, Comparison<T> comparer) { }

	[Address(RVA = "0x50F67D0", Offset = "0x50F67D0", Length = "0x188")]
	[Token(Token = "0x60034F3")]
	private static void InsertionSort(T[] keys, int lo, int hi, Comparison<T> comparer) { }

	[Address(RVA = "0x50F5720", Offset = "0x50F5720", Length = "0x140")]
	[Token(Token = "0x60034EB")]
	internal static int InternalBinarySearch(T[] array, int index, int length, T value, IComparer<T> comparer) { }

	[Address(RVA = "0x50F5B6C", Offset = "0x50F5B6C", Length = "0x464")]
	[Token(Token = "0x60034EF")]
	private static void IntroSort(T[] keys, int lo, int hi, int depthLimit, Comparison<T> comparer) { }

	[Address(RVA = "0x50F5A78", Offset = "0x50F5A78", Length = "0xF4")]
	[Token(Token = "0x60034EE")]
	internal static void IntrospectiveSort(T[] keys, int left, int length, Comparison<T> comparer) { }

	[Address(RVA = "0x50F5FD0", Offset = "0x50F5FD0", Length = "0x400")]
	[Token(Token = "0x60034F0")]
	private static int PickPivotAndPartition(T[] keys, int lo, int hi, Comparison<T> comparer) { }

	[Address(RVA = "0x50F5118", Offset = "0x50F5118", Length = "0x288")]
	[Token(Token = "0x60034E8")]
	public void Sort(T[] keys, int index, int length, IComparer<T> comparer) { }

	[Address(RVA = "0x50F5540", Offset = "0x50F5540", Length = "0x1E0")]
	[Token(Token = "0x60034EA")]
	internal static void Sort(T[] keys, int index, int length, Comparison<T> comparer) { }

	[Address(RVA = "0x50F59D0", Offset = "0x50F59D0", Length = "0xA8")]
	[Token(Token = "0x60034ED")]
	private static void Swap(T[] a, int i, int j) { }

	[Address(RVA = "0x50F5860", Offset = "0x50F5860", Length = "0x170")]
	[Token(Token = "0x60034EC")]
	private static void SwapIfGreater(T[] keys, Comparison<T> comparer, int a, int b) { }

}

