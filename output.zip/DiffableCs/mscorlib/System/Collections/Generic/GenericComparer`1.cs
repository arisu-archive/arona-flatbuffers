namespace System.Collections.Generic;

[Token(Token = "0x20006AB")]
internal class GenericComparer : Comparer<T>
{

	[Address(RVA = "0x4DE0D04", Offset = "0x4DE0D04", Length = "0x14")]
	[Token(Token = "0x600350C")]
	public GenericComparer`1() { }

	[Address(RVA = "0x4DE0C30", Offset = "0x4DE0C30", Length = "0x3C")]
	[Token(Token = "0x6003509")]
	public virtual int Compare(T x, T y) { }

	[Address(RVA = "0x4DE0C6C", Offset = "0x4DE0C6C", Length = "0x5C")]
	[Token(Token = "0x600350A")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x4DE0CC8", Offset = "0x4DE0CC8", Length = "0x3C")]
	[Token(Token = "0x600350B")]
	public virtual int GetHashCode() { }

}

