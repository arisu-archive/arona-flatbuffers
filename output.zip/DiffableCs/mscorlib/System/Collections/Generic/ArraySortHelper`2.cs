namespace System.Collections.Generic;

[Token(Token = "0x20006A9")]
internal class ArraySortHelper
{
	[Token(Token = "0x4001C47")]
	private static readonly ArraySortHelper<TKey, TValue> s_defaultArraySortHelper; //Field offset: 0x0

	[Token(Token = "0x170008A4")]
	public static ArraySortHelper<TKey, TValue> Default
	{
		[Address(RVA = "0x67E50CC", Offset = "0x67E50CC", Length = "0x6C")]
		[Token(Token = "0x6003500")]
		 get { } //Length: 108
	}

	[Address(RVA = "0x67E5140", Offset = "0x67E5140", Length = "0xEC")]
	[Token(Token = "0x6003502")]
	private static ArraySortHelper`2() { }

	[Address(RVA = "0x67E5138", Offset = "0x67E5138", Length = "0x8")]
	[Token(Token = "0x6003501")]
	public ArraySortHelper`2() { }

	[Address(RVA = "0x67E4BAC", Offset = "0x67E4BAC", Length = "0x2FC")]
	[Token(Token = "0x60034FE")]
	private static void DownHeap(TKey[] keys, TValue[] values, int i, int n, int lo, IComparer<TKey> comparer) { }

	[Address(RVA = "0x67E50CC", Offset = "0x67E50CC", Length = "0x6C")]
	[Token(Token = "0x6003500")]
	public static ArraySortHelper<TKey, TValue> get_Default() { }

	[Address(RVA = "0x67E49C0", Offset = "0x67E49C0", Length = "0x1EC")]
	[Token(Token = "0x60034FD")]
	private static void Heapsort(TKey[] keys, TValue[] values, int lo, int hi, IComparer<TKey> comparer) { }

	[Address(RVA = "0x67E4EA8", Offset = "0x67E4EA8", Length = "0x224")]
	[Token(Token = "0x60034FF")]
	private static void InsertionSort(TKey[] keys, TValue[] values, int lo, int hi, IComparer<TKey> comparer) { }

	[Address(RVA = "0x67E40B8", Offset = "0x67E40B8", Length = "0x494")]
	[Token(Token = "0x60034FB")]
	private static void IntroSort(TKey[] keys, TValue[] values, int lo, int hi, int depthLimit, IComparer<TKey> comparer) { }

	[Address(RVA = "0x67E3FB4", Offset = "0x67E3FB4", Length = "0x104")]
	[Token(Token = "0x60034FA")]
	internal static void IntrospectiveSort(TKey[] keys, TValue[] values, int left, int length, IComparer<TKey> comparer) { }

	[Address(RVA = "0x67E454C", Offset = "0x67E454C", Length = "0x474")]
	[Token(Token = "0x60034FC")]
	private static int PickPivotAndPartition(TKey[] keys, TValue[] values, int lo, int hi, IComparer<TKey> comparer) { }

	[Address(RVA = "0x67E3AE4", Offset = "0x67E3AE4", Length = "0x1F0")]
	[Token(Token = "0x60034F7")]
	public void Sort(TKey[] keys, TValue[] values, int index, int length, IComparer<TKey> comparer) { }

	[Address(RVA = "0x67E3EA4", Offset = "0x67E3EA4", Length = "0x110")]
	[Token(Token = "0x60034F9")]
	private static void Swap(TKey[] keys, TValue[] values, int i, int j) { }

	[Address(RVA = "0x67E3CD4", Offset = "0x67E3CD4", Length = "0x1D0")]
	[Token(Token = "0x60034F8")]
	private static void SwapIfGreaterWithItems(TKey[] keys, TValue[] values, IComparer<TKey> comparer, int a, int b) { }

}

