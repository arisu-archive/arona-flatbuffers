namespace System.Collections.Generic;

[DefaultMember("Item")]
[Token(Token = "0x200068E")]
public interface IReadOnlyList : IReadOnlyCollection<T>, IEnumerable<T>, IEnumerable
{

	[Token(Token = "0x17000880")]
	public T Item
	{
		[Token(Token = "0x600341B")]
		 get { } //Length: 0
	}

	[Token(Token = "0x600341B")]
	public T get_Item(int index) { }

}

