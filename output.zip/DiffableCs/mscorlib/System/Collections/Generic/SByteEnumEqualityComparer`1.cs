namespace System.Collections.Generic;

[Token(Token = "0x20006B5")]
internal sealed class SByteEnumEqualityComparer : EnumEqualityComparer<T>, ISerializable
{

	[Token(Token = "0x6003543")]
	public SByteEnumEqualityComparer`1() { }

	[Token(Token = "0x6003544")]
	public SByteEnumEqualityComparer`1(SerializationInfo information, StreamingContext context) { }

	[Token(Token = "0x6003545")]
	public virtual int GetHashCode(T obj) { }

}

