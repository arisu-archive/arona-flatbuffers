namespace System.Collections.Generic;

[Token(Token = "0x2000683")]
public interface IComparer
{

	[Token(Token = "0x6003403")]
	public int Compare(T x, T y) { }

}

