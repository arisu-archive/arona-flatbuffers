namespace System.Collections.Generic;

[Token(Token = "0x2000679")]
internal enum InsertionBehavior
{
	None = 0,
	OverwriteExisting = 1,
	ThrowOnExisting = 2,
}

