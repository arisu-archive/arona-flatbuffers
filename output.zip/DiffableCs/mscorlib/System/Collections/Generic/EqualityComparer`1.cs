namespace System.Collections.Generic;

[Token(Token = "0x20006AF")]
[TypeDependency("System.Collections.Generic.ObjectEqualityComparer`1")]
public abstract class EqualityComparer : IEqualityComparer, IEqualityComparer<T>
{
	[Token(Token = "0x4001C4A")]
	private static EqualityComparer<T> defaultComparer; //Field offset: 0x0

	[Token(Token = "0x170008A6")]
	public static EqualityComparer<T> Default
	{
		[Address(RVA = "0x498EE4C", Offset = "0x498EE4C", Length = "0xF8")]
		[Token(Token = "0x6003517")]
		 get { } //Length: 248
	}

	[Address(RVA = "0x498F9A4", Offset = "0x498F9A4", Length = "0x8")]
	[Token(Token = "0x600351F")]
	protected EqualityComparer`1() { }

	[Address(RVA = "0x498EF44", Offset = "0x498EF44", Length = "0x710")]
	[Token(Token = "0x6003518")]
	private static EqualityComparer<T> CreateComparer() { }

	[Token(Token = "0x6003519")]
	public abstract bool Equals(T x, T y) { }

	[Address(RVA = "0x498EE4C", Offset = "0x498EE4C", Length = "0xF8")]
	[Token(Token = "0x6003517")]
	public static EqualityComparer<T> get_Default() { }

	[Token(Token = "0x600351A")]
	public abstract int GetHashCode(T obj) { }

	[Address(RVA = "0x498F654", Offset = "0x498F654", Length = "0xA4")]
	[Token(Token = "0x600351B")]
	internal override int IndexOf(T[] array, T value, int startIndex, int count) { }

	[Address(RVA = "0x498F6F8", Offset = "0x498F6F8", Length = "0x98")]
	[Token(Token = "0x600351C")]
	internal override int LastIndexOf(T[] array, T value, int startIndex, int count) { }

	[Address(RVA = "0x498F84C", Offset = "0x498F84C", Length = "0x158")]
	[Token(Token = "0x600351E")]
	private override bool System.Collections.IEqualityComparer.Equals(object x, object y) { }

	[Address(RVA = "0x498F790", Offset = "0x498F790", Length = "0xBC")]
	[Token(Token = "0x600351D")]
	private override int System.Collections.IEqualityComparer.GetHashCode(object obj) { }

}

