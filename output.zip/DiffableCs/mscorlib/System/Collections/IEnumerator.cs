namespace System.Collections;

[Token(Token = "0x2000636")]
public interface IEnumerator
{

	[Token(Token = "0x1700077F")]
	public object Current
	{
		[Token(Token = "0x60030AC")]
		 get { } //Length: 0
	}

	[Token(Token = "0x60030AC")]
	public object get_Current() { }

	[Token(Token = "0x60030AB")]
	public bool MoveNext() { }

	[Token(Token = "0x60030AD")]
	public void Reset() { }

}

