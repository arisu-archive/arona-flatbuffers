namespace System.Collections;

[Token(Token = "0x200062F")]
public struct DictionaryEntry
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001B22")]
	private object _key; //Field offset: 0x0
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x4001B23")]
	private object _value; //Field offset: 0x8

	[Token(Token = "0x17000771")]
	public object Key
	{
		[Address(RVA = "0x73BA270", Offset = "0x73BA270", Length = "0x8")]
		[Token(Token = "0x6003090")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000772")]
	public object Value
	{
		[Address(RVA = "0x73BA278", Offset = "0x73BA278", Length = "0x8")]
		[Token(Token = "0x6003091")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x73BA240", Offset = "0x73BA240", Length = "0x30")]
	[Token(Token = "0x600308F")]
	public DictionaryEntry(object key, object value) { }

	[Address(RVA = "0x73BA270", Offset = "0x73BA270", Length = "0x8")]
	[Token(Token = "0x6003090")]
	public object get_Key() { }

	[Address(RVA = "0x73BA278", Offset = "0x73BA278", Length = "0x8")]
	[Token(Token = "0x6003091")]
	public object get_Value() { }

}

