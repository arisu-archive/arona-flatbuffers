namespace System.Collections;

[DebuggerDisplay("Count = {Count}")]
[DebuggerTypeProxy(typeof(StackDebugView))]
[Token(Token = "0x200064E")]
public class Stack : ICollection, IEnumerable, ICloneable
{
	[Token(Token = "0x2000650")]
	public class StackDebugView
	{

	}

	[Token(Token = "0x200064F")]
	private class StackEnumerator : IEnumerator, ICloneable
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001B62")]
		private Stack _stack; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4001B63")]
		private int _index; //Field offset: 0x18
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4001B64")]
		private int _version; //Field offset: 0x1C
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4001B65")]
		private object _currentElement; //Field offset: 0x20

		[Token(Token = "0x170007C7")]
		public override object Current
		{
			[Address(RVA = "0x73C1A58", Offset = "0x73C1A58", Length = "0x94")]
			[Token(Token = "0x6003197")]
			 get { } //Length: 148
		}

		[Address(RVA = "0x73C16C4", Offset = "0x73C16C4", Length = "0x5C")]
		[Token(Token = "0x6003194")]
		internal StackEnumerator(Stack stack) { }

		[Address(RVA = "0x73C1968", Offset = "0x73C1968", Length = "0x8")]
		[Token(Token = "0x6003195")]
		public override object Clone() { }

		[Address(RVA = "0x73C1A58", Offset = "0x73C1A58", Length = "0x94")]
		[Token(Token = "0x6003197")]
		public override object get_Current() { }

		[Address(RVA = "0x73C1970", Offset = "0x73C1970", Length = "0xE8")]
		[Token(Token = "0x6003196")]
		public override bool MoveNext() { }

		[Address(RVA = "0x73C1AEC", Offset = "0x73C1AEC", Length = "0x84")]
		[Token(Token = "0x6003198")]
		public override void Reset() { }

	}

	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001B5E")]
	private Object[] _array; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001B5F")]
	private int _size; //Field offset: 0x18
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x4001B60")]
	private int _version; //Field offset: 0x1C
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4001B61")]
	private object _syncRoot; //Field offset: 0x20

	[Token(Token = "0x170007C4")]
	public override int Count
	{
		[Address(RVA = "0x73C1254", Offset = "0x73C1254", Length = "0x8")]
		[Token(Token = "0x600318A")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170007C5")]
	public override bool IsSynchronized
	{
		[Address(RVA = "0x73C125C", Offset = "0x73C125C", Length = "0x8")]
		[Token(Token = "0x600318B")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170007C6")]
	public override object SyncRoot
	{
		[Address(RVA = "0x73C1264", Offset = "0x73C1264", Length = "0x78")]
		[Token(Token = "0x600318C")]
		 get { } //Length: 120
	}

	[Address(RVA = "0x73C110C", Offset = "0x73C110C", Length = "0x6C")]
	[Token(Token = "0x6003188")]
	public Stack() { }

	[Address(RVA = "0x73C1178", Offset = "0x73C1178", Length = "0xDC")]
	[Token(Token = "0x6003189")]
	public Stack(int initialCapacity) { }

	[Address(RVA = "0x73C12DC", Offset = "0x73C12DC", Length = "0x30")]
	[Token(Token = "0x600318D")]
	public override void Clear() { }

	[Address(RVA = "0x73C130C", Offset = "0x73C130C", Length = "0x90")]
	[Token(Token = "0x600318E")]
	public override object Clone() { }

	[Address(RVA = "0x73C139C", Offset = "0x73C139C", Length = "0x2C8")]
	[Token(Token = "0x600318F")]
	public override void CopyTo(Array array, int index) { }

	[Address(RVA = "0x73C1254", Offset = "0x73C1254", Length = "0x8")]
	[Token(Token = "0x600318A")]
	public override int get_Count() { }

	[Address(RVA = "0x73C125C", Offset = "0x73C125C", Length = "0x8")]
	[Token(Token = "0x600318B")]
	public override bool get_IsSynchronized() { }

	[Address(RVA = "0x73C1264", Offset = "0x73C1264", Length = "0x78")]
	[Token(Token = "0x600318C")]
	public override object get_SyncRoot() { }

	[Address(RVA = "0x73C1664", Offset = "0x73C1664", Length = "0x60")]
	[Token(Token = "0x6003190")]
	public override IEnumerator GetEnumerator() { }

	[Address(RVA = "0x73C1720", Offset = "0x73C1720", Length = "0x88")]
	[Token(Token = "0x6003191")]
	public override object Peek() { }

	[Address(RVA = "0x73C17A8", Offset = "0x73C17A8", Length = "0xA4")]
	[Token(Token = "0x6003192")]
	public override object Pop() { }

	[Address(RVA = "0x73C184C", Offset = "0x73C184C", Length = "0x11C")]
	[Token(Token = "0x6003193")]
	public override void Push(object obj) { }

}

