namespace System.Collections;

[DebuggerDisplay("Count = {Count}")]
[DebuggerTypeProxy(typeof(QueueDebugView))]
[Token(Token = "0x2000644")]
public class Queue : ICollection, IEnumerable, ICloneable
{
	[Token(Token = "0x2000646")]
	public class QueueDebugView
	{

	}

	[Token(Token = "0x2000645")]
	private class QueueEnumerator : IEnumerator, ICloneable
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001B44")]
		private Queue _q; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4001B45")]
		private int _index; //Field offset: 0x18
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4001B46")]
		private int _version; //Field offset: 0x1C
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4001B47")]
		private object _currentElement; //Field offset: 0x20

		[Token(Token = "0x170007A0")]
		public override object Current
		{
			[Address(RVA = "0x73BD994", Offset = "0x73BD994", Length = "0x94")]
			[Token(Token = "0x600311B")]
			 get { } //Length: 148
		}

		[Address(RVA = "0x73BD674", Offset = "0x73BD674", Length = "0x78")]
		[Token(Token = "0x6003118")]
		internal QueueEnumerator(Queue q) { }

		[Address(RVA = "0x73BD8A4", Offset = "0x73BD8A4", Length = "0x8")]
		[Token(Token = "0x6003119")]
		public override object Clone() { }

		[Address(RVA = "0x73BD994", Offset = "0x73BD994", Length = "0x94")]
		[Token(Token = "0x600311B")]
		public override object get_Current() { }

		[Address(RVA = "0x73BD8AC", Offset = "0x73BD8AC", Length = "0xE8")]
		[Token(Token = "0x600311A")]
		public override bool MoveNext() { }

		[Address(RVA = "0x73BDA28", Offset = "0x73BDA28", Length = "0x8C")]
		[Token(Token = "0x600311C")]
		public override void Reset() { }

	}

	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001B3D")]
	private Object[] _array; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001B3E")]
	private int _head; //Field offset: 0x18
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x4001B3F")]
	private int _tail; //Field offset: 0x1C
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4001B40")]
	private int _size; //Field offset: 0x20
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x4001B41")]
	private int _growFactor; //Field offset: 0x24
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4001B42")]
	private int _version; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4001B43")]
	private object _syncRoot; //Field offset: 0x30

	[Token(Token = "0x1700079D")]
	public override int Count
	{
		[Address(RVA = "0x73BD0B8", Offset = "0x73BD0B8", Length = "0x8")]
		[Token(Token = "0x600310D")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700079E")]
	public override bool IsSynchronized
	{
		[Address(RVA = "0x73BD1A4", Offset = "0x73BD1A4", Length = "0x8")]
		[Token(Token = "0x600310F")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700079F")]
	public override object SyncRoot
	{
		[Address(RVA = "0x73BD1AC", Offset = "0x73BD1AC", Length = "0x7C")]
		[Token(Token = "0x6003110")]
		 get { } //Length: 124
	}

	[Address(RVA = "0x73BCC68", Offset = "0x73BCC68", Length = "0xC")]
	[Token(Token = "0x6003109")]
	public Queue() { }

	[Address(RVA = "0x73BCE44", Offset = "0x73BCE44", Length = "0x8")]
	[Token(Token = "0x600310A")]
	public Queue(int capacity) { }

	[Address(RVA = "0x73BCC74", Offset = "0x73BCC74", Length = "0x1D0")]
	[Token(Token = "0x600310B")]
	public Queue(int capacity, float growFactor) { }

	[Address(RVA = "0x73BCE4C", Offset = "0x73BCE4C", Length = "0x26C")]
	[Token(Token = "0x600310C")]
	public Queue(ICollection col) { }

	[Address(RVA = "0x73BD0C0", Offset = "0x73BD0C0", Length = "0xE4")]
	[Token(Token = "0x600310E")]
	public override object Clone() { }

	[Address(RVA = "0x73BD228", Offset = "0x73BD228", Length = "0x1F4")]
	[Token(Token = "0x6003111")]
	public override void CopyTo(Array array, int index) { }

	[Address(RVA = "0x73BD6EC", Offset = "0x73BD6EC", Length = "0xE4")]
	[Token(Token = "0x6003114")]
	public override object Dequeue() { }

	[Address(RVA = "0x73BD41C", Offset = "0x73BD41C", Length = "0x104")]
	[Token(Token = "0x6003112")]
	public override void Enqueue(object obj) { }

	[Address(RVA = "0x73BD0B8", Offset = "0x73BD0B8", Length = "0x8")]
	[Token(Token = "0x600310D")]
	public override int get_Count() { }

	[Address(RVA = "0x73BD1A4", Offset = "0x73BD1A4", Length = "0x8")]
	[Token(Token = "0x600310F")]
	public override bool get_IsSynchronized() { }

	[Address(RVA = "0x73BD1AC", Offset = "0x73BD1AC", Length = "0x7C")]
	[Token(Token = "0x6003110")]
	public override object get_SyncRoot() { }

	[Address(RVA = "0x73BD864", Offset = "0x73BD864", Length = "0x40")]
	[Token(Token = "0x6003116")]
	internal object GetElement(int i) { }

	[Address(RVA = "0x73BD614", Offset = "0x73BD614", Length = "0x60")]
	[Token(Token = "0x6003113")]
	public override IEnumerator GetEnumerator() { }

	[Address(RVA = "0x73BD7D0", Offset = "0x73BD7D0", Length = "0x94")]
	[Token(Token = "0x6003115")]
	public override object Peek() { }

	[Address(RVA = "0x73BD520", Offset = "0x73BD520", Length = "0xF4")]
	[Token(Token = "0x6003117")]
	private void SetCapacity(int capacity) { }

}

