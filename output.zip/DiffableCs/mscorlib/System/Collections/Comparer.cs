namespace System.Collections;

[Token(Token = "0x200062E")]
public sealed class Comparer : IComparer, ISerializable
{
	[Token(Token = "0x4001B20")]
	public static readonly Comparer Default; //Field offset: 0x0
	[Token(Token = "0x4001B21")]
	public static readonly Comparer DefaultInvariant; //Field offset: 0x8
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001B1F")]
	private CompareInfo _compareInfo; //Field offset: 0x10

	[Address(RVA = "0x73BA170", Offset = "0x73BA170", Length = "0xD0")]
	[Token(Token = "0x600308E")]
	private static Comparer() { }

	[Address(RVA = "0x73B9CAC", Offset = "0x73B9CAC", Length = "0x90")]
	[Token(Token = "0x600308A")]
	public Comparer(CultureInfo culture) { }

	[Address(RVA = "0x73B9D3C", Offset = "0x73B9D3C", Length = "0x184")]
	[Token(Token = "0x600308B")]
	private Comparer(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x73B9F64", Offset = "0x73B9F64", Length = "0x20C")]
	[Token(Token = "0x600308D")]
	public override int Compare(object a, object b) { }

	[Address(RVA = "0x73B9EC0", Offset = "0x73B9EC0", Length = "0xA4")]
	[Token(Token = "0x600308C")]
	public override void GetObjectData(SerializationInfo info, StreamingContext context) { }

}

