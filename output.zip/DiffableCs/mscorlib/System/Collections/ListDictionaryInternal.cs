namespace System.Collections;

[DefaultMember("Item")]
[Token(Token = "0x200063B")]
internal class ListDictionaryInternal : IDictionary, ICollection, IEnumerable
{
	[Token(Token = "0x200063F")]
	private class DictionaryNode
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001B35")]
		public object key; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4001B36")]
		public object value; //Field offset: 0x18
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4001B37")]
		public DictionaryNode next; //Field offset: 0x20

		[Address(RVA = "0x73BA910", Offset = "0x73BA910", Length = "0x8")]
		[Token(Token = "0x60030E0")]
		public DictionaryNode() { }

	}

	[Token(Token = "0x200063C")]
	private class NodeEnumerator : IDictionaryEnumerator, IEnumerator
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001B2A")]
		private ListDictionaryInternal list; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4001B2B")]
		private DictionaryNode current; //Field offset: 0x18
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4001B2C")]
		private int version; //Field offset: 0x20
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x4001B2D")]
		private bool start; //Field offset: 0x24

		[Token(Token = "0x1700078B")]
		public override object Current
		{
			[Address(RVA = "0x73BB1D4", Offset = "0x73BB1D4", Length = "0x64")]
			[Token(Token = "0x60030D0")]
			 get { } //Length: 100
		}

		[Token(Token = "0x1700078C")]
		public override DictionaryEntry Entry
		{
			[Address(RVA = "0x73BB238", Offset = "0x73BB238", Length = "0x9C")]
			[Token(Token = "0x60030D1")]
			 get { } //Length: 156
		}

		[Token(Token = "0x1700078D")]
		public override object Key
		{
			[Address(RVA = "0x73BB2D4", Offset = "0x73BB2D4", Length = "0x64")]
			[Token(Token = "0x60030D2")]
			 get { } //Length: 100
		}

		[Token(Token = "0x1700078E")]
		public override object Value
		{
			[Address(RVA = "0x73BB338", Offset = "0x73BB338", Length = "0x64")]
			[Token(Token = "0x60030D3")]
			 get { } //Length: 100
		}

		[Address(RVA = "0x73BB008", Offset = "0x73BB008", Length = "0x58")]
		[Token(Token = "0x60030CF")]
		public NodeEnumerator(ListDictionaryInternal list) { }

		[Address(RVA = "0x73BB1D4", Offset = "0x73BB1D4", Length = "0x64")]
		[Token(Token = "0x60030D0")]
		public override object get_Current() { }

		[Address(RVA = "0x73BB238", Offset = "0x73BB238", Length = "0x9C")]
		[Token(Token = "0x60030D1")]
		public override DictionaryEntry get_Entry() { }

		[Address(RVA = "0x73BB2D4", Offset = "0x73BB2D4", Length = "0x64")]
		[Token(Token = "0x60030D2")]
		public override object get_Key() { }

		[Address(RVA = "0x73BB338", Offset = "0x73BB338", Length = "0x64")]
		[Token(Token = "0x60030D3")]
		public override object get_Value() { }

		[Address(RVA = "0x73BB39C", Offset = "0x73BB39C", Length = "0xC8")]
		[Token(Token = "0x60030D4")]
		public override bool MoveNext() { }

		[Address(RVA = "0x73BB464", Offset = "0x73BB464", Length = "0x84")]
		[Token(Token = "0x60030D5")]
		public override void Reset() { }

	}

	[Token(Token = "0x200063D")]
	private class NodeKeyValueCollection : ICollection, IEnumerable
	{
		[Token(Token = "0x200063E")]
		private class NodeKeyValueEnumerator : IEnumerator
		{
			[FieldOffset(Offset = "0x10")]
			[Token(Token = "0x4001B30")]
			private ListDictionaryInternal list; //Field offset: 0x10
			[FieldOffset(Offset = "0x18")]
			[Token(Token = "0x4001B31")]
			private DictionaryNode current; //Field offset: 0x18
			[FieldOffset(Offset = "0x20")]
			[Token(Token = "0x4001B32")]
			private int version; //Field offset: 0x20
			[FieldOffset(Offset = "0x24")]
			[Token(Token = "0x4001B33")]
			private bool isKeys; //Field offset: 0x24
			[FieldOffset(Offset = "0x25")]
			[Token(Token = "0x4001B34")]
			private bool start; //Field offset: 0x25

			[Token(Token = "0x17000792")]
			public override object Current
			{
				[Address(RVA = "0x73BB7F0", Offset = "0x73BB7F0", Length = "0x78")]
				[Token(Token = "0x60030DD")]
				 get { } //Length: 120
			}

			[Address(RVA = "0x73BB784", Offset = "0x73BB784", Length = "0x6C")]
			[Token(Token = "0x60030DC")]
			public NodeKeyValueEnumerator(ListDictionaryInternal list, bool isKeys) { }

			[Address(RVA = "0x73BB7F0", Offset = "0x73BB7F0", Length = "0x78")]
			[Token(Token = "0x60030DD")]
			public override object get_Current() { }

			[Address(RVA = "0x73BB868", Offset = "0x73BB868", Length = "0xC8")]
			[Token(Token = "0x60030DE")]
			public override bool MoveNext() { }

			[Address(RVA = "0x73BB930", Offset = "0x73BB930", Length = "0x84")]
			[Token(Token = "0x60030DF")]
			public override void Reset() { }

		}

		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001B2E")]
		private ListDictionaryInternal list; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4001B2F")]
		private bool isKeys; //Field offset: 0x18

		[Token(Token = "0x1700078F")]
		private override int System.Collections.ICollection.Count
		{
			[Address(RVA = "0x73BB6B4", Offset = "0x73BB6B4", Length = "0x38")]
			[Token(Token = "0x60030D8")]
			private get { } //Length: 56
		}

		[Token(Token = "0x17000790")]
		private override bool System.Collections.ICollection.IsSynchronized
		{
			[Address(RVA = "0x73BB6EC", Offset = "0x73BB6EC", Length = "0x8")]
			[Token(Token = "0x60030D9")]
			private get { } //Length: 8
		}

		[Token(Token = "0x17000791")]
		private override object System.Collections.ICollection.SyncRoot
		{
			[Address(RVA = "0x73BB6F4", Offset = "0x73BB6F4", Length = "0x18")]
			[Token(Token = "0x60030DA")]
			private get { } //Length: 24
		}

		[Address(RVA = "0x73BA998", Offset = "0x73BA998", Length = "0x3C")]
		[Token(Token = "0x60030D6")]
		public NodeKeyValueCollection(ListDictionaryInternal list, bool isKeys) { }

		[Address(RVA = "0x73BB4E8", Offset = "0x73BB4E8", Length = "0x1CC")]
		[Token(Token = "0x60030D7")]
		private override void System.Collections.ICollection.CopyTo(Array array, int index) { }

		[Address(RVA = "0x73BB6B4", Offset = "0x73BB6B4", Length = "0x38")]
		[Token(Token = "0x60030D8")]
		private override int System.Collections.ICollection.get_Count() { }

		[Address(RVA = "0x73BB6EC", Offset = "0x73BB6EC", Length = "0x8")]
		[Token(Token = "0x60030D9")]
		private override bool System.Collections.ICollection.get_IsSynchronized() { }

		[Address(RVA = "0x73BB6F4", Offset = "0x73BB6F4", Length = "0x18")]
		[Token(Token = "0x60030DA")]
		private override object System.Collections.ICollection.get_SyncRoot() { }

		[Address(RVA = "0x73BB70C", Offset = "0x73BB70C", Length = "0x78")]
		[Token(Token = "0x60030DB")]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	}

	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001B26")]
	private DictionaryNode head; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001B27")]
	private int version; //Field offset: 0x18
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x4001B28")]
	private int count; //Field offset: 0x1C
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4001B29")]
	private object _syncRoot; //Field offset: 0x20

	[Token(Token = "0x17000784")]
	public override int Count
	{
		[Address(RVA = "0x73BA918", Offset = "0x73BA918", Length = "0x8")]
		[Token(Token = "0x60030C1")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000787")]
	public override bool IsFixedSize
	{
		[Address(RVA = "0x73BA9DC", Offset = "0x73BA9DC", Length = "0x8")]
		[Token(Token = "0x60030C4")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000786")]
	public override bool IsReadOnly
	{
		[Address(RVA = "0x73BA9D4", Offset = "0x73BA9D4", Length = "0x8")]
		[Token(Token = "0x60030C3")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000788")]
	public override bool IsSynchronized
	{
		[Address(RVA = "0x73BA9E4", Offset = "0x73BA9E4", Length = "0x8")]
		[Token(Token = "0x60030C5")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000783")]
	public override object Item
	{
		[Address(RVA = "0x73BA6D4", Offset = "0x73BA6D4", Length = "0xB8")]
		[Token(Token = "0x60030BF")]
		 get { } //Length: 184
		[Address(RVA = "0x73BA78C", Offset = "0x73BA78C", Length = "0x184")]
		[Token(Token = "0x60030C0")]
		 set { } //Length: 388
	}

	[Token(Token = "0x17000785")]
	public override ICollection Keys
	{
		[Address(RVA = "0x73BA920", Offset = "0x73BA920", Length = "0x78")]
		[Token(Token = "0x60030C2")]
		 get { } //Length: 120
	}

	[Token(Token = "0x17000789")]
	public override object SyncRoot
	{
		[Address(RVA = "0x73BA9EC", Offset = "0x73BA9EC", Length = "0x78")]
		[Token(Token = "0x60030C6")]
		 get { } //Length: 120
	}

	[Token(Token = "0x1700078A")]
	public override ICollection Values
	{
		[Address(RVA = "0x73BAA64", Offset = "0x73BAA64", Length = "0x74")]
		[Token(Token = "0x60030C7")]
		 get { } //Length: 116
	}

	[Address(RVA = "0x73BA6CC", Offset = "0x73BA6CC", Length = "0x8")]
	[Token(Token = "0x60030BE")]
	public ListDictionaryInternal() { }

	[Address(RVA = "0x73BAAD8", Offset = "0x73BAAD8", Length = "0x1D0")]
	[Token(Token = "0x60030C8")]
	public override void Add(object key, object value) { }

	[Address(RVA = "0x73BACA8", Offset = "0x73BACA8", Length = "0x30")]
	[Token(Token = "0x60030C9")]
	public override void Clear() { }

	[Address(RVA = "0x73BACD8", Offset = "0x73BACD8", Length = "0xB8")]
	[Token(Token = "0x60030CA")]
	public override bool Contains(object key) { }

	[Address(RVA = "0x73BAD90", Offset = "0x73BAD90", Length = "0x218")]
	[Token(Token = "0x60030CB")]
	public override void CopyTo(Array array, int index) { }

	[Address(RVA = "0x73BA918", Offset = "0x73BA918", Length = "0x8")]
	[Token(Token = "0x60030C1")]
	public override int get_Count() { }

	[Address(RVA = "0x73BA9DC", Offset = "0x73BA9DC", Length = "0x8")]
	[Token(Token = "0x60030C4")]
	public override bool get_IsFixedSize() { }

	[Address(RVA = "0x73BA9D4", Offset = "0x73BA9D4", Length = "0x8")]
	[Token(Token = "0x60030C3")]
	public override bool get_IsReadOnly() { }

	[Address(RVA = "0x73BA9E4", Offset = "0x73BA9E4", Length = "0x8")]
	[Token(Token = "0x60030C5")]
	public override bool get_IsSynchronized() { }

	[Address(RVA = "0x73BA6D4", Offset = "0x73BA6D4", Length = "0xB8")]
	[Token(Token = "0x60030BF")]
	public override object get_Item(object key) { }

	[Address(RVA = "0x73BA920", Offset = "0x73BA920", Length = "0x78")]
	[Token(Token = "0x60030C2")]
	public override ICollection get_Keys() { }

	[Address(RVA = "0x73BA9EC", Offset = "0x73BA9EC", Length = "0x78")]
	[Token(Token = "0x60030C6")]
	public override object get_SyncRoot() { }

	[Address(RVA = "0x73BAA64", Offset = "0x73BAA64", Length = "0x74")]
	[Token(Token = "0x60030C7")]
	public override ICollection get_Values() { }

	[Address(RVA = "0x73BAFA8", Offset = "0x73BAFA8", Length = "0x60")]
	[Token(Token = "0x60030CC")]
	public override IDictionaryEnumerator GetEnumerator() { }

	[Address(RVA = "0x73BB0C0", Offset = "0x73BB0C0", Length = "0x114")]
	[Token(Token = "0x60030CE")]
	public override void Remove(object key) { }

	[Address(RVA = "0x73BA78C", Offset = "0x73BA78C", Length = "0x184")]
	[Token(Token = "0x60030C0")]
	public override void set_Item(object key, object value) { }

	[Address(RVA = "0x73BB060", Offset = "0x73BB060", Length = "0x60")]
	[Token(Token = "0x60030CD")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

