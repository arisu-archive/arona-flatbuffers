namespace System.Collections;

[Obsolete("Please use StringComparer instead.")]
[Token(Token = "0x2000642")]
public class CaseInsensitiveHashCodeProvider : IHashCodeProvider
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001B3B")]
	private readonly CompareInfo _compareInfo; //Field offset: 0x10

	[Address(RVA = "0x73BBEEC", Offset = "0x73BBEEC", Length = "0x80")]
	[Token(Token = "0x60030EA")]
	public CaseInsensitiveHashCodeProvider() { }

	[Address(RVA = "0x73BBF6C", Offset = "0x73BBF6C", Length = "0x90")]
	[Token(Token = "0x60030EB")]
	public CaseInsensitiveHashCodeProvider(CultureInfo culture) { }

	[Address(RVA = "0x73BBFFC", Offset = "0x73BBFFC", Length = "0xD8")]
	[Token(Token = "0x60030EC")]
	public override int GetHashCode(object obj) { }

}

