namespace System.Collections;

[Token(Token = "0x2000639")]
public interface IStructuralComparable
{

	[Token(Token = "0x60030BB")]
	public int CompareTo(object other, IComparer comparer) { }

}

