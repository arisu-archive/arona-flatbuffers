namespace System.Collections;

[DefaultMember("Item")]
[Token(Token = "0x2000633")]
public interface IDictionary : ICollection, IEnumerable
{

	[Token(Token = "0x1700077B")]
	public bool IsFixedSize
	{
		[Token(Token = "0x60030A4")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700077A")]
	public bool IsReadOnly
	{
		[Token(Token = "0x60030A3")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000777")]
	public object Item
	{
		[Token(Token = "0x600309C")]
		 get { } //Length: 0
		[Token(Token = "0x600309D")]
		 set { } //Length: 0
	}

	[Token(Token = "0x17000778")]
	public ICollection Keys
	{
		[Token(Token = "0x600309E")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000779")]
	public ICollection Values
	{
		[Token(Token = "0x600309F")]
		 get { } //Length: 0
	}

	[Token(Token = "0x60030A1")]
	public void Add(object key, object value) { }

	[Token(Token = "0x60030A2")]
	public void Clear() { }

	[Token(Token = "0x60030A0")]
	public bool Contains(object key) { }

	[Token(Token = "0x60030A4")]
	public bool get_IsFixedSize() { }

	[Token(Token = "0x60030A3")]
	public bool get_IsReadOnly() { }

	[Token(Token = "0x600309C")]
	public object get_Item(object key) { }

	[Token(Token = "0x600309E")]
	public ICollection get_Keys() { }

	[Token(Token = "0x600309F")]
	public ICollection get_Values() { }

	[Token(Token = "0x60030A5")]
	public IDictionaryEnumerator GetEnumerator() { }

	[Token(Token = "0x60030A6")]
	public void Remove(object key) { }

	[Token(Token = "0x600309D")]
	public void set_Item(object key, object value) { }

}

