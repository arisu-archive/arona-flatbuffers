namespace System.Collections;

[Token(Token = "0x2000641")]
public class CaseInsensitiveComparer : IComparer
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001B3A")]
	private CompareInfo _compareInfo; //Field offset: 0x10

	[Address(RVA = "0x73BBCF0", Offset = "0x73BBCF0", Length = "0x80")]
	[Token(Token = "0x60030E7")]
	public CaseInsensitiveComparer() { }

	[Address(RVA = "0x73BBD70", Offset = "0x73BBD70", Length = "0x90")]
	[Token(Token = "0x60030E8")]
	public CaseInsensitiveComparer(CultureInfo culture) { }

	[Address(RVA = "0x73BBE00", Offset = "0x73BBE00", Length = "0xEC")]
	[Token(Token = "0x60030E9")]
	public override int Compare(object a, object b) { }

}

