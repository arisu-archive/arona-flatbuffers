namespace System.Collections;

[DebuggerDisplay("Count = {Count}")]
[DebuggerTypeProxy(typeof(SortedListDebugView))]
[DefaultMember("Item")]
[Token(Token = "0x2000648")]
public class SortedList : IDictionary, ICollection, IEnumerable, ICloneable
{
	[DefaultMember("Item")]
	[Token(Token = "0x200064B")]
	[TypeForwardedFrom("mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")]
	private class KeyList : IList, ICollection, IEnumerable
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001B5C")]
		private SortedList sortedList; //Field offset: 0x10

		[Token(Token = "0x170007B8")]
		public override int Count
		{
			[Address(RVA = "0x73C07D8", Offset = "0x73C07D8", Length = "0x1C")]
			[Token(Token = "0x6003167")]
			 get { } //Length: 28
		}

		[Token(Token = "0x170007BA")]
		public override bool IsFixedSize
		{
			[Address(RVA = "0x73C07FC", Offset = "0x73C07FC", Length = "0x8")]
			[Token(Token = "0x6003169")]
			 get { } //Length: 8
		}

		[Token(Token = "0x170007B9")]
		public override bool IsReadOnly
		{
			[Address(RVA = "0x73C07F4", Offset = "0x73C07F4", Length = "0x8")]
			[Token(Token = "0x6003168")]
			 get { } //Length: 8
		}

		[Token(Token = "0x170007BB")]
		public override bool IsSynchronized
		{
			[Address(RVA = "0x73C0804", Offset = "0x73C0804", Length = "0x24")]
			[Token(Token = "0x600316A")]
			 get { } //Length: 36
		}

		[Token(Token = "0x170007BD")]
		public override object Item
		{
			[Address(RVA = "0x73C0A30", Offset = "0x73C0A30", Length = "0x24")]
			[Token(Token = "0x6003171")]
			 get { } //Length: 36
			[Address(RVA = "0x73C0A54", Offset = "0x73C0A54", Length = "0x50")]
			[Token(Token = "0x6003172")]
			 set { } //Length: 80
		}

		[Token(Token = "0x170007BC")]
		public override object SyncRoot
		{
			[Address(RVA = "0x73C0828", Offset = "0x73C0828", Length = "0x24")]
			[Token(Token = "0x600316B")]
			 get { } //Length: 36
		}

		[Address(RVA = "0x73BEC20", Offset = "0x73BEC20", Length = "0x30")]
		[Token(Token = "0x6003166")]
		internal KeyList(SortedList sortedList) { }

		[Address(RVA = "0x73C084C", Offset = "0x73C084C", Length = "0x50")]
		[Token(Token = "0x600316C")]
		public override int Add(object key) { }

		[Address(RVA = "0x73C089C", Offset = "0x73C089C", Length = "0x50")]
		[Token(Token = "0x600316D")]
		public override void Clear() { }

		[Address(RVA = "0x73C08EC", Offset = "0x73C08EC", Length = "0x24")]
		[Token(Token = "0x600316E")]
		public override bool Contains(object key) { }

		[Address(RVA = "0x73C0910", Offset = "0x73C0910", Length = "0xD0")]
		[Token(Token = "0x600316F")]
		public override void CopyTo(Array array, int arrayIndex) { }

		[Address(RVA = "0x73C07D8", Offset = "0x73C07D8", Length = "0x1C")]
		[Token(Token = "0x6003167")]
		public override int get_Count() { }

		[Address(RVA = "0x73C07FC", Offset = "0x73C07FC", Length = "0x8")]
		[Token(Token = "0x6003169")]
		public override bool get_IsFixedSize() { }

		[Address(RVA = "0x73C07F4", Offset = "0x73C07F4", Length = "0x8")]
		[Token(Token = "0x6003168")]
		public override bool get_IsReadOnly() { }

		[Address(RVA = "0x73C0804", Offset = "0x73C0804", Length = "0x24")]
		[Token(Token = "0x600316A")]
		public override bool get_IsSynchronized() { }

		[Address(RVA = "0x73C0A30", Offset = "0x73C0A30", Length = "0x24")]
		[Token(Token = "0x6003171")]
		public override object get_Item(int index) { }

		[Address(RVA = "0x73C0828", Offset = "0x73C0828", Length = "0x24")]
		[Token(Token = "0x600316B")]
		public override object get_SyncRoot() { }

		[Address(RVA = "0x73C0AA4", Offset = "0x73C0AA4", Length = "0x8C")]
		[Token(Token = "0x6003173")]
		public override IEnumerator GetEnumerator() { }

		[Address(RVA = "0x73C0B30", Offset = "0x73C0B30", Length = "0xCC")]
		[Token(Token = "0x6003174")]
		public override int IndexOf(object key) { }

		[Address(RVA = "0x73C09E0", Offset = "0x73C09E0", Length = "0x50")]
		[Token(Token = "0x6003170")]
		public override void Insert(int index, object value) { }

		[Address(RVA = "0x73C0BFC", Offset = "0x73C0BFC", Length = "0x50")]
		[Token(Token = "0x6003175")]
		public override void Remove(object key) { }

		[Address(RVA = "0x73C0C4C", Offset = "0x73C0C4C", Length = "0x50")]
		[Token(Token = "0x6003176")]
		public override void RemoveAt(int index) { }

		[Address(RVA = "0x73C0A54", Offset = "0x73C0A54", Length = "0x50")]
		[Token(Token = "0x6003172")]
		public override void set_Item(int index, object value) { }

	}

	[Token(Token = "0x200064D")]
	public class SortedListDebugView
	{

	}

	[Token(Token = "0x200064A")]
	private class SortedListEnumerator : IDictionaryEnumerator, IEnumerator, ICloneable
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001B53")]
		private SortedList _sortedList; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4001B54")]
		private object _key; //Field offset: 0x18
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4001B55")]
		private object _value; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4001B56")]
		private int _index; //Field offset: 0x28
		[FieldOffset(Offset = "0x2C")]
		[Token(Token = "0x4001B57")]
		private int _startIndex; //Field offset: 0x2C
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4001B58")]
		private int _endIndex; //Field offset: 0x30
		[FieldOffset(Offset = "0x34")]
		[Token(Token = "0x4001B59")]
		private int _version; //Field offset: 0x34
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4001B5A")]
		private bool _current; //Field offset: 0x38
		[FieldOffset(Offset = "0x3C")]
		[Token(Token = "0x4001B5B")]
		private int _getObjectRetType; //Field offset: 0x3C

		[Token(Token = "0x170007B6")]
		public override object Current
		{
			[Address(RVA = "0x73C0598", Offset = "0x73C0598", Length = "0xFC")]
			[Token(Token = "0x6003163")]
			 get { } //Length: 252
		}

		[Token(Token = "0x170007B5")]
		public override DictionaryEntry Entry
		{
			[Address(RVA = "0x73C04BC", Offset = "0x73C04BC", Length = "0xDC")]
			[Token(Token = "0x6003162")]
			 get { } //Length: 220
		}

		[Token(Token = "0x170007B4")]
		public override object Key
		{
			[Address(RVA = "0x73C02D4", Offset = "0x73C02D4", Length = "0xA4")]
			[Token(Token = "0x6003160")]
			 get { } //Length: 164
		}

		[Token(Token = "0x170007B7")]
		public override object Value
		{
			[Address(RVA = "0x73C0694", Offset = "0x73C0694", Length = "0xA4")]
			[Token(Token = "0x6003164")]
			 get { } //Length: 164
		}

		[Address(RVA = "0x73BE9F0", Offset = "0x73BE9F0", Length = "0x78")]
		[Token(Token = "0x600315E")]
		internal SortedListEnumerator(SortedList sortedList, int index, int count, int getObjRetType) { }

		[Address(RVA = "0x73C02CC", Offset = "0x73C02CC", Length = "0x8")]
		[Token(Token = "0x600315F")]
		public override object Clone() { }

		[Address(RVA = "0x73C0598", Offset = "0x73C0598", Length = "0xFC")]
		[Token(Token = "0x6003163")]
		public override object get_Current() { }

		[Address(RVA = "0x73C04BC", Offset = "0x73C04BC", Length = "0xDC")]
		[Token(Token = "0x6003162")]
		public override DictionaryEntry get_Entry() { }

		[Address(RVA = "0x73C02D4", Offset = "0x73C02D4", Length = "0xA4")]
		[Token(Token = "0x6003160")]
		public override object get_Key() { }

		[Address(RVA = "0x73C0694", Offset = "0x73C0694", Length = "0xA4")]
		[Token(Token = "0x6003164")]
		public override object get_Value() { }

		[Address(RVA = "0x73C0378", Offset = "0x73C0378", Length = "0x144")]
		[Token(Token = "0x6003161")]
		public override bool MoveNext() { }

		[Address(RVA = "0x73C0738", Offset = "0x73C0738", Length = "0xA0")]
		[Token(Token = "0x6003165")]
		public override void Reset() { }

	}

	[DefaultMember("Item")]
	[Token(Token = "0x2000649")]
	private class SyncSortedList : SortedList
	{
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4001B51")]
		private SortedList _list; //Field offset: 0x48
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4001B52")]
		private object _root; //Field offset: 0x50

		[Token(Token = "0x170007AE")]
		public virtual int Count
		{
			[Address(RVA = "0x73BF228", Offset = "0x73BF228", Length = "0xD4")]
			[Token(Token = "0x6003147")]
			 get { } //Length: 212
		}

		[Token(Token = "0x170007B1")]
		public virtual bool IsFixedSize
		{
			[Address(RVA = "0x73BF328", Offset = "0x73BF328", Length = "0x24")]
			[Token(Token = "0x600314A")]
			 get { } //Length: 36
		}

		[Token(Token = "0x170007B0")]
		public virtual bool IsReadOnly
		{
			[Address(RVA = "0x73BF304", Offset = "0x73BF304", Length = "0x24")]
			[Token(Token = "0x6003149")]
			 get { } //Length: 36
		}

		[Token(Token = "0x170007B2")]
		public virtual bool IsSynchronized
		{
			[Address(RVA = "0x73BF34C", Offset = "0x73BF34C", Length = "0x8")]
			[Token(Token = "0x600314B")]
			 get { } //Length: 8
		}

		[Token(Token = "0x170007B3")]
		public virtual object Item
		{
			[Address(RVA = "0x73BF354", Offset = "0x73BF354", Length = "0xDC")]
			[Token(Token = "0x600314C")]
			 get { } //Length: 220
			[Address(RVA = "0x73BF430", Offset = "0x73BF430", Length = "0xD8")]
			[Token(Token = "0x600314D")]
			 set { } //Length: 216
		}

		[Token(Token = "0x170007AF")]
		public virtual object SyncRoot
		{
			[Address(RVA = "0x73BF2FC", Offset = "0x73BF2FC", Length = "0x8")]
			[Token(Token = "0x6003148")]
			 get { } //Length: 8
		}

		[Address(RVA = "0x73BF1C4", Offset = "0x73BF1C4", Length = "0x64")]
		[Token(Token = "0x6003146")]
		internal SyncSortedList(SortedList list) { }

		[Address(RVA = "0x73BF508", Offset = "0x73BF508", Length = "0xD8")]
		[Token(Token = "0x600314E")]
		public virtual void Add(object key, object value) { }

		[Address(RVA = "0x73BF5E0", Offset = "0x73BF5E0", Length = "0xC0")]
		[Token(Token = "0x600314F")]
		public virtual void Clear() { }

		[Address(RVA = "0x73BF6A0", Offset = "0x73BF6A0", Length = "0xD4")]
		[Token(Token = "0x6003150")]
		public virtual object Clone() { }

		[Address(RVA = "0x73BF774", Offset = "0x73BF774", Length = "0xDC")]
		[Token(Token = "0x6003151")]
		public virtual bool Contains(object key) { }

		[Address(RVA = "0x73BF850", Offset = "0x73BF850", Length = "0xDC")]
		[Token(Token = "0x6003152")]
		public virtual bool ContainsKey(object key) { }

		[Address(RVA = "0x73BF92C", Offset = "0x73BF92C", Length = "0xDC")]
		[Token(Token = "0x6003153")]
		public virtual bool ContainsValue(object key) { }

		[Address(RVA = "0x73BFA08", Offset = "0x73BFA08", Length = "0xD8")]
		[Token(Token = "0x6003154")]
		public virtual void CopyTo(Array array, int index) { }

		[Address(RVA = "0x73BF228", Offset = "0x73BF228", Length = "0xD4")]
		[Token(Token = "0x6003147")]
		public virtual int get_Count() { }

		[Address(RVA = "0x73BF328", Offset = "0x73BF328", Length = "0x24")]
		[Token(Token = "0x600314A")]
		public virtual bool get_IsFixedSize() { }

		[Address(RVA = "0x73BF304", Offset = "0x73BF304", Length = "0x24")]
		[Token(Token = "0x6003149")]
		public virtual bool get_IsReadOnly() { }

		[Address(RVA = "0x73BF34C", Offset = "0x73BF34C", Length = "0x8")]
		[Token(Token = "0x600314B")]
		public virtual bool get_IsSynchronized() { }

		[Address(RVA = "0x73BF354", Offset = "0x73BF354", Length = "0xDC")]
		[Token(Token = "0x600314C")]
		public virtual object get_Item(object key) { }

		[Address(RVA = "0x73BF2FC", Offset = "0x73BF2FC", Length = "0x8")]
		[Token(Token = "0x6003148")]
		public virtual object get_SyncRoot() { }

		[Address(RVA = "0x73BFAE0", Offset = "0x73BFAE0", Length = "0xDC")]
		[Token(Token = "0x6003155")]
		public virtual object GetByIndex(int index) { }

		[Address(RVA = "0x73BFBBC", Offset = "0x73BFBBC", Length = "0xD4")]
		[Token(Token = "0x6003156")]
		public virtual IDictionaryEnumerator GetEnumerator() { }

		[Address(RVA = "0x73BFC90", Offset = "0x73BFC90", Length = "0xDC")]
		[Token(Token = "0x6003157")]
		public virtual object GetKey(int index) { }

		[Address(RVA = "0x73BFD6C", Offset = "0x73BFD6C", Length = "0xD4")]
		[Token(Token = "0x6003158")]
		public virtual IList GetKeyList() { }

		[Address(RVA = "0x73BFE40", Offset = "0x73BFE40", Length = "0xD4")]
		[Token(Token = "0x6003159")]
		public virtual IList GetValueList() { }

		[Address(RVA = "0x73BFF14", Offset = "0x73BFF14", Length = "0x144")]
		[Token(Token = "0x600315A")]
		public virtual int IndexOfKey(object key) { }

		[Address(RVA = "0x73C0058", Offset = "0x73C0058", Length = "0xDC")]
		[Token(Token = "0x600315B")]
		public virtual int IndexOfValue(object value) { }

		[Address(RVA = "0x73C0200", Offset = "0x73C0200", Length = "0xCC")]
		[Token(Token = "0x600315D")]
		public virtual void Remove(object key) { }

		[Address(RVA = "0x73C0134", Offset = "0x73C0134", Length = "0xCC")]
		[Token(Token = "0x600315C")]
		public virtual void RemoveAt(int index) { }

		[Address(RVA = "0x73BF430", Offset = "0x73BF430", Length = "0xD8")]
		[Token(Token = "0x600314D")]
		public virtual void set_Item(object key, object value) { }

	}

	[DefaultMember("Item")]
	[Token(Token = "0x200064C")]
	[TypeForwardedFrom("mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089")]
	private class ValueList : IList, ICollection, IEnumerable
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001B5D")]
		private SortedList sortedList; //Field offset: 0x10

		[Token(Token = "0x170007BE")]
		public override int Count
		{
			[Address(RVA = "0x73C0C9C", Offset = "0x73C0C9C", Length = "0x1C")]
			[Token(Token = "0x6003178")]
			 get { } //Length: 28
		}

		[Token(Token = "0x170007C0")]
		public override bool IsFixedSize
		{
			[Address(RVA = "0x73C0CC0", Offset = "0x73C0CC0", Length = "0x8")]
			[Token(Token = "0x600317A")]
			 get { } //Length: 8
		}

		[Token(Token = "0x170007BF")]
		public override bool IsReadOnly
		{
			[Address(RVA = "0x73C0CB8", Offset = "0x73C0CB8", Length = "0x8")]
			[Token(Token = "0x6003179")]
			 get { } //Length: 8
		}

		[Token(Token = "0x170007C1")]
		public override bool IsSynchronized
		{
			[Address(RVA = "0x73C0CC8", Offset = "0x73C0CC8", Length = "0x24")]
			[Token(Token = "0x600317B")]
			 get { } //Length: 36
		}

		[Token(Token = "0x170007C3")]
		public override object Item
		{
			[Address(RVA = "0x73C0EF4", Offset = "0x73C0EF4", Length = "0x24")]
			[Token(Token = "0x6003182")]
			 get { } //Length: 36
			[Address(RVA = "0x73C0F18", Offset = "0x73C0F18", Length = "0x50")]
			[Token(Token = "0x6003183")]
			 set { } //Length: 80
		}

		[Token(Token = "0x170007C2")]
		public override object SyncRoot
		{
			[Address(RVA = "0x73C0CEC", Offset = "0x73C0CEC", Length = "0x24")]
			[Token(Token = "0x600317C")]
			 get { } //Length: 36
		}

		[Address(RVA = "0x73BECDC", Offset = "0x73BECDC", Length = "0x30")]
		[Token(Token = "0x6003177")]
		internal ValueList(SortedList sortedList) { }

		[Address(RVA = "0x73C0D10", Offset = "0x73C0D10", Length = "0x50")]
		[Token(Token = "0x600317D")]
		public override int Add(object key) { }

		[Address(RVA = "0x73C0D60", Offset = "0x73C0D60", Length = "0x50")]
		[Token(Token = "0x600317E")]
		public override void Clear() { }

		[Address(RVA = "0x73C0DB0", Offset = "0x73C0DB0", Length = "0x24")]
		[Token(Token = "0x600317F")]
		public override bool Contains(object value) { }

		[Address(RVA = "0x73C0DD4", Offset = "0x73C0DD4", Length = "0xD0")]
		[Token(Token = "0x6003180")]
		public override void CopyTo(Array array, int arrayIndex) { }

		[Address(RVA = "0x73C0C9C", Offset = "0x73C0C9C", Length = "0x1C")]
		[Token(Token = "0x6003178")]
		public override int get_Count() { }

		[Address(RVA = "0x73C0CC0", Offset = "0x73C0CC0", Length = "0x8")]
		[Token(Token = "0x600317A")]
		public override bool get_IsFixedSize() { }

		[Address(RVA = "0x73C0CB8", Offset = "0x73C0CB8", Length = "0x8")]
		[Token(Token = "0x6003179")]
		public override bool get_IsReadOnly() { }

		[Address(RVA = "0x73C0CC8", Offset = "0x73C0CC8", Length = "0x24")]
		[Token(Token = "0x600317B")]
		public override bool get_IsSynchronized() { }

		[Address(RVA = "0x73C0EF4", Offset = "0x73C0EF4", Length = "0x24")]
		[Token(Token = "0x6003182")]
		public override object get_Item(int index) { }

		[Address(RVA = "0x73C0CEC", Offset = "0x73C0CEC", Length = "0x24")]
		[Token(Token = "0x600317C")]
		public override object get_SyncRoot() { }

		[Address(RVA = "0x73C0F68", Offset = "0x73C0F68", Length = "0x8C")]
		[Token(Token = "0x6003184")]
		public override IEnumerator GetEnumerator() { }

		[Address(RVA = "0x73C0FF4", Offset = "0x73C0FF4", Length = "0x78")]
		[Token(Token = "0x6003185")]
		public override int IndexOf(object value) { }

		[Address(RVA = "0x73C0EA4", Offset = "0x73C0EA4", Length = "0x50")]
		[Token(Token = "0x6003181")]
		public override void Insert(int index, object value) { }

		[Address(RVA = "0x73C106C", Offset = "0x73C106C", Length = "0x50")]
		[Token(Token = "0x6003186")]
		public override void Remove(object value) { }

		[Address(RVA = "0x73C10BC", Offset = "0x73C10BC", Length = "0x50")]
		[Token(Token = "0x6003187")]
		public override void RemoveAt(int index) { }

		[Address(RVA = "0x73C0F18", Offset = "0x73C0F18", Length = "0x50")]
		[Token(Token = "0x6003183")]
		public override void set_Item(int index, object value) { }

	}

	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001B49")]
	private Object[] keys; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001B4A")]
	private Object[] values; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4001B4B")]
	private int _size; //Field offset: 0x20
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x4001B4C")]
	private int version; //Field offset: 0x24
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4001B4D")]
	private IComparer comparer; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4001B4E")]
	private KeyList keyList; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4001B4F")]
	private ValueList valueList; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4001B50")]
	private object _syncRoot; //Field offset: 0x40

	[Token(Token = "0x170007A5")]
	public override int Capacity
	{
		[Address(RVA = "0x73BE180", Offset = "0x73BE180", Length = "0x224")]
		[Token(Token = "0x6003129")]
		 set { } //Length: 548
	}

	[Token(Token = "0x170007A6")]
	public override int Count
	{
		[Address(RVA = "0x73BE3A4", Offset = "0x73BE3A4", Length = "0x8")]
		[Token(Token = "0x600312A")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170007AA")]
	public override bool IsFixedSize
	{
		[Address(RVA = "0x73BE3D4", Offset = "0x73BE3D4", Length = "0x8")]
		[Token(Token = "0x600312E")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170007A9")]
	public override bool IsReadOnly
	{
		[Address(RVA = "0x73BE3CC", Offset = "0x73BE3CC", Length = "0x8")]
		[Token(Token = "0x600312D")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170007AB")]
	public override bool IsSynchronized
	{
		[Address(RVA = "0x73BE3DC", Offset = "0x73BE3DC", Length = "0x8")]
		[Token(Token = "0x600312F")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170007AD")]
	public override object Item
	{
		[Address(RVA = "0x73BED0C", Offset = "0x73BED0C", Length = "0x50")]
		[Token(Token = "0x600313E")]
		 get { } //Length: 80
		[Address(RVA = "0x73BED5C", Offset = "0x73BED5C", Length = "0x12C")]
		[Token(Token = "0x600313F")]
		 set { } //Length: 300
	}

	[Token(Token = "0x170007A7")]
	public override ICollection Keys
	{
		[Address(RVA = "0x73BE3AC", Offset = "0x73BE3AC", Length = "0x10")]
		[Token(Token = "0x600312B")]
		 get { } //Length: 16
	}

	[Token(Token = "0x170007AC")]
	public override object SyncRoot
	{
		[Address(RVA = "0x73BE3E4", Offset = "0x73BE3E4", Length = "0x78")]
		[Token(Token = "0x6003130")]
		 get { } //Length: 120
	}

	[Token(Token = "0x170007A8")]
	public override ICollection Values
	{
		[Address(RVA = "0x73BE3BC", Offset = "0x73BE3BC", Length = "0x10")]
		[Token(Token = "0x600312C")]
		 get { } //Length: 16
	}

	[Address(RVA = "0x73BDC00", Offset = "0x73BDC00", Length = "0x1C")]
	[Token(Token = "0x6003124")]
	public SortedList() { }

	[Address(RVA = "0x73BDD6C", Offset = "0x73BDD6C", Length = "0x15C")]
	[Token(Token = "0x6003126")]
	public SortedList(int initialCapacity) { }

	[Address(RVA = "0x73BDEC8", Offset = "0x73BDEC8", Length = "0x48")]
	[Token(Token = "0x6003127")]
	public SortedList(IComparer comparer) { }

	[Address(RVA = "0x73BDF10", Offset = "0x73BDF10", Length = "0x130")]
	[Token(Token = "0x6003128")]
	public override void Add(object key, object value) { }

	[Address(RVA = "0x73BE45C", Offset = "0x73BE45C", Length = "0x44")]
	[Token(Token = "0x6003131")]
	public override void Clear() { }

	[Address(RVA = "0x73BE4A0", Offset = "0x73BE4A0", Length = "0xB4")]
	[Token(Token = "0x6003132")]
	public override object Clone() { }

	[Address(RVA = "0x73BE554", Offset = "0x73BE554", Length = "0x24")]
	[Token(Token = "0x6003133")]
	public override bool Contains(object key) { }

	[Address(RVA = "0x73BE578", Offset = "0x73BE578", Length = "0x24")]
	[Token(Token = "0x6003134")]
	public override bool ContainsKey(object key) { }

	[Address(RVA = "0x73BE59C", Offset = "0x73BE59C", Length = "0x24")]
	[Token(Token = "0x6003135")]
	public override bool ContainsValue(object value) { }

	[Address(RVA = "0x73BE5C0", Offset = "0x73BE5C0", Length = "0x2B8")]
	[Token(Token = "0x6003136")]
	public override void CopyTo(Array array, int arrayIndex) { }

	[Address(RVA = "0x73BE878", Offset = "0x73BE878", Length = "0x4C")]
	[Token(Token = "0x6003137")]
	private void EnsureCapacity(int min) { }

	[Address(RVA = "0x73BE3A4", Offset = "0x73BE3A4", Length = "0x8")]
	[Token(Token = "0x600312A")]
	public override int get_Count() { }

	[Address(RVA = "0x73BE3D4", Offset = "0x73BE3D4", Length = "0x8")]
	[Token(Token = "0x600312E")]
	public override bool get_IsFixedSize() { }

	[Address(RVA = "0x73BE3CC", Offset = "0x73BE3CC", Length = "0x8")]
	[Token(Token = "0x600312D")]
	public override bool get_IsReadOnly() { }

	[Address(RVA = "0x73BE3DC", Offset = "0x73BE3DC", Length = "0x8")]
	[Token(Token = "0x600312F")]
	public override bool get_IsSynchronized() { }

	[Address(RVA = "0x73BED0C", Offset = "0x73BED0C", Length = "0x50")]
	[Token(Token = "0x600313E")]
	public override object get_Item(object key) { }

	[Address(RVA = "0x73BE3AC", Offset = "0x73BE3AC", Length = "0x10")]
	[Token(Token = "0x600312B")]
	public override ICollection get_Keys() { }

	[Address(RVA = "0x73BE3E4", Offset = "0x73BE3E4", Length = "0x78")]
	[Token(Token = "0x6003130")]
	public override object get_SyncRoot() { }

	[Address(RVA = "0x73BE3BC", Offset = "0x73BE3BC", Length = "0x10")]
	[Token(Token = "0x600312C")]
	public override ICollection get_Values() { }

	[Address(RVA = "0x73BE8C4", Offset = "0x73BE8C4", Length = "0xBC")]
	[Token(Token = "0x6003138")]
	public override object GetByIndex(int index) { }

	[Address(RVA = "0x73BEA68", Offset = "0x73BEA68", Length = "0x70")]
	[Token(Token = "0x600313A")]
	public override IDictionaryEnumerator GetEnumerator() { }

	[Address(RVA = "0x73BEAD8", Offset = "0x73BEAD8", Length = "0xBC")]
	[Token(Token = "0x600313B")]
	public override object GetKey(int index) { }

	[Address(RVA = "0x73BEB94", Offset = "0x73BEB94", Length = "0x8C")]
	[Token(Token = "0x600313C")]
	public override IList GetKeyList() { }

	[Address(RVA = "0x73BEC50", Offset = "0x73BEC50", Length = "0x8C")]
	[Token(Token = "0x600313D")]
	public override IList GetValueList() { }

	[Address(RVA = "0x73BEE88", Offset = "0x73BEE88", Length = "0xA0")]
	[Token(Token = "0x6003140")]
	public override int IndexOfKey(object key) { }

	[Address(RVA = "0x73BEF28", Offset = "0x73BEF28", Length = "0x60")]
	[Token(Token = "0x6003141")]
	public override int IndexOfValue(object value) { }

	[Address(RVA = "0x73BDC1C", Offset = "0x73BDC1C", Length = "0x150")]
	[Token(Token = "0x6003125")]
	private void Init() { }

	[Address(RVA = "0x73BE040", Offset = "0x73BE040", Length = "0x140")]
	[Token(Token = "0x6003142")]
	private void Insert(int index, object key, object value) { }

	[Address(RVA = "0x73BF0D4", Offset = "0x73BF0D4", Length = "0x40")]
	[Token(Token = "0x6003144")]
	public override void Remove(object key) { }

	[Address(RVA = "0x73BEF88", Offset = "0x73BEF88", Length = "0x14C")]
	[Token(Token = "0x6003143")]
	public override void RemoveAt(int index) { }

	[Address(RVA = "0x73BE180", Offset = "0x73BE180", Length = "0x224")]
	[Token(Token = "0x6003129")]
	public override void set_Capacity(int value) { }

	[Address(RVA = "0x73BED5C", Offset = "0x73BED5C", Length = "0x12C")]
	[Token(Token = "0x600313F")]
	public override void set_Item(object key, object value) { }

	[Address(RVA = "0x73BF114", Offset = "0x73BF114", Length = "0xB0")]
	[Token(Token = "0x6003145")]
	public static SortedList Synchronized(SortedList list) { }

	[Address(RVA = "0x73BE980", Offset = "0x73BE980", Length = "0x70")]
	[Token(Token = "0x6003139")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

