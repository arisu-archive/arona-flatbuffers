namespace System.Collections;

[Token(Token = "0x2000631")]
public interface ICollection : IEnumerable
{

	[Token(Token = "0x17000774")]
	public int Count
	{
		[Token(Token = "0x6003098")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000776")]
	public bool IsSynchronized
	{
		[Token(Token = "0x600309A")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000775")]
	public object SyncRoot
	{
		[Token(Token = "0x6003099")]
		 get { } //Length: 0
	}

	[Token(Token = "0x6003097")]
	public void CopyTo(Array array, int index) { }

	[Token(Token = "0x6003098")]
	public int get_Count() { }

	[Token(Token = "0x600309A")]
	public bool get_IsSynchronized() { }

	[Token(Token = "0x6003099")]
	public object get_SyncRoot() { }

}

