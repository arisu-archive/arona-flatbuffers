namespace System.Collections;

[Token(Token = "0x2000634")]
public interface IDictionaryEnumerator : IEnumerator
{

	[Token(Token = "0x1700077E")]
	public DictionaryEntry Entry
	{
		[Token(Token = "0x60030A9")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700077C")]
	public object Key
	{
		[Token(Token = "0x60030A7")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700077D")]
	public object Value
	{
		[Token(Token = "0x60030A8")]
		 get { } //Length: 0
	}

	[Token(Token = "0x60030A9")]
	public DictionaryEntry get_Entry() { }

	[Token(Token = "0x60030A7")]
	public object get_Key() { }

	[Token(Token = "0x60030A8")]
	public object get_Value() { }

}

