namespace System.Collections.Concurrent;

[DebuggerDisplay("Count = {Count}")]
[DebuggerTypeProxy(typeof(IProducerConsumerCollectionDebugView`1))]
[Token(Token = "0x200066C")]
public class ConcurrentStack : IProducerConsumerCollection<T>, IEnumerable<T>, IEnumerable, ICollection, IReadOnlyCollection<T>
{
	[CompilerGenerated]
	[Token(Token = "0x200066E")]
	private sealed class <GetEnumerator>d__35 : IEnumerator<T>, IDisposable, IEnumerator
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BCF")]
		private int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BD0")]
		private T <>2__current; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BD1")]
		public Node<T> head; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BD2")]
		private Node<T> <current>5__2; //Field offset: 0x0

		[Token(Token = "0x1700081E")]
		private override T System.Collections.Generic.IEnumerator<T>.Current
		{
			[Address(RVA = "0x70915B4", Offset = "0x70915B4", Length = "0x8")]
			[DebuggerHidden]
			[Token(Token = "0x60032F1")]
			private get { } //Length: 8
		}

		[Token(Token = "0x1700081F")]
		private override object System.Collections.IEnumerator.Current
		{
			[Address(RVA = "0x70915FC", Offset = "0x70915FC", Length = "0x8")]
			[DebuggerHidden]
			[Token(Token = "0x60032F3")]
			private get { } //Length: 8
		}

		[Address(RVA = "0x7091504", Offset = "0x7091504", Length = "0x28")]
		[DebuggerHidden]
		[Token(Token = "0x60032EE")]
		public <GetEnumerator>d__35(int <>1__state) { }

		[Address(RVA = "0x7091530", Offset = "0x7091530", Length = "0x84")]
		[Token(Token = "0x60032F0")]
		private override bool MoveNext() { }

		[Address(RVA = "0x70915B4", Offset = "0x70915B4", Length = "0x8")]
		[DebuggerHidden]
		[Token(Token = "0x60032F1")]
		private override T System.Collections.Generic.IEnumerator<T>.get_Current() { }

		[Address(RVA = "0x70915FC", Offset = "0x70915FC", Length = "0x8")]
		[DebuggerHidden]
		[Token(Token = "0x60032F3")]
		private override object System.Collections.IEnumerator.get_Current() { }

		[Address(RVA = "0x70915BC", Offset = "0x70915BC", Length = "0x40")]
		[DebuggerHidden]
		[Token(Token = "0x60032F2")]
		private override void System.Collections.IEnumerator.Reset() { }

		[Address(RVA = "0x709152C", Offset = "0x709152C", Length = "0x4")]
		[DebuggerHidden]
		[Token(Token = "0x60032EF")]
		private override void System.IDisposable.Dispose() { }

	}

	[Token(Token = "0x200066D")]
	private class Node
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BCD")]
		internal readonly T _value; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BCE")]
		internal Node<T> _next; //Field offset: 0x0

		[Address(RVA = "0x596B914", Offset = "0x596B914", Length = "0x40")]
		[Token(Token = "0x60032ED")]
		internal Node(T value) { }

	}

	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BCC")]
	private Node<T> _head; //Field offset: 0x0

	[Token(Token = "0x1700081B")]
	public override int Count
	{
		[Address(RVA = "0x6E227DC", Offset = "0x6E227DC", Length = "0x28")]
		[Token(Token = "0x60032DC")]
		 get { } //Length: 40
	}

	[Token(Token = "0x1700081C")]
	private override bool System.Collections.ICollection.IsSynchronized
	{
		[Address(RVA = "0x6E22804", Offset = "0x6E22804", Length = "0x8")]
		[Token(Token = "0x60032DD")]
		private get { } //Length: 8
	}

	[Token(Token = "0x1700081D")]
	private override object System.Collections.ICollection.SyncRoot
	{
		[Address(RVA = "0x6E2280C", Offset = "0x6E2280C", Length = "0x50")]
		[Token(Token = "0x60032DE")]
		private get { } //Length: 80
	}

	[Address(RVA = "0x6E227D4", Offset = "0x6E227D4", Length = "0x8")]
	[Token(Token = "0x60032DB")]
	public ConcurrentStack`1() { }

	[Address(RVA = "0x6E2285C", Offset = "0x6E2285C", Length = "0x20")]
	[Token(Token = "0x60032DF")]
	public void Clear() { }

	[Address(RVA = "0x6E227DC", Offset = "0x6E227DC", Length = "0x28")]
	[Token(Token = "0x60032DC")]
	public override int get_Count() { }

	[Address(RVA = "0x6E230F4", Offset = "0x6E230F4", Length = "0x3C")]
	[Token(Token = "0x60032EA")]
	public override IEnumerator<T> GetEnumerator() { }

	[Address(RVA = "0x6E23130", Offset = "0x6E23130", Length = "0x70")]
	[IteratorStateMachine(typeof(<GetEnumerator>d__35))]
	[Token(Token = "0x60032EB")]
	private IEnumerator<T> GetEnumerator(Node<T> head) { }

	[Address(RVA = "0x6E229A0", Offset = "0x6E229A0", Length = "0xEC")]
	[Token(Token = "0x60032E1")]
	public void Push(T item) { }

	[Address(RVA = "0x6E22A8C", Offset = "0x6E22A8C", Length = "0x14C")]
	[Token(Token = "0x60032E2")]
	private void PushCore(Node<T> head, Node<T> tail) { }

	[Address(RVA = "0x6E22BD8", Offset = "0x6E22BD8", Length = "0x24")]
	[Token(Token = "0x60032E3")]
	private override bool System.Collections.Concurrent.IProducerConsumerCollection<T>.TryAdd(T item) { }

	[Address(RVA = "0x6E2287C", Offset = "0x6E2287C", Length = "0x124")]
	[Token(Token = "0x60032E0")]
	private override void System.Collections.ICollection.CopyTo(Array array, int index) { }

	[Address(RVA = "0x6E22804", Offset = "0x6E22804", Length = "0x8")]
	[Token(Token = "0x60032DD")]
	private override bool System.Collections.ICollection.get_IsSynchronized() { }

	[Address(RVA = "0x6E2280C", Offset = "0x6E2280C", Length = "0x50")]
	[Token(Token = "0x60032DE")]
	private override object System.Collections.ICollection.get_SyncRoot() { }

	[Address(RVA = "0x6E231A0", Offset = "0x6E231A0", Length = "0x88")]
	[Token(Token = "0x60032EC")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	[Address(RVA = "0x6E22FC4", Offset = "0x6E22FC4", Length = "0x70")]
	[Token(Token = "0x60032E7")]
	public override T[] ToArray() { }

	[Address(RVA = "0x6E23034", Offset = "0x6E23034", Length = "0x3C")]
	[Token(Token = "0x60032E8")]
	private List<T> ToList() { }

	[Address(RVA = "0x6E23070", Offset = "0x6E23070", Length = "0x84")]
	[Token(Token = "0x60032E9")]
	private List<T> ToList(Node<T> curr) { }

	[Address(RVA = "0x6E22BFC", Offset = "0x6E22BFC", Length = "0x9C")]
	[Token(Token = "0x60032E4")]
	public bool TryPop(out T result) { }

	[Address(RVA = "0x6E22C98", Offset = "0x6E22C98", Length = "0x70")]
	[Token(Token = "0x60032E5")]
	private bool TryPopCore(out T result) { }

	[Address(RVA = "0x6E22D08", Offset = "0x6E22D08", Length = "0x2BC")]
	[Token(Token = "0x60032E6")]
	private int TryPopCore(int count, out Node<T> poppedHead) { }

}

