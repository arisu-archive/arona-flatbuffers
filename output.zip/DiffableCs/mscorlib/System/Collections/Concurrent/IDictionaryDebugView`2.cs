namespace System.Collections.Concurrent;

[Token(Token = "0x200066B")]
internal sealed class IDictionaryDebugView
{

}

