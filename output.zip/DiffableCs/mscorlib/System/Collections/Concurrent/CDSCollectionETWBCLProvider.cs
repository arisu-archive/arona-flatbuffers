namespace System.Collections.Concurrent;

[EventSource(Name = "System.Collections.Concurrent.ConcurrentCollectionsEventSource", Guid = "35167F8E-49B2-4b96-AB86-435B59336B5E")]
[Token(Token = "0x2000665")]
internal sealed class CDSCollectionETWBCLProvider : EventSource
{
	[Token(Token = "0x4001BB5")]
	public static CDSCollectionETWBCLProvider Log; //Field offset: 0x0

	[Address(RVA = "0x73CB28C", Offset = "0x73CB28C", Length = "0x70")]
	[Token(Token = "0x600328A")]
	private static CDSCollectionETWBCLProvider() { }

	[Address(RVA = "0x73CB1A0", Offset = "0x73CB1A0", Length = "0x8")]
	[Token(Token = "0x6003286")]
	private CDSCollectionETWBCLProvider() { }

	[Address(RVA = "0x73CB240", Offset = "0x73CB240", Length = "0x4C")]
	[Event(3, Level = EventLevel::Warning (3))]
	[Token(Token = "0x6003289")]
	public void ConcurrentDictionary_AcquiringAllLocks(int numOfBuckets) { }

	[Address(RVA = "0x73CB1F4", Offset = "0x73CB1F4", Length = "0x4C")]
	[Event(2, Level = EventLevel::Warning (3))]
	[Token(Token = "0x6003288")]
	public void ConcurrentStack_FastPopFailed(int spinCount) { }

	[Address(RVA = "0x73CB1A8", Offset = "0x73CB1A8", Length = "0x4C")]
	[Event(1, Level = EventLevel::Warning (3))]
	[Token(Token = "0x6003287")]
	public void ConcurrentStack_FastPushFailed(int spinCount) { }

}

