namespace System.Collections.Concurrent;

[DebuggerDisplay("Head = {Head}, Tail = {Tail}")]
[Token(Token = "0x2000664")]
internal struct PaddedHeadAndTail
{
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x4001BB3")]
	public int Head; //Field offset: 0x80
	[FieldOffset(Offset = "0x100")]
	[Token(Token = "0x4001BB4")]
	public int Tail; //Field offset: 0x100

}

