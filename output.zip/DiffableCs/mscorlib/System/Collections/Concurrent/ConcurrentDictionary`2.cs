namespace System.Collections.Concurrent;

[DebuggerDisplay("Count = {Count}")]
[DebuggerTypeProxy(typeof(IDictionaryDebugView`2))]
[DefaultMember("Item")]
[Token(Token = "0x2000666")]
public class ConcurrentDictionary : IDictionary<TKey, TValue>, ICollection<KeyValuePair`2<TKey, TValue>>, IEnumerable<KeyValuePair`2<TKey, TValue>>, IEnumerable, IDictionary, ICollection, IReadOnlyDictionary<TKey, TValue>, IReadOnlyCollection<KeyValuePair`2<TKey, TValue>>
{
	[CompilerGenerated]
	[Token(Token = "0x200066A")]
	private sealed class <GetEnumerator>d__35 : IEnumerator<KeyValuePair`2<TKey, TValue>>, IDisposable, IEnumerator
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BC6")]
		private int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BC7")]
		private KeyValuePair<TKey, TValue> <>2__current; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BC8")]
		public ConcurrentDictionary<TKey, TValue> <>4__this; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BC9")]
		private Node<TKey, TValue>[] <buckets>5__2; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BCA")]
		private int <i>5__3; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BCB")]
		private Node<TKey, TValue> <current>5__4; //Field offset: 0x0

		[Token(Token = "0x17000819")]
		private override KeyValuePair<TKey, TValue> System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Current
		{
			[Address(RVA = "0x7091784", Offset = "0x7091784", Length = "0x14")]
			[DebuggerHidden]
			[Token(Token = "0x60032D8")]
			private get { } //Length: 20
		}

		[Token(Token = "0x1700081A")]
		private override object System.Collections.IEnumerator.Current
		{
			[Address(RVA = "0x70917D8", Offset = "0x70917D8", Length = "0x44")]
			[DebuggerHidden]
			[Token(Token = "0x60032DA")]
			private get { } //Length: 68
		}

		[Address(RVA = "0x7091604", Offset = "0x7091604", Length = "0x28")]
		[DebuggerHidden]
		[Token(Token = "0x60032D5")]
		public <GetEnumerator>d__35(int <>1__state) { }

		[Address(RVA = "0x7091630", Offset = "0x7091630", Length = "0x154")]
		[Token(Token = "0x60032D7")]
		private override bool MoveNext() { }

		[Address(RVA = "0x7091784", Offset = "0x7091784", Length = "0x14")]
		[DebuggerHidden]
		[Token(Token = "0x60032D8")]
		private override KeyValuePair<TKey, TValue> System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<TKey,TValue>>.get_Current() { }

		[Address(RVA = "0x70917D8", Offset = "0x70917D8", Length = "0x44")]
		[DebuggerHidden]
		[Token(Token = "0x60032DA")]
		private override object System.Collections.IEnumerator.get_Current() { }

		[Address(RVA = "0x7091798", Offset = "0x7091798", Length = "0x40")]
		[DebuggerHidden]
		[Token(Token = "0x60032D9")]
		private override void System.Collections.IEnumerator.Reset() { }

		[Address(RVA = "0x709162C", Offset = "0x709162C", Length = "0x4")]
		[DebuggerHidden]
		[Token(Token = "0x60032D6")]
		private override void System.IDisposable.Dispose() { }

	}

	[Token(Token = "0x2000669")]
	private sealed class DictionaryEnumerator : IDictionaryEnumerator, IEnumerator
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BC5")]
		private IEnumerator<KeyValuePair`2<TKey, TValue>> _enumerator; //Field offset: 0x0

		[Token(Token = "0x17000818")]
		public override object Current
		{
			[Address(RVA = "0x6E416D8", Offset = "0x6E416D8", Length = "0x80")]
			[Token(Token = "0x60032D2")]
			 get { } //Length: 128
		}

		[Token(Token = "0x17000815")]
		public override DictionaryEntry Entry
		{
			[Address(RVA = "0x6E41400", Offset = "0x6E41400", Length = "0x170")]
			[Token(Token = "0x60032CF")]
			 get { } //Length: 368
		}

		[Token(Token = "0x17000816")]
		public override object Key
		{
			[Address(RVA = "0x6E41570", Offset = "0x6E41570", Length = "0xCC")]
			[Token(Token = "0x60032D0")]
			 get { } //Length: 204
		}

		[Token(Token = "0x17000817")]
		public override object Value
		{
			[Address(RVA = "0x6E4163C", Offset = "0x6E4163C", Length = "0x9C")]
			[Token(Token = "0x60032D1")]
			 get { } //Length: 156
		}

		[Address(RVA = "0x6E413AC", Offset = "0x6E413AC", Length = "0x54")]
		[Token(Token = "0x60032CE")]
		internal DictionaryEnumerator(ConcurrentDictionary<TKey, TValue> dictionary) { }

		[Address(RVA = "0x6E416D8", Offset = "0x6E416D8", Length = "0x80")]
		[Token(Token = "0x60032D2")]
		public override object get_Current() { }

		[Address(RVA = "0x6E41400", Offset = "0x6E41400", Length = "0x170")]
		[Token(Token = "0x60032CF")]
		public override DictionaryEntry get_Entry() { }

		[Address(RVA = "0x6E41570", Offset = "0x6E41570", Length = "0xCC")]
		[Token(Token = "0x60032D0")]
		public override object get_Key() { }

		[Address(RVA = "0x6E4163C", Offset = "0x6E4163C", Length = "0x9C")]
		[Token(Token = "0x60032D1")]
		public override object get_Value() { }

		[Address(RVA = "0x6E41758", Offset = "0x6E41758", Length = "0xA0")]
		[Token(Token = "0x60032D3")]
		public override bool MoveNext() { }

		[Address(RVA = "0x6E417F8", Offset = "0x6E417F8", Length = "0xA4")]
		[Token(Token = "0x60032D4")]
		public override void Reset() { }

	}

	[Token(Token = "0x2000668")]
	private sealed class Node
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BC1")]
		internal readonly TKey _key; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BC2")]
		internal TValue _value; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BC3")]
		internal Node<TKey, TValue> _next; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BC4")]
		internal readonly int _hashcode; //Field offset: 0x0

		[Address(RVA = "0x596C7CC", Offset = "0x596C7CC", Length = "0x80")]
		[Token(Token = "0x60032CD")]
		internal Node(TKey key, TValue value, int hashcode, Node<TKey, TValue> next) { }

	}

	[Token(Token = "0x2000667")]
	private sealed class Tables
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BBE")]
		internal readonly Node<TKey, TValue>[] _buckets; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BBF")]
		internal readonly Object[] _locks; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BC0")]
		internal Int32[] _countPerLock; //Field offset: 0x0

		[Address(RVA = "0x5F3563C", Offset = "0x5F3563C", Length = "0x64")]
		[Token(Token = "0x60032CC")]
		internal Tables(Node<TKey, TValue>[] buckets, Object[] locks, Int32[] countPerLock) { }

	}

	[Token(Token = "0x4001BBD")]
	private static readonly bool s_isValueWriteAtomic; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BB6")]
	private Tables<TKey, TValue> _tables; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BB7")]
	private IEqualityComparer<TKey> _comparer; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BB8")]
	private readonly bool _growLockArray; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BB9")]
	private int _budget; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BBA")]
	private KeyValuePair<TKey, TValue>[] _serializationArray; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BBB")]
	private int _serializationConcurrencyLevel; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BBC")]
	private int _serializationCapacity; //Field offset: 0x0

	[Token(Token = "0x17000807")]
	public override int Count
	{
		[Address(RVA = "0x6E074A8", Offset = "0x6E074A8", Length = "0xEC")]
		[Token(Token = "0x60032A3")]
		 get { } //Length: 236
	}

	[Token(Token = "0x17000814")]
	private static int DefaultConcurrencyLevel
	{
		[Address(RVA = "0x6E09060", Offset = "0x6E09060", Length = "0x50")]
		[Token(Token = "0x60032C2")]
		private get { } //Length: 80
	}

	[Token(Token = "0x17000806")]
	public override TValue Item
	{
		[Address(RVA = "0x6E07218", Offset = "0x6E07218", Length = "0xBC")]
		[Token(Token = "0x600329F")]
		 get { } //Length: 188
		[Address(RVA = "0x6E072D4", Offset = "0x6E072D4", Length = "0x104")]
		[Token(Token = "0x60032A0")]
		 set { } //Length: 260
	}

	[Token(Token = "0x17000808")]
	public override ICollection<TKey> Keys
	{
		[Address(RVA = "0x6E0799C", Offset = "0x6E0799C", Length = "0x14")]
		[Token(Token = "0x60032A9")]
		 get { } //Length: 20
	}

	[Token(Token = "0x1700080C")]
	private override bool System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.IsReadOnly
	{
		[Address(RVA = "0x6E07B20", Offset = "0x6E07B20", Length = "0x8")]
		[Token(Token = "0x60032AF")]
		private get { } //Length: 8
	}

	[Token(Token = "0x17000809")]
	private override IEnumerable<TKey> System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.Keys
	{
		[Address(RVA = "0x6E079B0", Offset = "0x6E079B0", Length = "0x14")]
		[Token(Token = "0x60032AA")]
		private get { } //Length: 20
	}

	[Token(Token = "0x1700080B")]
	private override IEnumerable<TValue> System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.Values
	{
		[Address(RVA = "0x6E079D8", Offset = "0x6E079D8", Length = "0x14")]
		[Token(Token = "0x60032AC")]
		private get { } //Length: 20
	}

	[Token(Token = "0x17000812")]
	private override bool System.Collections.ICollection.IsSynchronized
	{
		[Address(RVA = "0x6E087C0", Offset = "0x6E087C0", Length = "0x8")]
		[Token(Token = "0x60032BD")]
		private get { } //Length: 8
	}

	[Token(Token = "0x17000813")]
	private override object System.Collections.ICollection.SyncRoot
	{
		[Address(RVA = "0x6E087C8", Offset = "0x6E087C8", Length = "0x50")]
		[Token(Token = "0x60032BE")]
		private get { } //Length: 80
	}

	[Token(Token = "0x1700080D")]
	private override bool System.Collections.IDictionary.IsFixedSize
	{
		[Address(RVA = "0x6E07F88", Offset = "0x6E07F88", Length = "0x8")]
		[Token(Token = "0x60032B5")]
		private get { } //Length: 8
	}

	[Token(Token = "0x1700080E")]
	private override bool System.Collections.IDictionary.IsReadOnly
	{
		[Address(RVA = "0x6E07F90", Offset = "0x6E07F90", Length = "0x8")]
		[Token(Token = "0x60032B6")]
		private get { } //Length: 8
	}

	[Token(Token = "0x17000811")]
	private override object System.Collections.IDictionary.Item
	{
		[Address(RVA = "0x6E080C0", Offset = "0x6E080C0", Length = "0x10C")]
		[Token(Token = "0x60032BA")]
		private get { } //Length: 268
		[Address(RVA = "0x6E081CC", Offset = "0x6E081CC", Length = "0x1F4")]
		[Token(Token = "0x60032BB")]
		private set { } //Length: 500
	}

	[Token(Token = "0x1700080F")]
	private override ICollection System.Collections.IDictionary.Keys
	{
		[Address(RVA = "0x6E07F98", Offset = "0x6E07F98", Length = "0x14")]
		[Token(Token = "0x60032B7")]
		private get { } //Length: 20
	}

	[Token(Token = "0x17000810")]
	private override ICollection System.Collections.IDictionary.Values
	{
		[Address(RVA = "0x6E080AC", Offset = "0x6E080AC", Length = "0x14")]
		[Token(Token = "0x60032B9")]
		private get { } //Length: 20
	}

	[Token(Token = "0x1700080A")]
	public override ICollection<TValue> Values
	{
		[Address(RVA = "0x6E079C4", Offset = "0x6E079C4", Length = "0x14")]
		[Token(Token = "0x60032AB")]
		 get { } //Length: 20
	}

	[Address(RVA = "0x6E09AF8", Offset = "0x6E09AF8", Length = "0x98")]
	[Token(Token = "0x60032CB")]
	private static ConcurrentDictionary`2() { }

	[Address(RVA = "0x6E04F9C", Offset = "0x6E04F9C", Length = "0x84")]
	[Token(Token = "0x600328C")]
	public ConcurrentDictionary`2() { }

	[Address(RVA = "0x6E05020", Offset = "0x6E05020", Length = "0x1C")]
	[Token(Token = "0x600328D")]
	public ConcurrentDictionary`2(int concurrencyLevel, int capacity) { }

	[Address(RVA = "0x6E0503C", Offset = "0x6E0503C", Length = "0x88")]
	[Token(Token = "0x600328E")]
	public ConcurrentDictionary`2(IEqualityComparer<TKey> comparer) { }

	[Address(RVA = "0x6E054F8", Offset = "0x6E054F8", Length = "0x2D8")]
	[Token(Token = "0x6003290")]
	internal ConcurrentDictionary`2(int concurrencyLevel, int capacity, bool growLockArray, IEqualityComparer<TKey> comparer) { }

	[Address(RVA = "0x6E090B0", Offset = "0x6E090B0", Length = "0x11C")]
	[Token(Token = "0x60032C3")]
	private void AcquireAllLocks(ref int locksAcquired) { }

	[Address(RVA = "0x6E091CC", Offset = "0x6E091CC", Length = "0x11C")]
	[Token(Token = "0x60032C4")]
	private void AcquireLocks(int fromInclusive, int toExclusive, ref int locksAcquired) { }

	[Address(RVA = "0x6E06040", Offset = "0x6E06040", Length = "0x260")]
	[Token(Token = "0x6003297")]
	public override void Clear() { }

	[Address(RVA = "0x6E058D8", Offset = "0x6E058D8", Length = "0x28")]
	[Token(Token = "0x6003292")]
	public override bool ContainsKey(TKey key) { }

	[Address(RVA = "0x6E06854", Offset = "0x6E06854", Length = "0x108")]
	[Token(Token = "0x600329B")]
	private void CopyToEntries(DictionaryEntry[] array, int index) { }

	[Address(RVA = "0x6E0695C", Offset = "0x6E0695C", Length = "0x148")]
	[Token(Token = "0x600329C")]
	private void CopyToObjects(Object[] array, int index) { }

	[Address(RVA = "0x6E06750", Offset = "0x6E06750", Length = "0x104")]
	[Token(Token = "0x600329A")]
	private void CopyToPairs(KeyValuePair<TKey, TValue>[] array, int index) { }

	[Address(RVA = "0x6E074A8", Offset = "0x6E074A8", Length = "0xEC")]
	[Token(Token = "0x60032A3")]
	public override int get_Count() { }

	[Address(RVA = "0x6E09060", Offset = "0x6E09060", Length = "0x50")]
	[Token(Token = "0x60032C2")]
	private static int get_DefaultConcurrencyLevel() { }

	[Address(RVA = "0x6E07218", Offset = "0x6E07218", Length = "0xBC")]
	[Token(Token = "0x600329F")]
	public override TValue get_Item(TKey key) { }

	[Address(RVA = "0x6E0799C", Offset = "0x6E0799C", Length = "0x14")]
	[Token(Token = "0x60032A9")]
	public override ICollection<TKey> get_Keys() { }

	[Address(RVA = "0x6E079C4", Offset = "0x6E079C4", Length = "0x14")]
	[Token(Token = "0x60032AB")]
	public override ICollection<TValue> get_Values() { }

	[Address(RVA = "0x6E09030", Offset = "0x6E09030", Length = "0x10")]
	[Token(Token = "0x60032C0")]
	private static int GetBucket(int hashcode, int bucketCount) { }

	[Address(RVA = "0x6E09040", Offset = "0x6E09040", Length = "0x20")]
	[Token(Token = "0x60032C1")]
	private static void GetBucketAndLockNo(int hashcode, out int bucketNo, out int lockNo, int bucketCount, int lockCount) { }

	[Address(RVA = "0x6E07594", Offset = "0x6E07594", Length = "0x98")]
	[Token(Token = "0x60032A4")]
	private int GetCountInternal() { }

	[Address(RVA = "0x6E06AA4", Offset = "0x6E06AA4", Length = "0x7C")]
	[IteratorStateMachine(typeof(<GetEnumerator>d__35))]
	[Token(Token = "0x600329D")]
	public override IEnumerator<KeyValuePair`2<TKey, TValue>> GetEnumerator() { }

	[Address(RVA = "0x6E09364", Offset = "0x6E09364", Length = "0x290")]
	[Token(Token = "0x60032C6")]
	private ReadOnlyCollection<TKey> GetKeys() { }

	[Address(RVA = "0x6E077D0", Offset = "0x6E077D0", Length = "0x134")]
	[Token(Token = "0x60032A6")]
	public TValue GetOrAdd(TKey key, TValue value) { }

	[Address(RVA = "0x6E0762C", Offset = "0x6E0762C", Length = "0x1A4")]
	[Token(Token = "0x60032A5")]
	public TValue GetOrAdd(TKey key, Func<TKey, TValue> valueFactory) { }

	[Address(RVA = "0x6E095F4", Offset = "0x6E095F4", Length = "0x290")]
	[Token(Token = "0x60032C7")]
	private ReadOnlyCollection<TValue> GetValues() { }

	[Address(RVA = "0x6E08818", Offset = "0x6E08818", Length = "0x818")]
	[Token(Token = "0x60032BF")]
	private void GrowTable(Tables<TKey, TValue> tables) { }

	[Address(RVA = "0x6E050C4", Offset = "0x6E050C4", Length = "0x434")]
	[Token(Token = "0x600328F")]
	private void InitializeFromCollection(IEnumerable<KeyValuePair`2<TKey, TValue>> collection) { }

	[Address(RVA = "0x6E04EA8", Offset = "0x6E04EA8", Length = "0xF4")]
	[Token(Token = "0x600328B")]
	private static bool IsValueWriteAtomic() { }

	[Address(RVA = "0x6E09904", Offset = "0x6E09904", Length = "0x1F4")]
	[OnDeserialized]
	[Token(Token = "0x60032CA")]
	private void OnDeserialized(StreamingContext context) { }

	[Address(RVA = "0x6E098F8", Offset = "0x6E098F8", Length = "0xC")]
	[OnSerialized]
	[Token(Token = "0x60032C9")]
	private void OnSerialized(StreamingContext context) { }

	[Address(RVA = "0x6E09884", Offset = "0x6E09884", Length = "0x74")]
	[OnSerializing]
	[Token(Token = "0x60032C8")]
	private void OnSerializing(StreamingContext context) { }

	[Address(RVA = "0x6E092E8", Offset = "0x6E092E8", Length = "0x7C")]
	[Token(Token = "0x60032C5")]
	private void ReleaseLocks(int fromInclusive, int toExclusive) { }

	[Address(RVA = "0x6E072D4", Offset = "0x6E072D4", Length = "0x104")]
	[Token(Token = "0x60032A0")]
	public override void set_Item(TKey key, TValue value) { }

	[Address(RVA = "0x6E079EC", Offset = "0x6E079EC", Length = "0xB4")]
	[Token(Token = "0x60032AD")]
	private override void System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Add(KeyValuePair<TKey, TValue> keyValuePair) { }

	[Address(RVA = "0x6E07AA0", Offset = "0x6E07AA0", Length = "0x80")]
	[Token(Token = "0x60032AE")]
	private override bool System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Contains(KeyValuePair<TKey, TValue> keyValuePair) { }

	[Address(RVA = "0x6E062A0", Offset = "0x6E062A0", Length = "0x298")]
	[Token(Token = "0x6003298")]
	private override void System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.CopyTo(KeyValuePair<TKey, TValue>[] array, int index) { }

	[Address(RVA = "0x6E07B20", Offset = "0x6E07B20", Length = "0x8")]
	[Token(Token = "0x60032AF")]
	private override bool System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.get_IsReadOnly() { }

	[Address(RVA = "0x6E07B28", Offset = "0x6E07B28", Length = "0x38")]
	[Token(Token = "0x60032B0")]
	private override bool System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Remove(KeyValuePair<TKey, TValue> keyValuePair) { }

	[Address(RVA = "0x6E07904", Offset = "0x6E07904", Length = "0x70")]
	[Token(Token = "0x60032A7")]
	private override void System.Collections.Generic.IDictionary<TKey,TValue>.Add(TKey key, TValue value) { }

	[Address(RVA = "0x6E07974", Offset = "0x6E07974", Length = "0x28")]
	[Token(Token = "0x60032A8")]
	private override bool System.Collections.Generic.IDictionary<TKey,TValue>.Remove(TKey key) { }

	[Address(RVA = "0x6E079B0", Offset = "0x6E079B0", Length = "0x14")]
	[Token(Token = "0x60032AA")]
	private override IEnumerable<TKey> System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.get_Keys() { }

	[Address(RVA = "0x6E079D8", Offset = "0x6E079D8", Length = "0x14")]
	[Token(Token = "0x60032AC")]
	private override IEnumerable<TValue> System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.get_Values() { }

	[Address(RVA = "0x6E083C0", Offset = "0x6E083C0", Length = "0x400")]
	[Token(Token = "0x60032BC")]
	private override void System.Collections.ICollection.CopyTo(Array array, int index) { }

	[Address(RVA = "0x6E087C0", Offset = "0x6E087C0", Length = "0x8")]
	[Token(Token = "0x60032BD")]
	private override bool System.Collections.ICollection.get_IsSynchronized() { }

	[Address(RVA = "0x6E087C8", Offset = "0x6E087C8", Length = "0x50")]
	[Token(Token = "0x60032BE")]
	private override object System.Collections.ICollection.get_SyncRoot() { }

	[Address(RVA = "0x6E07B74", Offset = "0x6E07B74", Length = "0x29C")]
	[Token(Token = "0x60032B2")]
	private override void System.Collections.IDictionary.Add(object key, object value) { }

	[Address(RVA = "0x6E07E10", Offset = "0x6E07E10", Length = "0x10C")]
	[Token(Token = "0x60032B3")]
	private override bool System.Collections.IDictionary.Contains(object key) { }

	[Address(RVA = "0x6E07F88", Offset = "0x6E07F88", Length = "0x8")]
	[Token(Token = "0x60032B5")]
	private override bool System.Collections.IDictionary.get_IsFixedSize() { }

	[Address(RVA = "0x6E07F90", Offset = "0x6E07F90", Length = "0x8")]
	[Token(Token = "0x60032B6")]
	private override bool System.Collections.IDictionary.get_IsReadOnly() { }

	[Address(RVA = "0x6E080C0", Offset = "0x6E080C0", Length = "0x10C")]
	[Token(Token = "0x60032BA")]
	private override object System.Collections.IDictionary.get_Item(object key) { }

	[Address(RVA = "0x6E07F98", Offset = "0x6E07F98", Length = "0x14")]
	[Token(Token = "0x60032B7")]
	private override ICollection System.Collections.IDictionary.get_Keys() { }

	[Address(RVA = "0x6E080AC", Offset = "0x6E080AC", Length = "0x14")]
	[Token(Token = "0x60032B9")]
	private override ICollection System.Collections.IDictionary.get_Values() { }

	[Address(RVA = "0x6E07F1C", Offset = "0x6E07F1C", Length = "0x6C")]
	[Token(Token = "0x60032B4")]
	private override IDictionaryEnumerator System.Collections.IDictionary.GetEnumerator() { }

	[Address(RVA = "0x6E07FAC", Offset = "0x6E07FAC", Length = "0x100")]
	[Token(Token = "0x60032B8")]
	private override void System.Collections.IDictionary.Remove(object key) { }

	[Address(RVA = "0x6E081CC", Offset = "0x6E081CC", Length = "0x1F4")]
	[Token(Token = "0x60032BB")]
	private override void System.Collections.IDictionary.set_Item(object key, object value) { }

	[Address(RVA = "0x6E07B60", Offset = "0x6E07B60", Length = "0x14")]
	[Token(Token = "0x60032B1")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	[Address(RVA = "0x6E073D8", Offset = "0x6E073D8", Length = "0x80")]
	[Token(Token = "0x60032A1")]
	private static void ThrowKeyNotFoundException(object key) { }

	[Address(RVA = "0x6E07458", Offset = "0x6E07458", Length = "0x50")]
	[Token(Token = "0x60032A2")]
	private static void ThrowKeyNullException() { }

	[Address(RVA = "0x6E06538", Offset = "0x6E06538", Length = "0x218")]
	[Token(Token = "0x6003299")]
	public KeyValuePair<TKey, TValue>[] ToArray() { }

	[Address(RVA = "0x6E057D0", Offset = "0x6E057D0", Length = "0x108")]
	[Token(Token = "0x6003291")]
	public bool TryAdd(TKey key, TValue value) { }

	[Address(RVA = "0x6E06B20", Offset = "0x6E06B20", Length = "0x6F8")]
	[Token(Token = "0x600329E")]
	private bool TryAddInternal(TKey key, int hashcode, TValue value, bool updateIfExists, bool acquireLock, out TValue resultingValue) { }

	[Address(RVA = "0x6E05DC4", Offset = "0x6E05DC4", Length = "0xE8")]
	[Token(Token = "0x6003295")]
	public override bool TryGetValue(TKey key, out TValue value) { }

	[Address(RVA = "0x6E05EAC", Offset = "0x6E05EAC", Length = "0x194")]
	[Token(Token = "0x6003296")]
	private bool TryGetValueInternal(TKey key, int hashcode, out TValue value) { }

	[Address(RVA = "0x6E05900", Offset = "0x6E05900", Length = "0x1C")]
	[Token(Token = "0x6003293")]
	public bool TryRemove(TKey key, out TValue value) { }

	[Address(RVA = "0x6E0591C", Offset = "0x6E0591C", Length = "0x4A8")]
	[Token(Token = "0x6003294")]
	private bool TryRemoveInternal(TKey key, out TValue value, bool matchValue, TValue oldValue) { }

}

