namespace System.Collections.Concurrent;

[DebuggerDisplay("Count = {Count}")]
[DebuggerTypeProxy(typeof(IProducerConsumerCollectionDebugView`1))]
[Token(Token = "0x2000660")]
public class ConcurrentQueue : IProducerConsumerCollection<T>, IEnumerable<T>, IEnumerable, ICollection, IReadOnlyCollection<T>
{
	[CompilerGenerated]
	[Token(Token = "0x2000663")]
	private sealed class <Enumerate>d__28 : IEnumerator<T>, IDisposable, IEnumerator
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BA8")]
		private int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BA9")]
		private T <>2__current; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BAA")]
		public Segment<T> head; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BAB")]
		public Segment<T> tail; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BAC")]
		public int tailTail; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BAD")]
		public int headHead; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BAE")]
		public ConcurrentQueue<T> <>4__this; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BAF")]
		private int <headTail>5__2; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BB0")]
		private int <i>5__3; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BB1")]
		private Segment<T> <s>5__4; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BB2")]
		private int <i>5__5; //Field offset: 0x0

		[Token(Token = "0x17000804")]
		private override T System.Collections.Generic.IEnumerator<T>.Current
		{
			[Address(RVA = "0x6E905C4", Offset = "0x6E905C4", Length = "0xC")]
			[DebuggerHidden]
			[Token(Token = "0x6003283")]
			private get { } //Length: 12
		}

		[Token(Token = "0x17000805")]
		private override object System.Collections.IEnumerator.Current
		{
			[Address(RVA = "0x6E90610", Offset = "0x6E90610", Length = "0x3C")]
			[DebuggerHidden]
			[Token(Token = "0x6003285")]
			private get { } //Length: 60
		}

		[Address(RVA = "0x6E90240", Offset = "0x6E90240", Length = "0x28")]
		[DebuggerHidden]
		[Token(Token = "0x6003280")]
		public <Enumerate>d__28(int <>1__state) { }

		[Address(RVA = "0x6E9026C", Offset = "0x6E9026C", Length = "0x358")]
		[Token(Token = "0x6003282")]
		private override bool MoveNext() { }

		[Address(RVA = "0x6E905C4", Offset = "0x6E905C4", Length = "0xC")]
		[DebuggerHidden]
		[Token(Token = "0x6003283")]
		private override T System.Collections.Generic.IEnumerator<T>.get_Current() { }

		[Address(RVA = "0x6E90610", Offset = "0x6E90610", Length = "0x3C")]
		[DebuggerHidden]
		[Token(Token = "0x6003285")]
		private override object System.Collections.IEnumerator.get_Current() { }

		[Address(RVA = "0x6E905D0", Offset = "0x6E905D0", Length = "0x40")]
		[DebuggerHidden]
		[Token(Token = "0x6003284")]
		private override void System.Collections.IEnumerator.Reset() { }

		[Address(RVA = "0x6E90268", Offset = "0x6E90268", Length = "0x4")]
		[DebuggerHidden]
		[Token(Token = "0x6003281")]
		private override void System.IDisposable.Dispose() { }

	}

	[DebuggerDisplay("Capacity = {Capacity}")]
	[Token(Token = "0x2000661")]
	public sealed class Segment
	{
		[DebuggerDisplay("Item = {Item}, SequenceNumber = {SequenceNumber}")]
		[Token(Token = "0x2000662")]
		public struct Slot
		{
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x4001BA6")]
			public T Item; //Field offset: 0x0
			[FieldOffset(Offset = "0x0")]
			[Token(Token = "0x4001BA7")]
			public int SequenceNumber; //Field offset: 0x0

		}

		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BA0")]
		internal readonly Slot<T>[] _slots; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BA1")]
		internal readonly int _slotsMask; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BA2")]
		internal PaddedHeadAndTail _headAndTail; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BA3")]
		internal bool _preservedForObservation; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BA4")]
		internal bool _frozenForEnqueues; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BA5")]
		internal Segment<T> _nextSegment; //Field offset: 0x0

		[Token(Token = "0x17000802")]
		internal int Capacity
		{
			[Address(RVA = "0x5E6284C", Offset = "0x5E6284C", Length = "0x1C")]
			[Token(Token = "0x600327B")]
			internal get { } //Length: 28
		}

		[Token(Token = "0x17000803")]
		internal int FreezeOffset
		{
			[Address(RVA = "0x5E62868", Offset = "0x5E62868", Length = "0x20")]
			[Token(Token = "0x600327C")]
			internal get { } //Length: 32
		}

		[Address(RVA = "0x5E627A0", Offset = "0x5E627A0", Length = "0xAC")]
		[Token(Token = "0x600327A")]
		public Segment(int boundedLength) { }

		[Address(RVA = "0x5E62888", Offset = "0x5E62888", Length = "0xC8")]
		[Token(Token = "0x600327D")]
		internal void EnsureFrozenForEnqueues() { }

		[Address(RVA = "0x5E6284C", Offset = "0x5E6284C", Length = "0x1C")]
		[Token(Token = "0x600327B")]
		internal int get_Capacity() { }

		[Address(RVA = "0x5E62868", Offset = "0x5E62868", Length = "0x20")]
		[Token(Token = "0x600327C")]
		internal int get_FreezeOffset() { }

		[Address(RVA = "0x5E62950", Offset = "0x5E62950", Length = "0x1F4")]
		[Token(Token = "0x600327E")]
		public bool TryDequeue(out T item) { }

		[Address(RVA = "0x5E62B44", Offset = "0x5E62B44", Length = "0x174")]
		[Token(Token = "0x600327F")]
		public bool TryEnqueue(T item) { }

	}

	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001B9D")]
	private object _crossSegmentLock; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001B9E")]
	private Segment<T> _tail; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001B9F")]
	private Segment<T> _head; //Field offset: 0x0

	[Token(Token = "0x17000801")]
	public override int Count
	{
		[Address(RVA = "0x6E143E8", Offset = "0x6E143E8", Length = "0x268")]
		[Token(Token = "0x600326D")]
		 get { } //Length: 616
	}

	[Token(Token = "0x170007FF")]
	private override bool System.Collections.ICollection.IsSynchronized
	{
		[Address(RVA = "0x6E13FCC", Offset = "0x6E13FCC", Length = "0x8")]
		[Token(Token = "0x6003268")]
		private get { } //Length: 8
	}

	[Token(Token = "0x17000800")]
	private override object System.Collections.ICollection.SyncRoot
	{
		[Address(RVA = "0x6E13FD4", Offset = "0x6E13FD4", Length = "0x50")]
		[Token(Token = "0x6003269")]
		private get { } //Length: 80
	}

	[Address(RVA = "0x6E13DE8", Offset = "0x6E13DE8", Length = "0xE4")]
	[Token(Token = "0x6003266")]
	public ConcurrentQueue`1() { }

	[Address(RVA = "0x6E1552C", Offset = "0x6E1552C", Length = "0x158")]
	[Token(Token = "0x6003279")]
	public void Clear() { }

	[Address(RVA = "0x6E148B8", Offset = "0x6E148B8", Length = "0x3B8")]
	[Token(Token = "0x6003270")]
	public override void CopyTo(T[] array, int index) { }

	[Address(RVA = "0x6E15054", Offset = "0x6E15054", Length = "0x8C")]
	[Token(Token = "0x6003275")]
	public void Enqueue(T item) { }

	[Address(RVA = "0x6E150E0", Offset = "0x6E150E0", Length = "0x24C")]
	[Token(Token = "0x6003276")]
	private void EnqueueSlow(T item) { }

	[Address(RVA = "0x6E14F90", Offset = "0x6E14F90", Length = "0xC4")]
	[IteratorStateMachine(typeof(<Enumerate>d__28))]
	[Token(Token = "0x6003274")]
	private IEnumerator<T> Enumerate(Segment<T> head, int headHead, Segment<T> tail, int tailTail) { }

	[Address(RVA = "0x6E143E8", Offset = "0x6E143E8", Length = "0x268")]
	[Token(Token = "0x600326D")]
	public override int get_Count() { }

	[Address(RVA = "0x6E14650", Offset = "0x6E14650", Length = "0xBC")]
	[Token(Token = "0x600326E")]
	private static int GetCount(Segment<T> s, int head, int tail) { }

	[Address(RVA = "0x6E1470C", Offset = "0x6E1470C", Length = "0x1AC")]
	[Token(Token = "0x600326F")]
	private static long GetCount(Segment<T> head, int headHead, Segment<T> tail, int tailTail) { }

	[Address(RVA = "0x6E14C70", Offset = "0x6E14C70", Length = "0x70")]
	[Token(Token = "0x6003271")]
	public override IEnumerator<T> GetEnumerator() { }

	[Address(RVA = "0x6E14E74", Offset = "0x6E14E74", Length = "0x11C")]
	[Token(Token = "0x6003273")]
	private T GetItemWhenAvailable(Segment<T> segment, int i) { }

	[Address(RVA = "0x6E14CE0", Offset = "0x6E14CE0", Length = "0x194")]
	[Token(Token = "0x6003272")]
	private void SnapForObservation(out Segment<T> head, out int headHead, out Segment<T> tail, out int tailTail) { }

	[Address(RVA = "0x6E140AC", Offset = "0x6E140AC", Length = "0x24")]
	[Token(Token = "0x600326B")]
	private override bool System.Collections.Concurrent.IProducerConsumerCollection<T>.TryAdd(T item) { }

	[Address(RVA = "0x6E13ECC", Offset = "0x6E13ECC", Length = "0x100")]
	[Token(Token = "0x6003267")]
	private override void System.Collections.ICollection.CopyTo(Array array, int index) { }

	[Address(RVA = "0x6E13FCC", Offset = "0x6E13FCC", Length = "0x8")]
	[Token(Token = "0x6003268")]
	private override bool System.Collections.ICollection.get_IsSynchronized() { }

	[Address(RVA = "0x6E13FD4", Offset = "0x6E13FD4", Length = "0x50")]
	[Token(Token = "0x6003269")]
	private override object System.Collections.ICollection.get_SyncRoot() { }

	[Address(RVA = "0x6E14024", Offset = "0x6E14024", Length = "0x88")]
	[Token(Token = "0x600326A")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	[Address(RVA = "0x6E140D0", Offset = "0x6E140D0", Length = "0x318")]
	[Token(Token = "0x600326C")]
	public override T[] ToArray() { }

	[Address(RVA = "0x6E1532C", Offset = "0x6E1532C", Length = "0x84")]
	[Token(Token = "0x6003277")]
	public bool TryDequeue(out T result) { }

	[Address(RVA = "0x6E153B0", Offset = "0x6E153B0", Length = "0x17C")]
	[Token(Token = "0x6003278")]
	private bool TryDequeueSlow(out T item) { }

}

