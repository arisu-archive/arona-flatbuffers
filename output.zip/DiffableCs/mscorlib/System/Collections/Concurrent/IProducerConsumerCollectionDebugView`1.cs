namespace System.Collections.Concurrent;

[Token(Token = "0x2000670")]
internal sealed class IProducerConsumerCollectionDebugView
{

}

