namespace System.Collections.Concurrent;

[Token(Token = "0x200066F")]
public interface IProducerConsumerCollection : IEnumerable<T>, IEnumerable, ICollection
{

	[Token(Token = "0x60032F5")]
	public T[] ToArray() { }

	[Token(Token = "0x60032F4")]
	public bool TryAdd(T item) { }

}

