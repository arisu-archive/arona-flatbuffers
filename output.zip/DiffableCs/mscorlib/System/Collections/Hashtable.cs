namespace System.Collections;

[DebuggerDisplay("Count = {Count}")]
[DebuggerTypeProxy(typeof(HashtableDebugView))]
[DefaultMember("Item")]
[Token(Token = "0x2000658")]
public class Hashtable : IDictionary, ICollection, IEnumerable, ISerializable, IDeserializationCallback, ICloneable
{
	[Token(Token = "0x2000659")]
	private struct bucket
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001B90")]
		public object key; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x4001B91")]
		public object val; //Field offset: 0x8
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001B92")]
		public int hash_coll; //Field offset: 0x10

	}

	[Token(Token = "0x200065E")]
	public class HashtableDebugView
	{

	}

	[Token(Token = "0x200065D")]
	private class HashtableEnumerator : IDictionaryEnumerator, IEnumerator, ICloneable
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001B96")]
		private Hashtable _hashtable; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4001B97")]
		private int _bucket; //Field offset: 0x18
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4001B98")]
		private int _version; //Field offset: 0x1C
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4001B99")]
		private bool _current; //Field offset: 0x20
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x4001B9A")]
		private int _getObjectRetType; //Field offset: 0x24
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4001B9B")]
		private object _currentKey; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4001B9C")]
		private object _currentValue; //Field offset: 0x30

		[Token(Token = "0x170007FD")]
		public override object Current
		{
			[Address(RVA = "0x73CAF98", Offset = "0x73CAF98", Length = "0xE8")]
			[Token(Token = "0x6003262")]
			 get { } //Length: 232
		}

		[Token(Token = "0x170007FC")]
		public override DictionaryEntry Entry
		{
			[Address(RVA = "0x73CAF18", Offset = "0x73CAF18", Length = "0x80")]
			[Token(Token = "0x6003261")]
			 get { } //Length: 128
		}

		[Token(Token = "0x170007FB")]
		public override object Key
		{
			[Address(RVA = "0x73CAD80", Offset = "0x73CAD80", Length = "0x64")]
			[Token(Token = "0x600325F")]
			 get { } //Length: 100
		}

		[Token(Token = "0x170007FE")]
		public override object Value
		{
			[Address(RVA = "0x73CB080", Offset = "0x73CB080", Length = "0x64")]
			[Token(Token = "0x6003263")]
			 get { } //Length: 100
		}

		[Address(RVA = "0x73C88C8", Offset = "0x73C88C8", Length = "0x64")]
		[Token(Token = "0x600325D")]
		internal HashtableEnumerator(Hashtable hashtable, int getObjRetType) { }

		[Address(RVA = "0x73CAD78", Offset = "0x73CAD78", Length = "0x8")]
		[Token(Token = "0x600325E")]
		public override object Clone() { }

		[Address(RVA = "0x73CAF98", Offset = "0x73CAF98", Length = "0xE8")]
		[Token(Token = "0x6003262")]
		public override object get_Current() { }

		[Address(RVA = "0x73CAF18", Offset = "0x73CAF18", Length = "0x80")]
		[Token(Token = "0x6003261")]
		public override DictionaryEntry get_Entry() { }

		[Address(RVA = "0x73CAD80", Offset = "0x73CAD80", Length = "0x64")]
		[Token(Token = "0x600325F")]
		public override object get_Key() { }

		[Address(RVA = "0x73CB080", Offset = "0x73CB080", Length = "0x64")]
		[Token(Token = "0x6003263")]
		public override object get_Value() { }

		[Address(RVA = "0x73CADE4", Offset = "0x73CADE4", Length = "0x134")]
		[Token(Token = "0x6003260")]
		public override bool MoveNext() { }

		[Address(RVA = "0x73CB0E4", Offset = "0x73CB0E4", Length = "0xBC")]
		[Token(Token = "0x6003264")]
		public override void Reset() { }

	}

	[Token(Token = "0x200065A")]
	private class KeyCollection : ICollection, IEnumerable
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001B93")]
		private Hashtable _hashtable; //Field offset: 0x10

		[Token(Token = "0x170007EF")]
		public override int Count
		{
			[Address(RVA = "0x73CA100", Offset = "0x73CA100", Length = "0x1C")]
			[Token(Token = "0x6003240")]
			 get { } //Length: 28
		}

		[Token(Token = "0x170007ED")]
		public override bool IsSynchronized
		{
			[Address(RVA = "0x73CA0B8", Offset = "0x73CA0B8", Length = "0x24")]
			[Token(Token = "0x600323E")]
			 get { } //Length: 36
		}

		[Token(Token = "0x170007EE")]
		public override object SyncRoot
		{
			[Address(RVA = "0x73CA0DC", Offset = "0x73CA0DC", Length = "0x24")]
			[Token(Token = "0x600323F")]
			 get { } //Length: 36
		}

		[Address(RVA = "0x73C8C04", Offset = "0x73C8C04", Length = "0x30")]
		[Token(Token = "0x600323B")]
		internal KeyCollection(Hashtable hashtable) { }

		[Address(RVA = "0x73C9EC4", Offset = "0x73C9EC4", Length = "0x18C")]
		[Token(Token = "0x600323C")]
		public override void CopyTo(Array array, int arrayIndex) { }

		[Address(RVA = "0x73CA100", Offset = "0x73CA100", Length = "0x1C")]
		[Token(Token = "0x6003240")]
		public override int get_Count() { }

		[Address(RVA = "0x73CA0B8", Offset = "0x73CA0B8", Length = "0x24")]
		[Token(Token = "0x600323E")]
		public override bool get_IsSynchronized() { }

		[Address(RVA = "0x73CA0DC", Offset = "0x73CA0DC", Length = "0x24")]
		[Token(Token = "0x600323F")]
		public override object get_SyncRoot() { }

		[Address(RVA = "0x73CA050", Offset = "0x73CA050", Length = "0x68")]
		[Token(Token = "0x600323D")]
		public override IEnumerator GetEnumerator() { }

	}

	[DefaultMember("Item")]
	[Token(Token = "0x200065C")]
	private class SyncHashtable : Hashtable, IEnumerable
	{
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4001B95")]
		protected Hashtable _table; //Field offset: 0x50

		[Token(Token = "0x170007F3")]
		public virtual int Count
		{
			[Address(RVA = "0x73CA3F8", Offset = "0x73CA3F8", Length = "0x24")]
			[Token(Token = "0x600324A")]
			 get { } //Length: 36
		}

		[Token(Token = "0x170007F5")]
		public virtual bool IsFixedSize
		{
			[Address(RVA = "0x73CA440", Offset = "0x73CA440", Length = "0x24")]
			[Token(Token = "0x600324C")]
			 get { } //Length: 36
		}

		[Token(Token = "0x170007F4")]
		public virtual bool IsReadOnly
		{
			[Address(RVA = "0x73CA41C", Offset = "0x73CA41C", Length = "0x24")]
			[Token(Token = "0x600324B")]
			 get { } //Length: 36
		}

		[Token(Token = "0x170007F6")]
		public virtual bool IsSynchronized
		{
			[Address(RVA = "0x73CA464", Offset = "0x73CA464", Length = "0x8")]
			[Token(Token = "0x600324D")]
			 get { } //Length: 8
		}

		[Token(Token = "0x170007F7")]
		public virtual object Item
		{
			[Address(RVA = "0x73CA46C", Offset = "0x73CA46C", Length = "0x24")]
			[Token(Token = "0x600324E")]
			 get { } //Length: 36
			[Address(RVA = "0x73CA490", Offset = "0x73CA490", Length = "0xF0")]
			[Token(Token = "0x600324F")]
			 set { } //Length: 240
		}

		[Token(Token = "0x170007F9")]
		public virtual ICollection Keys
		{
			[Address(RVA = "0x73CAAAC", Offset = "0x73CAAAC", Length = "0xF0")]
			[Token(Token = "0x6003259")]
			 get { } //Length: 240
		}

		[Token(Token = "0x170007F8")]
		public virtual object SyncRoot
		{
			[Address(RVA = "0x73CA580", Offset = "0x73CA580", Length = "0x24")]
			[Token(Token = "0x6003250")]
			 get { } //Length: 36
		}

		[Token(Token = "0x170007FA")]
		public virtual ICollection Values
		{
			[Address(RVA = "0x73CAB9C", Offset = "0x73CAB9C", Length = "0xF0")]
			[Token(Token = "0x600325A")]
			 get { } //Length: 240
		}

		[Address(RVA = "0x73C9040", Offset = "0x73C9040", Length = "0x30")]
		[Token(Token = "0x6003247")]
		internal SyncHashtable(Hashtable table) { }

		[Address(RVA = "0x73CA374", Offset = "0x73CA374", Length = "0x44")]
		[Token(Token = "0x6003248")]
		internal SyncHashtable(SerializationInfo info, StreamingContext context) { }

		[Address(RVA = "0x73CA5A4", Offset = "0x73CA5A4", Length = "0xF0")]
		[Token(Token = "0x6003251")]
		public virtual void Add(object key, object value) { }

		[Address(RVA = "0x73CA694", Offset = "0x73CA694", Length = "0xD8")]
		[Token(Token = "0x6003252")]
		public virtual void Clear() { }

		[Address(RVA = "0x73CA910", Offset = "0x73CA910", Length = "0x154")]
		[Token(Token = "0x6003256")]
		public virtual object Clone() { }

		[Address(RVA = "0x73CA76C", Offset = "0x73CA76C", Length = "0x24")]
		[Token(Token = "0x6003253")]
		public virtual bool Contains(object key) { }

		[Address(RVA = "0x73CA790", Offset = "0x73CA790", Length = "0x90")]
		[Token(Token = "0x6003254")]
		public virtual bool ContainsKey(object key) { }

		[Address(RVA = "0x73CA820", Offset = "0x73CA820", Length = "0xF0")]
		[Token(Token = "0x6003255")]
		public virtual void CopyTo(Array array, int arrayIndex) { }

		[Address(RVA = "0x73CA3F8", Offset = "0x73CA3F8", Length = "0x24")]
		[Token(Token = "0x600324A")]
		public virtual int get_Count() { }

		[Address(RVA = "0x73CA440", Offset = "0x73CA440", Length = "0x24")]
		[Token(Token = "0x600324C")]
		public virtual bool get_IsFixedSize() { }

		[Address(RVA = "0x73CA41C", Offset = "0x73CA41C", Length = "0x24")]
		[Token(Token = "0x600324B")]
		public virtual bool get_IsReadOnly() { }

		[Address(RVA = "0x73CA464", Offset = "0x73CA464", Length = "0x8")]
		[Token(Token = "0x600324D")]
		public virtual bool get_IsSynchronized() { }

		[Address(RVA = "0x73CA46C", Offset = "0x73CA46C", Length = "0x24")]
		[Token(Token = "0x600324E")]
		public virtual object get_Item(object key) { }

		[Address(RVA = "0x73CAAAC", Offset = "0x73CAAAC", Length = "0xF0")]
		[Token(Token = "0x6003259")]
		public virtual ICollection get_Keys() { }

		[Address(RVA = "0x73CA580", Offset = "0x73CA580", Length = "0x24")]
		[Token(Token = "0x6003250")]
		public virtual object get_SyncRoot() { }

		[Address(RVA = "0x73CAB9C", Offset = "0x73CAB9C", Length = "0xF0")]
		[Token(Token = "0x600325A")]
		public virtual ICollection get_Values() { }

		[Address(RVA = "0x73CAA88", Offset = "0x73CAA88", Length = "0x24")]
		[Token(Token = "0x6003258")]
		public virtual IDictionaryEnumerator GetEnumerator() { }

		[Address(RVA = "0x73CA3B8", Offset = "0x73CA3B8", Length = "0x40")]
		[Token(Token = "0x6003249")]
		public virtual void GetObjectData(SerializationInfo info, StreamingContext context) { }

		[Address(RVA = "0x73CAD74", Offset = "0x73CAD74", Length = "0x4")]
		[Token(Token = "0x600325C")]
		public virtual void OnDeserialization(object sender) { }

		[Address(RVA = "0x73CAC8C", Offset = "0x73CAC8C", Length = "0xE8")]
		[Token(Token = "0x600325B")]
		public virtual void Remove(object key) { }

		[Address(RVA = "0x73CA490", Offset = "0x73CA490", Length = "0xF0")]
		[Token(Token = "0x600324F")]
		public virtual void set_Item(object key, object value) { }

		[Address(RVA = "0x73CAA64", Offset = "0x73CAA64", Length = "0x24")]
		[Token(Token = "0x6003257")]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	}

	[Token(Token = "0x200065B")]
	private class ValueCollection : ICollection, IEnumerable
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001B94")]
		private Hashtable _hashtable; //Field offset: 0x10

		[Token(Token = "0x170007F2")]
		public override int Count
		{
			[Address(RVA = "0x73CA358", Offset = "0x73CA358", Length = "0x1C")]
			[Token(Token = "0x6003246")]
			 get { } //Length: 28
		}

		[Token(Token = "0x170007F0")]
		public override bool IsSynchronized
		{
			[Address(RVA = "0x73CA310", Offset = "0x73CA310", Length = "0x24")]
			[Token(Token = "0x6003244")]
			 get { } //Length: 36
		}

		[Token(Token = "0x170007F1")]
		public override object SyncRoot
		{
			[Address(RVA = "0x73CA334", Offset = "0x73CA334", Length = "0x24")]
			[Token(Token = "0x6003245")]
			 get { } //Length: 36
		}

		[Address(RVA = "0x73C8CC0", Offset = "0x73C8CC0", Length = "0x30")]
		[Token(Token = "0x6003241")]
		internal ValueCollection(Hashtable hashtable) { }

		[Address(RVA = "0x73CA11C", Offset = "0x73CA11C", Length = "0x18C")]
		[Token(Token = "0x6003242")]
		public override void CopyTo(Array array, int arrayIndex) { }

		[Address(RVA = "0x73CA358", Offset = "0x73CA358", Length = "0x1C")]
		[Token(Token = "0x6003246")]
		public override int get_Count() { }

		[Address(RVA = "0x73CA310", Offset = "0x73CA310", Length = "0x24")]
		[Token(Token = "0x6003244")]
		public override bool get_IsSynchronized() { }

		[Address(RVA = "0x73CA334", Offset = "0x73CA334", Length = "0x24")]
		[Token(Token = "0x6003245")]
		public override object get_SyncRoot() { }

		[Address(RVA = "0x73CA2A8", Offset = "0x73CA2A8", Length = "0x68")]
		[Token(Token = "0x6003243")]
		public override IEnumerator GetEnumerator() { }

	}

	[Token(Token = "0x4001B7A")]
	internal const int HashPrime = 101; //Field offset: 0x0
	[Token(Token = "0x4001B83")]
	private const string KeyComparerName = "KeyComparer"; //Field offset: 0x0
	[Token(Token = "0x4001B82")]
	private const string ValuesName = "Values"; //Field offset: 0x0
	[Token(Token = "0x4001B81")]
	private const string KeysName = "Keys"; //Field offset: 0x0
	[Token(Token = "0x4001B80")]
	private const string HashSizeName = "HashSize"; //Field offset: 0x0
	[Token(Token = "0x4001B8F")]
	private static ConditionalWeakTable<Object, SerializationInfo> s_serializationInfoTable; //Field offset: 0x0
	[Token(Token = "0x4001B7E")]
	private const string ComparerName = "Comparer"; //Field offset: 0x0
	[Token(Token = "0x4001B7D")]
	private const string VersionName = "Version"; //Field offset: 0x0
	[Token(Token = "0x4001B7C")]
	private const string LoadFactorName = "LoadFactor"; //Field offset: 0x0
	[Token(Token = "0x4001B7B")]
	private const int InitialSize = 3; //Field offset: 0x0
	[Token(Token = "0x4001B7F")]
	private const string HashCodeProviderName = "HashCodeProvider"; //Field offset: 0x0
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001B84")]
	private bucket[] _buckets; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001B85")]
	private int _count; //Field offset: 0x18
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x4001B86")]
	private int _occupancy; //Field offset: 0x1C
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4001B87")]
	private int _loadsize; //Field offset: 0x20
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x4001B88")]
	private float _loadFactor; //Field offset: 0x24
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4001B89")]
	private int _version; //Field offset: 0x28
	[FieldOffset(Offset = "0x2C")]
	[Token(Token = "0x4001B8A")]
	private bool _isWriterInProgress; //Field offset: 0x2C
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4001B8B")]
	private ICollection _keys; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4001B8C")]
	private ICollection _values; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4001B8D")]
	private IEqualityComparer _keycomparer; //Field offset: 0x40
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4001B8E")]
	private object _syncRoot; //Field offset: 0x48

	[Token(Token = "0x170007EC")]
	public override int Count
	{
		[Address(RVA = "0x73C8F78", Offset = "0x73C8F78", Length = "0x8")]
		[Token(Token = "0x6003237")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170007E7")]
	public override bool IsFixedSize
	{
		[Address(RVA = "0x73C8A60", Offset = "0x73C8A60", Length = "0x8")]
		[Token(Token = "0x600322E")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170007E6")]
	public override bool IsReadOnly
	{
		[Address(RVA = "0x73C8A58", Offset = "0x73C8A58", Length = "0x8")]
		[Token(Token = "0x600322D")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170007E8")]
	public override bool IsSynchronized
	{
		[Address(RVA = "0x73C8A68", Offset = "0x73C8A68", Length = "0x8")]
		[Token(Token = "0x600322F")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170007E5")]
	public override object Item
	{
		[Address(RVA = "0x73C836C", Offset = "0x73C836C", Length = "0x21C")]
		[Token(Token = "0x6003224")]
		 get { } //Length: 540
		[Address(RVA = "0x73C8588", Offset = "0x73C8588", Length = "0x8")]
		[Token(Token = "0x6003225")]
		 set { } //Length: 8
	}

	[Token(Token = "0x170007E9")]
	public override ICollection Keys
	{
		[Address(RVA = "0x73C8B78", Offset = "0x73C8B78", Length = "0x8C")]
		[Token(Token = "0x6003231")]
		 get { } //Length: 140
	}

	[Token(Token = "0x170007E4")]
	private static ConditionalWeakTable<Object, SerializationInfo> SerializationInfoTable
	{
		[Address(RVA = "0x73C6F64", Offset = "0x73C6F64", Length = "0x5C")]
		[Token(Token = "0x600320E")]
		private get { } //Length: 92
	}

	[Token(Token = "0x170007EB")]
	public override object SyncRoot
	{
		[Address(RVA = "0x73C8F00", Offset = "0x73C8F00", Length = "0x78")]
		[Token(Token = "0x6003236")]
		 get { } //Length: 120
	}

	[Token(Token = "0x170007EA")]
	public override ICollection Values
	{
		[Address(RVA = "0x73C8C34", Offset = "0x73C8C34", Length = "0x8C")]
		[Token(Token = "0x6003232")]
		 get { } //Length: 140
	}

	[Address(RVA = "0x73C7668", Offset = "0x73C7668", Length = "0x68")]
	[Token(Token = "0x6003219")]
	protected Hashtable(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x73C6FC0", Offset = "0x73C6FC0", Length = "0x8")]
	[Token(Token = "0x600320F")]
	internal Hashtable(bool trash) { }

	[Address(RVA = "0x73C6FC8", Offset = "0x73C6FC8", Length = "0xC")]
	[Token(Token = "0x6003210")]
	public Hashtable() { }

	[Address(RVA = "0x73C728C", Offset = "0x73C728C", Length = "0x8")]
	[Token(Token = "0x6003211")]
	public Hashtable(int capacity) { }

	[Address(RVA = "0x73C6FD4", Offset = "0x73C6FD4", Length = "0x2B8")]
	[Token(Token = "0x6003212")]
	public Hashtable(int capacity, float loadFactor) { }

	[Address(RVA = "0x73C7294", Offset = "0x73C7294", Length = "0x2C")]
	[Token(Token = "0x6003213")]
	public Hashtable(int capacity, float loadFactor, IEqualityComparer equalityComparer) { }

	[Address(RVA = "0x73C72C0", Offset = "0x73C72C0", Length = "0x34")]
	[Token(Token = "0x6003214")]
	public Hashtable(IEqualityComparer equalityComparer) { }

	[Address(RVA = "0x73C72F4", Offset = "0x73C72F4", Length = "0x30")]
	[Token(Token = "0x6003215")]
	public Hashtable(int capacity, IEqualityComparer equalityComparer) { }

	[Address(RVA = "0x73C7324", Offset = "0x73C7324", Length = "0xC")]
	[Token(Token = "0x6003216")]
	public Hashtable(IDictionary d) { }

	[Address(RVA = "0x73C7330", Offset = "0x73C7330", Length = "0x8")]
	[Token(Token = "0x6003217")]
	public Hashtable(IDictionary d, float loadFactor) { }

	[Address(RVA = "0x73C7338", Offset = "0x73C7338", Length = "0x330")]
	[Token(Token = "0x6003218")]
	public Hashtable(IDictionary d, float loadFactor, IEqualityComparer equalityComparer) { }

	[Address(RVA = "0x73C7724", Offset = "0x73C7724", Length = "0x8")]
	[Token(Token = "0x600321B")]
	public override void Add(object key, object value) { }

	[Address(RVA = "0x73C7BB8", Offset = "0x73C7BB8", Length = "0xC8")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x600321C")]
	public override void Clear() { }

	[Address(RVA = "0x73C7CAC", Offset = "0x73C7CAC", Length = "0x128")]
	[Token(Token = "0x600321D")]
	public override object Clone() { }

	[Address(RVA = "0x73C7DD4", Offset = "0x73C7DD4", Length = "0x10")]
	[Token(Token = "0x600321E")]
	public override bool Contains(object key) { }

	[Address(RVA = "0x73C7DE4", Offset = "0x73C7DE4", Length = "0x180")]
	[Token(Token = "0x600321F")]
	public override bool ContainsKey(object key) { }

	[Address(RVA = "0x73C8004", Offset = "0x73C8004", Length = "0x110")]
	[Token(Token = "0x6003221")]
	private void CopyEntries(Array array, int arrayIndex) { }

	[Address(RVA = "0x73C7F64", Offset = "0x73C7F64", Length = "0xA0")]
	[Token(Token = "0x6003220")]
	private void CopyKeys(Array array, int arrayIndex) { }

	[Address(RVA = "0x73C8114", Offset = "0x73C8114", Length = "0x1B0")]
	[Token(Token = "0x6003222")]
	public override void CopyTo(Array array, int arrayIndex) { }

	[Address(RVA = "0x73C82C4", Offset = "0x73C82C4", Length = "0xA8")]
	[Token(Token = "0x6003223")]
	private void CopyValues(Array array, int arrayIndex) { }

	[Address(RVA = "0x73C8590", Offset = "0x73C8590", Length = "0x70")]
	[Token(Token = "0x6003226")]
	private void expand() { }

	[Address(RVA = "0x73C8F78", Offset = "0x73C8F78", Length = "0x8")]
	[Token(Token = "0x6003237")]
	public override int get_Count() { }

	[Address(RVA = "0x73C8A60", Offset = "0x73C8A60", Length = "0x8")]
	[Token(Token = "0x600322E")]
	public override bool get_IsFixedSize() { }

	[Address(RVA = "0x73C8A58", Offset = "0x73C8A58", Length = "0x8")]
	[Token(Token = "0x600322D")]
	public override bool get_IsReadOnly() { }

	[Address(RVA = "0x73C8A68", Offset = "0x73C8A68", Length = "0x8")]
	[Token(Token = "0x600322F")]
	public override bool get_IsSynchronized() { }

	[Address(RVA = "0x73C836C", Offset = "0x73C836C", Length = "0x21C")]
	[Token(Token = "0x6003224")]
	public override object get_Item(object key) { }

	[Address(RVA = "0x73C8B78", Offset = "0x73C8B78", Length = "0x8C")]
	[Token(Token = "0x6003231")]
	public override ICollection get_Keys() { }

	[Address(RVA = "0x73C6F64", Offset = "0x73C6F64", Length = "0x5C")]
	[Token(Token = "0x600320E")]
	private static ConditionalWeakTable<Object, SerializationInfo> get_SerializationInfoTable() { }

	[Address(RVA = "0x73C8F00", Offset = "0x73C8F00", Length = "0x78")]
	[Token(Token = "0x6003236")]
	public override object get_SyncRoot() { }

	[Address(RVA = "0x73C8C34", Offset = "0x73C8C34", Length = "0x8C")]
	[Token(Token = "0x6003232")]
	public override ICollection get_Values() { }

	[Address(RVA = "0x73C892C", Offset = "0x73C892C", Length = "0x64")]
	[Token(Token = "0x600322B")]
	public override IDictionaryEnumerator GetEnumerator() { }

	[Address(RVA = "0x73C8990", Offset = "0x73C8990", Length = "0xC8")]
	[Token(Token = "0x600322C")]
	protected override int GetHash(object key) { }

	[Address(RVA = "0x73C9070", Offset = "0x73C9070", Length = "0x540")]
	[Token(Token = "0x6003239")]
	public override void GetObjectData(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x73C76D0", Offset = "0x73C76D0", Length = "0x54")]
	[Token(Token = "0x600321A")]
	private uint InitHash(object key, int hashsize, out uint seed, out uint incr) { }

	[Address(RVA = "0x73C772C", Offset = "0x73C772C", Length = "0x48C")]
	[Token(Token = "0x6003233")]
	private void Insert(object key, object nvalue, bool add) { }

	[Address(RVA = "0x73C8A70", Offset = "0x73C8A70", Length = "0x108")]
	[Token(Token = "0x6003230")]
	protected override bool KeyEquals(object item, object key) { }

	[Address(RVA = "0x73C95B0", Offset = "0x73C95B0", Length = "0x898")]
	[Token(Token = "0x600323A")]
	public override void OnDeserialization(object sender) { }

	[Address(RVA = "0x73C8754", Offset = "0x73C8754", Length = "0x110")]
	[Token(Token = "0x6003234")]
	private void putEntry(bucket[] newBuckets, object key, object nvalue, int hashcode) { }

	[Address(RVA = "0x73C8738", Offset = "0x73C8738", Length = "0x1C")]
	[Token(Token = "0x6003227")]
	private void rehash() { }

	[Address(RVA = "0x73C8600", Offset = "0x73C8600", Length = "0x138")]
	[Token(Token = "0x6003229")]
	private void rehash(int newsize) { }

	[Address(RVA = "0x73C8CF0", Offset = "0x73C8CF0", Length = "0x210")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::MayFail (1))]
	[Token(Token = "0x6003235")]
	public override void Remove(object key) { }

	[Address(RVA = "0x73C8588", Offset = "0x73C8588", Length = "0x8")]
	[Token(Token = "0x6003225")]
	public override void set_Item(object key, object value) { }

	[Address(RVA = "0x73C8F80", Offset = "0x73C8F80", Length = "0xC0")]
	[Token(Token = "0x6003238")]
	public static Hashtable Synchronized(Hashtable table) { }

	[Address(RVA = "0x73C8864", Offset = "0x73C8864", Length = "0x64")]
	[Token(Token = "0x600322A")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	[Address(RVA = "0x73C7C80", Offset = "0x73C7C80", Length = "0x2C")]
	[Token(Token = "0x6003228")]
	private void UpdateVersion() { }

}

