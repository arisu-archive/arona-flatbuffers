namespace System.Collections;

[Token(Token = "0x2000637")]
public interface IEqualityComparer
{

	[Token(Token = "0x60030AE")]
	public bool Equals(object x, object y) { }

	[Token(Token = "0x60030AF")]
	public int GetHashCode(object obj) { }

}

