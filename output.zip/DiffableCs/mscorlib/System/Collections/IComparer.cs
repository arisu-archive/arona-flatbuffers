namespace System.Collections;

[Token(Token = "0x2000632")]
public interface IComparer
{

	[Token(Token = "0x600309B")]
	public int Compare(object x, object y) { }

}

