namespace System.Collections;

[Token(Token = "0x200063A")]
public interface IStructuralEquatable
{

	[Token(Token = "0x60030BC")]
	public bool Equals(object other, IEqualityComparer comparer) { }

	[Token(Token = "0x60030BD")]
	public int GetHashCode(IEqualityComparer comparer) { }

}

