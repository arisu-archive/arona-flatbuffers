namespace System.Collections;

[Token(Token = "0x2000643")]
public abstract class CollectionBase : IList, ICollection, IEnumerable
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001B3C")]
	private ArrayList _list; //Field offset: 0x10

	[Token(Token = "0x17000797")]
	public override int Count
	{
		[Address(RVA = "0x73BC154", Offset = "0x73BC154", Length = "0x24")]
		[Token(Token = "0x60030F0")]
		 get { } //Length: 36
	}

	[Token(Token = "0x17000795")]
	protected ArrayList InnerList
	{
		[Address(RVA = "0x73BC148", Offset = "0x73BC148", Length = "0x8")]
		[Token(Token = "0x60030EE")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000796")]
	protected IList List
	{
		[Address(RVA = "0x73BC150", Offset = "0x73BC150", Length = "0x4")]
		[Token(Token = "0x60030EF")]
		 get { } //Length: 4
	}

	[Token(Token = "0x1700079A")]
	private override bool System.Collections.ICollection.IsSynchronized
	{
		[Address(RVA = "0x73BC3E4", Offset = "0x73BC3E4", Length = "0x24")]
		[Token(Token = "0x60030F5")]
		private get { } //Length: 36
	}

	[Token(Token = "0x1700079B")]
	private override object System.Collections.ICollection.SyncRoot
	{
		[Address(RVA = "0x73BC408", Offset = "0x73BC408", Length = "0x24")]
		[Token(Token = "0x60030F6")]
		private get { } //Length: 36
	}

	[Token(Token = "0x17000799")]
	private override bool System.Collections.IList.IsFixedSize
	{
		[Address(RVA = "0x73BC3C0", Offset = "0x73BC3C0", Length = "0x24")]
		[Token(Token = "0x60030F4")]
		private get { } //Length: 36
	}

	[Token(Token = "0x17000798")]
	private override bool System.Collections.IList.IsReadOnly
	{
		[Address(RVA = "0x73BC39C", Offset = "0x73BC39C", Length = "0x24")]
		[Token(Token = "0x60030F3")]
		private get { } //Length: 36
	}

	[Token(Token = "0x1700079C")]
	private override object System.Collections.IList.Item
	{
		[Address(RVA = "0x73BC450", Offset = "0x73BC450", Length = "0xBC")]
		[Token(Token = "0x60030F8")]
		private get { } //Length: 188
		[Address(RVA = "0x73BC50C", Offset = "0x73BC50C", Length = "0x1E8")]
		[Token(Token = "0x60030F9")]
		private set { } //Length: 488
	}

	[Address(RVA = "0x73BC0D4", Offset = "0x73BC0D4", Length = "0x74")]
	[Token(Token = "0x60030ED")]
	protected CollectionBase() { }

	[Address(RVA = "0x73BC178", Offset = "0x73BC178", Length = "0x4C")]
	[Token(Token = "0x60030F1")]
	public override void Clear() { }

	[Address(RVA = "0x73BC154", Offset = "0x73BC154", Length = "0x24")]
	[Token(Token = "0x60030F0")]
	public override int get_Count() { }

	[Address(RVA = "0x73BC148", Offset = "0x73BC148", Length = "0x8")]
	[Token(Token = "0x60030EE")]
	protected ArrayList get_InnerList() { }

	[Address(RVA = "0x73BC150", Offset = "0x73BC150", Length = "0x4")]
	[Token(Token = "0x60030EF")]
	protected IList get_List() { }

	[Address(RVA = "0x73BCBCC", Offset = "0x73BCBCC", Length = "0x24")]
	[Token(Token = "0x60030FF")]
	public override IEnumerator GetEnumerator() { }

	[Address(RVA = "0x73BCBF8", Offset = "0x73BCBF8", Length = "0x4")]
	[Token(Token = "0x6003102")]
	protected override void OnClear() { }

	[Address(RVA = "0x73BCC60", Offset = "0x73BCC60", Length = "0x4")]
	[Token(Token = "0x6003107")]
	protected override void OnClearComplete() { }

	[Address(RVA = "0x73BCBF4", Offset = "0x73BCBF4", Length = "0x4")]
	[Token(Token = "0x6003101")]
	protected override void OnInsert(int index, object value) { }

	[Address(RVA = "0x73BCC5C", Offset = "0x73BCC5C", Length = "0x4")]
	[Token(Token = "0x6003106")]
	protected override void OnInsertComplete(int index, object value) { }

	[Address(RVA = "0x73BCBFC", Offset = "0x73BCBFC", Length = "0x4")]
	[Token(Token = "0x6003103")]
	protected override void OnRemove(int index, object value) { }

	[Address(RVA = "0x73BCC64", Offset = "0x73BCC64", Length = "0x4")]
	[Token(Token = "0x6003108")]
	protected override void OnRemoveComplete(int index, object value) { }

	[Address(RVA = "0x73BCBF0", Offset = "0x73BCBF0", Length = "0x4")]
	[Token(Token = "0x6003100")]
	protected override void OnSet(int index, object oldValue, object newValue) { }

	[Address(RVA = "0x73BCC58", Offset = "0x73BCC58", Length = "0x4")]
	[Token(Token = "0x6003105")]
	protected override void OnSetComplete(int index, object oldValue, object newValue) { }

	[Address(RVA = "0x73BCC00", Offset = "0x73BCC00", Length = "0x58")]
	[Token(Token = "0x6003104")]
	protected override void OnValidate(object value) { }

	[Address(RVA = "0x73BC1C4", Offset = "0x73BC1C4", Length = "0x1D8")]
	[Token(Token = "0x60030F2")]
	public override void RemoveAt(int index) { }

	[Address(RVA = "0x73BC42C", Offset = "0x73BC42C", Length = "0x24")]
	[Token(Token = "0x60030F7")]
	private override void System.Collections.ICollection.CopyTo(Array array, int index) { }

	[Address(RVA = "0x73BC3E4", Offset = "0x73BC3E4", Length = "0x24")]
	[Token(Token = "0x60030F5")]
	private override bool System.Collections.ICollection.get_IsSynchronized() { }

	[Address(RVA = "0x73BC408", Offset = "0x73BC408", Length = "0x24")]
	[Token(Token = "0x60030F6")]
	private override object System.Collections.ICollection.get_SyncRoot() { }

	[Address(RVA = "0x73BC718", Offset = "0x73BC718", Length = "0x140")]
	[Token(Token = "0x60030FB")]
	private override int System.Collections.IList.Add(object value) { }

	[Address(RVA = "0x73BC6F4", Offset = "0x73BC6F4", Length = "0x24")]
	[Token(Token = "0x60030FA")]
	private override bool System.Collections.IList.Contains(object value) { }

	[Address(RVA = "0x73BC3C0", Offset = "0x73BC3C0", Length = "0x24")]
	[Token(Token = "0x60030F4")]
	private override bool System.Collections.IList.get_IsFixedSize() { }

	[Address(RVA = "0x73BC39C", Offset = "0x73BC39C", Length = "0x24")]
	[Token(Token = "0x60030F3")]
	private override bool System.Collections.IList.get_IsReadOnly() { }

	[Address(RVA = "0x73BC450", Offset = "0x73BC450", Length = "0xBC")]
	[Token(Token = "0x60030F8")]
	private override object System.Collections.IList.get_Item(int index) { }

	[Address(RVA = "0x73BC9F4", Offset = "0x73BC9F4", Length = "0x24")]
	[Token(Token = "0x60030FD")]
	private override int System.Collections.IList.IndexOf(object value) { }

	[Address(RVA = "0x73BCA18", Offset = "0x73BCA18", Length = "0x1B4")]
	[Token(Token = "0x60030FE")]
	private override void System.Collections.IList.Insert(int index, object value) { }

	[Address(RVA = "0x73BC858", Offset = "0x73BC858", Length = "0x19C")]
	[Token(Token = "0x60030FC")]
	private override void System.Collections.IList.Remove(object value) { }

	[Address(RVA = "0x73BC50C", Offset = "0x73BC50C", Length = "0x1E8")]
	[Token(Token = "0x60030F9")]
	private override void System.Collections.IList.set_Item(int index, object value) { }

}

