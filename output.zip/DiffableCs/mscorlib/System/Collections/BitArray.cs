namespace System.Collections;

[DefaultMember("Item")]
[Token(Token = "0x2000651")]
public sealed class BitArray : ICollection, IEnumerable, ICloneable
{
	[Token(Token = "0x2000652")]
	private class BitArrayEnumeratorSimple : IEnumerator, ICloneable
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001B6A")]
		private BitArray bitarray; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4001B6B")]
		private int index; //Field offset: 0x18
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4001B6C")]
		private int version; //Field offset: 0x1C
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4001B6D")]
		private bool currentElement; //Field offset: 0x20

		[Token(Token = "0x170007CD")]
		public override object Current
		{
			[Address(RVA = "0x73C2A24", Offset = "0x73C2A24", Length = "0x15C")]
			[Token(Token = "0x60031AD")]
			 get { } //Length: 348
		}

		[Address(RVA = "0x73C2820", Offset = "0x73C2820", Length = "0x50")]
		[Token(Token = "0x60031AA")]
		internal BitArrayEnumeratorSimple(BitArray bitarray) { }

		[Address(RVA = "0x73C2870", Offset = "0x73C2870", Length = "0x8")]
		[Token(Token = "0x60031AB")]
		public override object Clone() { }

		[Address(RVA = "0x73C2A24", Offset = "0x73C2A24", Length = "0x15C")]
		[Token(Token = "0x60031AD")]
		public override object get_Current() { }

		[Address(RVA = "0x73C2878", Offset = "0x73C2878", Length = "0x1AC")]
		[Token(Token = "0x60031AC")]
		public override bool MoveNext() { }

		[Address(RVA = "0x73C2B80", Offset = "0x73C2B80", Length = "0x7C")]
		[Token(Token = "0x60031AE")]
		public override void Reset() { }

	}

	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001B66")]
	private Int32[] m_array; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001B67")]
	private int m_length; //Field offset: 0x18
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x4001B68")]
	private int _version; //Field offset: 0x1C
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4001B69")]
	private object _syncRoot; //Field offset: 0x20

	[Token(Token = "0x170007CA")]
	public override int Count
	{
		[Address(RVA = "0x73C26D4", Offset = "0x73C26D4", Length = "0x8")]
		[Token(Token = "0x60031A4")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170007CC")]
	public override bool IsSynchronized
	{
		[Address(RVA = "0x73C2754", Offset = "0x73C2754", Length = "0x8")]
		[Token(Token = "0x60031A6")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170007C8")]
	public bool Item
	{
		[Address(RVA = "0x73C1DE4", Offset = "0x73C1DE4", Length = "0x4")]
		[Token(Token = "0x600319C")]
		 get { } //Length: 4
		[Address(RVA = "0x73C1EC4", Offset = "0x73C1EC4", Length = "0x4")]
		[Token(Token = "0x600319D")]
		 set { } //Length: 4
	}

	[Token(Token = "0x170007C9")]
	public int Length
	{
		[Address(RVA = "0x73C2044", Offset = "0x73C2044", Length = "0x8")]
		[Token(Token = "0x60031A1")]
		 get { } //Length: 8
		[Address(RVA = "0x73C204C", Offset = "0x73C204C", Length = "0x198")]
		[Token(Token = "0x60031A2")]
		 set { } //Length: 408
	}

	[Token(Token = "0x170007CB")]
	public override object SyncRoot
	{
		[Address(RVA = "0x73C26DC", Offset = "0x73C26DC", Length = "0x78")]
		[Token(Token = "0x60031A5")]
		 get { } //Length: 120
	}

	[Address(RVA = "0x73C1B70", Offset = "0x73C1B70", Length = "0x8")]
	[Token(Token = "0x6003199")]
	public BitArray(int length) { }

	[Address(RVA = "0x73C1B78", Offset = "0x73C1B78", Length = "0x15C")]
	[Token(Token = "0x600319A")]
	public BitArray(int length, bool defaultValue) { }

	[Address(RVA = "0x73C1CF0", Offset = "0x73C1CF0", Length = "0xF4")]
	[Token(Token = "0x600319B")]
	public BitArray(BitArray bits) { }

	[Address(RVA = "0x73C275C", Offset = "0x73C275C", Length = "0x60")]
	[Token(Token = "0x60031A7")]
	public override object Clone() { }

	[Address(RVA = "0x73C21E4", Offset = "0x73C21E4", Length = "0x4F0")]
	[Token(Token = "0x60031A3")]
	public override void CopyTo(Array array, int index) { }

	[Address(RVA = "0x73C1DE8", Offset = "0x73C1DE8", Length = "0xDC")]
	[Token(Token = "0x600319E")]
	public bool Get(int index) { }

	[Address(RVA = "0x73C26D4", Offset = "0x73C26D4", Length = "0x8")]
	[Token(Token = "0x60031A4")]
	public override int get_Count() { }

	[Address(RVA = "0x73C2754", Offset = "0x73C2754", Length = "0x8")]
	[Token(Token = "0x60031A6")]
	public override bool get_IsSynchronized() { }

	[Address(RVA = "0x73C1DE4", Offset = "0x73C1DE4", Length = "0x4")]
	[Token(Token = "0x600319C")]
	public bool get_Item(int index) { }

	[Address(RVA = "0x73C2044", Offset = "0x73C2044", Length = "0x8")]
	[Token(Token = "0x60031A1")]
	public int get_Length() { }

	[Address(RVA = "0x73C26DC", Offset = "0x73C26DC", Length = "0x78")]
	[Token(Token = "0x60031A5")]
	public override object get_SyncRoot() { }

	[Address(RVA = "0x73C1CD4", Offset = "0x73C1CD4", Length = "0x1C")]
	[Token(Token = "0x60031A9")]
	private static int GetArrayLength(int n, int div) { }

	[Address(RVA = "0x73C27BC", Offset = "0x73C27BC", Length = "0x64")]
	[Token(Token = "0x60031A8")]
	public override IEnumerator GetEnumerator() { }

	[Address(RVA = "0x73C1EC8", Offset = "0x73C1EC8", Length = "0x120")]
	[Token(Token = "0x600319F")]
	public void Set(int index, bool value) { }

	[Address(RVA = "0x73C1EC4", Offset = "0x73C1EC4", Length = "0x4")]
	[Token(Token = "0x600319D")]
	public void set_Item(int index, bool value) { }

	[Address(RVA = "0x73C204C", Offset = "0x73C204C", Length = "0x198")]
	[Token(Token = "0x60031A2")]
	public void set_Length(int value) { }

	[Address(RVA = "0x73C1FE8", Offset = "0x73C1FE8", Length = "0x5C")]
	[Token(Token = "0x60031A0")]
	public void SetAll(bool value) { }

}

