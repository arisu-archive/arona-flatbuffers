namespace System.Collections;

[Obsolete("Please use IEqualityComparer instead.")]
[Token(Token = "0x200065F")]
public interface IHashCodeProvider
{

	[Token(Token = "0x6003265")]
	public int GetHashCode(object obj) { }

}

