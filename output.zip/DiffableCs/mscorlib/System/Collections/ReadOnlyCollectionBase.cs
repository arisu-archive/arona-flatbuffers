namespace System.Collections;

[Token(Token = "0x2000647")]
public abstract class ReadOnlyCollectionBase : ICollection, IEnumerable
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001B48")]
	private ArrayList _list; //Field offset: 0x10

	[Token(Token = "0x170007A2")]
	public override int Count
	{
		[Address(RVA = "0x73BDB2C", Offset = "0x73BDB2C", Length = "0x24")]
		[Token(Token = "0x600311E")]
		 get { } //Length: 36
	}

	[Token(Token = "0x170007A1")]
	protected ArrayList InnerList
	{
		[Address(RVA = "0x73BDAB4", Offset = "0x73BDAB4", Length = "0x78")]
		[Token(Token = "0x600311D")]
		 get { } //Length: 120
	}

	[Token(Token = "0x170007A3")]
	private override bool System.Collections.ICollection.IsSynchronized
	{
		[Address(RVA = "0x73BDB50", Offset = "0x73BDB50", Length = "0x24")]
		[Token(Token = "0x600311F")]
		private get { } //Length: 36
	}

	[Token(Token = "0x170007A4")]
	private override object System.Collections.ICollection.SyncRoot
	{
		[Address(RVA = "0x73BDB74", Offset = "0x73BDB74", Length = "0x24")]
		[Token(Token = "0x6003120")]
		private get { } //Length: 36
	}

	[Address(RVA = "0x73BDBF8", Offset = "0x73BDBF8", Length = "0x8")]
	[Token(Token = "0x6003123")]
	protected ReadOnlyCollectionBase() { }

	[Address(RVA = "0x73BDB2C", Offset = "0x73BDB2C", Length = "0x24")]
	[Token(Token = "0x600311E")]
	public override int get_Count() { }

	[Address(RVA = "0x73BDAB4", Offset = "0x73BDAB4", Length = "0x78")]
	[Token(Token = "0x600311D")]
	protected ArrayList get_InnerList() { }

	[Address(RVA = "0x73BDBD4", Offset = "0x73BDBD4", Length = "0x24")]
	[Token(Token = "0x6003122")]
	public override IEnumerator GetEnumerator() { }

	[Address(RVA = "0x73BDB98", Offset = "0x73BDB98", Length = "0x3C")]
	[Token(Token = "0x6003121")]
	private override void System.Collections.ICollection.CopyTo(Array array, int index) { }

	[Address(RVA = "0x73BDB50", Offset = "0x73BDB50", Length = "0x24")]
	[Token(Token = "0x600311F")]
	private override bool System.Collections.ICollection.get_IsSynchronized() { }

	[Address(RVA = "0x73BDB74", Offset = "0x73BDB74", Length = "0x24")]
	[Token(Token = "0x6003120")]
	private override object System.Collections.ICollection.get_SyncRoot() { }

}

