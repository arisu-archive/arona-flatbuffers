namespace System.Collections;

[Token(Token = "0x2000630")]
internal static class HashHelpers
{
	[Token(Token = "0x4001B24")]
	public static readonly Int32[] primes; //Field offset: 0x0
	[Token(Token = "0x4001B25")]
	private static ConditionalWeakTable<Object, SerializationInfo> s_serializationInfoTable; //Field offset: 0x8

	[Token(Token = "0x17000773")]
	internal static ConditionalWeakTable<Object, SerializationInfo> SerializationInfoTable
	{
		[Address(RVA = "0x73BA54C", Offset = "0x73BA54C", Length = "0xE0")]
		[Token(Token = "0x6003095")]
		internal get { } //Length: 224
	}

	[Address(RVA = "0x73BA62C", Offset = "0x73BA62C", Length = "0xA0")]
	[Token(Token = "0x6003096")]
	private static HashHelpers() { }

	[Address(RVA = "0x73BA4C8", Offset = "0x73BA4C8", Length = "0x84")]
	[Token(Token = "0x6003094")]
	public static int ExpandPrime(int oldSize) { }

	[Address(RVA = "0x73BA54C", Offset = "0x73BA54C", Length = "0xE0")]
	[Token(Token = "0x6003095")]
	internal static ConditionalWeakTable<Object, SerializationInfo> get_SerializationInfoTable() { }

	[Address(RVA = "0x73BA340", Offset = "0x73BA340", Length = "0x188")]
	[Token(Token = "0x6003093")]
	public static int GetPrime(int min) { }

	[Address(RVA = "0x73BA280", Offset = "0x73BA280", Length = "0xC0")]
	[Token(Token = "0x6003092")]
	public static bool IsPrime(int candidate) { }

}

