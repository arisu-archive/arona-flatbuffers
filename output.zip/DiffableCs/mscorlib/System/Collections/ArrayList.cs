namespace System.Collections;

[DebuggerDisplay("Count = {Count}")]
[DebuggerTypeProxy(typeof(ArrayListDebugView))]
[DefaultMember("Item")]
[Token(Token = "0x2000653")]
public class ArrayList : IList, ICollection, IEnumerable, ICloneable
{
	[Token(Token = "0x2000657")]
	public class ArrayListDebugView
	{

	}

	[Token(Token = "0x2000656")]
	private sealed class ArrayListEnumeratorSimple : IEnumerator, ICloneable
	{
		[Token(Token = "0x4001B79")]
		private static object s_dummyObject; //Field offset: 0x0
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001B74")]
		private ArrayList _list; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4001B75")]
		private int _index; //Field offset: 0x18
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4001B76")]
		private int _version; //Field offset: 0x1C
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4001B77")]
		private object _currentElement; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4001B78")]
		private bool _isArrayList; //Field offset: 0x28

		[Token(Token = "0x170007E3")]
		public override object Current
		{
			[Address(RVA = "0x73C6D38", Offset = "0x73C6D38", Length = "0xD0")]
			[Token(Token = "0x600320B")]
			 get { } //Length: 208
		}

		[Address(RVA = "0x73C6EE0", Offset = "0x73C6EE0", Length = "0x84")]
		[Token(Token = "0x600320D")]
		private static ArrayListEnumeratorSimple() { }

		[Address(RVA = "0x73C38D4", Offset = "0x73C38D4", Length = "0x11C")]
		[Token(Token = "0x6003208")]
		internal ArrayListEnumeratorSimple(ArrayList list) { }

		[Address(RVA = "0x73C6B4C", Offset = "0x73C6B4C", Length = "0x8")]
		[Token(Token = "0x6003209")]
		public override object Clone() { }

		[Address(RVA = "0x73C6D38", Offset = "0x73C6D38", Length = "0xD0")]
		[Token(Token = "0x600320B")]
		public override object get_Current() { }

		[Address(RVA = "0x73C6B54", Offset = "0x73C6B54", Length = "0x1E4")]
		[Token(Token = "0x600320A")]
		public override bool MoveNext() { }

		[Address(RVA = "0x73C6E08", Offset = "0x73C6E08", Length = "0xD8")]
		[Token(Token = "0x600320C")]
		public override void Reset() { }

	}

	[DefaultMember("Item")]
	[Token(Token = "0x2000654")]
	private class IListWrapper : ArrayList
	{
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4001B72")]
		private IList _list; //Field offset: 0x28

		[Token(Token = "0x170007D5")]
		public virtual int Capacity
		{
			[Address(RVA = "0x73C45D4", Offset = "0x73C45D4", Length = "0x90")]
			[Token(Token = "0x60031D3")]
			 set { } //Length: 144
		}

		[Token(Token = "0x170007D6")]
		public virtual int Count
		{
			[Address(RVA = "0x73C4664", Offset = "0x73C4664", Length = "0xA4")]
			[Token(Token = "0x60031D4")]
			 get { } //Length: 164
		}

		[Token(Token = "0x170007D8")]
		public virtual bool IsFixedSize
		{
			[Address(RVA = "0x73C47AC", Offset = "0x73C47AC", Length = "0xA4")]
			[Token(Token = "0x60031D6")]
			 get { } //Length: 164
		}

		[Token(Token = "0x170007D7")]
		public virtual bool IsReadOnly
		{
			[Address(RVA = "0x73C4708", Offset = "0x73C4708", Length = "0xA4")]
			[Token(Token = "0x60031D5")]
			 get { } //Length: 164
		}

		[Token(Token = "0x170007D9")]
		public virtual bool IsSynchronized
		{
			[Address(RVA = "0x73C4850", Offset = "0x73C4850", Length = "0xA4")]
			[Token(Token = "0x60031D7")]
			 get { } //Length: 164
		}

		[Token(Token = "0x170007DA")]
		public virtual object Item
		{
			[Address(RVA = "0x73C48F4", Offset = "0x73C48F4", Length = "0xA8")]
			[Token(Token = "0x60031D8")]
			 get { } //Length: 168
			[Address(RVA = "0x73C499C", Offset = "0x73C499C", Length = "0xCC")]
			[Token(Token = "0x60031D9")]
			 set { } //Length: 204
		}

		[Token(Token = "0x170007DB")]
		public virtual object SyncRoot
		{
			[Address(RVA = "0x73C4A68", Offset = "0x73C4A68", Length = "0xA4")]
			[Token(Token = "0x60031DA")]
			 get { } //Length: 164
		}

		[Address(RVA = "0x73C33C0", Offset = "0x73C33C0", Length = "0x34")]
		[Token(Token = "0x60031D2")]
		internal IListWrapper(IList list) { }

		[Address(RVA = "0x73C4B0C", Offset = "0x73C4B0C", Length = "0xBC")]
		[Token(Token = "0x60031DB")]
		public virtual int Add(object obj) { }

		[Address(RVA = "0x73C4BC8", Offset = "0x73C4BC8", Length = "0x44")]
		[Token(Token = "0x60031DC")]
		public virtual void AddRange(ICollection c) { }

		[Address(RVA = "0x73C4C0C", Offset = "0x73C4C0C", Length = "0x168")]
		[Token(Token = "0x60031DD")]
		public virtual void Clear() { }

		[Address(RVA = "0x73C4D74", Offset = "0x73C4D74", Length = "0x74")]
		[Token(Token = "0x60031DE")]
		public virtual object Clone() { }

		[Address(RVA = "0x73C4DE8", Offset = "0x73C4DE8", Length = "0xAC")]
		[Token(Token = "0x60031DF")]
		public virtual bool Contains(object obj) { }

		[Address(RVA = "0x73C4F4C", Offset = "0x73C4F4C", Length = "0x348")]
		[Token(Token = "0x60031E1")]
		public virtual void CopyTo(int index, Array array, int arrayIndex, int count) { }

		[Address(RVA = "0x73C4E94", Offset = "0x73C4E94", Length = "0xB8")]
		[Token(Token = "0x60031E0")]
		public virtual void CopyTo(Array array, int index) { }

		[Address(RVA = "0x73C4664", Offset = "0x73C4664", Length = "0xA4")]
		[Token(Token = "0x60031D4")]
		public virtual int get_Count() { }

		[Address(RVA = "0x73C47AC", Offset = "0x73C47AC", Length = "0xA4")]
		[Token(Token = "0x60031D6")]
		public virtual bool get_IsFixedSize() { }

		[Address(RVA = "0x73C4708", Offset = "0x73C4708", Length = "0xA4")]
		[Token(Token = "0x60031D5")]
		public virtual bool get_IsReadOnly() { }

		[Address(RVA = "0x73C4850", Offset = "0x73C4850", Length = "0xA4")]
		[Token(Token = "0x60031D7")]
		public virtual bool get_IsSynchronized() { }

		[Address(RVA = "0x73C48F4", Offset = "0x73C48F4", Length = "0xA8")]
		[Token(Token = "0x60031D8")]
		public virtual object get_Item(int index) { }

		[Address(RVA = "0x73C4A68", Offset = "0x73C4A68", Length = "0xA4")]
		[Token(Token = "0x60031DA")]
		public virtual object get_SyncRoot() { }

		[Address(RVA = "0x73C5294", Offset = "0x73C5294", Length = "0xA0")]
		[Token(Token = "0x60031E2")]
		public virtual IEnumerator GetEnumerator() { }

		[Address(RVA = "0x73C5334", Offset = "0x73C5334", Length = "0xAC")]
		[Token(Token = "0x60031E3")]
		public virtual int IndexOf(object value) { }

		[Address(RVA = "0x73C53E0", Offset = "0x73C53E0", Length = "0xCC")]
		[Token(Token = "0x60031E4")]
		public virtual void Insert(int index, object obj) { }

		[Address(RVA = "0x73C54AC", Offset = "0x73C54AC", Length = "0x3D0")]
		[Token(Token = "0x60031E5")]
		public virtual void InsertRange(int index, ICollection c) { }

		[Address(RVA = "0x73C587C", Offset = "0x73C587C", Length = "0x40")]
		[Token(Token = "0x60031E6")]
		public virtual void Remove(object value) { }

		[Address(RVA = "0x73C58BC", Offset = "0x73C58BC", Length = "0xBC")]
		[Token(Token = "0x60031E7")]
		public virtual void RemoveAt(int index) { }

		[Address(RVA = "0x73C5978", Offset = "0x73C5978", Length = "0x220")]
		[Token(Token = "0x60031E8")]
		public virtual void RemoveRange(int index, int count) { }

		[Address(RVA = "0x73C5B98", Offset = "0x73C5B98", Length = "0x370")]
		[Token(Token = "0x60031E9")]
		public virtual void Reverse(int index, int count) { }

		[Address(RVA = "0x73C45D4", Offset = "0x73C45D4", Length = "0x90")]
		[Token(Token = "0x60031D3")]
		public virtual void set_Capacity(int value) { }

		[Address(RVA = "0x73C499C", Offset = "0x73C499C", Length = "0xCC")]
		[Token(Token = "0x60031D9")]
		public virtual void set_Item(int index, object value) { }

		[Address(RVA = "0x73C5F08", Offset = "0x73C5F08", Length = "0x2C0")]
		[Token(Token = "0x60031EA")]
		public virtual void Sort(int index, int count, IComparer comparer) { }

		[Address(RVA = "0x73C61C8", Offset = "0x73C61C8", Length = "0x158")]
		[Token(Token = "0x60031EB")]
		public virtual Object[] ToArray() { }

		[Address(RVA = "0x73C6320", Offset = "0x73C6320", Length = "0x1B8")]
		[Token(Token = "0x60031EC")]
		public virtual Array ToArray(Type type) { }

	}

	[DefaultMember("Item")]
	[Token(Token = "0x2000655")]
	private class ReadOnlyArrayList : ArrayList
	{
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4001B73")]
		private ArrayList _list; //Field offset: 0x28

		[Token(Token = "0x170007E2")]
		public virtual int Capacity
		{
			[Address(RVA = "0x73C6668", Offset = "0x73C6668", Length = "0x50")]
			[Token(Token = "0x60031F7")]
			 set { } //Length: 80
		}

		[Token(Token = "0x170007DC")]
		public virtual int Count
		{
			[Address(RVA = "0x73C64D8", Offset = "0x73C64D8", Length = "0x24")]
			[Token(Token = "0x60031EE")]
			 get { } //Length: 36
		}

		[Token(Token = "0x170007DE")]
		public virtual bool IsFixedSize
		{
			[Address(RVA = "0x73C6504", Offset = "0x73C6504", Length = "0x8")]
			[Token(Token = "0x60031F0")]
			 get { } //Length: 8
		}

		[Token(Token = "0x170007DD")]
		public virtual bool IsReadOnly
		{
			[Address(RVA = "0x73C64FC", Offset = "0x73C64FC", Length = "0x8")]
			[Token(Token = "0x60031EF")]
			 get { } //Length: 8
		}

		[Token(Token = "0x170007DF")]
		public virtual bool IsSynchronized
		{
			[Address(RVA = "0x73C650C", Offset = "0x73C650C", Length = "0x24")]
			[Token(Token = "0x60031F1")]
			 get { } //Length: 36
		}

		[Token(Token = "0x170007E0")]
		public virtual object Item
		{
			[Address(RVA = "0x73C6530", Offset = "0x73C6530", Length = "0x24")]
			[Token(Token = "0x60031F2")]
			 get { } //Length: 36
			[Address(RVA = "0x73C6554", Offset = "0x73C6554", Length = "0x50")]
			[Token(Token = "0x60031F3")]
			 set { } //Length: 80
		}

		[Token(Token = "0x170007E1")]
		public virtual object SyncRoot
		{
			[Address(RVA = "0x73C65A4", Offset = "0x73C65A4", Length = "0x24")]
			[Token(Token = "0x60031F4")]
			 get { } //Length: 36
		}

		[Address(RVA = "0x73C3E68", Offset = "0x73C3E68", Length = "0x2C")]
		[Token(Token = "0x60031ED")]
		internal ReadOnlyArrayList(ArrayList l) { }

		[Address(RVA = "0x73C65C8", Offset = "0x73C65C8", Length = "0x50")]
		[Token(Token = "0x60031F5")]
		public virtual int Add(object obj) { }

		[Address(RVA = "0x73C6618", Offset = "0x73C6618", Length = "0x50")]
		[Token(Token = "0x60031F6")]
		public virtual void AddRange(ICollection c) { }

		[Address(RVA = "0x73C66B8", Offset = "0x73C66B8", Length = "0x50")]
		[Token(Token = "0x60031F8")]
		public virtual void Clear() { }

		[Address(RVA = "0x73C6708", Offset = "0x73C6708", Length = "0x118")]
		[Token(Token = "0x60031F9")]
		public virtual object Clone() { }

		[Address(RVA = "0x73C6820", Offset = "0x73C6820", Length = "0x24")]
		[Token(Token = "0x60031FA")]
		public virtual bool Contains(object obj) { }

		[Address(RVA = "0x73C6844", Offset = "0x73C6844", Length = "0x24")]
		[Token(Token = "0x60031FB")]
		public virtual void CopyTo(Array array, int index) { }

		[Address(RVA = "0x73C6868", Offset = "0x73C6868", Length = "0x24")]
		[Token(Token = "0x60031FC")]
		public virtual void CopyTo(int index, Array array, int arrayIndex, int count) { }

		[Address(RVA = "0x73C64D8", Offset = "0x73C64D8", Length = "0x24")]
		[Token(Token = "0x60031EE")]
		public virtual int get_Count() { }

		[Address(RVA = "0x73C6504", Offset = "0x73C6504", Length = "0x8")]
		[Token(Token = "0x60031F0")]
		public virtual bool get_IsFixedSize() { }

		[Address(RVA = "0x73C64FC", Offset = "0x73C64FC", Length = "0x8")]
		[Token(Token = "0x60031EF")]
		public virtual bool get_IsReadOnly() { }

		[Address(RVA = "0x73C650C", Offset = "0x73C650C", Length = "0x24")]
		[Token(Token = "0x60031F1")]
		public virtual bool get_IsSynchronized() { }

		[Address(RVA = "0x73C6530", Offset = "0x73C6530", Length = "0x24")]
		[Token(Token = "0x60031F2")]
		public virtual object get_Item(int index) { }

		[Address(RVA = "0x73C65A4", Offset = "0x73C65A4", Length = "0x24")]
		[Token(Token = "0x60031F4")]
		public virtual object get_SyncRoot() { }

		[Address(RVA = "0x73C688C", Offset = "0x73C688C", Length = "0x24")]
		[Token(Token = "0x60031FD")]
		public virtual IEnumerator GetEnumerator() { }

		[Address(RVA = "0x73C68B0", Offset = "0x73C68B0", Length = "0x24")]
		[Token(Token = "0x60031FE")]
		public virtual int IndexOf(object value) { }

		[Address(RVA = "0x73C68D4", Offset = "0x73C68D4", Length = "0x50")]
		[Token(Token = "0x60031FF")]
		public virtual void Insert(int index, object obj) { }

		[Address(RVA = "0x73C6924", Offset = "0x73C6924", Length = "0x50")]
		[Token(Token = "0x6003200")]
		public virtual void InsertRange(int index, ICollection c) { }

		[Address(RVA = "0x73C6974", Offset = "0x73C6974", Length = "0x50")]
		[Token(Token = "0x6003201")]
		public virtual void Remove(object value) { }

		[Address(RVA = "0x73C69C4", Offset = "0x73C69C4", Length = "0x50")]
		[Token(Token = "0x6003202")]
		public virtual void RemoveAt(int index) { }

		[Address(RVA = "0x73C6A14", Offset = "0x73C6A14", Length = "0x50")]
		[Token(Token = "0x6003203")]
		public virtual void RemoveRange(int index, int count) { }

		[Address(RVA = "0x73C6A64", Offset = "0x73C6A64", Length = "0x50")]
		[Token(Token = "0x6003204")]
		public virtual void Reverse(int index, int count) { }

		[Address(RVA = "0x73C6668", Offset = "0x73C6668", Length = "0x50")]
		[Token(Token = "0x60031F7")]
		public virtual void set_Capacity(int value) { }

		[Address(RVA = "0x73C6554", Offset = "0x73C6554", Length = "0x50")]
		[Token(Token = "0x60031F3")]
		public virtual void set_Item(int index, object value) { }

		[Address(RVA = "0x73C6AB4", Offset = "0x73C6AB4", Length = "0x50")]
		[Token(Token = "0x6003205")]
		public virtual void Sort(int index, int count, IComparer comparer) { }

		[Address(RVA = "0x73C6B04", Offset = "0x73C6B04", Length = "0x24")]
		[Token(Token = "0x6003206")]
		public virtual Object[] ToArray() { }

		[Address(RVA = "0x73C6B28", Offset = "0x73C6B28", Length = "0x24")]
		[Token(Token = "0x6003207")]
		public virtual Array ToArray(Type type) { }

	}

	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001B6E")]
	private Object[] _items; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001B6F")]
	private int _size; //Field offset: 0x18
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x4001B70")]
	private int _version; //Field offset: 0x1C
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4001B71")]
	private object _syncRoot; //Field offset: 0x20

	[Token(Token = "0x170007CE")]
	public override int Capacity
	{
		[Address(RVA = "0x73C2F9C", Offset = "0x73C2F9C", Length = "0x130")]
		[Token(Token = "0x60031B2")]
		 set { } //Length: 304
	}

	[Token(Token = "0x170007CF")]
	public override int Count
	{
		[Address(RVA = "0x73C30CC", Offset = "0x73C30CC", Length = "0x8")]
		[Token(Token = "0x60031B3")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170007D0")]
	public override bool IsFixedSize
	{
		[Address(RVA = "0x73C30D4", Offset = "0x73C30D4", Length = "0x8")]
		[Token(Token = "0x60031B4")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170007D1")]
	public override bool IsReadOnly
	{
		[Address(RVA = "0x73C30DC", Offset = "0x73C30DC", Length = "0x8")]
		[Token(Token = "0x60031B5")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170007D2")]
	public override bool IsSynchronized
	{
		[Address(RVA = "0x73C30E4", Offset = "0x73C30E4", Length = "0x8")]
		[Token(Token = "0x60031B6")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170007D4")]
	public override object Item
	{
		[Address(RVA = "0x73C3164", Offset = "0x73C3164", Length = "0xA8")]
		[Token(Token = "0x60031B8")]
		 get { } //Length: 168
		[Address(RVA = "0x73C320C", Offset = "0x73C320C", Length = "0xF4")]
		[Token(Token = "0x60031B9")]
		 set { } //Length: 244
	}

	[Token(Token = "0x170007D3")]
	public override object SyncRoot
	{
		[Address(RVA = "0x73C30EC", Offset = "0x73C30EC", Length = "0x78")]
		[Token(Token = "0x60031B7")]
		 get { } //Length: 120
	}

	[Address(RVA = "0x73C2BFC", Offset = "0x73C2BFC", Length = "0x94")]
	[Token(Token = "0x60031AF")]
	public ArrayList() { }

	[Address(RVA = "0x73C2C90", Offset = "0x73C2C90", Length = "0x14C")]
	[Token(Token = "0x60031B0")]
	public ArrayList(int capacity) { }

	[Address(RVA = "0x73C2DDC", Offset = "0x73C2DDC", Length = "0x1C0")]
	[Token(Token = "0x60031B1")]
	public ArrayList(ICollection c) { }

	[Address(RVA = "0x73C3300", Offset = "0x73C3300", Length = "0xC0")]
	[Token(Token = "0x60031BA")]
	public static ArrayList Adapter(IList list) { }

	[Address(RVA = "0x73C33F4", Offset = "0x73C33F4", Length = "0xB0")]
	[Token(Token = "0x60031BB")]
	public override int Add(object value) { }

	[Address(RVA = "0x73C3500", Offset = "0x73C3500", Length = "0x18")]
	[Token(Token = "0x60031BC")]
	public override void AddRange(ICollection c) { }

	[Address(RVA = "0x73C3518", Offset = "0x73C3518", Length = "0x3C")]
	[Token(Token = "0x60031BD")]
	public override void Clear() { }

	[Address(RVA = "0x73C3554", Offset = "0x73C3554", Length = "0x88")]
	[Token(Token = "0x60031BE")]
	public override object Clone() { }

	[Address(RVA = "0x73C35DC", Offset = "0x73C35DC", Length = "0xCC")]
	[Token(Token = "0x60031BF")]
	public override bool Contains(object item) { }

	[Address(RVA = "0x73C376C", Offset = "0x73C376C", Length = "0x108")]
	[Token(Token = "0x60031C2")]
	public override void CopyTo(int index, Array array, int arrayIndex, int count) { }

	[Address(RVA = "0x73C36BC", Offset = "0x73C36BC", Length = "0xB0")]
	[Token(Token = "0x60031C1")]
	public override void CopyTo(Array array, int arrayIndex) { }

	[Address(RVA = "0x73C36A8", Offset = "0x73C36A8", Length = "0x14")]
	[Token(Token = "0x60031C0")]
	public override void CopyTo(Array array) { }

	[Address(RVA = "0x73C34A4", Offset = "0x73C34A4", Length = "0x5C")]
	[Token(Token = "0x60031C3")]
	private void EnsureCapacity(int min) { }

	[Address(RVA = "0x73C30CC", Offset = "0x73C30CC", Length = "0x8")]
	[Token(Token = "0x60031B3")]
	public override int get_Count() { }

	[Address(RVA = "0x73C30D4", Offset = "0x73C30D4", Length = "0x8")]
	[Token(Token = "0x60031B4")]
	public override bool get_IsFixedSize() { }

	[Address(RVA = "0x73C30DC", Offset = "0x73C30DC", Length = "0x8")]
	[Token(Token = "0x60031B5")]
	public override bool get_IsReadOnly() { }

	[Address(RVA = "0x73C30E4", Offset = "0x73C30E4", Length = "0x8")]
	[Token(Token = "0x60031B6")]
	public override bool get_IsSynchronized() { }

	[Address(RVA = "0x73C3164", Offset = "0x73C3164", Length = "0xA8")]
	[Token(Token = "0x60031B8")]
	public override object get_Item(int index) { }

	[Address(RVA = "0x73C30EC", Offset = "0x73C30EC", Length = "0x78")]
	[Token(Token = "0x60031B7")]
	public override object get_SyncRoot() { }

	[Address(RVA = "0x73C3874", Offset = "0x73C3874", Length = "0x60")]
	[Token(Token = "0x60031C4")]
	public override IEnumerator GetEnumerator() { }

	[Address(RVA = "0x73C39F0", Offset = "0x73C39F0", Length = "0x18")]
	[Token(Token = "0x60031C5")]
	public override int IndexOf(object value) { }

	[Address(RVA = "0x73C3A08", Offset = "0x73C3A08", Length = "0x13C")]
	[Token(Token = "0x60031C6")]
	public override void Insert(int index, object value) { }

	[Address(RVA = "0x73C3B44", Offset = "0x73C3B44", Length = "0x268")]
	[Token(Token = "0x60031C7")]
	public override void InsertRange(int index, ICollection c) { }

	[Address(RVA = "0x73C3DAC", Offset = "0x73C3DAC", Length = "0xBC")]
	[Token(Token = "0x60031C8")]
	public static ArrayList ReadOnly(ArrayList list) { }

	[Address(RVA = "0x73C3E94", Offset = "0x73C3E94", Length = "0x40")]
	[Token(Token = "0x60031C9")]
	public override void Remove(object obj) { }

	[Address(RVA = "0x73C3ED4", Offset = "0x73C3ED4", Length = "0xEC")]
	[Token(Token = "0x60031CA")]
	public override void RemoveAt(int index) { }

	[Address(RVA = "0x73C3FC0", Offset = "0x73C3FC0", Length = "0x190")]
	[Token(Token = "0x60031CB")]
	public override void RemoveRange(int index, int count) { }

	[Address(RVA = "0x73C4150", Offset = "0x73C4150", Length = "0x38")]
	[Token(Token = "0x60031CC")]
	public override void Reverse() { }

	[Address(RVA = "0x73C4188", Offset = "0x73C4188", Length = "0x144")]
	[Token(Token = "0x60031CD")]
	public override void Reverse(int index, int count) { }

	[Address(RVA = "0x73C2F9C", Offset = "0x73C2F9C", Length = "0x130")]
	[Token(Token = "0x60031B2")]
	public override void set_Capacity(int value) { }

	[Address(RVA = "0x73C320C", Offset = "0x73C320C", Length = "0xF4")]
	[Token(Token = "0x60031B9")]
	public override void set_Item(int index, object value) { }

	[Address(RVA = "0x73C42CC", Offset = "0x73C42CC", Length = "0x48")]
	[Token(Token = "0x60031CE")]
	public override void Sort(IComparer comparer) { }

	[Address(RVA = "0x73C4314", Offset = "0x73C4314", Length = "0x104")]
	[Token(Token = "0x60031CF")]
	public override void Sort(int index, int count, IComparer comparer) { }

	[Address(RVA = "0x73C4418", Offset = "0x73C4418", Length = "0xCC")]
	[Token(Token = "0x60031D0")]
	public override Object[] ToArray() { }

	[Address(RVA = "0x73C44E4", Offset = "0x73C44E4", Length = "0xF0")]
	[Token(Token = "0x60031D1")]
	public override Array ToArray(Type type) { }

}

