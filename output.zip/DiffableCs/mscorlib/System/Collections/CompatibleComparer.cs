namespace System.Collections;

[Token(Token = "0x2000640")]
internal sealed class CompatibleComparer : IEqualityComparer
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001B38")]
	private readonly IHashCodeProvider _hcp; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001B39")]
	private readonly IComparer _comparer; //Field offset: 0x18

	[Token(Token = "0x17000794")]
	internal IComparer Comparer
	{
		[Address(RVA = "0x73BBA00", Offset = "0x73BBA00", Length = "0x8")]
		[Token(Token = "0x60030E3")]
		internal get { } //Length: 8
	}

	[Token(Token = "0x17000793")]
	internal IHashCodeProvider HashCodeProvider
	{
		[Address(RVA = "0x73BB9F8", Offset = "0x73BB9F8", Length = "0x8")]
		[Token(Token = "0x60030E2")]
		internal get { } //Length: 8
	}

	[Address(RVA = "0x73BB9B4", Offset = "0x73BB9B4", Length = "0x44")]
	[Token(Token = "0x60030E1")]
	internal CompatibleComparer(IHashCodeProvider hashCodeProvider, IComparer comparer) { }

	[Address(RVA = "0x73BBA20", Offset = "0x73BBA20", Length = "0x1C4")]
	[Token(Token = "0x60030E5")]
	public int Compare(object a, object b) { }

	[Address(RVA = "0x73BBA08", Offset = "0x73BBA08", Length = "0x18")]
	[Token(Token = "0x60030E4")]
	public override bool Equals(object a, object b) { }

	[Address(RVA = "0x73BBA00", Offset = "0x73BBA00", Length = "0x8")]
	[Token(Token = "0x60030E3")]
	internal IComparer get_Comparer() { }

	[Address(RVA = "0x73BB9F8", Offset = "0x73BB9F8", Length = "0x8")]
	[Token(Token = "0x60030E2")]
	internal IHashCodeProvider get_HashCodeProvider() { }

	[Address(RVA = "0x73BBBE4", Offset = "0x73BBBE4", Length = "0x10C")]
	[Token(Token = "0x60030E6")]
	public override int GetHashCode(object obj) { }

}

