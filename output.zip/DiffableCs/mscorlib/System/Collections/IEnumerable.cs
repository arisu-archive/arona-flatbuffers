namespace System.Collections;

[Token(Token = "0x2000635")]
public interface IEnumerable
{

	[Token(Token = "0x60030AA")]
	public IEnumerator GetEnumerator() { }

}

