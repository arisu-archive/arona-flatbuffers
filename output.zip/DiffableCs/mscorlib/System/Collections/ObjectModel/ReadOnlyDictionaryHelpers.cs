namespace System.Collections.ObjectModel;

[Token(Token = "0x2000678")]
internal static class ReadOnlyDictionaryHelpers
{

	[Address(RVA = "0x43F4E58", Offset = "0x43F4E58", Length = "0x6D4")]
	[Token(Token = "0x6003392")]
	internal static void CopyToNonGenericICollectionHelper(ICollection<T> collection, Array array, int index) { }

}

