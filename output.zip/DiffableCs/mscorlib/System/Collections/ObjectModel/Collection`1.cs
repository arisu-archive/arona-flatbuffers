namespace System.Collections.ObjectModel;

[DebuggerDisplay("Count = {Count}")]
[DebuggerTypeProxy(typeof(ICollectionDebugView`1))]
[DefaultMember("Item")]
[Token(Token = "0x2000671")]
public class Collection : IList<T>, ICollection<T>, IEnumerable<T>, IEnumerable, IList, ICollection, IReadOnlyList<T>, IReadOnlyCollection<T>
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BD3")]
	private IList<T> items; //Field offset: 0x0

	[Token(Token = "0x17000820")]
	public override int Count
	{
		[Address(RVA = "0x6BFB26C", Offset = "0x6BFB26C", Length = "0x88")]
		[Token(Token = "0x60032F8")]
		 get { } //Length: 136
	}

	[Token(Token = "0x17000822")]
	public override T Item
	{
		[Address(RVA = "0x6BFB2FC", Offset = "0x6BFB2FC", Length = "0x98")]
		[Token(Token = "0x60032FA")]
		 get { } //Length: 152
		[Address(RVA = "0x6BFB394", Offset = "0x6BFB394", Length = "0x174")]
		[Token(Token = "0x60032FB")]
		 set { } //Length: 372
	}

	[Token(Token = "0x17000821")]
	protected IList<T> Items
	{
		[Address(RVA = "0x6BFB2F4", Offset = "0x6BFB2F4", Length = "0x8")]
		[Token(Token = "0x60032F9")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000823")]
	private override bool System.Collections.Generic.ICollection<T>.IsReadOnly
	{
		[Address(RVA = "0x6BFC060", Offset = "0x6BFC060", Length = "0x8C")]
		[Token(Token = "0x6003309")]
		private get { } //Length: 140
	}

	[Token(Token = "0x17000824")]
	private override bool System.Collections.ICollection.IsSynchronized
	{
		[Address(RVA = "0x6BFC18C", Offset = "0x6BFC18C", Length = "0x8")]
		[Token(Token = "0x600330B")]
		private get { } //Length: 8
	}

	[Token(Token = "0x17000825")]
	private override object System.Collections.ICollection.SyncRoot
	{
		[Address(RVA = "0x6BFC194", Offset = "0x6BFC194", Length = "0xBC")]
		[Token(Token = "0x600330C")]
		private get { } //Length: 188
	}

	[Token(Token = "0x17000828")]
	private override bool System.Collections.IList.IsFixedSize
	{
		[Address(RVA = "0x6BFC9D8", Offset = "0x6BFC9D8", Length = "0x128")]
		[Token(Token = "0x6003311")]
		private get { } //Length: 296
	}

	[Token(Token = "0x17000827")]
	private override bool System.Collections.IList.IsReadOnly
	{
		[Address(RVA = "0x6BFC94C", Offset = "0x6BFC94C", Length = "0x8C")]
		[Token(Token = "0x6003310")]
		private get { } //Length: 140
	}

	[Token(Token = "0x17000826")]
	private override object System.Collections.IList.Item
	{
		[Address(RVA = "0x6BFC710", Offset = "0x6BFC710", Length = "0xCC")]
		[Token(Token = "0x600330E")]
		private get { } //Length: 204
		[Address(RVA = "0x6BFC7DC", Offset = "0x6BFC7DC", Length = "0x170")]
		[Token(Token = "0x600330F")]
		private set { } //Length: 368
	}

	[Address(RVA = "0x6BFB1C0", Offset = "0x6BFB1C0", Length = "0x6C")]
	[Token(Token = "0x60032F6")]
	public Collection`1() { }

	[Address(RVA = "0x6BFB22C", Offset = "0x6BFB22C", Length = "0x40")]
	[Token(Token = "0x60032F7")]
	public Collection`1(IList<T> list) { }

	[Address(RVA = "0x6BFB508", Offset = "0x6BFB508", Length = "0x158")]
	[Token(Token = "0x60032FC")]
	public override void Add(T item) { }

	[Address(RVA = "0x6BFB660", Offset = "0x6BFB660", Length = "0xBC")]
	[Token(Token = "0x60032FD")]
	public override void Clear() { }

	[Address(RVA = "0x6BFBDD0", Offset = "0x6BFBDD0", Length = "0x8C")]
	[Token(Token = "0x6003305")]
	protected override void ClearItems() { }

	[Address(RVA = "0x6BFB7C0", Offset = "0x6BFB7C0", Length = "0xA4")]
	[Token(Token = "0x60032FF")]
	public override bool Contains(T item) { }

	[Address(RVA = "0x6BFB71C", Offset = "0x6BFB71C", Length = "0xA4")]
	[Token(Token = "0x60032FE")]
	public override void CopyTo(T[] array, int index) { }

	[Address(RVA = "0x6BFB26C", Offset = "0x6BFB26C", Length = "0x88")]
	[Token(Token = "0x60032F8")]
	public override int get_Count() { }

	[Address(RVA = "0x6BFB2FC", Offset = "0x6BFB2FC", Length = "0x98")]
	[Token(Token = "0x60032FA")]
	public override T get_Item(int index) { }

	[Address(RVA = "0x6BFB2F4", Offset = "0x6BFB2F4", Length = "0x8")]
	[Token(Token = "0x60032F9")]
	protected IList<T> get_Items() { }

	[Address(RVA = "0x6BFB864", Offset = "0x6BFB864", Length = "0x88")]
	[Token(Token = "0x6003300")]
	public override IEnumerator<T> GetEnumerator() { }

	[Address(RVA = "0x6BFB8EC", Offset = "0x6BFB8EC", Length = "0xA4")]
	[Token(Token = "0x6003301")]
	public override int IndexOf(T item) { }

	[Address(RVA = "0x6BFB990", Offset = "0x6BFB990", Length = "0x174")]
	[Token(Token = "0x6003302")]
	public override void Insert(int index, T item) { }

	[Address(RVA = "0x6BFBE5C", Offset = "0x6BFBE5C", Length = "0xB4")]
	[Token(Token = "0x6003306")]
	protected override void InsertItem(int index, T item) { }

	[Address(RVA = "0x6BFD1EC", Offset = "0x6BFD1EC", Length = "0xB0")]
	[Token(Token = "0x6003317")]
	private static bool IsCompatibleObject(object value) { }

	[Address(RVA = "0x6BFBB04", Offset = "0x6BFBB04", Length = "0x170")]
	[Token(Token = "0x6003303")]
	public override bool Remove(T item) { }

	[Address(RVA = "0x6BFBC74", Offset = "0x6BFBC74", Length = "0x15C")]
	[Token(Token = "0x6003304")]
	public override void RemoveAt(int index) { }

	[Address(RVA = "0x6BFBF10", Offset = "0x6BFBF10", Length = "0x9C")]
	[Token(Token = "0x6003307")]
	protected override void RemoveItem(int index) { }

	[Address(RVA = "0x6BFB394", Offset = "0x6BFB394", Length = "0x174")]
	[Token(Token = "0x60032FB")]
	public override void set_Item(int index, T value) { }

	[Address(RVA = "0x6BFBFAC", Offset = "0x6BFBFAC", Length = "0xB4")]
	[Token(Token = "0x6003308")]
	protected override void SetItem(int index, T item) { }

	[Address(RVA = "0x6BFC060", Offset = "0x6BFC060", Length = "0x8C")]
	[Token(Token = "0x6003309")]
	private override bool System.Collections.Generic.ICollection<T>.get_IsReadOnly() { }

	[Address(RVA = "0x6BFC250", Offset = "0x6BFC250", Length = "0x4C0")]
	[Token(Token = "0x600330D")]
	private override void System.Collections.ICollection.CopyTo(Array array, int index) { }

	[Address(RVA = "0x6BFC18C", Offset = "0x6BFC18C", Length = "0x8")]
	[Token(Token = "0x600330B")]
	private override bool System.Collections.ICollection.get_IsSynchronized() { }

	[Address(RVA = "0x6BFC194", Offset = "0x6BFC194", Length = "0xBC")]
	[Token(Token = "0x600330C")]
	private override object System.Collections.ICollection.get_SyncRoot() { }

	[Address(RVA = "0x6BFC0EC", Offset = "0x6BFC0EC", Length = "0xA0")]
	[Token(Token = "0x600330A")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	[Address(RVA = "0x6BFCB00", Offset = "0x6BFCB00", Length = "0x210")]
	[Token(Token = "0x6003312")]
	private override int System.Collections.IList.Add(object value) { }

	[Address(RVA = "0x6BFCD10", Offset = "0x6BFCD10", Length = "0xC4")]
	[Token(Token = "0x6003313")]
	private override bool System.Collections.IList.Contains(object value) { }

	[Address(RVA = "0x6BFC9D8", Offset = "0x6BFC9D8", Length = "0x128")]
	[Token(Token = "0x6003311")]
	private override bool System.Collections.IList.get_IsFixedSize() { }

	[Address(RVA = "0x6BFC94C", Offset = "0x6BFC94C", Length = "0x8C")]
	[Token(Token = "0x6003310")]
	private override bool System.Collections.IList.get_IsReadOnly() { }

	[Address(RVA = "0x6BFC710", Offset = "0x6BFC710", Length = "0xCC")]
	[Token(Token = "0x600330E")]
	private override object System.Collections.IList.get_Item(int index) { }

	[Address(RVA = "0x6BFCDD4", Offset = "0x6BFCDD4", Length = "0xC4")]
	[Token(Token = "0x6003314")]
	private override int System.Collections.IList.IndexOf(object value) { }

	[Address(RVA = "0x6BFCE98", Offset = "0x6BFCE98", Length = "0x204")]
	[Token(Token = "0x6003315")]
	private override void System.Collections.IList.Insert(int index, object value) { }

	[Address(RVA = "0x6BFD09C", Offset = "0x6BFD09C", Length = "0x150")]
	[Token(Token = "0x6003316")]
	private override void System.Collections.IList.Remove(object value) { }

	[Address(RVA = "0x6BFC7DC", Offset = "0x6BFC7DC", Length = "0x170")]
	[Token(Token = "0x600330F")]
	private override void System.Collections.IList.set_Item(int index, object value) { }

}

