namespace System.Collections.ObjectModel;

[DebuggerDisplay("Count = {Count}")]
[DebuggerTypeProxy(typeof(CollectionDebugView`1))]
[DefaultMember("Item")]
[Token(Token = "0x2000673")]
public abstract class KeyedCollection : Collection<TItem>
{
	[Token(Token = "0x4001BD6")]
	private const int defaultThreshold = 0; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BD7")]
	private readonly IEqualityComparer<TKey> comparer; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BD8")]
	private Dictionary<TKey, TItem> dict; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BD9")]
	private int keyCount; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BDA")]
	private readonly int threshold; //Field offset: 0x0

	[Token(Token = "0x17000835")]
	protected IDictionary<TKey, TItem> Dictionary
	{
		[Address(RVA = "0x515F05C", Offset = "0x515F05C", Length = "0x8")]
		[Token(Token = "0x6003340")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000834")]
	public TItem Item
	{
		[Address(RVA = "0x515E970", Offset = "0x515E970", Length = "0xCC")]
		[Token(Token = "0x600333C")]
		 get { } //Length: 204
	}

	[Token(Token = "0x17000833")]
	private List<TItem> Items
	{
		[Address(RVA = "0x515E8E8", Offset = "0x515E8E8", Length = "0x88")]
		[Token(Token = "0x600333B")]
		private get { } //Length: 136
	}

	[Address(RVA = "0x515E780", Offset = "0x515E780", Length = "0x1C")]
	[Token(Token = "0x6003338")]
	protected KeyedCollection`2() { }

	[Address(RVA = "0x515E79C", Offset = "0x515E79C", Length = "0x18")]
	[Token(Token = "0x6003339")]
	protected KeyedCollection`2(IEqualityComparer<TKey> comparer) { }

	[Address(RVA = "0x515E7B4", Offset = "0x515E7B4", Length = "0x134")]
	[Token(Token = "0x600333A")]
	protected KeyedCollection`2(IEqualityComparer<TKey> comparer, int dictionaryCreationThreshold) { }

	[Address(RVA = "0x515F388", Offset = "0x515F388", Length = "0x12C")]
	[Token(Token = "0x6003346")]
	private void AddKey(TKey key, TItem item) { }

	[Address(RVA = "0x515F064", Offset = "0x515F064", Length = "0x58")]
	[Token(Token = "0x6003341")]
	protected virtual void ClearItems() { }

	[Address(RVA = "0x515EA3C", Offset = "0x515EA3C", Length = "0x1F8")]
	[Token(Token = "0x600333D")]
	public bool Contains(TKey key) { }

	[Address(RVA = "0x515F4B4", Offset = "0x515F4B4", Length = "0x1B8")]
	[Token(Token = "0x6003347")]
	private void CreateDictionary() { }

	[Address(RVA = "0x515F05C", Offset = "0x515F05C", Length = "0x8")]
	[Token(Token = "0x6003340")]
	protected IDictionary<TKey, TItem> get_Dictionary() { }

	[Address(RVA = "0x515E970", Offset = "0x515E970", Length = "0xCC")]
	[Token(Token = "0x600333C")]
	public TItem get_Item(TKey key) { }

	[Address(RVA = "0x515E8E8", Offset = "0x515E8E8", Length = "0x88")]
	[Token(Token = "0x600333B")]
	private List<TItem> get_Items() { }

	[Token(Token = "0x6003342")]
	protected abstract TKey GetKeyForItem(TItem item) { }

	[Address(RVA = "0x515F0BC", Offset = "0x515F0BC", Length = "0x7C")]
	[Token(Token = "0x6003343")]
	protected virtual void InsertItem(int index, TItem item) { }

	[Address(RVA = "0x515EE84", Offset = "0x515EE84", Length = "0x1D8")]
	[Token(Token = "0x600333F")]
	public bool Remove(TKey key) { }

	[Address(RVA = "0x515F138", Offset = "0x515F138", Length = "0xA0")]
	[Token(Token = "0x6003344")]
	protected virtual void RemoveItem(int index) { }

	[Address(RVA = "0x515F66C", Offset = "0x515F66C", Length = "0x34")]
	[Token(Token = "0x6003348")]
	private void RemoveKey(TKey key) { }

	[Address(RVA = "0x515F1D8", Offset = "0x515F1D8", Length = "0x1B0")]
	[Token(Token = "0x6003345")]
	protected virtual void SetItem(int index, TItem item) { }

	[Address(RVA = "0x515EC34", Offset = "0x515EC34", Length = "0x250")]
	[Token(Token = "0x600333E")]
	public bool TryGetValue(TKey key, out TItem item) { }

}

