namespace System.Collections.ObjectModel;

[DebuggerDisplay("Count = {Count}")]
[DebuggerTypeProxy(typeof(ICollectionDebugView`1))]
[DefaultMember("Item")]
[Token(Token = "0x2000672")]
public class ReadOnlyCollection : IList<T>, ICollection<T>, IEnumerable<T>, IEnumerable, IList, ICollection, IReadOnlyList<T>, IReadOnlyCollection<T>
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BD4")]
	private IList<T> list; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BD5")]
	private object _syncRoot; //Field offset: 0x0

	[Token(Token = "0x17000829")]
	public override int Count
	{
		[Address(RVA = "0x5BDB21C", Offset = "0x5BDB21C", Length = "0x88")]
		[Token(Token = "0x6003319")]
		 get { } //Length: 136
	}

	[Token(Token = "0x1700082A")]
	public override T Item
	{
		[Address(RVA = "0x5BDB2A4", Offset = "0x5BDB2A4", Length = "0x98")]
		[Token(Token = "0x600331A")]
		 get { } //Length: 152
	}

	[Token(Token = "0x1700082B")]
	protected IList<T> Items
	{
		[Address(RVA = "0x5BDB5B0", Offset = "0x5BDB5B0", Length = "0x8")]
		[Token(Token = "0x600331F")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700082C")]
	private override bool System.Collections.Generic.ICollection<T>.IsReadOnly
	{
		[Address(RVA = "0x5BDB5B8", Offset = "0x5BDB5B8", Length = "0x8")]
		[Token(Token = "0x6003320")]
		private get { } //Length: 8
	}

	[Token(Token = "0x1700082D")]
	private override T System.Collections.Generic.IList<T>.Item
	{
		[Address(RVA = "0x5BDB5C0", Offset = "0x5BDB5C0", Length = "0x98")]
		[Token(Token = "0x6003321")]
		private get { } //Length: 152
		[Address(RVA = "0x5BDB658", Offset = "0x5BDB658", Length = "0xC")]
		[Token(Token = "0x6003322")]
		private set { } //Length: 12
	}

	[Token(Token = "0x1700082E")]
	private override bool System.Collections.ICollection.IsSynchronized
	{
		[Address(RVA = "0x5BDB750", Offset = "0x5BDB750", Length = "0x8")]
		[Token(Token = "0x6003329")]
		private get { } //Length: 8
	}

	[Token(Token = "0x1700082F")]
	private override object System.Collections.ICollection.SyncRoot
	{
		[Address(RVA = "0x5BDB758", Offset = "0x5BDB758", Length = "0x114")]
		[Token(Token = "0x600332A")]
		private get { } //Length: 276
	}

	[Token(Token = "0x17000830")]
	private override bool System.Collections.IList.IsFixedSize
	{
		[Address(RVA = "0x5BDBD2C", Offset = "0x5BDBD2C", Length = "0x8")]
		[Token(Token = "0x600332C")]
		private get { } //Length: 8
	}

	[Token(Token = "0x17000831")]
	private override bool System.Collections.IList.IsReadOnly
	{
		[Address(RVA = "0x5BDBD34", Offset = "0x5BDBD34", Length = "0x8")]
		[Token(Token = "0x600332D")]
		private get { } //Length: 8
	}

	[Token(Token = "0x17000832")]
	private override object System.Collections.IList.Item
	{
		[Address(RVA = "0x5BDBD3C", Offset = "0x5BDBD3C", Length = "0xCC")]
		[Token(Token = "0x600332E")]
		private get { } //Length: 204
		[Address(RVA = "0x5BDBE08", Offset = "0x5BDBE08", Length = "0xC")]
		[Token(Token = "0x600332F")]
		private set { } //Length: 12
	}

	[Address(RVA = "0x5BDB1DC", Offset = "0x5BDB1DC", Length = "0x40")]
	[Token(Token = "0x6003318")]
	public ReadOnlyCollection`1(IList<T> list) { }

	[Address(RVA = "0x5BDB33C", Offset = "0x5BDB33C", Length = "0xA4")]
	[Token(Token = "0x600331B")]
	public override bool Contains(T value) { }

	[Address(RVA = "0x5BDB3E0", Offset = "0x5BDB3E0", Length = "0xA4")]
	[Token(Token = "0x600331C")]
	public override void CopyTo(T[] array, int index) { }

	[Address(RVA = "0x5BDB21C", Offset = "0x5BDB21C", Length = "0x88")]
	[Token(Token = "0x6003319")]
	public override int get_Count() { }

	[Address(RVA = "0x5BDB2A4", Offset = "0x5BDB2A4", Length = "0x98")]
	[Token(Token = "0x600331A")]
	public override T get_Item(int index) { }

	[Address(RVA = "0x5BDB5B0", Offset = "0x5BDB5B0", Length = "0x8")]
	[Token(Token = "0x600331F")]
	protected IList<T> get_Items() { }

	[Address(RVA = "0x5BDB484", Offset = "0x5BDB484", Length = "0x88")]
	[Token(Token = "0x600331D")]
	public override IEnumerator<T> GetEnumerator() { }

	[Address(RVA = "0x5BDB50C", Offset = "0x5BDB50C", Length = "0xA4")]
	[Token(Token = "0x600331E")]
	public override int IndexOf(T value) { }

	[Address(RVA = "0x5BDBE3C", Offset = "0x5BDBE3C", Length = "0xB0")]
	[Token(Token = "0x6003332")]
	private static bool IsCompatibleObject(object value) { }

	[Address(RVA = "0x5BDB664", Offset = "0x5BDB664", Length = "0xC")]
	[Token(Token = "0x6003323")]
	private override void System.Collections.Generic.ICollection<T>.Add(T value) { }

	[Address(RVA = "0x5BDB670", Offset = "0x5BDB670", Length = "0xC")]
	[Token(Token = "0x6003324")]
	private override void System.Collections.Generic.ICollection<T>.Clear() { }

	[Address(RVA = "0x5BDB5B8", Offset = "0x5BDB5B8", Length = "0x8")]
	[Token(Token = "0x6003320")]
	private override bool System.Collections.Generic.ICollection<T>.get_IsReadOnly() { }

	[Address(RVA = "0x5BDB688", Offset = "0x5BDB688", Length = "0x1C")]
	[Token(Token = "0x6003326")]
	private override bool System.Collections.Generic.ICollection<T>.Remove(T value) { }

	[Address(RVA = "0x5BDB5C0", Offset = "0x5BDB5C0", Length = "0x98")]
	[Token(Token = "0x6003321")]
	private override T System.Collections.Generic.IList<T>.get_Item(int index) { }

	[Address(RVA = "0x5BDB67C", Offset = "0x5BDB67C", Length = "0xC")]
	[Token(Token = "0x6003325")]
	private override void System.Collections.Generic.IList<T>.Insert(int index, T value) { }

	[Address(RVA = "0x5BDB6A4", Offset = "0x5BDB6A4", Length = "0xC")]
	[Token(Token = "0x6003327")]
	private override void System.Collections.Generic.IList<T>.RemoveAt(int index) { }

	[Address(RVA = "0x5BDB658", Offset = "0x5BDB658", Length = "0xC")]
	[Token(Token = "0x6003322")]
	private override void System.Collections.Generic.IList<T>.set_Item(int index, T value) { }

	[Address(RVA = "0x5BDB86C", Offset = "0x5BDB86C", Length = "0x4C0")]
	[Token(Token = "0x600332B")]
	private override void System.Collections.ICollection.CopyTo(Array array, int index) { }

	[Address(RVA = "0x5BDB750", Offset = "0x5BDB750", Length = "0x8")]
	[Token(Token = "0x6003329")]
	private override bool System.Collections.ICollection.get_IsSynchronized() { }

	[Address(RVA = "0x5BDB758", Offset = "0x5BDB758", Length = "0x114")]
	[Token(Token = "0x600332A")]
	private override object System.Collections.ICollection.get_SyncRoot() { }

	[Address(RVA = "0x5BDB6B0", Offset = "0x5BDB6B0", Length = "0xA0")]
	[Token(Token = "0x6003328")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	[Address(RVA = "0x5BDBE14", Offset = "0x5BDBE14", Length = "0x1C")]
	[Token(Token = "0x6003330")]
	private override int System.Collections.IList.Add(object value) { }

	[Address(RVA = "0x5BDBE30", Offset = "0x5BDBE30", Length = "0xC")]
	[Token(Token = "0x6003331")]
	private override void System.Collections.IList.Clear() { }

	[Address(RVA = "0x5BDBEEC", Offset = "0x5BDBEEC", Length = "0xC4")]
	[Token(Token = "0x6003333")]
	private override bool System.Collections.IList.Contains(object value) { }

	[Address(RVA = "0x5BDBD2C", Offset = "0x5BDBD2C", Length = "0x8")]
	[Token(Token = "0x600332C")]
	private override bool System.Collections.IList.get_IsFixedSize() { }

	[Address(RVA = "0x5BDBD34", Offset = "0x5BDBD34", Length = "0x8")]
	[Token(Token = "0x600332D")]
	private override bool System.Collections.IList.get_IsReadOnly() { }

	[Address(RVA = "0x5BDBD3C", Offset = "0x5BDBD3C", Length = "0xCC")]
	[Token(Token = "0x600332E")]
	private override object System.Collections.IList.get_Item(int index) { }

	[Address(RVA = "0x5BDBFB0", Offset = "0x5BDBFB0", Length = "0xC4")]
	[Token(Token = "0x6003334")]
	private override int System.Collections.IList.IndexOf(object value) { }

	[Address(RVA = "0x5BDC074", Offset = "0x5BDC074", Length = "0xC")]
	[Token(Token = "0x6003335")]
	private override void System.Collections.IList.Insert(int index, object value) { }

	[Address(RVA = "0x5BDC080", Offset = "0x5BDC080", Length = "0xC")]
	[Token(Token = "0x6003336")]
	private override void System.Collections.IList.Remove(object value) { }

	[Address(RVA = "0x5BDC08C", Offset = "0x5BDC08C", Length = "0xC")]
	[Token(Token = "0x6003337")]
	private override void System.Collections.IList.RemoveAt(int index) { }

	[Address(RVA = "0x5BDBE08", Offset = "0x5BDBE08", Length = "0xC")]
	[Token(Token = "0x600332F")]
	private override void System.Collections.IList.set_Item(int index, object value) { }

}

