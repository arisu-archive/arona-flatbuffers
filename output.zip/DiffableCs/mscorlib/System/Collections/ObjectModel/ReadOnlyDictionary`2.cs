namespace System.Collections.ObjectModel;

[DebuggerDisplay("Count = {Count}")]
[DebuggerTypeProxy(typeof(DictionaryDebugView`2))]
[DefaultMember("Item")]
[Token(Token = "0x2000674")]
public class ReadOnlyDictionary : IDictionary<TKey, TValue>, ICollection<KeyValuePair`2<TKey, TValue>>, IEnumerable<KeyValuePair`2<TKey, TValue>>, IEnumerable, IDictionary, ICollection, IReadOnlyDictionary<TKey, TValue>, IReadOnlyCollection<KeyValuePair`2<TKey, TValue>>
{
	[Token(Token = "0x2000675")]
	private struct DictionaryEnumerator : IDictionaryEnumerator, IEnumerator
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BDF")]
		private readonly IDictionary<TKey, TValue> _dictionary; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BE0")]
		private IEnumerator<KeyValuePair`2<TKey, TValue>> _enumerator; //Field offset: 0x0

		[Token(Token = "0x1700084A")]
		public override object Current
		{
			[Address(RVA = "0x6E42594", Offset = "0x6E42594", Length = "0x80")]
			[Token(Token = "0x6003373")]
			 get { } //Length: 128
		}

		[Token(Token = "0x17000847")]
		public override DictionaryEntry Entry
		{
			[Address(RVA = "0x6E42298", Offset = "0x6E42298", Length = "0x180")]
			[Token(Token = "0x6003370")]
			 get { } //Length: 384
		}

		[Token(Token = "0x17000848")]
		public override object Key
		{
			[Address(RVA = "0x6E42418", Offset = "0x6E42418", Length = "0xC0")]
			[Token(Token = "0x6003371")]
			 get { } //Length: 192
		}

		[Token(Token = "0x17000849")]
		public override object Value
		{
			[Address(RVA = "0x6E424D8", Offset = "0x6E424D8", Length = "0xBC")]
			[Token(Token = "0x6003372")]
			 get { } //Length: 188
		}

		[Address(RVA = "0x6E421DC", Offset = "0x6E421DC", Length = "0xBC")]
		[Token(Token = "0x600336F")]
		public DictionaryEnumerator(IDictionary<TKey, TValue> dictionary) { }

		[Address(RVA = "0x6E42594", Offset = "0x6E42594", Length = "0x80")]
		[Token(Token = "0x6003373")]
		public override object get_Current() { }

		[Address(RVA = "0x6E42298", Offset = "0x6E42298", Length = "0x180")]
		[Token(Token = "0x6003370")]
		public override DictionaryEntry get_Entry() { }

		[Address(RVA = "0x6E42418", Offset = "0x6E42418", Length = "0xC0")]
		[Token(Token = "0x6003371")]
		public override object get_Key() { }

		[Address(RVA = "0x6E424D8", Offset = "0x6E424D8", Length = "0xBC")]
		[Token(Token = "0x6003372")]
		public override object get_Value() { }

		[Address(RVA = "0x6E42614", Offset = "0x6E42614", Length = "0xA0")]
		[Token(Token = "0x6003374")]
		public override bool MoveNext() { }

		[Address(RVA = "0x6E426B4", Offset = "0x6E426B4", Length = "0xA4")]
		[Token(Token = "0x6003375")]
		public override void Reset() { }

	}

	[DebuggerDisplay("Count = {Count}")]
	[DebuggerTypeProxy(typeof(CollectionDebugView`1))]
	[Token(Token = "0x2000676")]
	internal sealed class KeyCollection : ICollection<TKey>, IEnumerable<TKey>, IEnumerable, ICollection, IReadOnlyCollection<TKey>
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BE1")]
		private readonly ICollection<TKey> _collection; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BE2")]
		private object _syncRoot; //Field offset: 0x0

		[Token(Token = "0x1700084B")]
		public override int Count
		{
			[Address(RVA = "0x5129FA8", Offset = "0x5129FA8", Length = "0x88")]
			[Token(Token = "0x600337B")]
			 get { } //Length: 136
		}

		[Token(Token = "0x1700084C")]
		private override bool System.Collections.Generic.ICollection<TKey>.IsReadOnly
		{
			[Address(RVA = "0x512A030", Offset = "0x512A030", Length = "0x8")]
			[Token(Token = "0x600337C")]
			private get { } //Length: 8
		}

		[Token(Token = "0x1700084D")]
		private override bool System.Collections.ICollection.IsSynchronized
		{
			[Address(RVA = "0x512A1C8", Offset = "0x512A1C8", Length = "0x8")]
			[Token(Token = "0x6003381")]
			private get { } //Length: 8
		}

		[Token(Token = "0x1700084E")]
		private override object System.Collections.ICollection.SyncRoot
		{
			[Address(RVA = "0x512A1D0", Offset = "0x512A1D0", Length = "0x114")]
			[Token(Token = "0x6003382")]
			private get { } //Length: 276
		}

		[Address(RVA = "0x5129D48", Offset = "0x5129D48", Length = "0x80")]
		[Token(Token = "0x6003376")]
		internal KeyCollection(ICollection<TKey> collection) { }

		[Address(RVA = "0x512A2E4", Offset = "0x512A2E4", Length = "0x38")]
		[Token(Token = "0x6003383")]
		internal KeyCollection() { }

		[Address(RVA = "0x5129F04", Offset = "0x5129F04", Length = "0xA4")]
		[Token(Token = "0x600337A")]
		public override void CopyTo(TKey[] array, int arrayIndex) { }

		[Address(RVA = "0x5129FA8", Offset = "0x5129FA8", Length = "0x88")]
		[Token(Token = "0x600337B")]
		public override int get_Count() { }

		[Address(RVA = "0x512A088", Offset = "0x512A088", Length = "0x88")]
		[Token(Token = "0x600337E")]
		public override IEnumerator<TKey> GetEnumerator() { }

		[Address(RVA = "0x5129DC8", Offset = "0x5129DC8", Length = "0x50")]
		[Token(Token = "0x6003377")]
		private override void System.Collections.Generic.ICollection<TKey>.Add(TKey item) { }

		[Address(RVA = "0x5129E18", Offset = "0x5129E18", Length = "0x50")]
		[Token(Token = "0x6003378")]
		private override void System.Collections.Generic.ICollection<TKey>.Clear() { }

		[Address(RVA = "0x5129E68", Offset = "0x5129E68", Length = "0x9C")]
		[Token(Token = "0x6003379")]
		private override bool System.Collections.Generic.ICollection<TKey>.Contains(TKey item) { }

		[Address(RVA = "0x512A030", Offset = "0x512A030", Length = "0x8")]
		[Token(Token = "0x600337C")]
		private override bool System.Collections.Generic.ICollection<TKey>.get_IsReadOnly() { }

		[Address(RVA = "0x512A038", Offset = "0x512A038", Length = "0x50")]
		[Token(Token = "0x600337D")]
		private override bool System.Collections.Generic.ICollection<TKey>.Remove(TKey item) { }

		[Address(RVA = "0x512A1B0", Offset = "0x512A1B0", Length = "0x18")]
		[Token(Token = "0x6003380")]
		private override void System.Collections.ICollection.CopyTo(Array array, int index) { }

		[Address(RVA = "0x512A1C8", Offset = "0x512A1C8", Length = "0x8")]
		[Token(Token = "0x6003381")]
		private override bool System.Collections.ICollection.get_IsSynchronized() { }

		[Address(RVA = "0x512A1D0", Offset = "0x512A1D0", Length = "0x114")]
		[Token(Token = "0x6003382")]
		private override object System.Collections.ICollection.get_SyncRoot() { }

		[Address(RVA = "0x512A110", Offset = "0x512A110", Length = "0xA0")]
		[Token(Token = "0x600337F")]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	}

	[DebuggerDisplay("Count = {Count}")]
	[DebuggerTypeProxy(typeof(CollectionDebugView`1))]
	[Token(Token = "0x2000677")]
	internal sealed class ValueCollection : ICollection<TValue>, IEnumerable<TValue>, IEnumerable, ICollection, IReadOnlyCollection<TValue>
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BE3")]
		private readonly ICollection<TValue> _collection; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001BE4")]
		private object _syncRoot; //Field offset: 0x0

		[Token(Token = "0x1700084F")]
		public override int Count
		{
			[Address(RVA = "0x612C448", Offset = "0x612C448", Length = "0x88")]
			[Token(Token = "0x6003389")]
			 get { } //Length: 136
		}

		[Token(Token = "0x17000850")]
		private override bool System.Collections.Generic.ICollection<TValue>.IsReadOnly
		{
			[Address(RVA = "0x612C4D0", Offset = "0x612C4D0", Length = "0x8")]
			[Token(Token = "0x600338A")]
			private get { } //Length: 8
		}

		[Token(Token = "0x17000851")]
		private override bool System.Collections.ICollection.IsSynchronized
		{
			[Address(RVA = "0x612C668", Offset = "0x612C668", Length = "0x8")]
			[Token(Token = "0x600338F")]
			private get { } //Length: 8
		}

		[Token(Token = "0x17000852")]
		private override object System.Collections.ICollection.SyncRoot
		{
			[Address(RVA = "0x612C670", Offset = "0x612C670", Length = "0x114")]
			[Token(Token = "0x6003390")]
			private get { } //Length: 276
		}

		[Address(RVA = "0x612C1E8", Offset = "0x612C1E8", Length = "0x80")]
		[Token(Token = "0x6003384")]
		internal ValueCollection(ICollection<TValue> collection) { }

		[Address(RVA = "0x612C784", Offset = "0x612C784", Length = "0x38")]
		[Token(Token = "0x6003391")]
		internal ValueCollection() { }

		[Address(RVA = "0x612C3A4", Offset = "0x612C3A4", Length = "0xA4")]
		[Token(Token = "0x6003388")]
		public override void CopyTo(TValue[] array, int arrayIndex) { }

		[Address(RVA = "0x612C448", Offset = "0x612C448", Length = "0x88")]
		[Token(Token = "0x6003389")]
		public override int get_Count() { }

		[Address(RVA = "0x612C528", Offset = "0x612C528", Length = "0x88")]
		[Token(Token = "0x600338C")]
		public override IEnumerator<TValue> GetEnumerator() { }

		[Address(RVA = "0x612C268", Offset = "0x612C268", Length = "0x50")]
		[Token(Token = "0x6003385")]
		private override void System.Collections.Generic.ICollection<TValue>.Add(TValue item) { }

		[Address(RVA = "0x612C2B8", Offset = "0x612C2B8", Length = "0x50")]
		[Token(Token = "0x6003386")]
		private override void System.Collections.Generic.ICollection<TValue>.Clear() { }

		[Address(RVA = "0x612C308", Offset = "0x612C308", Length = "0x9C")]
		[Token(Token = "0x6003387")]
		private override bool System.Collections.Generic.ICollection<TValue>.Contains(TValue item) { }

		[Address(RVA = "0x612C4D0", Offset = "0x612C4D0", Length = "0x8")]
		[Token(Token = "0x600338A")]
		private override bool System.Collections.Generic.ICollection<TValue>.get_IsReadOnly() { }

		[Address(RVA = "0x612C4D8", Offset = "0x612C4D8", Length = "0x50")]
		[Token(Token = "0x600338B")]
		private override bool System.Collections.Generic.ICollection<TValue>.Remove(TValue item) { }

		[Address(RVA = "0x612C650", Offset = "0x612C650", Length = "0x18")]
		[Token(Token = "0x600338E")]
		private override void System.Collections.ICollection.CopyTo(Array array, int index) { }

		[Address(RVA = "0x612C668", Offset = "0x612C668", Length = "0x8")]
		[Token(Token = "0x600338F")]
		private override bool System.Collections.ICollection.get_IsSynchronized() { }

		[Address(RVA = "0x612C670", Offset = "0x612C670", Length = "0x114")]
		[Token(Token = "0x6003390")]
		private override object System.Collections.ICollection.get_SyncRoot() { }

		[Address(RVA = "0x612C5B0", Offset = "0x612C5B0", Length = "0xA0")]
		[Token(Token = "0x600338D")]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	}

	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BDB")]
	private readonly IDictionary<TKey, TValue> m_dictionary; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BDC")]
	private object _syncRoot; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BDD")]
	private KeyCollection<TKey, TValue> _keys; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001BDE")]
	private ValueCollection<TKey, TValue> _values; //Field offset: 0x0

	[Token(Token = "0x1700083C")]
	public override int Count
	{
		[Address(RVA = "0x5E0B91C", Offset = "0x5E0B91C", Length = "0x88")]
		[Token(Token = "0x6003355")]
		 get { } //Length: 136
	}

	[Token(Token = "0x1700083A")]
	public override TValue Item
	{
		[Address(RVA = "0x5E0B6FC", Offset = "0x5E0B6FC", Length = "0x98")]
		[Token(Token = "0x6003350")]
		 get { } //Length: 152
	}

	[Token(Token = "0x17000836")]
	public KeyCollection<TKey, TValue> Keys
	{
		[Address(RVA = "0x5E0B36C", Offset = "0x5E0B36C", Length = "0x114")]
		[Token(Token = "0x600334A")]
		 get { } //Length: 276
	}

	[Token(Token = "0x1700083D")]
	private override bool System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.IsReadOnly
	{
		[Address(RVA = "0x5E0BAEC", Offset = "0x5E0BAEC", Length = "0x8")]
		[Token(Token = "0x6003358")]
		private get { } //Length: 8
	}

	[Token(Token = "0x1700083B")]
	private override TValue System.Collections.Generic.IDictionary<TKey,TValue>.Item
	{
		[Address(RVA = "0x5E0B834", Offset = "0x5E0B834", Length = "0x98")]
		[Token(Token = "0x6003353")]
		private get { } //Length: 152
		[Address(RVA = "0x5E0B8CC", Offset = "0x5E0B8CC", Length = "0x50")]
		[Token(Token = "0x6003354")]
		private set { } //Length: 80
	}

	[Token(Token = "0x17000838")]
	private override ICollection<TKey> System.Collections.Generic.IDictionary<TKey,TValue>.Keys
	{
		[Address(RVA = "0x5E0B630", Offset = "0x5E0B630", Length = "0x14")]
		[Token(Token = "0x600334D")]
		private get { } //Length: 20
	}

	[Token(Token = "0x17000839")]
	private override ICollection<TValue> System.Collections.Generic.IDictionary<TKey,TValue>.Values
	{
		[Address(RVA = "0x5E0B6E8", Offset = "0x5E0B6E8", Length = "0x14")]
		[Token(Token = "0x600334F")]
		private get { } //Length: 20
	}

	[Token(Token = "0x17000845")]
	private override IEnumerable<TKey> System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.Keys
	{
		[Address(RVA = "0x5E0CC3C", Offset = "0x5E0CC3C", Length = "0x14")]
		[Token(Token = "0x600336D")]
		private get { } //Length: 20
	}

	[Token(Token = "0x17000846")]
	private override IEnumerable<TValue> System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.Values
	{
		[Address(RVA = "0x5E0CC50", Offset = "0x5E0CC50", Length = "0x14")]
		[Token(Token = "0x600336E")]
		private get { } //Length: 20
	}

	[Token(Token = "0x17000843")]
	private override bool System.Collections.ICollection.IsSynchronized
	{
		[Address(RVA = "0x5E0CB20", Offset = "0x5E0CB20", Length = "0x8")]
		[Token(Token = "0x600336B")]
		private get { } //Length: 8
	}

	[Token(Token = "0x17000844")]
	private override object System.Collections.ICollection.SyncRoot
	{
		[Address(RVA = "0x5E0CB28", Offset = "0x5E0CB28", Length = "0x114")]
		[Token(Token = "0x600336C")]
		private get { } //Length: 276
	}

	[Token(Token = "0x1700083E")]
	private override bool System.Collections.IDictionary.IsFixedSize
	{
		[Address(RVA = "0x5E0C020", Offset = "0x5E0C020", Length = "0x8")]
		[Token(Token = "0x6003363")]
		private get { } //Length: 8
	}

	[Token(Token = "0x1700083F")]
	private override bool System.Collections.IDictionary.IsReadOnly
	{
		[Address(RVA = "0x5E0C028", Offset = "0x5E0C028", Length = "0x8")]
		[Token(Token = "0x6003364")]
		private get { } //Length: 8
	}

	[Token(Token = "0x17000842")]
	private override object System.Collections.IDictionary.Item
	{
		[Address(RVA = "0x5E0C0A8", Offset = "0x5E0C0A8", Length = "0xC0")]
		[Token(Token = "0x6003368")]
		private get { } //Length: 192
		[Address(RVA = "0x5E0C168", Offset = "0x5E0C168", Length = "0x50")]
		[Token(Token = "0x6003369")]
		private set { } //Length: 80
	}

	[Token(Token = "0x17000840")]
	private override ICollection System.Collections.IDictionary.Keys
	{
		[Address(RVA = "0x5E0C030", Offset = "0x5E0C030", Length = "0x14")]
		[Token(Token = "0x6003365")]
		private get { } //Length: 20
	}

	[Token(Token = "0x17000841")]
	private override ICollection System.Collections.IDictionary.Values
	{
		[Address(RVA = "0x5E0C094", Offset = "0x5E0C094", Length = "0x14")]
		[Token(Token = "0x6003367")]
		private get { } //Length: 20
	}

	[Token(Token = "0x17000837")]
	public ValueCollection<TKey, TValue> Values
	{
		[Address(RVA = "0x5E0B480", Offset = "0x5E0B480", Length = "0x114")]
		[Token(Token = "0x600334B")]
		 get { } //Length: 276
	}

	[Address(RVA = "0x5E0B2EC", Offset = "0x5E0B2EC", Length = "0x80")]
	[Token(Token = "0x6003349")]
	public ReadOnlyDictionary`2(IDictionary<TKey, TValue> dictionary) { }

	[Address(RVA = "0x5E0B594", Offset = "0x5E0B594", Length = "0x9C")]
	[Token(Token = "0x600334C")]
	public override bool ContainsKey(TKey key) { }

	[Address(RVA = "0x5E0B91C", Offset = "0x5E0B91C", Length = "0x88")]
	[Token(Token = "0x6003355")]
	public override int get_Count() { }

	[Address(RVA = "0x5E0B6FC", Offset = "0x5E0B6FC", Length = "0x98")]
	[Token(Token = "0x6003350")]
	public override TValue get_Item(TKey key) { }

	[Address(RVA = "0x5E0B36C", Offset = "0x5E0B36C", Length = "0x114")]
	[Token(Token = "0x600334A")]
	public KeyCollection<TKey, TValue> get_Keys() { }

	[Address(RVA = "0x5E0B480", Offset = "0x5E0B480", Length = "0x114")]
	[Token(Token = "0x600334B")]
	public ValueCollection<TKey, TValue> get_Values() { }

	[Address(RVA = "0x5E0BBE4", Offset = "0x5E0BBE4", Length = "0x88")]
	[Token(Token = "0x600335C")]
	public override IEnumerator<KeyValuePair`2<TKey, TValue>> GetEnumerator() { }

	[Address(RVA = "0x5E0BD0C", Offset = "0x5E0BD0C", Length = "0x9C")]
	[Token(Token = "0x600335E")]
	private static bool IsCompatibleKey(object key) { }

	[Address(RVA = "0x5E0BAF4", Offset = "0x5E0BAF4", Length = "0x50")]
	[Token(Token = "0x6003359")]
	private override void System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Add(KeyValuePair<TKey, TValue> item) { }

	[Address(RVA = "0x5E0BB44", Offset = "0x5E0BB44", Length = "0x50")]
	[Token(Token = "0x600335A")]
	private override void System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Clear() { }

	[Address(RVA = "0x5E0B9A4", Offset = "0x5E0B9A4", Length = "0xA4")]
	[Token(Token = "0x6003356")]
	private override bool System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Contains(KeyValuePair<TKey, TValue> item) { }

	[Address(RVA = "0x5E0BA48", Offset = "0x5E0BA48", Length = "0xA4")]
	[Token(Token = "0x6003357")]
	private override void System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.CopyTo(KeyValuePair<TKey, TValue>[] array, int arrayIndex) { }

	[Address(RVA = "0x5E0BAEC", Offset = "0x5E0BAEC", Length = "0x8")]
	[Token(Token = "0x6003358")]
	private override bool System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.get_IsReadOnly() { }

	[Address(RVA = "0x5E0BB94", Offset = "0x5E0BB94", Length = "0x50")]
	[Token(Token = "0x600335B")]
	private override bool System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Remove(KeyValuePair<TKey, TValue> item) { }

	[Address(RVA = "0x5E0B794", Offset = "0x5E0B794", Length = "0x50")]
	[Token(Token = "0x6003351")]
	private override void System.Collections.Generic.IDictionary<TKey,TValue>.Add(TKey key, TValue value) { }

	[Address(RVA = "0x5E0B834", Offset = "0x5E0B834", Length = "0x98")]
	[Token(Token = "0x6003353")]
	private override TValue System.Collections.Generic.IDictionary<TKey,TValue>.get_Item(TKey key) { }

	[Address(RVA = "0x5E0B630", Offset = "0x5E0B630", Length = "0x14")]
	[Token(Token = "0x600334D")]
	private override ICollection<TKey> System.Collections.Generic.IDictionary<TKey,TValue>.get_Keys() { }

	[Address(RVA = "0x5E0B6E8", Offset = "0x5E0B6E8", Length = "0x14")]
	[Token(Token = "0x600334F")]
	private override ICollection<TValue> System.Collections.Generic.IDictionary<TKey,TValue>.get_Values() { }

	[Address(RVA = "0x5E0B7E4", Offset = "0x5E0B7E4", Length = "0x50")]
	[Token(Token = "0x6003352")]
	private override bool System.Collections.Generic.IDictionary<TKey,TValue>.Remove(TKey key) { }

	[Address(RVA = "0x5E0B8CC", Offset = "0x5E0B8CC", Length = "0x50")]
	[Token(Token = "0x6003354")]
	private override void System.Collections.Generic.IDictionary<TKey,TValue>.set_Item(TKey key, TValue value) { }

	[Address(RVA = "0x5E0CC3C", Offset = "0x5E0CC3C", Length = "0x14")]
	[Token(Token = "0x600336D")]
	private override IEnumerable<TKey> System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.get_Keys() { }

	[Address(RVA = "0x5E0CC50", Offset = "0x5E0CC50", Length = "0x14")]
	[Token(Token = "0x600336E")]
	private override IEnumerable<TValue> System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.get_Values() { }

	[Address(RVA = "0x5E0C1B8", Offset = "0x5E0C1B8", Length = "0x968")]
	[Token(Token = "0x600336A")]
	private override void System.Collections.ICollection.CopyTo(Array array, int index) { }

	[Address(RVA = "0x5E0CB20", Offset = "0x5E0CB20", Length = "0x8")]
	[Token(Token = "0x600336B")]
	private override bool System.Collections.ICollection.get_IsSynchronized() { }

	[Address(RVA = "0x5E0CB28", Offset = "0x5E0CB28", Length = "0x114")]
	[Token(Token = "0x600336C")]
	private override object System.Collections.ICollection.get_SyncRoot() { }

	[Address(RVA = "0x5E0BDA8", Offset = "0x5E0BDA8", Length = "0x50")]
	[Token(Token = "0x600335F")]
	private override void System.Collections.IDictionary.Add(object key, object value) { }

	[Address(RVA = "0x5E0BDF8", Offset = "0x5E0BDF8", Length = "0x50")]
	[Token(Token = "0x6003360")]
	private override void System.Collections.IDictionary.Clear() { }

	[Address(RVA = "0x5E0BE48", Offset = "0x5E0BE48", Length = "0xC0")]
	[Token(Token = "0x6003361")]
	private override bool System.Collections.IDictionary.Contains(object key) { }

	[Address(RVA = "0x5E0C020", Offset = "0x5E0C020", Length = "0x8")]
	[Token(Token = "0x6003363")]
	private override bool System.Collections.IDictionary.get_IsFixedSize() { }

	[Address(RVA = "0x5E0C028", Offset = "0x5E0C028", Length = "0x8")]
	[Token(Token = "0x6003364")]
	private override bool System.Collections.IDictionary.get_IsReadOnly() { }

	[Address(RVA = "0x5E0C0A8", Offset = "0x5E0C0A8", Length = "0xC0")]
	[Token(Token = "0x6003368")]
	private override object System.Collections.IDictionary.get_Item(object key) { }

	[Address(RVA = "0x5E0C030", Offset = "0x5E0C030", Length = "0x14")]
	[Token(Token = "0x6003365")]
	private override ICollection System.Collections.IDictionary.get_Keys() { }

	[Address(RVA = "0x5E0C094", Offset = "0x5E0C094", Length = "0x14")]
	[Token(Token = "0x6003367")]
	private override ICollection System.Collections.IDictionary.get_Values() { }

	[Address(RVA = "0x5E0BF08", Offset = "0x5E0BF08", Length = "0x118")]
	[Token(Token = "0x6003362")]
	private override IDictionaryEnumerator System.Collections.IDictionary.GetEnumerator() { }

	[Address(RVA = "0x5E0C044", Offset = "0x5E0C044", Length = "0x50")]
	[Token(Token = "0x6003366")]
	private override void System.Collections.IDictionary.Remove(object key) { }

	[Address(RVA = "0x5E0C168", Offset = "0x5E0C168", Length = "0x50")]
	[Token(Token = "0x6003369")]
	private override void System.Collections.IDictionary.set_Item(object key, object value) { }

	[Address(RVA = "0x5E0BC6C", Offset = "0x5E0BC6C", Length = "0xA0")]
	[Token(Token = "0x600335D")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	[Address(RVA = "0x5E0B644", Offset = "0x5E0B644", Length = "0xA4")]
	[Token(Token = "0x600334E")]
	public override bool TryGetValue(TKey key, out TValue value) { }

}

