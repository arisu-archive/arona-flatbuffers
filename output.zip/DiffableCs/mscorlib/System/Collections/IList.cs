namespace System.Collections;

[DefaultMember("Item")]
[Token(Token = "0x2000638")]
public interface IList : ICollection, IEnumerable
{

	[Token(Token = "0x17000782")]
	public bool IsFixedSize
	{
		[Token(Token = "0x60030B6")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000781")]
	public bool IsReadOnly
	{
		[Token(Token = "0x60030B5")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000780")]
	public object Item
	{
		[Token(Token = "0x60030B0")]
		 get { } //Length: 0
		[Token(Token = "0x60030B1")]
		 set { } //Length: 0
	}

	[Token(Token = "0x60030B2")]
	public int Add(object value) { }

	[Token(Token = "0x60030B4")]
	public void Clear() { }

	[Token(Token = "0x60030B3")]
	public bool Contains(object value) { }

	[Token(Token = "0x60030B6")]
	public bool get_IsFixedSize() { }

	[Token(Token = "0x60030B5")]
	public bool get_IsReadOnly() { }

	[Token(Token = "0x60030B0")]
	public object get_Item(int index) { }

	[Token(Token = "0x60030B7")]
	public int IndexOf(object value) { }

	[Token(Token = "0x60030B8")]
	public void Insert(int index, object value) { }

	[Token(Token = "0x60030B9")]
	public void Remove(object value) { }

	[Token(Token = "0x60030BA")]
	public void RemoveAt(int index) { }

	[Token(Token = "0x60030B1")]
	public void set_Item(int index, object value) { }

}

