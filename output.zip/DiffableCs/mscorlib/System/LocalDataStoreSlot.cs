namespace System;

[ComVisible(True)]
[Token(Token = "0x2000161")]
public sealed class LocalDataStoreSlot
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x400054D")]
	private LocalDataStoreMgr m_mgr; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400054E")]
	private int m_slot; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400054F")]
	private long m_cookie; //Field offset: 0x20

	[Token(Token = "0x17000166")]
	internal long Cookie
	{
		[Address(RVA = "0x74281D0", Offset = "0x74281D0", Length = "0x8")]
		[Token(Token = "0x6000E42")]
		internal get { } //Length: 8
	}

	[Token(Token = "0x17000164")]
	internal LocalDataStoreMgr Manager
	{
		[Address(RVA = "0x74281C0", Offset = "0x74281C0", Length = "0x8")]
		[Token(Token = "0x6000E40")]
		internal get { } //Length: 8
	}

	[Token(Token = "0x17000165")]
	internal int Slot
	{
		[Address(RVA = "0x74281C8", Offset = "0x74281C8", Length = "0x8")]
		[Token(Token = "0x6000E41")]
		internal get { } //Length: 8
	}

	[Address(RVA = "0x7428174", Offset = "0x7428174", Length = "0x4C")]
	[Token(Token = "0x6000E3F")]
	internal LocalDataStoreSlot(LocalDataStoreMgr mgr, int slot, long cookie) { }

	[Address(RVA = "0x74281D8", Offset = "0x74281D8", Length = "0x9C")]
	[Token(Token = "0x6000E43")]
	protected virtual void Finalize() { }

	[Address(RVA = "0x74281D0", Offset = "0x74281D0", Length = "0x8")]
	[Token(Token = "0x6000E42")]
	internal long get_Cookie() { }

	[Address(RVA = "0x74281C0", Offset = "0x74281C0", Length = "0x8")]
	[Token(Token = "0x6000E40")]
	internal LocalDataStoreMgr get_Manager() { }

	[Address(RVA = "0x74281C8", Offset = "0x74281C8", Length = "0x8")]
	[Token(Token = "0x6000E41")]
	internal int get_Slot() { }

}

