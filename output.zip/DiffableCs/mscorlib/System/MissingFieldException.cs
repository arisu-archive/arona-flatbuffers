namespace System;

[Token(Token = "0x200014E")]
public class MissingFieldException : MissingMemberException, ISerializable
{

	[Token(Token = "0x1700014F")]
	public virtual string Message
	{
		[Address(RVA = "0x74210C8", Offset = "0x74210C8", Length = "0x114")]
		[Token(Token = "0x6000D5E")]
		 get { } //Length: 276
	}

	[Address(RVA = "0x7420DE4", Offset = "0x7420DE4", Length = "0x5C")]
	[Token(Token = "0x6000D5A")]
	public MissingFieldException() { }

	[Address(RVA = "0x7420E64", Offset = "0x7420E64", Length = "0x24")]
	[Token(Token = "0x6000D5B")]
	public MissingFieldException(string message) { }

	[Address(RVA = "0x7420E88", Offset = "0x7420E88", Length = "0x40")]
	[Token(Token = "0x6000D5C")]
	public MissingFieldException(string className, string fieldName) { }

	[Address(RVA = "0x7420F24", Offset = "0x7420F24", Length = "0x4")]
	[Token(Token = "0x6000D5D")]
	protected MissingFieldException(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x74210C8", Offset = "0x74210C8", Length = "0x114")]
	[Token(Token = "0x6000D5E")]
	public virtual string get_Message() { }

}

