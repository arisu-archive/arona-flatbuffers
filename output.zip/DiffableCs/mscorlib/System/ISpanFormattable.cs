namespace System;

[Token(Token = "0x20000D9")]
internal interface ISpanFormattable
{

	[Token(Token = "0x60007DF")]
	public bool TryFormat(Span<Char> destination, out int charsWritten, ReadOnlySpan<Char> format, IFormatProvider provider) { }

}

