namespace System;

[IsReadOnly]
[Token(Token = "0x200009B")]
public struct bool : IComparable, IConvertible, IComparable<Boolean>, IEquatable<Boolean>
{
	[Token(Token = "0x4000209")]
	internal const int True = 1; //Field offset: 0x0
	[Token(Token = "0x400020A")]
	internal const int False = 0; //Field offset: 0x0
	[Token(Token = "0x400020B")]
	internal const string TrueLiteral = "True"; //Field offset: 0x0
	[Token(Token = "0x400020C")]
	internal const string FalseLiteral = "False"; //Field offset: 0x0
	[Token(Token = "0x400020D")]
	public static readonly string TrueString; //Field offset: 0x0
	[Token(Token = "0x400020E")]
	public static readonly string FalseString; //Field offset: 0x8
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000208")]
	private readonly bool m_value; //Field offset: 0x0

	[Address(RVA = "0x73547B8", Offset = "0x73547B8", Length = "0x9C")]
	[Token(Token = "0x600047A")]
	private static Boolean() { }

	[Address(RVA = "0x7352E10", Offset = "0x7352E10", Length = "0x20")]
	[Token(Token = "0x6000464")]
	public override int CompareTo(bool value) { }

	[Address(RVA = "0x7352D38", Offset = "0x7352D38", Length = "0xD8")]
	[Token(Token = "0x6000463")]
	public override int CompareTo(object obj) { }

	[Address(RVA = "0x7352CAC", Offset = "0x7352CAC", Length = "0x78")]
	[Token(Token = "0x6000461")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x7352D24", Offset = "0x7352D24", Length = "0x14")]
	[NonVersionable]
	[Token(Token = "0x6000462")]
	public override bool Equals(bool obj) { }

	[Address(RVA = "0x7352BDC", Offset = "0x7352BDC", Length = "0x10")]
	[Token(Token = "0x600045E")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x7353574", Offset = "0x7353574", Length = "0x8")]
	[Token(Token = "0x600046A")]
	public override TypeCode GetTypeCode() { }

	[Address(RVA = "0x7352E30", Offset = "0x7352E30", Length = "0xD8")]
	[Token(Token = "0x6000465")]
	public static bool Parse(string value) { }

	[Address(RVA = "0x7352F08", Offset = "0x7352F08", Length = "0xC4")]
	[Token(Token = "0x6000466")]
	public static bool Parse(ReadOnlySpan<Char> value) { }

	[Address(RVA = "0x735357C", Offset = "0x735357C", Length = "0x10")]
	[Token(Token = "0x600046B")]
	private override bool System.IConvertible.ToBoolean(IFormatProvider provider) { }

	[Address(RVA = "0x735367C", Offset = "0x735367C", Length = "0x5C")]
	[Token(Token = "0x600046E")]
	private override byte System.IConvertible.ToByte(IFormatProvider provider) { }

	[Address(RVA = "0x735358C", Offset = "0x735358C", Length = "0x8C")]
	[Token(Token = "0x600046C")]
	private override char System.IConvertible.ToChar(IFormatProvider provider) { }

	[Address(RVA = "0x7353ADC", Offset = "0x7353ADC", Length = "0x8C")]
	[Token(Token = "0x6000478")]
	private override DateTime System.IConvertible.ToDateTime(IFormatProvider provider) { }

	[Address(RVA = "0x7353A28", Offset = "0x7353A28", Length = "0x5C")]
	[Token(Token = "0x6000477")]
	private override decimal System.IConvertible.ToDecimal(IFormatProvider provider) { }

	[Address(RVA = "0x73539B0", Offset = "0x73539B0", Length = "0x64")]
	[Token(Token = "0x6000476")]
	private override double System.IConvertible.ToDouble(IFormatProvider provider) { }

	[Address(RVA = "0x73536E0", Offset = "0x73536E0", Length = "0x5C")]
	[Token(Token = "0x600046F")]
	private override short System.IConvertible.ToInt16(IFormatProvider provider) { }

	[Address(RVA = "0x73537A8", Offset = "0x73537A8", Length = "0x5C")]
	[Token(Token = "0x6000471")]
	private override int System.IConvertible.ToInt32(IFormatProvider provider) { }

	[Address(RVA = "0x7353870", Offset = "0x7353870", Length = "0x5C")]
	[Token(Token = "0x6000473")]
	private override long System.IConvertible.ToInt64(IFormatProvider provider) { }

	[Address(RVA = "0x7353618", Offset = "0x7353618", Length = "0x5C")]
	[Token(Token = "0x600046D")]
	private override sbyte System.IConvertible.ToSByte(IFormatProvider provider) { }

	[Address(RVA = "0x7353938", Offset = "0x7353938", Length = "0x64")]
	[Token(Token = "0x6000475")]
	private override float System.IConvertible.ToSingle(IFormatProvider provider) { }

	[Address(RVA = "0x7353B68", Offset = "0x7353B68", Length = "0xB0")]
	[Token(Token = "0x6000479")]
	private override object System.IConvertible.ToType(Type type, IFormatProvider provider) { }

	[Address(RVA = "0x7353744", Offset = "0x7353744", Length = "0x5C")]
	[Token(Token = "0x6000470")]
	private override ushort System.IConvertible.ToUInt16(IFormatProvider provider) { }

	[Address(RVA = "0x735380C", Offset = "0x735380C", Length = "0x5C")]
	[Token(Token = "0x6000472")]
	private override uint System.IConvertible.ToUInt32(IFormatProvider provider) { }

	[Address(RVA = "0x73538D4", Offset = "0x73538D4", Length = "0x5C")]
	[Token(Token = "0x6000474")]
	private override ulong System.IConvertible.ToUInt64(IFormatProvider provider) { }

	[Address(RVA = "0x7352C58", Offset = "0x7352C58", Length = "0x54")]
	[Token(Token = "0x6000460")]
	public override string ToString(IFormatProvider provider) { }

	[Address(RVA = "0x7352BEC", Offset = "0x7352BEC", Length = "0x6C")]
	[Token(Token = "0x600045F")]
	public virtual string ToString() { }

	[Address(RVA = "0x7353380", Offset = "0x7353380", Length = "0x148")]
	[Token(Token = "0x6000469")]
	private static ReadOnlySpan<Char> TrimWhiteSpaceAndNull(ReadOnlySpan<Char> value) { }

	[Address(RVA = "0x7352FCC", Offset = "0x7352FCC", Length = "0x2FC")]
	[Token(Token = "0x6000468")]
	public static bool TryParse(ReadOnlySpan<Char> value, out bool result) { }

	[Address(RVA = "0x73532C8", Offset = "0x73532C8", Length = "0xB8")]
	[Token(Token = "0x6000467")]
	public static bool TryParse(string value, out bool result) { }

}

