namespace System;

[Flags]
[Token(Token = "0x20000A1")]
public enum Base64FormattingOptions
{
	None = 0,
	InsertLineBreaks = 1,
}

