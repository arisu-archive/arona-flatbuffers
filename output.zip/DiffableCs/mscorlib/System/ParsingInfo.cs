namespace System;

[Token(Token = "0x20000C4")]
internal struct ParsingInfo
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x400030B")]
	internal Calendar calendar; //Field offset: 0x0
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x400030C")]
	internal int dayOfWeek; //Field offset: 0x8
	[FieldOffset(Offset = "0xC")]
	[Token(Token = "0x400030D")]
	internal TM timeMark; //Field offset: 0xC
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x400030E")]
	internal bool fUseHour12; //Field offset: 0x10
	[FieldOffset(Offset = "0x11")]
	[Token(Token = "0x400030F")]
	internal bool fUseTwoDigitYear; //Field offset: 0x11
	[FieldOffset(Offset = "0x12")]
	[Token(Token = "0x4000310")]
	internal bool fAllowInnerWhite; //Field offset: 0x12
	[FieldOffset(Offset = "0x13")]
	[Token(Token = "0x4000311")]
	internal bool fAllowTrailingWhite; //Field offset: 0x13
	[FieldOffset(Offset = "0x14")]
	[Token(Token = "0x4000312")]
	internal bool fCustomNumberParser; //Field offset: 0x14
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000313")]
	internal MatchNumberDelegate parseNumberDelegate; //Field offset: 0x18

	[Address(RVA = "0x73F32B0", Offset = "0x73F32B0", Length = "0xC")]
	[Token(Token = "0x600077C")]
	internal void Init() { }

}

