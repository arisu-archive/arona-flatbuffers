namespace System.Threading;

[Token(Token = "0x20001F8")]
internal class SparselyPopulatedArray
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40009B2")]
	private readonly SparselyPopulatedArrayFragment<T> _head; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40009B3")]
	private SparselyPopulatedArrayFragment<T> _tail; //Field offset: 0x0

	[Token(Token = "0x170001E4")]
	internal SparselyPopulatedArrayFragment<T> Tail
	{
		[Address(RVA = "0x5F1C374", Offset = "0x5F1C374", Length = "0x18")]
		[Token(Token = "0x60012CB")]
		internal get { } //Length: 24
	}

	[Address(RVA = "0x5F1C2E4", Offset = "0x5F1C2E4", Length = "0x90")]
	[Token(Token = "0x60012CA")]
	internal SparselyPopulatedArray`1(int initialSize) { }

	[Address(RVA = "0x5F1C38C", Offset = "0x5F1C38C", Length = "0x254")]
	[Token(Token = "0x60012CC")]
	internal SparselyPopulatedArrayAddInfo<T> Add(T element) { }

	[Address(RVA = "0x5F1C374", Offset = "0x5F1C374", Length = "0x18")]
	[Token(Token = "0x60012CB")]
	internal SparselyPopulatedArrayFragment<T> get_Tail() { }

}

