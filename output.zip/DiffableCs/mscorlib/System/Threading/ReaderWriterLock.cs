namespace System.Threading;

[ComVisible(True)]
[Token(Token = "0x200022E")]
public sealed class ReaderWriterLock : CriticalFinalizerObject
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000A4F")]
	private int seq_num; //Field offset: 0x10
	[FieldOffset(Offset = "0x14")]
	[Token(Token = "0x4000A50")]
	private int state; //Field offset: 0x14
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000A51")]
	private int readers; //Field offset: 0x18
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x4000A52")]
	private int writer_lock_owner; //Field offset: 0x1C
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000A53")]
	private LockQueue writer_queue; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000A54")]
	private Hashtable reader_locks; //Field offset: 0x28

	[Address(RVA = "0x747389C", Offset = "0x747389C", Length = "0xF8")]
	[Token(Token = "0x6001443")]
	public ReaderWriterLock() { }

	[Address(RVA = "0x747399C", Offset = "0x747399C", Length = "0x8")]
	[Token(Token = "0x6001445")]
	public void AcquireReaderLock(int millisecondsTimeout) { }

	[Address(RVA = "0x74739A4", Offset = "0x74739A4", Length = "0x374")]
	[Token(Token = "0x6001446")]
	private void AcquireReaderLock(int millisecondsTimeout, int initialLockCount) { }

	[Address(RVA = "0x7473ED8", Offset = "0x7473ED8", Length = "0x8")]
	[Token(Token = "0x6001447")]
	public void AcquireWriterLock(int millisecondsTimeout) { }

	[Address(RVA = "0x7473D48", Offset = "0x7473D48", Length = "0x190")]
	[Token(Token = "0x6001448")]
	private void AcquireWriterLock(int millisecondsTimeout, int initialLockCount) { }

	[Address(RVA = "0x7473994", Offset = "0x7473994", Length = "0x8")]
	[Token(Token = "0x6001444")]
	protected virtual void Finalize() { }

	[Address(RVA = "0x7473D18", Offset = "0x7473D18", Length = "0x30")]
	[Token(Token = "0x600144D")]
	private bool HasWriterLock() { }

	[Address(RVA = "0x7473EE0", Offset = "0x7473EE0", Length = "0x1D4")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001449")]
	public void ReleaseReaderLock() { }

	[Address(RVA = "0x74741C8", Offset = "0x74741C8", Length = "0x124")]
	[Token(Token = "0x600144A")]
	private void ReleaseReaderLock(int currentCount, int releaseCount) { }

	[Address(RVA = "0x74740B4", Offset = "0x74740B4", Length = "0x114")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x600144B")]
	public void ReleaseWriterLock() { }

	[Address(RVA = "0x74742EC", Offset = "0x74742EC", Length = "0x5C")]
	[Token(Token = "0x600144C")]
	private void ReleaseWriterLock(int releaseCount) { }

}

