namespace System.Threading;

[ComVisible(True)]
[Token(Token = "0x200022C")]
public sealed class Mutex : WaitHandle
{

}

