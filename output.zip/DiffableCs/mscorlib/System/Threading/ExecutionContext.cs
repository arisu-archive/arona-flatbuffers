namespace System.Threading;

[Token(Token = "0x200020C")]
public sealed class ExecutionContext : IDisposable, ISerializable
{
	[Flags]
	[Token(Token = "0x200020F")]
	public enum CaptureOptions
	{
		None = 0,
		IgnoreSyncCtx = 1,
		OptimizeDefaultCase = 2,
	}

	[Token(Token = "0x200020D")]
	private enum Flags
	{
		None = 0,
		IsNewCapture = 1,
		IsFlowSuppressed = 2,
		IsPreAllocatedDefault = 4,
	}

	[Token(Token = "0x200020E")]
	public struct Reader
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40009FB")]
		private ExecutionContext m_ec; //Field offset: 0x0

		[Token(Token = "0x170001F7")]
		public bool IsFlowSuppressed
		{
			[Address(RVA = "0x746CE78", Offset = "0x746CE78", Length = "0x14")]
			[Token(Token = "0x600134C")]
			 get { } //Length: 20
		}

		[Token(Token = "0x170001F6")]
		public bool IsNull
		{
			[Address(RVA = "0x746CE48", Offset = "0x746CE48", Length = "0x10")]
			[Token(Token = "0x600134A")]
			 get { } //Length: 16
		}

		[Token(Token = "0x170001FA")]
		public Reader LogicalCallContext
		{
			[Address(RVA = "0x746CEBC", Offset = "0x746CEBC", Length = "0x38")]
			[Token(Token = "0x600134F")]
			 get { } //Length: 56
		}

		[Token(Token = "0x170001F8")]
		public SynchronizationContext SynchronizationContext
		{
			[Address(RVA = "0x746CE8C", Offset = "0x746CE8C", Length = "0x18")]
			[Token(Token = "0x600134D")]
			 get { } //Length: 24
		}

		[Token(Token = "0x170001F9")]
		public SynchronizationContext SynchronizationContextNoFlow
		{
			[Address(RVA = "0x746CEA4", Offset = "0x746CEA4", Length = "0x18")]
			[Token(Token = "0x600134E")]
			 get { } //Length: 24
		}

		[Address(RVA = "0x746CE38", Offset = "0x746CE38", Length = "0x8")]
		[Token(Token = "0x6001348")]
		public Reader(ExecutionContext ec) { }

		[Address(RVA = "0x746CE40", Offset = "0x746CE40", Length = "0x8")]
		[Token(Token = "0x6001349")]
		public ExecutionContext DangerousGetRawExecutionContext() { }

		[Address(RVA = "0x746CE78", Offset = "0x746CE78", Length = "0x14")]
		[Token(Token = "0x600134C")]
		public bool get_IsFlowSuppressed() { }

		[Address(RVA = "0x746CE48", Offset = "0x746CE48", Length = "0x10")]
		[Token(Token = "0x600134A")]
		public bool get_IsNull() { }

		[Address(RVA = "0x746CEBC", Offset = "0x746CEBC", Length = "0x38")]
		[Token(Token = "0x600134F")]
		public Reader get_LogicalCallContext() { }

		[Address(RVA = "0x746CE8C", Offset = "0x746CE8C", Length = "0x18")]
		[Token(Token = "0x600134D")]
		public SynchronizationContext get_SynchronizationContext() { }

		[Address(RVA = "0x746CEA4", Offset = "0x746CEA4", Length = "0x18")]
		[Token(Token = "0x600134E")]
		public SynchronizationContext get_SynchronizationContextNoFlow() { }

		[Address(RVA = "0x746CEF4", Offset = "0x746CEF4", Length = "0x28")]
		[Token(Token = "0x6001350")]
		public bool HasSameLocalValues(ExecutionContext other) { }

		[Address(RVA = "0x746CE58", Offset = "0x746CE58", Length = "0x20")]
		[Token(Token = "0x600134B")]
		public bool IsDefaultFTContext(bool ignoreSyncCtx) { }

	}

	[Token(Token = "0x40009F4")]
	private static readonly ExecutionContext s_dummyDefaultEC; //Field offset: 0x0
	[Token(Token = "0x40009F5")]
	internal static readonly ExecutionContext Default; //Field offset: 0x8
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40009ED")]
	private SynchronizationContext _syncContext; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40009EE")]
	private SynchronizationContext _syncContextNoFlow; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40009EF")]
	private LogicalCallContext _logicalCallContext; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40009F0")]
	private IllogicalCallContext _illogicalCallContext; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40009F1")]
	private Flags _flags; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40009F2")]
	private Dictionary<IAsyncLocal, Object> _localValues; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40009F3")]
	private List<IAsyncLocal> _localChangeNotifications; //Field offset: 0x40

	[Token(Token = "0x170001F3")]
	internal IllogicalCallContext IllogicalCallContext
	{
		[Address(RVA = "0x746BE88", Offset = "0x746BE88", Length = "0x78")]
		[Token(Token = "0x600132E")]
		internal get { } //Length: 120
		[Address(RVA = "0x746BF00", Offset = "0x746BF00", Length = "0x8")]
		[Token(Token = "0x600132F")]
		internal set { } //Length: 8
	}

	[Token(Token = "0x170001F0")]
	internal bool isFlowSuppressed
	{
		[Address(RVA = "0x746BABC", Offset = "0x746BABC", Length = "0xC")]
		[Token(Token = "0x6001325")]
		internal get { } //Length: 12
		[Address(RVA = "0x746B748", Offset = "0x746B748", Length = "0x20")]
		[Token(Token = "0x6001326")]
		internal set { } //Length: 32
	}

	[Token(Token = "0x170001EF")]
	internal bool isNewCapture
	{
		[Address(RVA = "0x746BA98", Offset = "0x746BA98", Length = "0x14")]
		[Token(Token = "0x6001323")]
		internal get { } //Length: 20
		[Address(RVA = "0x746BAAC", Offset = "0x746BAAC", Length = "0x10")]
		[Token(Token = "0x6001324")]
		internal set { } //Length: 16
	}

	[Token(Token = "0x170001F1")]
	internal bool IsPreAllocatedDefault
	{
		[Address(RVA = "0x746BAC8", Offset = "0x746BAC8", Length = "0xC")]
		[Token(Token = "0x6001327")]
		internal get { } //Length: 12
	}

	[Token(Token = "0x170001F2")]
	internal LogicalCallContext LogicalCallContext
	{
		[Address(RVA = "0x746BE08", Offset = "0x746BE08", Length = "0x78")]
		[Token(Token = "0x600132C")]
		internal get { } //Length: 120
		[Address(RVA = "0x746BE80", Offset = "0x746BE80", Length = "0x8")]
		[Token(Token = "0x600132D")]
		internal set { } //Length: 8
	}

	[Token(Token = "0x170001F4")]
	internal SynchronizationContext SynchronizationContext
	{
		[Address(RVA = "0x746BF08", Offset = "0x746BF08", Length = "0x8")]
		[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
		[Token(Token = "0x6001330")]
		internal get { } //Length: 8
		[Address(RVA = "0x746BF10", Offset = "0x746BF10", Length = "0x8")]
		[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
		[Token(Token = "0x6001331")]
		internal set { } //Length: 8
	}

	[Token(Token = "0x170001F5")]
	internal SynchronizationContext SynchronizationContextNoFlow
	{
		[Address(RVA = "0x746BF18", Offset = "0x746BF18", Length = "0x8")]
		[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
		[Token(Token = "0x6001332")]
		internal get { } //Length: 8
		[Address(RVA = "0x746BF20", Offset = "0x746BF20", Length = "0x8")]
		[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
		[Token(Token = "0x6001333")]
		internal set { } //Length: 8
	}

	[Address(RVA = "0x746CD94", Offset = "0x746CD94", Length = "0xA4")]
	[Token(Token = "0x6001347")]
	private static ExecutionContext() { }

	[Address(RVA = "0x746CC7C", Offset = "0x746CC7C", Length = "0x118")]
	[Token(Token = "0x6001345")]
	private ExecutionContext(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x746BAD4", Offset = "0x746BAD4", Length = "0x8")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001328")]
	internal ExecutionContext() { }

	[Address(RVA = "0x746BADC", Offset = "0x746BADC", Length = "0x30")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001329")]
	internal ExecutionContext(bool isPreAllocatedDefault) { }

	[Address(RVA = "0x746C904", Offset = "0x746C904", Length = "0x218")]
	[Token(Token = "0x6001343")]
	internal static ExecutionContext Capture(ref StackCrawlMark stackMark, CaptureOptions options) { }

	[Address(RVA = "0x7464200", Offset = "0x7464200", Length = "0x50")]
	[Token(Token = "0x6001341")]
	public static ExecutionContext Capture() { }

	[Address(RVA = "0x746C51C", Offset = "0x746C51C", Length = "0x180")]
	[Token(Token = "0x600133C")]
	public ExecutionContext CreateCopy() { }

	[Address(RVA = "0x746C69C", Offset = "0x746C69C", Length = "0x140")]
	[Token(Token = "0x600133D")]
	internal ExecutionContext CreateMutableCopy() { }

	[Address(RVA = "0x746BF28", Offset = "0x746BF28", Length = "0x4")]
	[Token(Token = "0x6001334")]
	public override void Dispose() { }

	[Address(RVA = "0x746C278", Offset = "0x746C278", Length = "0x6C")]
	[Token(Token = "0x600133A")]
	private static void EstablishCopyOnWriteScope(Thread currentThread, bool knownNullWindowsIdentity, ref ExecutionContextSwitcher ecsw) { }

	[Address(RVA = "0x746C4B0", Offset = "0x746C4B0", Length = "0x6C")]
	[Token(Token = "0x6001339")]
	internal static void EstablishCopyOnWriteScope(ref ExecutionContextSwitcher ecsw) { }

	[Address(RVA = "0x746CB1C", Offset = "0x746CB1C", Length = "0x50")]
	[FriendAccessAllowed]
	[Token(Token = "0x6001342")]
	internal static ExecutionContext FastCapture() { }

	[Address(RVA = "0x746BE88", Offset = "0x746BE88", Length = "0x78")]
	[Token(Token = "0x600132E")]
	internal IllogicalCallContext get_IllogicalCallContext() { }

	[Address(RVA = "0x746BABC", Offset = "0x746BABC", Length = "0xC")]
	[Token(Token = "0x6001325")]
	internal bool get_isFlowSuppressed() { }

	[Address(RVA = "0x746BA98", Offset = "0x746BA98", Length = "0x14")]
	[Token(Token = "0x6001323")]
	internal bool get_isNewCapture() { }

	[Address(RVA = "0x746BAC8", Offset = "0x746BAC8", Length = "0xC")]
	[Token(Token = "0x6001327")]
	internal bool get_IsPreAllocatedDefault() { }

	[Address(RVA = "0x746BE08", Offset = "0x746BE08", Length = "0x78")]
	[Token(Token = "0x600132C")]
	internal LogicalCallContext get_LogicalCallContext() { }

	[Address(RVA = "0x746BF08", Offset = "0x746BF08", Length = "0x8")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001330")]
	internal SynchronizationContext get_SynchronizationContext() { }

	[Address(RVA = "0x746BF18", Offset = "0x746BF18", Length = "0x8")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001332")]
	internal SynchronizationContext get_SynchronizationContextNoFlow() { }

	[Address(RVA = "0x746CB6C", Offset = "0x746CB6C", Length = "0x110")]
	[Token(Token = "0x6001344")]
	public override void GetObjectData(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x746C228", Offset = "0x746C228", Length = "0x50")]
	[Token(Token = "0x6001346")]
	internal bool IsDefaultFTContext(bool ignoreSyncCtx) { }

	[Address(RVA = "0x746C8B4", Offset = "0x746C8B4", Length = "0x50")]
	[Token(Token = "0x6001340")]
	public static bool IsFlowSuppressed() { }

	[Address(RVA = "0x746B248", Offset = "0x746B248", Length = "0x490")]
	[HandleProcessCorruptedStateExceptions]
	[Token(Token = "0x600132B")]
	internal static void OnAsyncLocalContextChanged(ExecutionContext previous, ExecutionContext current) { }

	[Address(RVA = "0x746B884", Offset = "0x746B884", Length = "0x98")]
	[Token(Token = "0x600133F")]
	public static void RestoreFlow() { }

	[Address(RVA = "0x746BF2C", Offset = "0x746BF2C", Length = "0x7C")]
	[FriendAccessAllowed]
	[Token(Token = "0x6001336")]
	internal static void Run(ExecutionContext executionContext, ContextCallback callback, object state, bool preserveSyncCtx) { }

	[Address(RVA = "0x7468110", Offset = "0x7468110", Length = "0xE8")]
	[Token(Token = "0x6001335")]
	public static void Run(ExecutionContext executionContext, ContextCallback callback, object state) { }

	[Address(RVA = "0x746BFA8", Offset = "0x746BFA8", Length = "0x210")]
	[HandleProcessCorruptedStateExceptions]
	[Token(Token = "0x6001338")]
	internal static void RunInternal(ExecutionContext executionContext, ContextCallback callback, object state, bool preserveSyncCtx) { }

	[Address(RVA = "0x746C1B8", Offset = "0x746C1B8", Length = "0x70")]
	[Token(Token = "0x6001337")]
	internal static void RunInternal(ExecutionContext executionContext, ContextCallback callback, object state) { }

	[Address(RVA = "0x746BF00", Offset = "0x746BF00", Length = "0x8")]
	[Token(Token = "0x600132F")]
	internal void set_IllogicalCallContext(IllogicalCallContext value) { }

	[Address(RVA = "0x746B748", Offset = "0x746B748", Length = "0x20")]
	[Token(Token = "0x6001326")]
	internal void set_isFlowSuppressed(bool value) { }

	[Address(RVA = "0x746BAAC", Offset = "0x746BAAC", Length = "0x10")]
	[Token(Token = "0x6001324")]
	internal void set_isNewCapture(bool value) { }

	[Address(RVA = "0x746BE80", Offset = "0x746BE80", Length = "0x8")]
	[Token(Token = "0x600132D")]
	internal void set_LogicalCallContext(LogicalCallContext value) { }

	[Address(RVA = "0x746BF10", Offset = "0x746BF10", Length = "0x8")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001331")]
	internal void set_SynchronizationContext(SynchronizationContext value) { }

	[Address(RVA = "0x746BF20", Offset = "0x746BF20", Length = "0x8")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001333")]
	internal void set_SynchronizationContextNoFlow(SynchronizationContext value) { }

	[Address(RVA = "0x746C2E4", Offset = "0x746C2E4", Length = "0x1CC")]
	[HandleProcessCorruptedStateExceptions]
	[Token(Token = "0x600133B")]
	internal static ExecutionContextSwitcher SetExecutionContext(ExecutionContext executionContext, bool preserveSyncCtx) { }

	[Address(RVA = "0x746BB0C", Offset = "0x746BB0C", Length = "0x2FC")]
	[Token(Token = "0x600132A")]
	internal static void SetLocalValue(IAsyncLocal local, object newValue, bool needChangeNotifications) { }

	[Address(RVA = "0x746C7DC", Offset = "0x746C7DC", Length = "0xD8")]
	[Token(Token = "0x600133E")]
	public static AsyncFlowControl SuppressFlow() { }

}

