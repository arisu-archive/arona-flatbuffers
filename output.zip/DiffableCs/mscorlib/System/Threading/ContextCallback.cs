namespace System.Threading;

[ComVisible(True)]
[Token(Token = "0x2000209")]
public sealed class ContextCallback : MulticastDelegate
{

	[Address(RVA = "0x7467FD0", Offset = "0x7467FD0", Length = "0x140")]
	[Token(Token = "0x6001319")]
	public ContextCallback(object object, IntPtr method) { }

	[Address(RVA = "0x746B0F8", Offset = "0x746B0F8", Length = "0x14")]
	[Token(Token = "0x600131A")]
	public override void Invoke(object state) { }

}

