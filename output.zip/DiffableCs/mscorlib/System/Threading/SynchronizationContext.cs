namespace System.Threading;

[Token(Token = "0x2000212")]
public class SynchronizationContext
{
	[Token(Token = "0x4000A04")]
	private static Type s_cachedPreparedType1; //Field offset: 0x0
	[Token(Token = "0x4000A05")]
	private static Type s_cachedPreparedType2; //Field offset: 0x8
	[Token(Token = "0x4000A06")]
	private static Type s_cachedPreparedType3; //Field offset: 0x10
	[Token(Token = "0x4000A07")]
	private static Type s_cachedPreparedType4; //Field offset: 0x18
	[Token(Token = "0x4000A08")]
	private static Type s_cachedPreparedType5; //Field offset: 0x20
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000A03")]
	private SynchronizationContextProperties _props; //Field offset: 0x10

	[Token(Token = "0x170001FB")]
	public static SynchronizationContext Current
	{
		[Address(RVA = "0x746D7A0", Offset = "0x746D7A0", Length = "0x3C")]
		[Token(Token = "0x600136D")]
		 get { } //Length: 60
	}

	[Token(Token = "0x170001FD")]
	internal static SynchronizationContext CurrentExplicit
	{
		[Address(RVA = "0x746DA40", Offset = "0x746DA40", Length = "0x4")]
		[Token(Token = "0x6001371")]
		internal get { } //Length: 4
	}

	[Token(Token = "0x170001FC")]
	internal static SynchronizationContext CurrentNoFlow
	{
		[Address(RVA = "0x746D844", Offset = "0x746D844", Length = "0x3C")]
		[FriendAccessAllowed]
		[Token(Token = "0x600136E")]
		internal get { } //Length: 60
	}

	[Address(RVA = "0x746D334", Offset = "0x746D334", Length = "0x8")]
	[Token(Token = "0x6001364")]
	public SynchronizationContext() { }

	[Address(RVA = "0x746D9E4", Offset = "0x746D9E4", Length = "0x5C")]
	[Token(Token = "0x6001370")]
	public override SynchronizationContext CreateCopy() { }

	[Address(RVA = "0x746D7A0", Offset = "0x746D7A0", Length = "0x3C")]
	[Token(Token = "0x600136D")]
	public static SynchronizationContext get_Current() { }

	[Address(RVA = "0x746DA40", Offset = "0x746DA40", Length = "0x4")]
	[Token(Token = "0x6001371")]
	internal static SynchronizationContext get_CurrentExplicit() { }

	[Address(RVA = "0x746D844", Offset = "0x746D844", Length = "0x3C")]
	[FriendAccessAllowed]
	[Token(Token = "0x600136E")]
	internal static SynchronizationContext get_CurrentNoFlow() { }

	[Address(RVA = "0x746D7F8", Offset = "0x746D7F8", Length = "0x4C")]
	[Token(Token = "0x600136F")]
	private static SynchronizationContext GetThreadLocalContext() { }

	[Address(RVA = "0x746D33C", Offset = "0x746D33C", Length = "0xC")]
	[Token(Token = "0x6001365")]
	public bool IsWaitNotificationRequired() { }

	[Address(RVA = "0x746D564", Offset = "0x746D564", Length = "0x4")]
	[Token(Token = "0x6001369")]
	public override void OperationCompleted() { }

	[Address(RVA = "0x746D560", Offset = "0x746D560", Length = "0x4")]
	[Token(Token = "0x6001368")]
	public override void OperationStarted() { }

	[Address(RVA = "0x746D370", Offset = "0x746D370", Length = "0x88")]
	[Token(Token = "0x6001367")]
	public override void Post(SendOrPostCallback d, object state) { }

	[Address(RVA = "0x746D348", Offset = "0x746D348", Length = "0x28")]
	[Token(Token = "0x6001366")]
	public override void Send(SendOrPostCallback d, object state) { }

	[Address(RVA = "0x746D65C", Offset = "0x746D65C", Length = "0x48")]
	[Token(Token = "0x600136C")]
	public static void SetSynchronizationContext(SynchronizationContext syncContext) { }

	[Address(RVA = "0x746D568", Offset = "0x746D568", Length = "0x68")]
	[CLSCompliant(False)]
	[PrePrepareMethod]
	[Token(Token = "0x600136A")]
	public override int Wait(IntPtr[] waitHandles, bool waitAll, int millisecondsTimeout) { }

	[Address(RVA = "0x746D5D0", Offset = "0x746D5D0", Length = "0x88")]
	[CLSCompliant(False)]
	[PrePrepareMethod]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::MayFail (1))]
	[Token(Token = "0x600136B")]
	protected static int WaitHelper(IntPtr[] waitHandles, bool waitAll, int millisecondsTimeout) { }

}

