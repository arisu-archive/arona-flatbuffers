namespace System.Threading;

[Token(Token = "0x2000224")]
internal sealed class ThreadPoolWorkQueueThreadLocals
{
	[ThreadStatic]
	[Token(Token = "0x4000A38")]
	public static ThreadPoolWorkQueueThreadLocals threadLocals; //Field offset: 0x80000000
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000A39")]
	public readonly ThreadPoolWorkQueue workQueue; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000A3A")]
	public readonly WorkStealingQueue workStealingQueue; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000A3B")]
	public readonly Random random; //Field offset: 0x20

	[Address(RVA = "0x746F8B4", Offset = "0x746F8B4", Length = "0x130")]
	[Token(Token = "0x60013EB")]
	public ThreadPoolWorkQueueThreadLocals(ThreadPoolWorkQueue tpq) { }

	[Address(RVA = "0x7471550", Offset = "0x7471550", Length = "0xC8")]
	[Token(Token = "0x60013EC")]
	private void CleanUp() { }

	[Address(RVA = "0x7471618", Offset = "0x7471618", Length = "0xB8")]
	[Token(Token = "0x60013ED")]
	protected virtual void Finalize() { }

}

