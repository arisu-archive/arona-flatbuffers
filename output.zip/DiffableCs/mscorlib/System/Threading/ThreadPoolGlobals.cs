namespace System.Threading;

[Token(Token = "0x200021F")]
internal static class ThreadPoolGlobals
{
	[Token(Token = "0x4000A27")]
	public static int processorCount; //Field offset: 0x0
	[Token(Token = "0x4000A28")]
	public static bool vmTpInitialized; //Field offset: 0x4
	[Token(Token = "0x4000A29")]
	public static bool enableWorkerTracking; //Field offset: 0x5
	[Token(Token = "0x4000A2A")]
	public static readonly ThreadPoolWorkQueue workQueue; //Field offset: 0x8

	[Address(RVA = "0x746F6A4", Offset = "0x746F6A4", Length = "0x90")]
	[Token(Token = "0x60013D1")]
	private static ThreadPoolGlobals() { }

}

