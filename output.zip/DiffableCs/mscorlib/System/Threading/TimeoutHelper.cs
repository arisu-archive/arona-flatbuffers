namespace System.Threading;

[Token(Token = "0x20001EE")]
internal static class TimeoutHelper
{

	[Address(RVA = "0x746590C", Offset = "0x746590C", Length = "0x8")]
	[Token(Token = "0x6001299")]
	public static uint GetTime() { }

	[Address(RVA = "0x7465A10", Offset = "0x7465A10", Length = "0x3C")]
	[Token(Token = "0x600129A")]
	public static int UpdateTimeOut(uint startTime, int originalWaitMillisecondsTimeout) { }

}

