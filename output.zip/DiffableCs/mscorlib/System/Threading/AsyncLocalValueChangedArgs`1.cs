namespace System.Threading;

[IsReadOnly]
[Token(Token = "0x20001D7")]
public struct AsyncLocalValueChangedArgs
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x400095C")]
	private readonly T <PreviousValue>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x400095D")]
	private readonly T <CurrentValue>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x400095E")]
	private readonly bool <ThreadContextChanged>k__BackingField; //Field offset: 0x0

	[Token(Token = "0x170001D3")]
	public T CurrentValue
	{
		[Address(RVA = "0x67EAEF8", Offset = "0x67EAEF8", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6001241")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x67EAF00", Offset = "0x67EAF00", Length = "0x50")]
	[Token(Token = "0x6001242")]
	internal AsyncLocalValueChangedArgs`1(T previousValue, T currentValue, bool contextChanged) { }

	[Address(RVA = "0x67EAEF8", Offset = "0x67EAEF8", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6001241")]
	public T get_CurrentValue() { }

}

