namespace System.Threading;

[Token(Token = "0x2000207")]
internal sealed class SystemThreading_ThreadLocalDebugView
{

}

