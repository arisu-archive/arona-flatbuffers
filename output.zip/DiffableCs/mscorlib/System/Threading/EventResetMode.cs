namespace System.Threading;

[Token(Token = "0x20001D9")]
public enum EventResetMode
{
	AutoReset = 0,
	ManualReset = 1,
}

