namespace System.Threading;

[Token(Token = "0x20001DD")]
public sealed class ManualResetEvent : EventWaitHandle
{

	[Address(RVA = "0x74635F8", Offset = "0x74635F8", Length = "0xC")]
	[Token(Token = "0x6001250")]
	public ManualResetEvent(bool initialState) { }

}

