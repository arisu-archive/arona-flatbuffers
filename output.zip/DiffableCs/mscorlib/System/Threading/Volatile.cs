namespace System.Threading;

[Token(Token = "0x2000235")]
public static class Volatile
{
	[Token(Token = "0x2000236")]
	private struct VolatileBoolean
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000A94")]
		public bool Value; //Field offset: 0x0

	}

	[Token(Token = "0x2000237")]
	private struct VolatileInt32
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000A95")]
		public int Value; //Field offset: 0x0

	}

	[Token(Token = "0x2000238")]
	private struct VolatileObject
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000A96")]
		public object Value; //Field offset: 0x0

	}


	[Address(RVA = "0x7475E04", Offset = "0x7475E04", Length = "0x18")]
	[Intrinsic]
	[Token(Token = "0x6001470")]
	public static bool Read(ref bool location) { }

	[Address(RVA = "0x7475E40", Offset = "0x7475E40", Length = "0x18")]
	[Intrinsic]
	[Token(Token = "0x6001472")]
	public static int Read(ref int location) { }

	[Address(RVA = "0x44D1978", Offset = "0x44D1978", Length = "0x18")]
	[Intrinsic]
	[Token(Token = "0x6001474")]
	public static T Read(ref T location) { }

	[Address(RVA = "0x7475E1C", Offset = "0x7475E1C", Length = "0x24")]
	[Intrinsic]
	[Token(Token = "0x6001471")]
	public static void Write(ref bool location, bool value) { }

	[Address(RVA = "0x7475E58", Offset = "0x7475E58", Length = "0x24")]
	[Intrinsic]
	[Token(Token = "0x6001473")]
	public static void Write(ref int location, int value) { }

	[Address(RVA = "0x44D1990", Offset = "0x44D1990", Length = "0x2C")]
	[Intrinsic]
	[Token(Token = "0x6001475")]
	public static void Write(ref T location, T value) { }

}

