namespace System.Threading;

[Token(Token = "0x20001E2")]
public enum ThreadPriority
{
	Lowest = 0,
	BelowNormal = 1,
	Normal = 2,
	AboveNormal = 3,
	Highest = 4,
}

