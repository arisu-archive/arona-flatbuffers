namespace System.Threading;

[ComVisible(True)]
[Token(Token = "0x200022F")]
public sealed class RegisteredWaitHandle : MarshalByRefObject
{
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000A55")]
	private WaitHandle _waitObject; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000A56")]
	private WaitOrTimerCallback _callback; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000A57")]
	private object _state; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000A58")]
	private WaitHandle _finalEvent; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000A59")]
	private ManualResetEvent _cancelEvent; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000A5A")]
	private TimeSpan _timeout; //Field offset: 0x40
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000A5B")]
	private int _callsInProcess; //Field offset: 0x48
	[FieldOffset(Offset = "0x4C")]
	[Token(Token = "0x4000A5C")]
	private bool _executeOnlyOnce; //Field offset: 0x4C
	[FieldOffset(Offset = "0x4D")]
	[Token(Token = "0x4000A5D")]
	private bool _unregistered; //Field offset: 0x4D

	[Address(RVA = "0x7471C04", Offset = "0x7471C04", Length = "0xFC")]
	[Token(Token = "0x600144E")]
	internal RegisteredWaitHandle(WaitHandle waitObject, WaitOrTimerCallback callback, object state, TimeSpan timeout, bool executeOnlyOnce) { }

	[Address(RVA = "0x747488C", Offset = "0x747488C", Length = "0x104")]
	[Token(Token = "0x6001450")]
	private void DoCallBack(object timedOut) { }

	[Address(RVA = "0x7474990", Offset = "0x7474990", Length = "0xF0")]
	[ComVisible(True)]
	[Token(Token = "0x6001451")]
	public bool Unregister(WaitHandle waitObject) { }

	[Address(RVA = "0x7474348", Offset = "0x7474348", Length = "0x544")]
	[Token(Token = "0x600144F")]
	internal void Wait(object state) { }

}

