namespace System.Threading;

[Token(Token = "0x20001F0")]
public class CancellationTokenSource : IDisposable
{
	[Token(Token = "0x20001F1")]
	private sealed class Linked1CancellationTokenSource : CancellationTokenSource
	{
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x40009A4")]
		private readonly CancellationTokenRegistration _reg1; //Field offset: 0x40

		[Address(RVA = "0x74674F8", Offset = "0x74674F8", Length = "0x104")]
		[Token(Token = "0x60012BB")]
		internal Linked1CancellationTokenSource(CancellationToken token1) { }

		[Address(RVA = "0x7467CF8", Offset = "0x7467CF8", Length = "0x34")]
		[Token(Token = "0x60012BC")]
		protected virtual void Dispose(bool disposing) { }

	}

	[Token(Token = "0x20001F2")]
	private sealed class Linked2CancellationTokenSource : CancellationTokenSource
	{
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x40009A5")]
		private readonly CancellationTokenRegistration _reg1; //Field offset: 0x40
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x40009A6")]
		private readonly CancellationTokenRegistration _reg2; //Field offset: 0x58

		[Address(RVA = "0x74675FC", Offset = "0x74675FC", Length = "0x13C")]
		[Token(Token = "0x60012BD")]
		internal Linked2CancellationTokenSource(CancellationToken token1, CancellationToken token2) { }

		[Address(RVA = "0x7467D2C", Offset = "0x7467D2C", Length = "0x3C")]
		[Token(Token = "0x60012BE")]
		protected virtual void Dispose(bool disposing) { }

	}

	[Token(Token = "0x20001F3")]
	private sealed class LinkedNCancellationTokenSource : CancellationTokenSource
	{
		[CompilerGenerated]
		[Token(Token = "0x20001F4")]
		private sealed class <>c
		{
			[Token(Token = "0x40009A9")]
			public static readonly <>c <>9; //Field offset: 0x0

			[Address(RVA = "0x7467ED4", Offset = "0x7467ED4", Length = "0x70")]
			[Token(Token = "0x60012C2")]
			private static <>c() { }

			[Address(RVA = "0x7467F44", Offset = "0x7467F44", Length = "0x8")]
			[Token(Token = "0x60012C3")]
			public <>c() { }

			[Address(RVA = "0x7467F4C", Offset = "0x7467F4C", Length = "0x84")]
			[Token(Token = "0x60012C4")]
			internal void <.cctor>b__4_0(object s) { }

		}

		[Token(Token = "0x40009A7")]
		internal static readonly Action<Object> s_linkedTokenCancelDelegate; //Field offset: 0x0
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x40009A8")]
		private CancellationTokenRegistration[] _linkingRegistrations; //Field offset: 0x40

		[Address(RVA = "0x7467E04", Offset = "0x7467E04", Length = "0xD0")]
		[Token(Token = "0x60012C1")]
		private static LinkedNCancellationTokenSource() { }

		[Address(RVA = "0x7467978", Offset = "0x7467978", Length = "0x1E0")]
		[Token(Token = "0x60012BF")]
		internal LinkedNCancellationTokenSource(CancellationToken[] tokens) { }

		[Address(RVA = "0x7467D68", Offset = "0x7467D68", Length = "0x9C")]
		[Token(Token = "0x60012C0")]
		protected virtual void Dispose(bool disposing) { }

	}

	[Token(Token = "0x4000995")]
	internal static readonly CancellationTokenSource s_canceledSource; //Field offset: 0x0
	[Token(Token = "0x400099A")]
	private const int CannotBeCanceled = 0; //Field offset: 0x0
	[Token(Token = "0x400099B")]
	private const int NotCanceledState = 1; //Field offset: 0x0
	[Token(Token = "0x400099C")]
	private const int NotifyingState = 2; //Field offset: 0x0
	[Token(Token = "0x400099D")]
	private const int NotifyingCompleteState = 3; //Field offset: 0x0
	[Token(Token = "0x4000996")]
	internal static readonly CancellationTokenSource s_neverCanceledSource; //Field offset: 0x8
	[Token(Token = "0x4000997")]
	private static readonly int s_nLists; //Field offset: 0x10
	[Token(Token = "0x40009A3")]
	private static readonly TimerCallback s_timerCallback; //Field offset: 0x18
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000998")]
	private ManualResetEvent _kernelEvent; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000999")]
	private SparselyPopulatedArray<CancellationCallbackInfo>[] _registeredCallbacksLists; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400099E")]
	private int _state; //Field offset: 0x20
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x400099F")]
	private int _threadIDExecutingCallbacks; //Field offset: 0x24
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40009A0")]
	private bool _disposed; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40009A1")]
	private CancellationCallbackInfo _executingCallback; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40009A2")]
	private Timer _timer; //Field offset: 0x38

	[Token(Token = "0x170001E3")]
	internal CancellationCallbackInfo ExecutingCallback
	{
		[Address(RVA = "0x746661C", Offset = "0x746661C", Length = "0x18")]
		[Token(Token = "0x60012A7")]
		internal get { } //Length: 24
	}

	[Token(Token = "0x170001DF")]
	internal bool IsCancellationCompleted
	{
		[Address(RVA = "0x746630C", Offset = "0x746630C", Length = "0x1C")]
		[Token(Token = "0x60012A2")]
		internal get { } //Length: 28
	}

	[Token(Token = "0x170001DE")]
	public bool IsCancellationRequested
	{
		[Address(RVA = "0x7463C20", Offset = "0x7463C20", Length = "0x1C")]
		[Token(Token = "0x60012A1")]
		 get { } //Length: 28
	}

	[Token(Token = "0x170001E0")]
	internal bool IsDisposed
	{
		[Address(RVA = "0x7466564", Offset = "0x7466564", Length = "0x8")]
		[Token(Token = "0x60012A3")]
		internal get { } //Length: 8
	}

	[Token(Token = "0x170001E1")]
	internal int ThreadIDExecutingCallbacks
	{
		[Address(RVA = "0x7466328", Offset = "0x7466328", Length = "0x18")]
		[Token(Token = "0x60012A4")]
		internal get { } //Length: 24
		[Address(RVA = "0x746656C", Offset = "0x746656C", Length = "0x24")]
		[Token(Token = "0x60012A5")]
		internal set { } //Length: 36
	}

	[Token(Token = "0x170001E2")]
	public CancellationToken Token
	{
		[Address(RVA = "0x7466590", Offset = "0x7466590", Length = "0x30")]
		[Token(Token = "0x60012A6")]
		 get { } //Length: 48
	}

	[Address(RVA = "0x7467B58", Offset = "0x7467B58", Length = "0x1A0")]
	[Token(Token = "0x60012BA")]
	private static CancellationTokenSource() { }

	[Address(RVA = "0x7466634", Offset = "0x7466634", Length = "0x34")]
	[Token(Token = "0x60012A8")]
	public CancellationTokenSource() { }

	[Address(RVA = "0x7466668", Offset = "0x7466668", Length = "0x1C")]
	[Token(Token = "0x60012A9")]
	public void Cancel() { }

	[Address(RVA = "0x7466684", Offset = "0x7466684", Length = "0x28")]
	[Token(Token = "0x60012AA")]
	public void Cancel(bool throwOnFirstException) { }

	[Address(RVA = "0x746675C", Offset = "0x746675C", Length = "0x1EC")]
	[Token(Token = "0x60012AB")]
	public void CancelAfter(int millisecondsDelay) { }

	[Address(RVA = "0x7467198", Offset = "0x7467198", Length = "0xBC")]
	[Token(Token = "0x60012B5")]
	private void CancellationCallbackCoreWork(CancellationCallbackCoreWorkArguments args) { }

	[Address(RVA = "0x7467254", Offset = "0x7467254", Length = "0x7C")]
	[Token(Token = "0x60012B4")]
	private void CancellationCallbackCoreWork_OnSyncContext(object obj) { }

	[Address(RVA = "0x7467810", Offset = "0x7467810", Length = "0x168")]
	[Token(Token = "0x60012B8")]
	public static CancellationTokenSource CreateLinkedTokenSource(CancellationToken[] tokens) { }

	[Address(RVA = "0x7467738", Offset = "0x7467738", Length = "0xD8")]
	[Token(Token = "0x60012B7")]
	internal static CancellationTokenSource CreateLinkedTokenSource(CancellationToken token) { }

	[Address(RVA = "0x74673DC", Offset = "0x74673DC", Length = "0x11C")]
	[Token(Token = "0x60012B6")]
	public static CancellationTokenSource CreateLinkedTokenSource(CancellationToken token1, CancellationToken token2) { }

	[Address(RVA = "0x7466ACC", Offset = "0x7466ACC", Length = "0x9C")]
	[Token(Token = "0x60012AE")]
	protected override void Dispose(bool disposing) { }

	[Address(RVA = "0x7466A60", Offset = "0x7466A60", Length = "0x6C")]
	[Token(Token = "0x60012AD")]
	public override void Dispose() { }

	[Address(RVA = "0x7466C5C", Offset = "0x7466C5C", Length = "0x514")]
	[Token(Token = "0x60012B3")]
	private void ExecuteCallbackHandlers(bool throwOnFirstException) { }

	[Address(RVA = "0x746661C", Offset = "0x746661C", Length = "0x18")]
	[Token(Token = "0x60012A7")]
	internal CancellationCallbackInfo get_ExecutingCallback() { }

	[Address(RVA = "0x746630C", Offset = "0x746630C", Length = "0x1C")]
	[Token(Token = "0x60012A2")]
	internal bool get_IsCancellationCompleted() { }

	[Address(RVA = "0x7463C20", Offset = "0x7463C20", Length = "0x1C")]
	[Token(Token = "0x60012A1")]
	public bool get_IsCancellationRequested() { }

	[Address(RVA = "0x7466564", Offset = "0x7466564", Length = "0x8")]
	[Token(Token = "0x60012A3")]
	internal bool get_IsDisposed() { }

	[Address(RVA = "0x7466328", Offset = "0x7466328", Length = "0x18")]
	[Token(Token = "0x60012A4")]
	internal int get_ThreadIDExecutingCallbacks() { }

	[Address(RVA = "0x7466590", Offset = "0x7466590", Length = "0x30")]
	[Token(Token = "0x60012A6")]
	public CancellationToken get_Token() { }

	[Address(RVA = "0x7464250", Offset = "0x7464250", Length = "0x308")]
	[Token(Token = "0x60012B1")]
	internal CancellationTokenRegistration InternalRegister(Action<Object> callback, object stateForCallback, SynchronizationContext targetSyncContext, ExecutionContext executionContext) { }

	[Address(RVA = "0x74666AC", Offset = "0x74666AC", Length = "0xB0")]
	[Token(Token = "0x60012B2")]
	private void NotifyCancellation(bool throwOnFirstException) { }

	[Address(RVA = "0x746656C", Offset = "0x746656C", Length = "0x24")]
	[Token(Token = "0x60012A5")]
	internal void set_ThreadIDExecutingCallbacks(int value) { }

	[Address(RVA = "0x74665C0", Offset = "0x74665C0", Length = "0x5C")]
	[Token(Token = "0x60012AF")]
	internal void ThrowIfDisposed() { }

	[Address(RVA = "0x7466B68", Offset = "0x7466B68", Length = "0x54")]
	[Token(Token = "0x60012B0")]
	private static void ThrowObjectDisposedException() { }

	[Address(RVA = "0x7466948", Offset = "0x7466948", Length = "0x118")]
	[Token(Token = "0x60012AC")]
	private static void TimerCallbackLogic(object obj) { }

	[Address(RVA = "0x7466340", Offset = "0x7466340", Length = "0x88")]
	[Token(Token = "0x60012B9")]
	internal void WaitForCallbackToComplete(CancellationCallbackInfo callbackInfo) { }

}

