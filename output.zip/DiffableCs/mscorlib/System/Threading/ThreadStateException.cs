namespace System.Threading;

[Token(Token = "0x20001E5")]
public class ThreadStateException : SystemException
{

	[Address(RVA = "0x7463A6C", Offset = "0x7463A6C", Length = "0x5C")]
	[Token(Token = "0x600125C")]
	public ThreadStateException() { }

	[Address(RVA = "0x7463AC8", Offset = "0x7463AC8", Length = "0x24")]
	[Token(Token = "0x600125D")]
	public ThreadStateException(string message) { }

	[Address(RVA = "0x7463AEC", Offset = "0x7463AEC", Length = "0x8")]
	[Token(Token = "0x600125E")]
	protected ThreadStateException(SerializationInfo info, StreamingContext context) { }

}

