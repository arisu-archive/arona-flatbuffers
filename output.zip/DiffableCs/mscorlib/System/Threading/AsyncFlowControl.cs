namespace System.Threading;

[Token(Token = "0x200020B")]
public struct AsyncFlowControl : IDisposable
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40009EA")]
	private bool useEC; //Field offset: 0x0
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x40009EB")]
	private ExecutionContext _ec; //Field offset: 0x8
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40009EC")]
	private Thread _thread; //Field offset: 0x10

	[Address(RVA = "0x746B768", Offset = "0x746B768", Length = "0x4")]
	[Token(Token = "0x600131E")]
	public override void Dispose() { }

	[Address(RVA = "0x746B9BC", Offset = "0x746B9BC", Length = "0x9C")]
	[Token(Token = "0x6001321")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x746BA58", Offset = "0x746BA58", Length = "0x40")]
	[Token(Token = "0x6001322")]
	public bool Equals(AsyncFlowControl obj) { }

	[Address(RVA = "0x746B91C", Offset = "0x746B91C", Length = "0xA0")]
	[Token(Token = "0x6001320")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x746B6D8", Offset = "0x746B6D8", Length = "0x70")]
	[Token(Token = "0x600131D")]
	internal void Setup() { }

	[Address(RVA = "0x746B76C", Offset = "0x746B76C", Length = "0x118")]
	[Token(Token = "0x600131F")]
	public void Undo() { }

}

