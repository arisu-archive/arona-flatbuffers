namespace System.Threading;

[Token(Token = "0x20001F6")]
internal class CancellationCallbackInfo
{
	[Token(Token = "0x20001F7")]
	public sealed class WithSyncContext : CancellationCallbackInfo
	{
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x40009B1")]
		internal readonly SynchronizationContext TargetSyncContext; //Field offset: 0x30

		[Address(RVA = "0x7466C30", Offset = "0x7466C30", Length = "0x2C")]
		[Token(Token = "0x60012C9")]
		internal WithSyncContext(Action<Object> callback, object stateForCallback, ExecutionContext targetExecutionContext, CancellationTokenSource cancellationTokenSource, SynchronizationContext targetSyncContext) { }

	}

	[Token(Token = "0x40009B0")]
	private static ContextCallback s_executionContextCallback; //Field offset: 0x0
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40009AC")]
	internal readonly Action<Object> Callback; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40009AD")]
	internal readonly object StateForCallback; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40009AE")]
	internal readonly ExecutionContext TargetExecutionContext; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40009AF")]
	internal readonly CancellationTokenSource CancellationTokenSource; //Field offset: 0x28

	[Address(RVA = "0x7466BBC", Offset = "0x7466BBC", Length = "0x74")]
	[Token(Token = "0x60012C6")]
	internal CancellationCallbackInfo(Action<Object> callback, object stateForCallback, ExecutionContext targetExecutionContext, CancellationTokenSource cancellationTokenSource) { }

	[Address(RVA = "0x74672D0", Offset = "0x74672D0", Length = "0x10C")]
	[Token(Token = "0x60012C7")]
	internal void ExecuteCallback() { }

	[Address(RVA = "0x74681F8", Offset = "0x74681F8", Length = "0x8C")]
	[Token(Token = "0x60012C8")]
	private static void ExecutionContextCallback(object obj) { }

}

