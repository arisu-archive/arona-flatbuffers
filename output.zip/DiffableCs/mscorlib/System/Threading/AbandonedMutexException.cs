namespace System.Threading;

[Token(Token = "0x20001D4")]
public class AbandonedMutexException : SystemException
{
	[FieldOffset(Offset = "0x8C")]
	[Token(Token = "0x4000959")]
	private int _mutexIndex; //Field offset: 0x8C
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x400095A")]
	private Mutex _mutex; //Field offset: 0x90

	[Address(RVA = "0x74632A4", Offset = "0x74632A4", Length = "0x64")]
	[Token(Token = "0x6001239")]
	public AbandonedMutexException() { }

	[Address(RVA = "0x7463308", Offset = "0x7463308", Length = "0x80")]
	[Token(Token = "0x600123A")]
	public AbandonedMutexException(int location, WaitHandle handle) { }

	[Address(RVA = "0x7463414", Offset = "0x7463414", Length = "0x10")]
	[Token(Token = "0x600123B")]
	protected AbandonedMutexException(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x7463388", Offset = "0x7463388", Length = "0x8C")]
	[Token(Token = "0x600123C")]
	private void SetupException(int location, WaitHandle handle) { }

}

