namespace System.Threading;

[ComVisible(True)]
[Token(Token = "0x2000231")]
public sealed class Timer : MarshalByRefObject, IDisposable
{
	[Token(Token = "0x2000233")]
	private sealed class Scheduler
	{
		[Token(Token = "0x4000A8F")]
		private static readonly Scheduler instance; //Field offset: 0x0
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000A90")]
		private bool needReSort; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000A91")]
		private List<Timer> list; //Field offset: 0x18
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000A92")]
		private long current_next_run; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000A93")]
		private ManualResetEvent changed; //Field offset: 0x28

		[Token(Token = "0x17000211")]
		public static Scheduler Instance
		{
			[Address(RVA = "0x74758DC", Offset = "0x74758DC", Length = "0x58")]
			[Token(Token = "0x6001464")]
			 get { } //Length: 88
		}

		[Address(RVA = "0x7475C44", Offset = "0x7475C44", Length = "0x6C")]
		[Token(Token = "0x600146D")]
		private static Scheduler() { }

		[Address(RVA = "0x7475934", Offset = "0x7475934", Length = "0xA8")]
		[Token(Token = "0x6001465")]
		private Scheduler() { }

		[Address(RVA = "0x7475A0C", Offset = "0x7475A0C", Length = "0xFC")]
		[Token(Token = "0x6001468")]
		private void Add(Timer timer) { }

		[Address(RVA = "0x7475114", Offset = "0x7475114", Length = "0x17C")]
		[Token(Token = "0x6001467")]
		public void Change(Timer timer, long new_next_run) { }

		[Address(RVA = "0x7475B80", Offset = "0x7475B80", Length = "0xC4")]
		[Token(Token = "0x600146B")]
		private void FireTimer(Timer timer) { }

		[Address(RVA = "0x74758DC", Offset = "0x74758DC", Length = "0x58")]
		[Token(Token = "0x6001464")]
		public static Scheduler get_Instance() { }

		[Address(RVA = "0x747539C", Offset = "0x747539C", Length = "0xF4")]
		[Token(Token = "0x6001461")]
		private void InitScheduler() { }

		[Address(RVA = "0x74759DC", Offset = "0x74759DC", Length = "0x30")]
		[Token(Token = "0x6001469")]
		private void InternalRemove(Timer timer) { }

		[Address(RVA = "0x7475054", Offset = "0x7475054", Length = "0xBC")]
		[Token(Token = "0x6001466")]
		public void Remove(Timer timer) { }

		[Address(RVA = "0x74755C8", Offset = "0x74755C8", Length = "0x314")]
		[Token(Token = "0x600146C")]
		private int RunSchedulerLoop() { }

		[Address(RVA = "0x74754AC", Offset = "0x74754AC", Length = "0x11C")]
		[Token(Token = "0x6001463")]
		private void SchedulerThread() { }

		[Address(RVA = "0x7475B08", Offset = "0x7475B08", Length = "0x78")]
		[Token(Token = "0x600146A")]
		private static void TimerCB(object o) { }

		[Address(RVA = "0x7475490", Offset = "0x7475490", Length = "0x1C")]
		[Token(Token = "0x6001462")]
		private void WakeupScheduler() { }

	}

	[Token(Token = "0x2000232")]
	private struct TimerComparer : IComparer, IComparer<Timer>
	{

		[Address(RVA = "0x747532C", Offset = "0x747532C", Length = "0x70")]
		[Token(Token = "0x6001460")]
		public override int Compare(Timer tx, Timer ty) { }

		[Address(RVA = "0x7475294", Offset = "0x7475294", Length = "0x98")]
		[Token(Token = "0x600145F")]
		private override int System.Collections.IComparer.Compare(object x, object y) { }

	}

	[Token(Token = "0x4000A8E")]
	private const long MaxValue = 4294967294; //Field offset: 0x0
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000A86")]
	private TimerCallback callback; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000A87")]
	private object state; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000A88")]
	private long due_time_ms; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000A89")]
	private long period_ms; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000A8A")]
	private long next_run; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000A8B")]
	private bool disposed; //Field offset: 0x40
	[FieldOffset(Offset = "0x41")]
	[Token(Token = "0x4000A8C")]
	private bool is_dead; //Field offset: 0x41
	[FieldOffset(Offset = "0x42")]
	[Token(Token = "0x4000A8D")]
	private bool is_added; //Field offset: 0x42

	[Token(Token = "0x17000210")]
	private static Scheduler scheduler
	{
		[Address(RVA = "0x7474B14", Offset = "0x7474B14", Length = "0x88")]
		[Token(Token = "0x6001455")]
		private get { } //Length: 136
	}

	[Address(RVA = "0x7474B9C", Offset = "0x7474B9C", Length = "0x4C")]
	[Token(Token = "0x6001456")]
	public Timer(TimerCallback callback, object state, int dueTime, int period) { }

	[Address(RVA = "0x7474C90", Offset = "0x7474C90", Length = "0xD4")]
	[Token(Token = "0x6001457")]
	public Timer(TimerCallback callback, object state, TimeSpan dueTime, TimeSpan period) { }

	[Address(RVA = "0x7474F44", Offset = "0x7474F44", Length = "0x20")]
	[Token(Token = "0x6001459")]
	public bool Change(int dueTime, int period) { }

	[Address(RVA = "0x7474F64", Offset = "0x7474F64", Length = "0xB8")]
	[Token(Token = "0x600145A")]
	public bool Change(TimeSpan dueTime, TimeSpan period) { }

	[Address(RVA = "0x7474D64", Offset = "0x7474D64", Length = "0x1E0")]
	[Token(Token = "0x600145C")]
	private bool Change(long dueTime, long period, bool first) { }

	[Address(RVA = "0x747501C", Offset = "0x747501C", Length = "0x38")]
	[Token(Token = "0x600145B")]
	public override void Dispose() { }

	[Address(RVA = "0x7474B14", Offset = "0x7474B14", Length = "0x88")]
	[Token(Token = "0x6001455")]
	private static Scheduler get_scheduler() { }

	[Address(RVA = "0x7475110", Offset = "0x7475110", Length = "0x4")]
	[Token(Token = "0x600145E")]
	private static long GetTimeMonotonic() { }

	[Address(RVA = "0x7474BE8", Offset = "0x7474BE8", Length = "0xA8")]
	[Token(Token = "0x6001458")]
	private void Init(TimerCallback callback, object state, long dueTime, long period) { }

	[Address(RVA = "0x7475290", Offset = "0x7475290", Length = "0x4")]
	[Token(Token = "0x600145D")]
	internal void KeepRootedWhileScheduled() { }

}

