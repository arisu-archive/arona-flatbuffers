namespace System.Threading;

[ComVisible(False)]
[DebuggerDisplay("Current Count = {m_currentCount}")]
[Token(Token = "0x20001FD")]
public class SemaphoreSlim : IDisposable
{
	[CompilerGenerated]
	[Token(Token = "0x20001FF")]
	private struct <WaitUntilCountOrTimeoutAsync>d__32 : IAsyncStateMachine
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40009C9")]
		public int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x40009CA")]
		public AsyncTaskMethodBuilder<Boolean> <>t__builder; //Field offset: 0x8
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40009CB")]
		public CancellationToken cancellationToken; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x40009CC")]
		public TaskNode asyncWaiter; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x40009CD")]
		public int millisecondsTimeout; //Field offset: 0x30
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x40009CE")]
		public SemaphoreSlim <>4__this; //Field offset: 0x38
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x40009CF")]
		private CancellationTokenSource <cts>5__2; //Field offset: 0x40
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x40009D0")]
		private object <>7__wrap2; //Field offset: 0x48
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x40009D1")]
		private ConfiguredTaskAwaiter<Task> <>u__1; //Field offset: 0x50
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x40009D2")]
		private ConfiguredTaskAwaiter<Boolean> <>u__2; //Field offset: 0x60

		[Address(RVA = "0x746998C", Offset = "0x746998C", Length = "0x88C")]
		[Token(Token = "0x60012F3")]
		private override void MoveNext() { }

		[Address(RVA = "0x746A218", Offset = "0x746A218", Length = "0x7C")]
		[DebuggerHidden]
		[Token(Token = "0x60012F4")]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[Token(Token = "0x20001FE")]
	private sealed class TaskNode : Task<Boolean>, IThreadPoolWorkItem
	{
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x40009C7")]
		internal TaskNode Prev; //Field offset: 0x58
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x40009C8")]
		internal TaskNode Next; //Field offset: 0x60

		[Address(RVA = "0x7469190", Offset = "0x7469190", Length = "0x48")]
		[Token(Token = "0x60012F0")]
		internal TaskNode() { }

		[Address(RVA = "0x746993C", Offset = "0x746993C", Length = "0x4C")]
		[Token(Token = "0x60012F1")]
		private override void System.Threading.IThreadPoolWorkItem.ExecuteWorkItem() { }

		[Address(RVA = "0x7469988", Offset = "0x7469988", Length = "0x4")]
		[Token(Token = "0x60012F2")]
		private override void System.Threading.IThreadPoolWorkItem.MarkAborted(ThreadAbortException tae) { }

	}

	[Token(Token = "0x40009C3")]
	private static readonly Task<Boolean> s_trueTask; //Field offset: 0x0
	[Token(Token = "0x40009C5")]
	private const int NO_MAXIMUM = 2147483647; //Field offset: 0x0
	[Token(Token = "0x40009C4")]
	private static readonly Task<Boolean> s_falseTask; //Field offset: 0x8
	[Token(Token = "0x40009C6")]
	private static Action<Object> s_cancellationTokenCanceledEventHandler; //Field offset: 0x10
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40009BC")]
	private int m_currentCount; //Field offset: 0x10
	[FieldOffset(Offset = "0x14")]
	[Token(Token = "0x40009BD")]
	private readonly int m_maxCount; //Field offset: 0x14
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40009BE")]
	private int m_waitCount; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40009BF")]
	private object m_lockObj; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40009C0")]
	private ManualResetEvent m_waitHandle; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40009C1")]
	private TaskNode m_asyncHead; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40009C2")]
	private TaskNode m_asyncTail; //Field offset: 0x38

	[Token(Token = "0x170001EA")]
	public int CurrentCount
	{
		[Address(RVA = "0x7468370", Offset = "0x7468370", Length = "0x18")]
		[Token(Token = "0x60012DB")]
		 get { } //Length: 24
	}

	[Address(RVA = "0x74697F4", Offset = "0x74697F4", Length = "0x148")]
	[Token(Token = "0x60012EF")]
	private static SemaphoreSlim() { }

	[Address(RVA = "0x7468388", Offset = "0x7468388", Length = "0x8")]
	[Token(Token = "0x60012DC")]
	public SemaphoreSlim(int initialCount) { }

	[Address(RVA = "0x7468390", Offset = "0x7468390", Length = "0x1A0")]
	[Token(Token = "0x60012DD")]
	public SemaphoreSlim(int initialCount, int maxCount) { }

	[Address(RVA = "0x74696E0", Offset = "0x74696E0", Length = "0x114")]
	[Token(Token = "0x60012EC")]
	private static void CancellationTokenCanceledEventHandler(object obj) { }

	[Address(RVA = "0x7468A94", Offset = "0x7468A94", Length = "0x84")]
	[Token(Token = "0x60012ED")]
	private void CheckDispose() { }

	[Address(RVA = "0x7468F80", Offset = "0x7468F80", Length = "0xB0")]
	[Token(Token = "0x60012E4")]
	private TaskNode CreateAndAddAsyncWaiter() { }

	[Address(RVA = "0x7469644", Offset = "0x7469644", Length = "0x9C")]
	[Token(Token = "0x60012EB")]
	protected override void Dispose(bool disposing) { }

	[Address(RVA = "0x74695D8", Offset = "0x74695D8", Length = "0x6C")]
	[Token(Token = "0x60012EA")]
	public override void Dispose() { }

	[Address(RVA = "0x7468370", Offset = "0x7468370", Length = "0x18")]
	[Token(Token = "0x60012DB")]
	public int get_CurrentCount() { }

	[Address(RVA = "0x7468530", Offset = "0x7468530", Length = "0x8")]
	[Token(Token = "0x60012EE")]
	private static string GetResourceString(string str) { }

	[Address(RVA = "0x74695CC", Offset = "0x74695CC", Length = "0xC")]
	[Token(Token = "0x60012E9")]
	private static void QueueWaiterTask(TaskNode waiterTask) { }

	[Address(RVA = "0x74692C0", Offset = "0x74692C0", Length = "0x8")]
	[Token(Token = "0x60012E7")]
	public int Release() { }

	[Address(RVA = "0x74692C8", Offset = "0x74692C8", Length = "0x304")]
	[Token(Token = "0x60012E8")]
	public int Release(int releaseCount) { }

	[Address(RVA = "0x74691D8", Offset = "0x74691D8", Length = "0xE8")]
	[Token(Token = "0x60012E5")]
	private bool RemoveAsyncWaiter(TaskNode task) { }

	[Address(RVA = "0x7468544", Offset = "0x7468544", Length = "0x548")]
	[Token(Token = "0x60012E0")]
	public bool Wait(int millisecondsTimeout, CancellationToken cancellationToken) { }

	[Address(RVA = "0x7468A8C", Offset = "0x7468A8C", Length = "0x8")]
	[Token(Token = "0x60012DF")]
	public bool Wait(int millisecondsTimeout) { }

	[Address(RVA = "0x7468538", Offset = "0x7468538", Length = "0xC")]
	[Token(Token = "0x60012DE")]
	public void Wait() { }

	[Address(RVA = "0x7468F74", Offset = "0x7468F74", Length = "0xC")]
	[Token(Token = "0x60012E2")]
	public Task WaitAsync() { }

	[Address(RVA = "0x7468B18", Offset = "0x7468B18", Length = "0x32C")]
	[Token(Token = "0x60012E3")]
	public Task<Boolean> WaitAsync(int millisecondsTimeout, CancellationToken cancellationToken) { }

	[Address(RVA = "0x7468E44", Offset = "0x7468E44", Length = "0xCC")]
	[Token(Token = "0x60012E1")]
	private bool WaitUntilCountOrTimeout(int millisecondsTimeout, uint startTime, CancellationToken cancellationToken) { }

	[Address(RVA = "0x7469030", Offset = "0x7469030", Length = "0x160")]
	[AsyncStateMachine(typeof(<WaitUntilCountOrTimeoutAsync>d__32))]
	[Token(Token = "0x60012E6")]
	private Task<Boolean> WaitUntilCountOrTimeoutAsync(TaskNode asyncWaiter, int millisecondsTimeout, CancellationToken cancellationToken) { }

}

