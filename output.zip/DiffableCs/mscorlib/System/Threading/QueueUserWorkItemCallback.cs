namespace System.Threading;

[Token(Token = "0x2000226")]
internal sealed class QueueUserWorkItemCallback : IThreadPoolWorkItem
{
	[Token(Token = "0x4000A3F")]
	internal static ContextCallback ccb; //Field offset: 0x0
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000A3C")]
	private WaitCallback callback; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000A3D")]
	private ExecutionContext context; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000A3E")]
	private object state; //Field offset: 0x20

	[Address(RVA = "0x7471968", Offset = "0x7471968", Length = "0xA0")]
	[Token(Token = "0x60013F3")]
	private static QueueUserWorkItemCallback() { }

	[Address(RVA = "0x747171C", Offset = "0x747171C", Length = "0xEC")]
	[Token(Token = "0x60013EF")]
	internal QueueUserWorkItemCallback(WaitCallback waitCallback, object stateObj, bool compressStack, ref StackCrawlMark stackMark) { }

	[Address(RVA = "0x7471808", Offset = "0x7471808", Length = "0xE4")]
	[Token(Token = "0x60013F0")]
	private override void System.Threading.IThreadPoolWorkItem.ExecuteWorkItem() { }

	[Address(RVA = "0x74718EC", Offset = "0x74718EC", Length = "0x4")]
	[Token(Token = "0x60013F1")]
	private override void System.Threading.IThreadPoolWorkItem.MarkAborted(ThreadAbortException tae) { }

	[Address(RVA = "0x74718F0", Offset = "0x74718F0", Length = "0x78")]
	[Token(Token = "0x60013F2")]
	private static void WaitCallback_Context(object state) { }

}

