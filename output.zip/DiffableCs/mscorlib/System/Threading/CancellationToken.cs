namespace System.Threading;

[DebuggerDisplay("IsCancellationRequested = {IsCancellationRequested}")]
[IsReadOnly]
[Token(Token = "0x20001E8")]
public struct CancellationToken
{
	[CompilerGenerated]
	[Token(Token = "0x20001E9")]
	private sealed class <>c
	{
		[Token(Token = "0x400097A")]
		public static readonly <>c <>9; //Field offset: 0x0

		[Address(RVA = "0x74648F8", Offset = "0x74648F8", Length = "0x70")]
		[Token(Token = "0x6001276")]
		private static <>c() { }

		[Address(RVA = "0x7464968", Offset = "0x7464968", Length = "0x8")]
		[Token(Token = "0x6001277")]
		public <>c() { }

		[Address(RVA = "0x7464970", Offset = "0x7464970", Length = "0x6C")]
		[Token(Token = "0x6001278")]
		internal void <.cctor>b__26_0(object obj) { }

	}

	[Token(Token = "0x4000979")]
	private static readonly Action<Object> s_actionToActionObjShunt; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000978")]
	private readonly CancellationTokenSource _source; //Field offset: 0x0

	[Token(Token = "0x170001D6")]
	public bool CanBeCanceled
	{
		[Address(RVA = "0x7463C3C", Offset = "0x7463C3C", Length = "0x10")]
		[Token(Token = "0x6001265")]
		 get { } //Length: 16
	}

	[Token(Token = "0x170001D5")]
	public bool IsCancellationRequested
	{
		[Address(RVA = "0x7463BF4", Offset = "0x7463BF4", Length = "0x2C")]
		[Token(Token = "0x6001264")]
		 get { } //Length: 44
	}

	[Token(Token = "0x170001D4")]
	public static CancellationToken None
	{
		[Address(RVA = "0x7463BEC", Offset = "0x7463BEC", Length = "0x8")]
		[Token(Token = "0x6001263")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x7464828", Offset = "0x7464828", Length = "0xD0")]
	[Token(Token = "0x6001275")]
	private static CancellationToken() { }

	[Address(RVA = "0x7463C4C", Offset = "0x7463C4C", Length = "0x8")]
	[Token(Token = "0x6001266")]
	internal CancellationToken(CancellationTokenSource source) { }

	[Address(RVA = "0x7463C54", Offset = "0x7463C54", Length = "0x9C")]
	[Token(Token = "0x6001267")]
	public CancellationToken(bool canceled) { }

	[Address(RVA = "0x7464568", Offset = "0x7464568", Length = "0xA8")]
	[Token(Token = "0x600126F")]
	public virtual bool Equals(object other) { }

	[Address(RVA = "0x7464558", Offset = "0x7464558", Length = "0x10")]
	[Token(Token = "0x600126E")]
	public bool Equals(CancellationToken other) { }

	[Address(RVA = "0x7463C3C", Offset = "0x7463C3C", Length = "0x10")]
	[Token(Token = "0x6001265")]
	public bool get_CanBeCanceled() { }

	[Address(RVA = "0x7463BF4", Offset = "0x7463BF4", Length = "0x2C")]
	[Token(Token = "0x6001264")]
	public bool get_IsCancellationRequested() { }

	[Address(RVA = "0x7463BEC", Offset = "0x7463BEC", Length = "0x8")]
	[Token(Token = "0x6001263")]
	public static CancellationToken get_None() { }

	[Address(RVA = "0x7464610", Offset = "0x7464610", Length = "0x74")]
	[Token(Token = "0x6001270")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x7464164", Offset = "0x7464164", Length = "0x9C")]
	[Token(Token = "0x600126C")]
	internal CancellationTokenRegistration InternalRegisterWithoutEC(Action<Object> callback, object state) { }

	[Address(RVA = "0x7464684", Offset = "0x7464684", Length = "0x64")]
	[Token(Token = "0x6001271")]
	public static bool op_Equality(CancellationToken left, CancellationToken right) { }

	[Address(RVA = "0x74646E8", Offset = "0x74646E8", Length = "0x64")]
	[Token(Token = "0x6001272")]
	public static bool op_Inequality(CancellationToken left, CancellationToken right) { }

	[Address(RVA = "0x74640C0", Offset = "0x74640C0", Length = "0xA4")]
	[Token(Token = "0x600126B")]
	public CancellationTokenRegistration Register(Action<Object> callback, object state, bool useSynchronizationContext) { }

	[Address(RVA = "0x7463DEC", Offset = "0x7463DEC", Length = "0x134")]
	[Token(Token = "0x600126D")]
	public CancellationTokenRegistration Register(Action<Object> callback, object state, bool useSynchronizationContext, bool useExecutionContext) { }

	[Address(RVA = "0x7463F20", Offset = "0x7463F20", Length = "0x104")]
	[Token(Token = "0x6001269")]
	public CancellationTokenRegistration Register(Action callback, bool useSynchronizationContext) { }

	[Address(RVA = "0x7463CF0", Offset = "0x7463CF0", Length = "0xFC")]
	[Token(Token = "0x6001268")]
	public CancellationTokenRegistration Register(Action callback) { }

	[Address(RVA = "0x7464024", Offset = "0x7464024", Length = "0x9C")]
	[Token(Token = "0x600126A")]
	public CancellationTokenRegistration Register(Action<Object> callback, object state) { }

	[Address(RVA = "0x746474C", Offset = "0x746474C", Length = "0x80")]
	[Token(Token = "0x6001273")]
	public void ThrowIfCancellationRequested() { }

	[Address(RVA = "0x74647CC", Offset = "0x74647CC", Length = "0x5C")]
	[Token(Token = "0x6001274")]
	private void ThrowOperationCanceledException() { }

}

