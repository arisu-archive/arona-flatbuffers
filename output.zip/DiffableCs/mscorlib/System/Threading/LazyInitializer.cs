namespace System.Threading;

[Token(Token = "0x20001DA")]
public static class LazyInitializer
{

	[Address(RVA = "0x436A1F4", Offset = "0x436A1F4", Length = "0x48")]
	[Token(Token = "0x6001244")]
	public static T EnsureInitialized(ref T target) { }

	[Address(RVA = "0x436A23C", Offset = "0x436A23C", Length = "0x5C")]
	[Token(Token = "0x6001246")]
	public static T EnsureInitialized(ref T target, Func<T> valueFactory) { }

	[Address(RVA = "0x436A2FC", Offset = "0x436A2FC", Length = "0x78")]
	[Token(Token = "0x6001248")]
	public static T EnsureInitialized(ref T target, ref bool initialized, ref object syncLock, Func<T> valueFactory) { }

	[Address(RVA = "0x436A298", Offset = "0x436A298", Length = "0x64")]
	[Token(Token = "0x600124A")]
	public static T EnsureInitialized(ref T target, ref object syncLock, Func<T> valueFactory) { }

	[Address(RVA = "0x436A3EC", Offset = "0x436A3EC", Length = "0xF0")]
	[Token(Token = "0x6001245")]
	private static T EnsureInitializedCore(ref T target) { }

	[Address(RVA = "0x436A4DC", Offset = "0x436A4DC", Length = "0x94")]
	[Token(Token = "0x6001247")]
	private static T EnsureInitializedCore(ref T target, Func<T> valueFactory) { }

	[Address(RVA = "0x436A6F4", Offset = "0x436A6F4", Length = "0x140")]
	[Token(Token = "0x6001249")]
	private static T EnsureInitializedCore(ref T target, ref bool initialized, ref object syncLock, Func<T> valueFactory) { }

	[Address(RVA = "0x436A570", Offset = "0x436A570", Length = "0x184")]
	[Token(Token = "0x600124B")]
	private static T EnsureInitializedCore(ref T target, ref object syncLock, Func<T> valueFactory) { }

	[Address(RVA = "0x7463438", Offset = "0x7463438", Length = "0x80")]
	[Token(Token = "0x600124C")]
	private static object EnsureLockInitialized(ref object syncLock) { }

}

