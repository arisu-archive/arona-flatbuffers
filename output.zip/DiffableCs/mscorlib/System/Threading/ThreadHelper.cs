namespace System.Threading;

[Token(Token = "0x2000217")]
internal class ThreadHelper
{
	[Token(Token = "0x4000A12")]
	internal static ContextCallback _ccb; //Field offset: 0x0
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000A0F")]
	private Delegate _start; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000A10")]
	private object _startArg; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000A11")]
	private ExecutionContext _executionContext; //Field offset: 0x20

	[Address(RVA = "0x746E400", Offset = "0x746E400", Length = "0xA0")]
	[Token(Token = "0x6001387")]
	private static ThreadHelper() { }

	[Address(RVA = "0x746E0C0", Offset = "0x746E0C0", Length = "0x30")]
	[Token(Token = "0x6001382")]
	internal ThreadHelper(Delegate start) { }

	[Address(RVA = "0x746E0F0", Offset = "0x746E0F0", Length = "0x8")]
	[Token(Token = "0x6001383")]
	internal void SetExecutionContextHelper(ExecutionContext ec) { }

	[Address(RVA = "0x746E1F4", Offset = "0x746E1F4", Length = "0x114")]
	[Token(Token = "0x6001385")]
	internal void ThreadStart(object obj) { }

	[Address(RVA = "0x746E308", Offset = "0x746E308", Length = "0xF8")]
	[Token(Token = "0x6001386")]
	internal void ThreadStart() { }

	[Address(RVA = "0x746E0F8", Offset = "0x746E0F8", Length = "0xFC")]
	[Token(Token = "0x6001384")]
	private static void ThreadStart_Context(object state) { }

}

