namespace System.Threading;

[DefaultMember("Item")]
[Token(Token = "0x20001FA")]
internal class SparselyPopulatedArrayFragment
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40009B6")]
	internal readonly T[] _elements; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40009B7")]
	internal int _freeCount; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40009B8")]
	internal SparselyPopulatedArrayFragment<T> _next; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40009B9")]
	internal SparselyPopulatedArrayFragment<T> _prev; //Field offset: 0x0

	[Token(Token = "0x170001E7")]
	internal T Item
	{
		[Address(RVA = "0x5F1C214", Offset = "0x5F1C214", Length = "0x38")]
		[Token(Token = "0x60012D2")]
		internal get { } //Length: 56
	}

	[Token(Token = "0x170001E8")]
	internal int Length
	{
		[Address(RVA = "0x5F1C24C", Offset = "0x5F1C24C", Length = "0x1C")]
		[Token(Token = "0x60012D3")]
		internal get { } //Length: 28
	}

	[Token(Token = "0x170001E9")]
	internal SparselyPopulatedArrayFragment<T> Prev
	{
		[Address(RVA = "0x5F1C268", Offset = "0x5F1C268", Length = "0x18")]
		[Token(Token = "0x60012D4")]
		internal get { } //Length: 24
	}

	[Address(RVA = "0x5F1C180", Offset = "0x5F1C180", Length = "0x18")]
	[Token(Token = "0x60012D0")]
	internal SparselyPopulatedArrayFragment`1(int size) { }

	[Address(RVA = "0x5F1C198", Offset = "0x5F1C198", Length = "0x7C")]
	[Token(Token = "0x60012D1")]
	internal SparselyPopulatedArrayFragment`1(int size, SparselyPopulatedArrayFragment<T> prev) { }

	[Address(RVA = "0x5F1C214", Offset = "0x5F1C214", Length = "0x38")]
	[Token(Token = "0x60012D2")]
	internal T get_Item(int index) { }

	[Address(RVA = "0x5F1C24C", Offset = "0x5F1C24C", Length = "0x1C")]
	[Token(Token = "0x60012D3")]
	internal int get_Length() { }

	[Address(RVA = "0x5F1C268", Offset = "0x5F1C268", Length = "0x18")]
	[Token(Token = "0x60012D4")]
	internal SparselyPopulatedArrayFragment<T> get_Prev() { }

	[Address(RVA = "0x5F1C280", Offset = "0x5F1C280", Length = "0x64")]
	[Token(Token = "0x60012D5")]
	internal T SafeAtomicRemove(int index, T expectedElement) { }

}

