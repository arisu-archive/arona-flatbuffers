namespace System.Threading;

[Token(Token = "0x20001E7")]
public class WaitHandleCannotBeOpenedException : ApplicationException
{

	[Address(RVA = "0x7463B64", Offset = "0x7463B64", Length = "0x5C")]
	[Token(Token = "0x6001260")]
	public WaitHandleCannotBeOpenedException() { }

	[Address(RVA = "0x7463BC0", Offset = "0x7463BC0", Length = "0x24")]
	[Token(Token = "0x6001261")]
	public WaitHandleCannotBeOpenedException(string message) { }

	[Address(RVA = "0x7463BE4", Offset = "0x7463BE4", Length = "0x8")]
	[Token(Token = "0x6001262")]
	protected WaitHandleCannotBeOpenedException(SerializationInfo info, StreamingContext context) { }

}

