namespace System.Threading;

[Token(Token = "0x200022D")]
internal static class NativeEventCalls
{

	[Address(RVA = "0x7473898", Offset = "0x7473898", Length = "0x4")]
	[Token(Token = "0x6001442")]
	public static void CloseEvent_internal(IntPtr handle) { }

	[Address(RVA = "0x74736E4", Offset = "0x74736E4", Length = "0x4")]
	[Token(Token = "0x600143D")]
	private static IntPtr CreateEvent_icall(bool manual, bool initial, Char* name, int name_length, out int errorCode) { }

	[Address(RVA = "0x7473690", Offset = "0x7473690", Length = "0x54")]
	[Token(Token = "0x600143C")]
	public static IntPtr CreateEvent_internal(bool manual, bool initial, string name, out int errorCode) { }

	[Address(RVA = "0x74737C0", Offset = "0x74737C0", Length = "0xD4")]
	[Token(Token = "0x6001440")]
	public static bool ResetEvent(SafeWaitHandle handle) { }

	[Address(RVA = "0x7473894", Offset = "0x7473894", Length = "0x4")]
	[Token(Token = "0x6001441")]
	private static bool ResetEvent_internal(IntPtr handle) { }

	[Address(RVA = "0x74736E8", Offset = "0x74736E8", Length = "0xD4")]
	[Token(Token = "0x600143E")]
	public static bool SetEvent(SafeWaitHandle handle) { }

	[Address(RVA = "0x74737BC", Offset = "0x74737BC", Length = "0x4")]
	[Token(Token = "0x600143F")]
	private static bool SetEvent_internal(IntPtr handle) { }

}

