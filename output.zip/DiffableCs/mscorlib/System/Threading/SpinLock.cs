namespace System.Threading;

[ComVisible(False)]
[DebuggerDisplay("IsHeld = {IsHeld}")]
[DebuggerTypeProxy(typeof(SystemThreading_SpinLockDebugView))]
[Token(Token = "0x2000200")]
public struct SpinLock
{
	[Token(Token = "0x2000201")]
	public class SystemThreading_SpinLockDebugView
	{

	}

	[Token(Token = "0x40009D4")]
	private static int MAXIMUM_WAITERS; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40009D3")]
	private int m_owner; //Field offset: 0x0

	[Token(Token = "0x170001EB")]
	public bool IsHeldByCurrentThread
	{
		[Address(RVA = "0x746AD14", Offset = "0x746AD14", Length = "0xE0")]
		[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
		[Token(Token = "0x60012FD")]
		 get { } //Length: 224
	}

	[Token(Token = "0x170001EC")]
	public bool IsThreadOwnerTrackingEnabled
	{
		[Address(RVA = "0x746A930", Offset = "0x746A930", Length = "0x1C")]
		[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
		[Token(Token = "0x60012FE")]
		 get { } //Length: 28
	}

	[Address(RVA = "0x746ADF4", Offset = "0x746ADF4", Length = "0x4C")]
	[Token(Token = "0x60012FF")]
	private static SpinLock() { }

	[Address(RVA = "0x746A294", Offset = "0x746A294", Length = "0x38")]
	[Token(Token = "0x60012F5")]
	public SpinLock(bool enableThreadOwnerTracking) { }

	[Address(RVA = "0x746A384", Offset = "0x746A384", Length = "0x4D8")]
	[Token(Token = "0x60012F8")]
	private void ContinueTryEnter(int millisecondsTimeout, ref bool lockTaken) { }

	[Address(RVA = "0x746A94C", Offset = "0x746A94C", Length = "0x180")]
	[Token(Token = "0x60012FA")]
	private void ContinueTryEnterWithThreadTracking(int millisecondsTimeout, uint startTime, ref bool lockTaken) { }

	[Address(RVA = "0x746AACC", Offset = "0x746AACC", Length = "0xA4")]
	[Token(Token = "0x60012F9")]
	private void DecrementWaiters() { }

	[Address(RVA = "0x746A2CC", Offset = "0x746A2CC", Length = "0xB8")]
	[Token(Token = "0x60012F6")]
	public void Enter(ref bool lockTaken) { }

	[Address(RVA = "0x746AB70", Offset = "0x746AB70", Length = "0x8C")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x60012FB")]
	public void Exit(bool useMemoryBarrier) { }

	[Address(RVA = "0x746ABFC", Offset = "0x746ABFC", Length = "0x118")]
	[Token(Token = "0x60012FC")]
	private void ExitSlowPath(bool useMemoryBarrier) { }

	[Address(RVA = "0x746AD14", Offset = "0x746AD14", Length = "0xE0")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x60012FD")]
	public bool get_IsHeldByCurrentThread() { }

	[Address(RVA = "0x746A930", Offset = "0x746A930", Length = "0x1C")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x60012FE")]
	public bool get_IsThreadOwnerTrackingEnabled() { }

	[Address(RVA = "0x746A85C", Offset = "0x746A85C", Length = "0xD4")]
	[Token(Token = "0x60012F7")]
	public void TryEnter(int millisecondsTimeout, ref bool lockTaken) { }

}

