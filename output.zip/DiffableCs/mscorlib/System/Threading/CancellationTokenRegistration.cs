namespace System.Threading;

[IsReadOnly]
[Token(Token = "0x20001EF")]
public struct CancellationTokenRegistration : IEquatable<CancellationTokenRegistration>, IDisposable
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000993")]
	private readonly CancellationCallbackInfo m_callbackInfo; //Field offset: 0x0
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x4000994")]
	private readonly SparselyPopulatedArrayAddInfo<CancellationCallbackInfo> m_registrationInfo; //Field offset: 0x8

	[Address(RVA = "0x74661C4", Offset = "0x74661C4", Length = "0x38")]
	[Token(Token = "0x600129B")]
	internal CancellationTokenRegistration(CancellationCallbackInfo callbackInfo, SparselyPopulatedArrayAddInfo<CancellationCallbackInfo> registrationInfo) { }

	[Address(RVA = "0x7466278", Offset = "0x7466278", Length = "0x94")]
	[Token(Token = "0x600129D")]
	public override void Dispose() { }

	[Address(RVA = "0x74663C8", Offset = "0x74663C8", Length = "0x90")]
	[Token(Token = "0x600129E")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x7466458", Offset = "0x7466458", Length = "0x80")]
	[Token(Token = "0x600129F")]
	public override bool Equals(CancellationTokenRegistration other) { }

	[Address(RVA = "0x74664D8", Offset = "0x74664D8", Length = "0x8C")]
	[Token(Token = "0x60012A0")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x74661FC", Offset = "0x74661FC", Length = "0x7C")]
	[Token(Token = "0x600129C")]
	public bool Unregister() { }

}

