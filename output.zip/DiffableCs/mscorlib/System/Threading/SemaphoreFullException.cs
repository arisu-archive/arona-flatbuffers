namespace System.Threading;

[Token(Token = "0x20001DF")]
public class SemaphoreFullException : SystemException
{

	[Address(RVA = "0x7463758", Offset = "0x7463758", Length = "0x4C")]
	[Token(Token = "0x6001253")]
	public SemaphoreFullException() { }

	[Address(RVA = "0x74637A4", Offset = "0x74637A4", Length = "0x8")]
	[Token(Token = "0x6001254")]
	protected SemaphoreFullException(SerializationInfo info, StreamingContext context) { }

}

