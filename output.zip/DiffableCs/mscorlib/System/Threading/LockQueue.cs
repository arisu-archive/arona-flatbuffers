namespace System.Threading;

[Token(Token = "0x200022B")]
internal class LockQueue
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000A4D")]
	private ReaderWriterLock rwlock; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000A4E")]
	private int lockCount; //Field offset: 0x18

	[Token(Token = "0x1700020F")]
	public bool IsEmpty
	{
		[Address(RVA = "0x7473548", Offset = "0x7473548", Length = "0xAC")]
		[Token(Token = "0x600143A")]
		 get { } //Length: 172
	}

	[Address(RVA = "0x7473390", Offset = "0x7473390", Length = "0x30")]
	[Token(Token = "0x6001438")]
	public LockQueue(ReaderWriterLock rwlock) { }

	[Address(RVA = "0x7473548", Offset = "0x7473548", Length = "0xAC")]
	[Token(Token = "0x600143A")]
	public bool get_IsEmpty() { }

	[Address(RVA = "0x74735F4", Offset = "0x74735F4", Length = "0x9C")]
	[Token(Token = "0x600143B")]
	public void Pulse() { }

	[Address(RVA = "0x74733C0", Offset = "0x74733C0", Length = "0x188")]
	[Token(Token = "0x6001439")]
	public bool Wait(int timeout) { }

}

