namespace System.Threading;

[Token(Token = "0x20001DE")]
public sealed class ParameterizedThreadStart : MulticastDelegate
{

	[Address(RVA = "0x7463604", Offset = "0x7463604", Length = "0x140")]
	[Token(Token = "0x6001251")]
	public ParameterizedThreadStart(object object, IntPtr method) { }

	[Address(RVA = "0x7463744", Offset = "0x7463744", Length = "0x14")]
	[Token(Token = "0x6001252")]
	public override void Invoke(object obj) { }

}

