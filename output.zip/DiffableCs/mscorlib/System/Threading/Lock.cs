namespace System.Threading;

[Token(Token = "0x20001FC")]
public class Lock
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40009BB")]
	private object _lock; //Field offset: 0x10

	[Address(RVA = "0x74682FC", Offset = "0x74682FC", Length = "0x74")]
	[Token(Token = "0x60012DA")]
	public Lock() { }

	[Address(RVA = "0x74682C4", Offset = "0x74682C4", Length = "0xC")]
	[Token(Token = "0x60012D8")]
	public void Acquire() { }

	[Address(RVA = "0x74682F0", Offset = "0x74682F0", Length = "0xC")]
	[Token(Token = "0x60012D9")]
	public void Release() { }

}

