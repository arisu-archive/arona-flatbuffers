namespace System.Threading;

[Token(Token = "0x20001D5")]
public sealed class AsyncLocal : IAsyncLocal
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x400095B")]
	private readonly Action<AsyncLocalValueChangedArgs`1<T>> m_valueChangedHandler; //Field offset: 0x0

	[Token(Token = "0x170001D2")]
	public T Value
	{
		[Address(RVA = "0x67EAF80", Offset = "0x67EAF80", Length = "0x74")]
		[Token(Token = "0x600123E")]
		 set { } //Length: 116
	}

	[Address(RVA = "0x67EAF50", Offset = "0x67EAF50", Length = "0x30")]
	[Token(Token = "0x600123D")]
	public AsyncLocal`1(Action<AsyncLocalValueChangedArgs`1<T>> valueChangedHandler) { }

	[Address(RVA = "0x67EAF80", Offset = "0x67EAF80", Length = "0x74")]
	[Token(Token = "0x600123E")]
	public void set_Value(T value) { }

	[Address(RVA = "0x67EAFF4", Offset = "0x67EAFF4", Length = "0x144")]
	[Token(Token = "0x600123F")]
	private override void System.Threading.IAsyncLocal.OnValueChanged(object previousValueObj, object currentValueObj, bool contextChanged) { }

}

