namespace System.Threading;

[ComVisible(True)]
[Token(Token = "0x200021E")]
public sealed class WaitOrTimerCallback : MulticastDelegate
{

	[Address(RVA = "0x746F54C", Offset = "0x746F54C", Length = "0x144")]
	[Token(Token = "0x60013CF")]
	public WaitOrTimerCallback(object object, IntPtr method) { }

	[Address(RVA = "0x746F690", Offset = "0x746F690", Length = "0x14")]
	[Token(Token = "0x60013D0")]
	public override void Invoke(object state, bool timedOut) { }

}

