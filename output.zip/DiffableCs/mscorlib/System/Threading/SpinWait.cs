namespace System.Threading;

[Token(Token = "0x20001EC")]
public struct SpinWait
{
	[Token(Token = "0x400098E")]
	internal static readonly int SpinCountforSpinBeforeWait; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x400098F")]
	private int _count; //Field offset: 0x0

	[Token(Token = "0x170001DB")]
	public int Count
	{
		[Address(RVA = "0x7465DD4", Offset = "0x7465DD4", Length = "0x8")]
		[Token(Token = "0x6001290")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170001DC")]
	public bool NextSpinWillYield
	{
		[Address(RVA = "0x7465DDC", Offset = "0x7465DDC", Length = "0x78")]
		[Token(Token = "0x6001291")]
		 get { } //Length: 120
	}

	[Address(RVA = "0x7466000", Offset = "0x7466000", Length = "0x84")]
	[Token(Token = "0x6001296")]
	private static SpinWait() { }

	[Address(RVA = "0x7465DD4", Offset = "0x7465DD4", Length = "0x8")]
	[Token(Token = "0x6001290")]
	public int get_Count() { }

	[Address(RVA = "0x7465DDC", Offset = "0x7465DDC", Length = "0x78")]
	[Token(Token = "0x6001291")]
	public bool get_NextSpinWillYield() { }

	[Address(RVA = "0x7465FF8", Offset = "0x7465FF8", Length = "0x8")]
	[Token(Token = "0x6001295")]
	public void Reset() { }

	[Address(RVA = "0x7465CDC", Offset = "0x7465CDC", Length = "0x58")]
	[Token(Token = "0x6001292")]
	public void SpinOnce() { }

	[Address(RVA = "0x7465914", Offset = "0x7465914", Length = "0xFC")]
	[Token(Token = "0x6001293")]
	public void SpinOnce(int sleep1Threshold) { }

	[Address(RVA = "0x7465E54", Offset = "0x7465E54", Length = "0x1A4")]
	[Token(Token = "0x6001294")]
	private void SpinOnceCore(int sleep1Threshold) { }

}

