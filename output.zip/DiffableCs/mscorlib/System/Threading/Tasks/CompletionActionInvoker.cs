namespace System.Threading.Tasks;

[Token(Token = "0x2000269")]
internal sealed class CompletionActionInvoker : IThreadPoolWorkItem
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000B3C")]
	private readonly ITaskCompletionAction m_action; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000B3D")]
	private readonly Task m_completingTask; //Field offset: 0x18

	[Address(RVA = "0x747F6D4", Offset = "0x747F6D4", Length = "0x44")]
	[Token(Token = "0x60015D5")]
	internal CompletionActionInvoker(ITaskCompletionAction action, Task completingTask) { }

	[Address(RVA = "0x7481D8C", Offset = "0x7481D8C", Length = "0x4")]
	[Token(Token = "0x60015D7")]
	public override void MarkAborted(ThreadAbortException e) { }

	[Address(RVA = "0x7481CE4", Offset = "0x7481CE4", Length = "0xA8")]
	[Token(Token = "0x60015D6")]
	private override void System.Threading.IThreadPoolWorkItem.ExecuteWorkItem() { }

}

