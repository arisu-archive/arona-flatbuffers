namespace System.Threading.Tasks;

[Token(Token = "0x200024F")]
internal class ParallelLoopState64 : ParallelLoopState
{
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000AC9")]
	private readonly ParallelLoopStateFlags64 _sharedParallelStateFlags; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000ACA")]
	private long _currentIteration; //Field offset: 0x20

	[Token(Token = "0x17000222")]
	internal long CurrentIteration
	{
		[Address(RVA = "0x7478798", Offset = "0x7478798", Length = "0x8")]
		[Token(Token = "0x60014DF")]
		internal get { } //Length: 8
		[Address(RVA = "0x74787A0", Offset = "0x74787A0", Length = "0x8")]
		[Token(Token = "0x60014E0")]
		internal set { } //Length: 8
	}

	[Address(RVA = "0x7478758", Offset = "0x7478758", Length = "0x40")]
	[Token(Token = "0x60014DE")]
	internal ParallelLoopState64(ParallelLoopStateFlags64 sharedParallelStateFlags) { }

	[Address(RVA = "0x7478798", Offset = "0x7478798", Length = "0x8")]
	[Token(Token = "0x60014DF")]
	internal long get_CurrentIteration() { }

	[Address(RVA = "0x74787A8", Offset = "0x74787A8", Length = "0xC")]
	[Token(Token = "0x60014E1")]
	internal virtual void InternalBreak() { }

	[Address(RVA = "0x74787A0", Offset = "0x74787A0", Length = "0x8")]
	[Token(Token = "0x60014E0")]
	internal void set_CurrentIteration(long value) { }

}

