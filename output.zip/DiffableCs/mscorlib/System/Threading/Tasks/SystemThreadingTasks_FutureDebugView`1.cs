namespace System.Threading.Tasks;

[Token(Token = "0x200025D")]
internal class SystemThreadingTasks_FutureDebugView
{

}

