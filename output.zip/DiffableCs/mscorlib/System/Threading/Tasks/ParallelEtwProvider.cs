namespace System.Threading.Tasks;

[EventSource(Name = "System.Threading.Tasks.Parallel.EventSource")]
[Token(Token = "0x200024B")]
internal sealed class ParallelEtwProvider : EventSource
{
	[Token(Token = "0x200024C")]
	internal enum ForkJoinOperationType
	{
		ParallelInvoke = 1,
		ParallelFor = 2,
		ParallelForEach = 3,
	}

	[Token(Token = "0x200024D")]
	internal class Tasks
	{
		[Token(Token = "0x4000AC5")]
		public const EventTask Loop = 1; //Field offset: 0x0
		[Token(Token = "0x4000AC6")]
		public const EventTask Invoke = 2; //Field offset: 0x0
		[Token(Token = "0x4000AC7")]
		public const EventTask ForkJoin = 5; //Field offset: 0x0

	}

	[Token(Token = "0x4000AC0")]
	public static readonly ParallelEtwProvider Log; //Field offset: 0x0

	[Address(RVA = "0x7478368", Offset = "0x7478368", Length = "0x70")]
	[Token(Token = "0x60014D8")]
	private static ParallelEtwProvider() { }

	[Address(RVA = "0x7478014", Offset = "0x7478014", Length = "0x8")]
	[Token(Token = "0x60014D3")]
	private ParallelEtwProvider() { }

	[Address(RVA = "0x7478298", Offset = "0x7478298", Length = "0x68")]
	[Event(5, Level = EventLevel::Verbose (5), Task = 5, Opcode = EventOpcode::Start (1))]
	[Token(Token = "0x60014D6")]
	public void ParallelFork(int OriginatingTaskSchedulerID, int OriginatingTaskID, int ForkJoinContextID) { }

	[Address(RVA = "0x7478300", Offset = "0x7478300", Length = "0x68")]
	[Event(6, Level = EventLevel::Verbose (5), Task = 5, Opcode = EventOpcode::Stop (2))]
	[Token(Token = "0x60014D7")]
	public void ParallelJoin(int OriginatingTaskSchedulerID, int OriginatingTaskID, int ForkJoinContextID) { }

	[Address(RVA = "0x747801C", Offset = "0x747801C", Length = "0x154")]
	[Event(1, Level = EventLevel::Informational (4), Task = 1, Opcode = EventOpcode::Start (1))]
	[Token(Token = "0x60014D4")]
	public void ParallelLoopBegin(int OriginatingTaskSchedulerID, int OriginatingTaskID, int ForkJoinContextID, ForkJoinOperationType OperationType, long InclusiveFrom, long ExclusiveTo) { }

	[Address(RVA = "0x7478170", Offset = "0x7478170", Length = "0x128")]
	[Event(2, Level = EventLevel::Informational (4), Task = 1, Opcode = EventOpcode::Stop (2))]
	[Token(Token = "0x60014D5")]
	public void ParallelLoopEnd(int OriginatingTaskSchedulerID, int OriginatingTaskID, int ForkJoinContextID, long TotalIterations) { }

}

