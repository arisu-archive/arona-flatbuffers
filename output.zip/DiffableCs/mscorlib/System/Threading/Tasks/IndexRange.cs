namespace System.Threading.Tasks;

[Token(Token = "0x2000253")]
internal struct IndexRange
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000ACF")]
	internal long _nFromInclusive; //Field offset: 0x0
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x4000AD0")]
	internal long _nToExclusive; //Field offset: 0x8
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000AD1")]
	internal Box<Int64> _nSharedCurrentIndexOffset; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000AD2")]
	internal int _bRangeFinished; //Field offset: 0x18

}

