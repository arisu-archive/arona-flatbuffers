namespace System.Threading.Tasks;

[Extension]
[Token(Token = "0x200025B")]
internal static class DebuggerSupport
{
	[Token(Token = "0x4000AEB")]
	private static readonly LowLevelDictionary<Int32, Task> s_activeTasks; //Field offset: 0x0
	[Token(Token = "0x4000AEC")]
	private static readonly object s_activeTasksLock; //Field offset: 0x8

	[Token(Token = "0x17000226")]
	public static bool LoggingOn
	{
		[Address(RVA = "0x7479878", Offset = "0x7479878", Length = "0x8")]
		[Token(Token = "0x6001504")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x7479CD4", Offset = "0x7479CD4", Length = "0xD8")]
	[Token(Token = "0x600150E")]
	private static DebuggerSupport() { }

	[Address(RVA = "0x7479894", Offset = "0x7479894", Length = "0x94")]
	[Token(Token = "0x600150A")]
	public static void AddToActiveTasks(Task task) { }

	[Address(RVA = "0x7479928", Offset = "0x7479928", Length = "0x144")]
	[Token(Token = "0x600150B")]
	private static void AddToActiveTasksNonInlined(Task task) { }

	[Address(RVA = "0x7479878", Offset = "0x7479878", Length = "0x8")]
	[Token(Token = "0x6001504")]
	public static bool get_LoggingOn() { }

	[Address(RVA = "0x7479AFC", Offset = "0x7479AFC", Length = "0x94")]
	[Token(Token = "0x600150C")]
	public static void RemoveFromActiveTasks(Task task) { }

	[Address(RVA = "0x7479B90", Offset = "0x7479B90", Length = "0x144")]
	[Token(Token = "0x600150D")]
	private static void RemoveFromActiveTasksNonInlined(Task task) { }

	[Address(RVA = "0x7479884", Offset = "0x7479884", Length = "0x4")]
	[Token(Token = "0x6001506")]
	public static void TraceOperationCompletion(CausalityTraceLevel traceLevel, Task task, AsyncStatus status) { }

	[Address(RVA = "0x7479880", Offset = "0x7479880", Length = "0x4")]
	[Token(Token = "0x6001505")]
	public static void TraceOperationCreation(CausalityTraceLevel traceLevel, Task task, string operationName, ulong relatedContext) { }

	[Address(RVA = "0x7479888", Offset = "0x7479888", Length = "0x4")]
	[Token(Token = "0x6001507")]
	public static void TraceOperationRelation(CausalityTraceLevel traceLevel, Task task, CausalityRelation relation) { }

	[Address(RVA = "0x7479890", Offset = "0x7479890", Length = "0x4")]
	[Token(Token = "0x6001509")]
	public static void TraceSynchronousWorkCompletion(CausalityTraceLevel traceLevel, CausalitySynchronousWork work) { }

	[Address(RVA = "0x747988C", Offset = "0x747988C", Length = "0x4")]
	[Token(Token = "0x6001508")]
	public static void TraceSynchronousWorkStart(CausalityTraceLevel traceLevel, Task task, CausalitySynchronousWork work) { }

}

