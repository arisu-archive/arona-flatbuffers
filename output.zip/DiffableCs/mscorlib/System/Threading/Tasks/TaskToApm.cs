namespace System.Threading.Tasks;

[Token(Token = "0x200023C")]
internal static class TaskToApm
{
	[CompilerGenerated]
	[Token(Token = "0x200023E")]
	private sealed class <>c__DisplayClass3_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000A9C")]
		public AsyncCallback callback; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000A9D")]
		public IAsyncResult asyncResult; //Field offset: 0x18

		[Address(RVA = "0x74764BC", Offset = "0x74764BC", Length = "0x8")]
		[Token(Token = "0x6001492")]
		public <>c__DisplayClass3_0() { }

		[Address(RVA = "0x74765C0", Offset = "0x74765C0", Length = "0x28")]
		[Token(Token = "0x6001493")]
		internal void <InvokeCallbackWhenTaskCompletes>b__0() { }

	}

	[Token(Token = "0x200023D")]
	private sealed class TaskWrapperAsyncResult : IAsyncResult
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000A99")]
		internal readonly Task Task; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000A9A")]
		private readonly object _state; //Field offset: 0x18
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000A9B")]
		private readonly bool _completedSynchronously; //Field offset: 0x20

		[Token(Token = "0x17000213")]
		private override object System.IAsyncResult.AsyncState
		{
			[Address(RVA = "0x74764F4", Offset = "0x74764F4", Length = "0x8")]
			[Token(Token = "0x600148E")]
			private get { } //Length: 8
		}

		[Token(Token = "0x17000216")]
		private override WaitHandle System.IAsyncResult.AsyncWaitHandle
		{
			[Address(RVA = "0x747651C", Offset = "0x747651C", Length = "0xA4")]
			[Token(Token = "0x6001491")]
			private get { } //Length: 164
		}

		[Token(Token = "0x17000214")]
		private override bool System.IAsyncResult.CompletedSynchronously
		{
			[Address(RVA = "0x74764FC", Offset = "0x74764FC", Length = "0x8")]
			[Token(Token = "0x600148F")]
			private get { } //Length: 8
		}

		[Token(Token = "0x17000215")]
		private override bool System.IAsyncResult.IsCompleted
		{
			[Address(RVA = "0x7476504", Offset = "0x7476504", Length = "0x18")]
			[Token(Token = "0x6001490")]
			private get { } //Length: 24
		}

		[Address(RVA = "0x7476240", Offset = "0x7476240", Length = "0x58")]
		[Token(Token = "0x600148D")]
		internal TaskWrapperAsyncResult(Task task, object state, bool completedSynchronously) { }

		[Address(RVA = "0x74764F4", Offset = "0x74764F4", Length = "0x8")]
		[Token(Token = "0x600148E")]
		private override object System.IAsyncResult.get_AsyncState() { }

		[Address(RVA = "0x747651C", Offset = "0x747651C", Length = "0xA4")]
		[Token(Token = "0x6001491")]
		private override WaitHandle System.IAsyncResult.get_AsyncWaitHandle() { }

		[Address(RVA = "0x74764FC", Offset = "0x74764FC", Length = "0x8")]
		[Token(Token = "0x600148F")]
		private override bool System.IAsyncResult.get_CompletedSynchronously() { }

		[Address(RVA = "0x7476504", Offset = "0x7476504", Length = "0x18")]
		[Token(Token = "0x6001490")]
		private override bool System.IAsyncResult.get_IsCompleted() { }

	}


	[Address(RVA = "0x74760EC", Offset = "0x74760EC", Length = "0xF0")]
	[Token(Token = "0x6001489")]
	public static IAsyncResult Begin(Task task, AsyncCallback callback, object state) { }

	[Address(RVA = "0x74763A8", Offset = "0x74763A8", Length = "0xF8")]
	[Token(Token = "0x600148A")]
	public static void End(IAsyncResult asyncResult) { }

	[Address(RVA = "0x445A330", Offset = "0x445A330", Length = "0x110")]
	[Token(Token = "0x600148B")]
	public static TResult End(IAsyncResult asyncResult) { }

	[Address(RVA = "0x7476298", Offset = "0x7476298", Length = "0x110")]
	[Token(Token = "0x600148C")]
	private static void InvokeCallbackWhenTaskCompletes(Task antecedent, AsyncCallback callback, IAsyncResult asyncResult) { }

}

