namespace System.Threading.Tasks;

[AsyncMethodBuilder(typeof(AsyncValueTaskMethodBuilder))]
[IsReadOnly]
[Token(Token = "0x200023F")]
public struct ValueTask : IEquatable<ValueTask>
{
	[Token(Token = "0x2000240")]
	private sealed class ValueTaskSourceAsTask : Task<VoidTaskResult>
	{
		[CompilerGenerated]
		[Token(Token = "0x2000241")]
		private sealed class <>c
		{
			[Token(Token = "0x4000AA5")]
			public static readonly <>c <>9; //Field offset: 0x0

			[Address(RVA = "0x74771F8", Offset = "0x74771F8", Length = "0x70")]
			[Token(Token = "0x60014A4")]
			private static <>c() { }

			[Address(RVA = "0x7477268", Offset = "0x7477268", Length = "0x8")]
			[Token(Token = "0x60014A5")]
			public <>c() { }

			[Address(RVA = "0x7477270", Offset = "0x7477270", Length = "0x2B0")]
			[Token(Token = "0x60014A6")]
			internal void <.cctor>b__4_0(object state) { }

		}

		[Token(Token = "0x4000AA2")]
		private static readonly Action<Object> s_completionAction; //Field offset: 0x0
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x4000AA3")]
		private IValueTaskSource _source; //Field offset: 0x58
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x4000AA4")]
		private readonly short _token; //Field offset: 0x60

		[Address(RVA = "0x7477128", Offset = "0x7477128", Length = "0xD0")]
		[Token(Token = "0x60014A3")]
		private static ValueTaskSourceAsTask() { }

		[Address(RVA = "0x7476C88", Offset = "0x7476C88", Length = "0x12C")]
		[Token(Token = "0x60014A2")]
		public ValueTaskSourceAsTask(IValueTaskSource source, short token) { }

	}

	[Token(Token = "0x4000A9E")]
	private static readonly Task s_canceledTask; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000A9F")]
	internal readonly object _obj; //Field offset: 0x0
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x4000AA0")]
	internal readonly short _token; //Field offset: 0x8
	[FieldOffset(Offset = "0xA")]
	[Token(Token = "0x4000AA1")]
	internal readonly bool _continueOnCapturedContext; //Field offset: 0xA

	[Token(Token = "0x17000217")]
	internal static Task CompletedTask
	{
		[Address(RVA = "0x74765E8", Offset = "0x74765E8", Length = "0x88")]
		[Token(Token = "0x6001494")]
		internal get { } //Length: 136
	}

	[Token(Token = "0x17000218")]
	public bool IsCompleted
	{
		[Address(RVA = "0x7476DB4", Offset = "0x7476DB4", Length = "0x104")]
		[Token(Token = "0x600149D")]
		 get { } //Length: 260
	}

	[Address(RVA = "0x747703C", Offset = "0x747703C", Length = "0x98")]
	[Token(Token = "0x60014A1")]
	private static ValueTask() { }

	[Address(RVA = "0x7476670", Offset = "0x7476670", Length = "0x44")]
	[Token(Token = "0x6001495")]
	public ValueTask(Task task) { }

	[Address(RVA = "0x74766B4", Offset = "0x74766B4", Length = "0x48")]
	[Token(Token = "0x6001496")]
	public ValueTask(IValueTaskSource source, short token) { }

	[Address(RVA = "0x74766FC", Offset = "0x74766FC", Length = "0x30")]
	[Token(Token = "0x6001497")]
	private ValueTask(object obj, short token, bool continueOnCapturedContext) { }

	[Address(RVA = "0x7476820", Offset = "0x7476820", Length = "0xCC")]
	[Token(Token = "0x600149B")]
	public Task AsTask() { }

	[Address(RVA = "0x7476FE8", Offset = "0x7476FE8", Length = "0x54")]
	[Token(Token = "0x60014A0")]
	public ConfiguredValueTaskAwaitable ConfigureAwait(bool continueOnCapturedContext) { }

	[Address(RVA = "0x7476744", Offset = "0x7476744", Length = "0xB8")]
	[Token(Token = "0x6001499")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x74767FC", Offset = "0x74767FC", Length = "0x24")]
	[Token(Token = "0x600149A")]
	public override bool Equals(ValueTask other) { }

	[Address(RVA = "0x74765E8", Offset = "0x74765E8", Length = "0x88")]
	[Token(Token = "0x6001494")]
	internal static Task get_CompletedTask() { }

	[Address(RVA = "0x7476DB4", Offset = "0x7476DB4", Length = "0x104")]
	[Token(Token = "0x600149D")]
	public bool get_IsCompleted() { }

	[Address(RVA = "0x7476FBC", Offset = "0x7476FBC", Length = "0x2C")]
	[Token(Token = "0x600149F")]
	public ValueTaskAwaiter GetAwaiter() { }

	[Address(RVA = "0x747672C", Offset = "0x747672C", Length = "0x18")]
	[Token(Token = "0x6001498")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x74768EC", Offset = "0x74768EC", Length = "0x2D8")]
	[Token(Token = "0x600149C")]
	private Task GetTaskForValueTaskSource(IValueTaskSource t) { }

	[Address(RVA = "0x7476EB8", Offset = "0x7476EB8", Length = "0x104")]
	[StackTraceHidden]
	[Token(Token = "0x600149E")]
	internal void ThrowIfCompletedUnsuccessfully() { }

}

