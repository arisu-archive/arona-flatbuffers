namespace System.Threading.Tasks;

[Token(Token = "0x2000274")]
internal sealed class ContinuationResultTaskFromTask : Task<TResult>
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000B65")]
	private Task m_antecedent; //Field offset: 0x0

	[Address(RVA = "0x6E2AF90", Offset = "0x6E2AF90", Length = "0xD8")]
	[Token(Token = "0x60015EA")]
	public ContinuationResultTaskFromTask`1(Task antecedent, Delegate function, object state, TaskCreationOptions creationOptions, InternalTaskOptions internalOptions) { }

	[Address(RVA = "0x6E2B068", Offset = "0x6E2B068", Length = "0xFC")]
	[Token(Token = "0x60015EB")]
	internal virtual void InnerInvoke() { }

}

