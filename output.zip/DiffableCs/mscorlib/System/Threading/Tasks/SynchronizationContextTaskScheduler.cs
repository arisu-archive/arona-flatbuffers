namespace System.Threading.Tasks;

[Token(Token = "0x2000283")]
internal sealed class SynchronizationContextTaskScheduler : TaskScheduler
{
	[CompilerGenerated]
	[Token(Token = "0x2000284")]
	private sealed class <>c
	{
		[Token(Token = "0x4000B87")]
		public static readonly <>c <>9; //Field offset: 0x0

		[Address(RVA = "0x748486C", Offset = "0x748486C", Length = "0x70")]
		[Token(Token = "0x6001642")]
		private static <>c() { }

		[Address(RVA = "0x74848DC", Offset = "0x74848DC", Length = "0x8")]
		[Token(Token = "0x6001643")]
		public <>c() { }

		[Address(RVA = "0x74848E4", Offset = "0x74848E4", Length = "0x84")]
		[Token(Token = "0x6001644")]
		internal void <.cctor>b__8_0(object s) { }

	}

	[Token(Token = "0x4000B86")]
	private static readonly SendOrPostCallback s_postCallback; //Field offset: 0x0
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000B85")]
	private SynchronizationContext m_synchronizationContext; //Field offset: 0x18

	[Token(Token = "0x17000253")]
	public virtual int MaximumConcurrencyLevel
	{
		[Address(RVA = "0x7484794", Offset = "0x7484794", Length = "0x8")]
		[Token(Token = "0x6001640")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x748479C", Offset = "0x748479C", Length = "0xD0")]
	[Token(Token = "0x6001641")]
	private static SynchronizationContextTaskScheduler() { }

	[Address(RVA = "0x748448C", Offset = "0x748448C", Length = "0xBC")]
	[Token(Token = "0x600163D")]
	internal SynchronizationContextTaskScheduler() { }

	[Address(RVA = "0x7484794", Offset = "0x7484794", Length = "0x8")]
	[Token(Token = "0x6001640")]
	public virtual int get_MaximumConcurrencyLevel() { }

	[Address(RVA = "0x74846CC", Offset = "0x74846CC", Length = "0x84")]
	[Token(Token = "0x600163E")]
	protected private virtual void QueueTask(Task task) { }

	[Address(RVA = "0x7484750", Offset = "0x7484750", Length = "0x44")]
	[Token(Token = "0x600163F")]
	protected virtual bool TryExecuteTaskInline(Task task, bool taskWasPreviouslyQueued) { }

}

