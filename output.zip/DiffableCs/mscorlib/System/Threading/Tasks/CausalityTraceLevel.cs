namespace System.Threading.Tasks;

[FriendAccessAllowed]
[Token(Token = "0x2000288")]
internal enum CausalityTraceLevel
{
	Required = 0,
	Important = 1,
	Verbose = 2,
}

