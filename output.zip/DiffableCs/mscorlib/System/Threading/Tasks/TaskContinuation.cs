namespace System.Threading.Tasks;

[Token(Token = "0x2000277")]
internal abstract class TaskContinuation
{

	[Address(RVA = "0x748200C", Offset = "0x748200C", Length = "0x8")]
	[Token(Token = "0x60015F2")]
	protected TaskContinuation() { }

	[Address(RVA = "0x7481EC4", Offset = "0x7481EC4", Length = "0x148")]
	[Token(Token = "0x60015F1")]
	protected static void InlineIfPossibleOrElseQueue(Task task, bool needsProtection) { }

	[Token(Token = "0x60015F0")]
	internal abstract void Run(Task completedTask, bool bCanInlineContinuationTask) { }

}

