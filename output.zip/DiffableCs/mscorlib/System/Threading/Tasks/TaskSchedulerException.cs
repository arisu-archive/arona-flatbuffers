namespace System.Threading.Tasks;

[Token(Token = "0x200023B")]
public class TaskSchedulerException : Exception
{

	[Address(RVA = "0x7475F7C", Offset = "0x7475F7C", Length = "0x70")]
	[Token(Token = "0x6001486")]
	public TaskSchedulerException() { }

	[Address(RVA = "0x7475FEC", Offset = "0x7475FEC", Length = "0x80")]
	[Token(Token = "0x6001487")]
	public TaskSchedulerException(Exception innerException) { }

	[Address(RVA = "0x747606C", Offset = "0x747606C", Length = "0x80")]
	[Token(Token = "0x6001488")]
	protected TaskSchedulerException(SerializationInfo info, StreamingContext context) { }

}

