namespace System.Threading.Tasks;

[Token(Token = "0x2000249")]
public static class Parallel
{
	[CompilerGenerated]
	[Token(Token = "0x200024A")]
	private sealed class <>c__DisplayClass20_0
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AB6")]
		public OperationCanceledException oce; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AB7")]
		public ParallelOptions parallelOptions; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AB8")]
		public ParallelLoopStateFlags64 sharedPStateFlags; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AB9")]
		public RangeManager rangeManager; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000ABA")]
		public int forkJoinContextID; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000ABB")]
		public Action<Int64, ParallelLoopState> bodyWithState; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000ABC")]
		public Func<Int64, ParallelLoopState, TLocal, TLocal> bodyWithLocal; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000ABD")]
		public Func<TLocal> localInit; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000ABE")]
		public Action<Int64> body; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000ABF")]
		public Action<TLocal> localFinally; //Field offset: 0x0

		[Address(RVA = "0x45B43B8", Offset = "0x45B43B8", Length = "0x8")]
		[Token(Token = "0x60014D0")]
		public <>c__DisplayClass20_0`1() { }

		[Address(RVA = "0x45B43C0", Offset = "0x45B43C0", Length = "0x88")]
		[Token(Token = "0x60014D1")]
		internal void <ForWorker64>b__0(object o) { }

		[Address(RVA = "0x45B4448", Offset = "0x45B4448", Length = "0x680")]
		[Token(Token = "0x60014D2")]
		internal void <ForWorker64>b__1(ref RangeWorker currentWorker, int timeout, out bool replicationDelegateYieldedBeforeCompletion) { }

	}

	[Token(Token = "0x4000AB4")]
	internal static int s_forkJoinContextID; //Field offset: 0x0
	[Token(Token = "0x4000AB5")]
	internal static readonly ParallelOptions s_defaultParallelOptions; //Field offset: 0x8

	[Address(RVA = "0x7477F9C", Offset = "0x7477F9C", Length = "0x78")]
	[Token(Token = "0x60014CF")]
	private static Parallel() { }

	[Address(RVA = "0x7477A7C", Offset = "0x7477A7C", Length = "0x34")]
	[Token(Token = "0x60014CA")]
	private static bool CheckTimeoutReached(int timeoutOccursAt) { }

	[Address(RVA = "0x7477AB0", Offset = "0x7477AB0", Length = "0x1C")]
	[Token(Token = "0x60014CB")]
	private static int ComputeTimeoutPoint(int timeoutLength) { }

	[Address(RVA = "0x7477960", Offset = "0x7477960", Length = "0x11C")]
	[Token(Token = "0x60014C9")]
	public static ParallelLoopResult For(long fromInclusive, long toExclusive, Action<Int64, ParallelLoopState> body) { }

	[Address(RVA = "0x43EE68C", Offset = "0x43EE68C", Length = "0x7A4")]
	[Token(Token = "0x60014CC")]
	private static ParallelLoopResult ForWorker64(long fromInclusive, long toExclusive, ParallelOptions parallelOptions, Action<Int64> body, Action<Int64, ParallelLoopState> bodyWithState, Func<Int64, ParallelLoopState, TLocal, TLocal> bodyWithLocal, Func<TLocal> localInit, Action<TLocal> localFinally) { }

	[Address(RVA = "0x7477ACC", Offset = "0x7477ACC", Length = "0x458")]
	[Token(Token = "0x60014CD")]
	private static OperationCanceledException ReduceToSingleCancellationException(ICollection exceptions, CancellationToken cancelToken) { }

	[Address(RVA = "0x7477F24", Offset = "0x7477F24", Length = "0x78")]
	[Token(Token = "0x60014CE")]
	private static void ThrowSingleCancellationExceptionOrOtherException(ICollection exceptions, CancellationToken cancelToken, Exception otherException) { }

}

