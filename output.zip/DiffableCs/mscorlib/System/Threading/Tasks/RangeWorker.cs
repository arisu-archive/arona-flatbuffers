namespace System.Threading.Tasks;

[Token(Token = "0x2000254")]
internal struct RangeWorker
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000AD3")]
	internal readonly IndexRange[] _indexRanges; //Field offset: 0x0
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x4000AD4")]
	internal int _nCurrentIndexRange; //Field offset: 0x8
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000AD5")]
	internal long _nStep; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000AD6")]
	internal long _nIncrementValue; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000AD7")]
	internal readonly long _nMaxIncrementValue; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000AD8")]
	internal readonly bool _use32BitCurrentIndex; //Field offset: 0x28

	[Token(Token = "0x17000225")]
	internal bool IsInitialized
	{
		[Address(RVA = "0x74788D8", Offset = "0x74788D8", Length = "0x10")]
		[Token(Token = "0x60014ED")]
		internal get { } //Length: 16
	}

	[Address(RVA = "0x74788E8", Offset = "0x74788E8", Length = "0x48")]
	[Token(Token = "0x60014EE")]
	internal RangeWorker(IndexRange[] ranges, int nInitialRange, long nStep, bool use32BitCurrentIndex) { }

	[Address(RVA = "0x7478930", Offset = "0x7478930", Length = "0x25C")]
	[Token(Token = "0x60014EF")]
	internal bool FindNewWork(out long nFromInclusiveLocal, out long nToExclusiveLocal) { }

	[Address(RVA = "0x74788D8", Offset = "0x74788D8", Length = "0x10")]
	[Token(Token = "0x60014ED")]
	internal bool get_IsInitialized() { }

}

