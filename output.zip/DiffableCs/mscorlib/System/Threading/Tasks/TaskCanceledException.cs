namespace System.Threading.Tasks;

[Token(Token = "0x2000239")]
public class TaskCanceledException : OperationCanceledException
{
	[FieldOffset(Offset = "0x98")]
	[Token(Token = "0x4000A97")]
	private readonly Task _canceledTask; //Field offset: 0x98

	[Address(RVA = "0x7475E7C", Offset = "0x7475E7C", Length = "0x4C")]
	[Token(Token = "0x6001476")]
	public TaskCanceledException() { }

	[Address(RVA = "0x7475EC8", Offset = "0x7475EC8", Length = "0x88")]
	[Token(Token = "0x6001477")]
	public TaskCanceledException(Task task) { }

	[Address(RVA = "0x7475F74", Offset = "0x7475F74", Length = "0x8")]
	[Token(Token = "0x6001478")]
	protected TaskCanceledException(SerializationInfo info, StreamingContext context) { }

}

