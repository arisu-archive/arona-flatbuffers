namespace System.Threading.Tasks;

[Token(Token = "0x200027B")]
internal sealed class TaskSchedulerAwaitTaskContinuation : AwaitTaskContinuation
{
	[CompilerGenerated]
	[Token(Token = "0x200027C")]
	private sealed class <>c
	{
		[Token(Token = "0x4000B70")]
		public static readonly <>c <>9; //Field offset: 0x0
		[Token(Token = "0x4000B71")]
		public static Action<Object> <>9__2_0; //Field offset: 0x8

		[Address(RVA = "0x7482CEC", Offset = "0x7482CEC", Length = "0x70")]
		[Token(Token = "0x60015FF")]
		private static <>c() { }

		[Address(RVA = "0x7482D5C", Offset = "0x7482D5C", Length = "0x8")]
		[Token(Token = "0x6001600")]
		public <>c() { }

		[Address(RVA = "0x7482D64", Offset = "0x7482D64", Length = "0xF0")]
		[Token(Token = "0x6001601")]
		internal void <Run>b__2_0(object state) { }

	}

	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000B6F")]
	private readonly TaskScheduler m_scheduler; //Field offset: 0x20

	[Address(RVA = "0x747E778", Offset = "0x747E778", Length = "0x34")]
	[Token(Token = "0x60015FD")]
	internal TaskSchedulerAwaitTaskContinuation(TaskScheduler scheduler, Action action, bool flowExecutionContext) { }

	[Address(RVA = "0x74828E4", Offset = "0x74828E4", Length = "0x24C")]
	[Token(Token = "0x60015FE")]
	internal virtual void Run(Task ignored, bool canInlineContinuationTask) { }

}

