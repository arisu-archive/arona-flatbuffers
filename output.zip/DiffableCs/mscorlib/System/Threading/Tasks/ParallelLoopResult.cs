namespace System.Threading.Tasks;

[Token(Token = "0x2000252")]
public struct ParallelLoopResult
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000ACD")]
	internal bool _completed; //Field offset: 0x0
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x4000ACE")]
	internal Nullable<Int64> _lowestBreakIteration; //Field offset: 0x8

}

