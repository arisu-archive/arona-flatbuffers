namespace System.Threading.Tasks;

[Token(Token = "0x2000251")]
internal class ParallelLoopStateFlags64 : ParallelLoopStateFlags
{
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000ACC")]
	internal long _lowestBreakIteration; //Field offset: 0x18

	[Token(Token = "0x17000224")]
	internal long LowestBreakIteration
	{
		[Address(RVA = "0x7478724", Offset = "0x7478724", Length = "0x34")]
		[Token(Token = "0x60014E9")]
		internal get { } //Length: 52
	}

	[Address(RVA = "0x74788C8", Offset = "0x74788C8", Length = "0x10")]
	[Token(Token = "0x60014EC")]
	public ParallelLoopStateFlags64() { }

	[Address(RVA = "0x7478724", Offset = "0x7478724", Length = "0x34")]
	[Token(Token = "0x60014E9")]
	internal long get_LowestBreakIteration() { }

	[Address(RVA = "0x7478834", Offset = "0x7478834", Length = "0x74")]
	[Token(Token = "0x60014EA")]
	internal bool ShouldExitLoop(long CallerIteration) { }

	[Address(RVA = "0x74788A8", Offset = "0x74788A8", Length = "0x20")]
	[Token(Token = "0x60014EB")]
	internal bool ShouldExitLoop() { }

}

