namespace System.Threading.Tasks;

[DebuggerDisplay("Id={Id}")]
[DebuggerTypeProxy(typeof(SystemThreadingTasks_TaskSchedulerDebugView))]
[Token(Token = "0x2000281")]
public abstract class TaskScheduler
{
	[Token(Token = "0x2000282")]
	public sealed class SystemThreadingTasks_TaskSchedulerDebugView
	{

	}

	[Token(Token = "0x4000B7F")]
	private static ConditionalWeakTable<TaskScheduler, Object> s_activeTaskSchedulers; //Field offset: 0x0
	[Token(Token = "0x4000B80")]
	private static readonly TaskScheduler s_defaultTaskScheduler; //Field offset: 0x8
	[Token(Token = "0x4000B81")]
	internal static int s_taskSchedulerIdCounter; //Field offset: 0x10
	[Token(Token = "0x4000B83")]
	private static EventHandler<UnobservedTaskExceptionEventArgs> _unobservedTaskException; //Field offset: 0x18
	[Token(Token = "0x4000B84")]
	private static readonly Lock _unobservedTaskExceptionLockObject; //Field offset: 0x20
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000B82")]
	private int m_taskSchedulerId; //Field offset: 0x10

	[Token(Token = "0x17000250")]
	public static TaskScheduler Current
	{
		[Address(RVA = "0x74777FC", Offset = "0x74777FC", Length = "0xA0")]
		[Token(Token = "0x6001636")]
		 get { } //Length: 160
	}

	[Token(Token = "0x1700024F")]
	public static TaskScheduler Default
	{
		[Address(RVA = "0x74843DC", Offset = "0x74843DC", Length = "0x58")]
		[Token(Token = "0x6001635")]
		 get { } //Length: 88
	}

	[Token(Token = "0x17000252")]
	public int Id
	{
		[Address(RVA = "0x747F1DC", Offset = "0x747F1DC", Length = "0x94")]
		[Token(Token = "0x6001639")]
		 get { } //Length: 148
	}

	[Token(Token = "0x17000251")]
	internal static TaskScheduler InternalCurrent
	{
		[Address(RVA = "0x747E6D4", Offset = "0x747E6D4", Length = "0xA4")]
		[Token(Token = "0x6001637")]
		internal get { } //Length: 164
	}

	[Token(Token = "0x1700024D")]
	public override int MaximumConcurrencyLevel
	{
		[Address(RVA = "0x74843B8", Offset = "0x74843B8", Length = "0x8")]
		[Token(Token = "0x600162F")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700024E")]
	internal override bool RequiresAtomicStartTransition
	{
		[Address(RVA = "0x74843CC", Offset = "0x74843CC", Length = "0x8")]
		[Token(Token = "0x6001633")]
		internal get { } //Length: 8
	}

	[Address(RVA = "0x74845BC", Offset = "0x74845BC", Length = "0xB8")]
	[Token(Token = "0x600163C")]
	private static TaskScheduler() { }

	[Address(RVA = "0x74843D4", Offset = "0x74843D4", Length = "0x8")]
	[Token(Token = "0x6001634")]
	protected TaskScheduler() { }

	[Address(RVA = "0x7484434", Offset = "0x7484434", Length = "0x58")]
	[Token(Token = "0x6001638")]
	public static TaskScheduler FromCurrentSynchronizationContext() { }

	[Address(RVA = "0x74777FC", Offset = "0x74777FC", Length = "0xA0")]
	[Token(Token = "0x6001636")]
	public static TaskScheduler get_Current() { }

	[Address(RVA = "0x74843DC", Offset = "0x74843DC", Length = "0x58")]
	[Token(Token = "0x6001635")]
	public static TaskScheduler get_Default() { }

	[Address(RVA = "0x747F1DC", Offset = "0x747F1DC", Length = "0x94")]
	[Token(Token = "0x6001639")]
	public int get_Id() { }

	[Address(RVA = "0x747E6D4", Offset = "0x747E6D4", Length = "0xA4")]
	[Token(Token = "0x6001637")]
	internal static TaskScheduler get_InternalCurrent() { }

	[Address(RVA = "0x74843B8", Offset = "0x74843B8", Length = "0x8")]
	[Token(Token = "0x600162F")]
	public override int get_MaximumConcurrencyLevel() { }

	[Address(RVA = "0x74843CC", Offset = "0x74843CC", Length = "0x8")]
	[Token(Token = "0x6001633")]
	internal override bool get_RequiresAtomicStartTransition() { }

	[Address(RVA = "0x74843C8", Offset = "0x74843C8", Length = "0x4")]
	[Token(Token = "0x6001632")]
	internal override void NotifyWorkItemProgress() { }

	[Address(RVA = "0x74834B0", Offset = "0x74834B0", Length = "0x13C")]
	[Token(Token = "0x600163B")]
	internal static void PublishUnobservedTaskException(object sender, UnobservedTaskExceptionEventArgs ueea) { }

	[Token(Token = "0x600162D")]
	protected private abstract void QueueTask(Task task) { }

	[Address(RVA = "0x74843C0", Offset = "0x74843C0", Length = "0x8")]
	[Token(Token = "0x6001631")]
	protected private override bool TryDequeue(Task task) { }

	[Address(RVA = "0x7484548", Offset = "0x7484548", Length = "0x74")]
	[Token(Token = "0x600163A")]
	protected bool TryExecuteTask(Task task) { }

	[Token(Token = "0x600162E")]
	protected abstract bool TryExecuteTaskInline(Task task, bool taskWasPreviouslyQueued) { }

	[Address(RVA = "0x747B894", Offset = "0x747B894", Length = "0x1E4")]
	[Token(Token = "0x6001630")]
	internal bool TryRunInline(Task task, bool taskWasPreviouslyQueued) { }

}

