namespace System.Threading.Tasks;

[Token(Token = "0x2000247")]
internal class Box
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000AB0")]
	internal T Value; //Field offset: 0x0

	[Address(RVA = "0x6B4D098", Offset = "0x6B4D098", Length = "0x28")]
	[Token(Token = "0x60014C2")]
	internal Box`1(T value) { }

}

