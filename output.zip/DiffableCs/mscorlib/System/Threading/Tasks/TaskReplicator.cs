namespace System.Threading.Tasks;

[Token(Token = "0x2000256")]
internal class TaskReplicator
{
	[Token(Token = "0x2000258")]
	private abstract class Replica
	{
		[CompilerGenerated]
		[Token(Token = "0x2000259")]
		private sealed class <>c
		{
			[Token(Token = "0x4000AE6")]
			public static readonly <>c <>9; //Field offset: 0x0
			[Token(Token = "0x4000AE7")]
			public static Action<Object> <>9__4_0; //Field offset: 0x8
			[Token(Token = "0x4000AE8")]
			public static Action<Object> <>9__7_0; //Field offset: 0x10

			[Address(RVA = "0x7479700", Offset = "0x7479700", Length = "0x70")]
			[Token(Token = "0x60014FD")]
			private static <>c() { }

			[Address(RVA = "0x7479770", Offset = "0x7479770", Length = "0x8")]
			[Token(Token = "0x60014FE")]
			public <>c() { }

			[Address(RVA = "0x7479778", Offset = "0x7479778", Length = "0x80")]
			[Token(Token = "0x60014FF")]
			internal void <.ctor>b__4_0(object s) { }

			[Address(RVA = "0x74797F8", Offset = "0x74797F8", Length = "0x80")]
			[Token(Token = "0x6001500")]
			internal void <Execute>b__7_0(object s) { }

		}

		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000AE2")]
		protected readonly TaskReplicator _replicator; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000AE3")]
		protected readonly int _timeout; //Field offset: 0x18
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4000AE4")]
		protected int _remainingConcurrency; //Field offset: 0x1C
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000AE5")]
		protected Task _pendingTask; //Field offset: 0x20

		[Address(RVA = "0x7478EEC", Offset = "0x7478EEC", Length = "0x1AC")]
		[Token(Token = "0x60014F7")]
		protected Replica(TaskReplicator replicator, int maxConcurrency, int timeout) { }

		[Token(Token = "0x60014FB")]
		protected abstract void CreateNewReplica() { }

		[Address(RVA = "0x74791A0", Offset = "0x74791A0", Length = "0x324")]
		[Token(Token = "0x60014FA")]
		public void Execute() { }

		[Token(Token = "0x60014FC")]
		protected abstract void ExecuteAction(out bool yieldedBeforeCompletion) { }

		[Address(RVA = "0x74790C4", Offset = "0x74790C4", Length = "0x38")]
		[Token(Token = "0x60014F8")]
		public void Start() { }

		[Address(RVA = "0x7479158", Offset = "0x7479158", Length = "0x3C")]
		[Token(Token = "0x60014F9")]
		public void Wait() { }

	}

	[Token(Token = "0x200025A")]
	private sealed class Replica : Replica
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AE9")]
		private readonly ReplicatableUserAction<TState> _action; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AEA")]
		private TState _state; //Field offset: 0x0

		[Address(RVA = "0x5E3CFA8", Offset = "0x5E3CFA8", Length = "0x30")]
		[Token(Token = "0x6001501")]
		public Replica`1(TaskReplicator replicator, int maxConcurrency, int timeout, ReplicatableUserAction<TState> action) { }

		[Address(RVA = "0x5E3CFD8", Offset = "0x5E3CFD8", Length = "0xB0")]
		[Token(Token = "0x6001502")]
		protected virtual void CreateNewReplica() { }

		[Address(RVA = "0x5E3D088", Offset = "0x5E3D088", Length = "0x38")]
		[Token(Token = "0x6001503")]
		protected virtual void ExecuteAction(out bool yieldedBeforeCompletion) { }

	}

	[Token(Token = "0x2000257")]
	internal sealed class ReplicatableUserAction : MulticastDelegate
	{

		[Address(RVA = "0x5E3D1D8", Offset = "0x5E3D1D8", Length = "0xEC")]
		[Token(Token = "0x60014F5")]
		public ReplicatableUserAction`1(object object, IntPtr method) { }

		[Address(RVA = "0x5E3D2C4", Offset = "0x5E3D2C4", Length = "0x14")]
		[Token(Token = "0x60014F6")]
		public override void Invoke(ref TState replicaState, int timeout, out bool yieldedBeforeCompletion) { }

	}

	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000ADD")]
	private readonly TaskScheduler _scheduler; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000ADE")]
	private readonly bool _stopOnFirstFailure; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000ADF")]
	private readonly ConcurrentQueue<Replica> _pendingReplicas; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000AE0")]
	private ConcurrentQueue<Exception> _exceptions; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000AE1")]
	private bool _stopReplicating; //Field offset: 0x30

	[Address(RVA = "0x7478D90", Offset = "0x7478D90", Length = "0xE8")]
	[Token(Token = "0x60014F2")]
	private TaskReplicator(ParallelOptions options, bool stopOnFirstFailure) { }

	[Address(RVA = "0x7478E78", Offset = "0x7478E78", Length = "0x74")]
	[Token(Token = "0x60014F4")]
	private static int GenerateCooperativeMultitaskingTaskTimeout() { }

	[Address(RVA = "0x445A000", Offset = "0x445A000", Length = "0x198")]
	[Token(Token = "0x60014F3")]
	public static void Run(ReplicatableUserAction<TState> action, ParallelOptions options, bool stopOnFirstFailure) { }

}

