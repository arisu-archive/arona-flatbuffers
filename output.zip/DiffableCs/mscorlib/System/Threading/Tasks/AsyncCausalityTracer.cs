namespace System.Threading.Tasks;

[FriendAccessAllowed]
[Token(Token = "0x200028C")]
internal static class AsyncCausalityTracer
{

	[FriendAccessAllowed]
	[Token(Token = "0x17000255")]
	internal static bool LoggingOn
	{
		[Address(RVA = "0x7481640", Offset = "0x7481640", Length = "0x8")]
		[FriendAccessAllowed]
		[Token(Token = "0x6001650")]
		internal get { } //Length: 8
	}

	[Address(RVA = "0x7481640", Offset = "0x7481640", Length = "0x8")]
	[FriendAccessAllowed]
	[Token(Token = "0x6001650")]
	internal static bool get_LoggingOn() { }

	[Address(RVA = "0x7484DF4", Offset = "0x7484DF4", Length = "0x4")]
	[FriendAccessAllowed]
	[Token(Token = "0x6001652")]
	internal static void TraceOperationCompletion(CausalityTraceLevel traceLevel, int taskId, AsyncCausalityStatus status) { }

	[Address(RVA = "0x7484DF0", Offset = "0x7484DF0", Length = "0x4")]
	[FriendAccessAllowed]
	[Token(Token = "0x6001651")]
	internal static void TraceOperationCreation(CausalityTraceLevel traceLevel, int taskId, string operationName, ulong relatedContext) { }

	[Address(RVA = "0x7481648", Offset = "0x7481648", Length = "0x4")]
	[Token(Token = "0x6001654")]
	internal static void TraceSynchronousWorkCompletion(CausalityTraceLevel traceLevel, CausalitySynchronousWork work) { }

	[Address(RVA = "0x7484DF8", Offset = "0x7484DF8", Length = "0x4")]
	[Token(Token = "0x6001653")]
	internal static void TraceSynchronousWorkStart(CausalityTraceLevel traceLevel, int taskId, CausalitySynchronousWork work) { }

}

