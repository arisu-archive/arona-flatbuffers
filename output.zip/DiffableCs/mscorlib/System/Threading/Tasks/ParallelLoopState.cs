namespace System.Threading.Tasks;

[DebuggerDisplay("ShouldExitCurrentIteration = {ShouldExitCurrentIteration}")]
[Token(Token = "0x200024E")]
public class ParallelLoopState
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000AC8")]
	private readonly ParallelLoopStateFlags _flagsBase; //Field offset: 0x10

	[Address(RVA = "0x74783D8", Offset = "0x74783D8", Length = "0x30")]
	[Token(Token = "0x60014D9")]
	internal ParallelLoopState(ParallelLoopStateFlags fbase) { }

	[Address(RVA = "0x74784E8", Offset = "0x74784E8", Length = "0xC")]
	[Token(Token = "0x60014DC")]
	public void Break() { }

	[Address(RVA = "0x74784F4", Offset = "0x74784F4", Length = "0x158")]
	[Token(Token = "0x60014DD")]
	internal static void Break(long iteration, ParallelLoopStateFlags64 pflags) { }

	[Address(RVA = "0x7478498", Offset = "0x7478498", Length = "0x50")]
	[Token(Token = "0x60014DB")]
	internal override void InternalBreak() { }

	[Address(RVA = "0x7478408", Offset = "0x7478408", Length = "0x18")]
	[Token(Token = "0x60014DA")]
	public void Stop() { }

}

