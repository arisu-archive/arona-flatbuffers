namespace System.Threading.Tasks;

[Token(Token = "0x200025E")]
public class TaskFactory
{
	[CompilerGenerated]
	[Token(Token = "0x2000260")]
	private sealed class <>c__DisplayClass35_0
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AF6")]
		public Func<IAsyncResult, TResult> endFunction; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AF7")]
		public Action<IAsyncResult> endAction; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AF8")]
		public Task<TResult> promise; //Field offset: 0x0

		[Address(RVA = "0x45BEBCC", Offset = "0x45BEBCC", Length = "0x8")]
		[Token(Token = "0x6001538")]
		public <>c__DisplayClass35_0() { }

		[Address(RVA = "0x45BEBD4", Offset = "0x45BEBD4", Length = "0xE8")]
		[Token(Token = "0x6001539")]
		internal void <FromAsyncImpl>b__0(IAsyncResult iar) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x2000261")]
	private sealed class <>c__DisplayClass38_0
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AF9")]
		public Func<IAsyncResult, TResult> endFunction; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AFA")]
		public Action<IAsyncResult> endAction; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AFB")]
		public Task<TResult> promise; //Field offset: 0x0

		[Address(RVA = "0x45C03D4", Offset = "0x45C03D4", Length = "0x8")]
		[Token(Token = "0x600153A")]
		public <>c__DisplayClass38_0`1() { }

		[Address(RVA = "0x45C03DC", Offset = "0x45C03DC", Length = "0xE8")]
		[Token(Token = "0x600153B")]
		internal void <FromAsyncImpl>b__0(IAsyncResult iar) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x2000262")]
	private sealed class <>c__DisplayClass41_0
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AFC")]
		public Func<IAsyncResult, TResult> endFunction; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AFD")]
		public Action<IAsyncResult> endAction; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AFE")]
		public Task<TResult> promise; //Field offset: 0x0

		[Address(RVA = "0x45C0DD0", Offset = "0x45C0DD0", Length = "0x8")]
		[Token(Token = "0x600153C")]
		public <>c__DisplayClass41_0`2() { }

		[Address(RVA = "0x45C0DD8", Offset = "0x45C0DD8", Length = "0xE8")]
		[Token(Token = "0x600153D")]
		internal void <FromAsyncImpl>b__0(IAsyncResult iar) { }

	}

	[Token(Token = "0x200025F")]
	private sealed class FromAsyncTrimPromise : Task<TResult>
	{
		[Token(Token = "0x4000AF3")]
		internal static readonly AsyncCallback s_completeFromAsyncResult; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AF4")]
		private TInstance m_thisRef; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AF5")]
		private Func<TInstance, IAsyncResult, TResult> m_endMethod; //Field offset: 0x0

		[Address(RVA = "0x4D64600", Offset = "0x4D64600", Length = "0xD4")]
		[Token(Token = "0x6001537")]
		private static FromAsyncTrimPromise`1() { }

		[Address(RVA = "0x4D641BC", Offset = "0x4D641BC", Length = "0x50")]
		[Token(Token = "0x6001534")]
		internal FromAsyncTrimPromise`1(TInstance thisRef, Func<TInstance, IAsyncResult, TResult> endMethod) { }

		[Address(RVA = "0x4D64484", Offset = "0x4D64484", Length = "0x17C")]
		[Token(Token = "0x6001536")]
		internal void Complete(TInstance thisRef, Func<TInstance, IAsyncResult, TResult> endMethod, IAsyncResult asyncResult, bool requiresSynchronization) { }

		[Address(RVA = "0x4D6420C", Offset = "0x4D6420C", Length = "0x278")]
		[Token(Token = "0x6001535")]
		internal static void CompleteFromAsyncResult(IAsyncResult asyncResult) { }

	}

	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000AEF")]
	private CancellationToken m_defaultCancellationToken; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000AF0")]
	private TaskScheduler m_defaultScheduler; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000AF1")]
	private TaskCreationOptions m_defaultCreationOptions; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000AF2")]
	private TaskContinuationOptions m_defaultContinuationOptions; //Field offset: 0x0

	[Address(RVA = "0x5F37AA8", Offset = "0x5F37AA8", Length = "0x24")]
	[Token(Token = "0x600152A")]
	public TaskFactory`1() { }

	[Address(RVA = "0x5F37ACC", Offset = "0x5F37ACC", Length = "0x74")]
	[Token(Token = "0x600152B")]
	public TaskFactory`1(CancellationToken cancellationToken, TaskCreationOptions creationOptions, TaskContinuationOptions continuationOptions, TaskScheduler scheduler) { }

	[Address(RVA = "0x5F37E00", Offset = "0x5F37E00", Length = "0x28")]
	[Token(Token = "0x600152E")]
	public Task<TResult> FromAsync(Func<AsyncCallback, Object, IAsyncResult> beginMethod, Func<IAsyncResult, TResult> endMethod, object state) { }

	[Address(RVA = "0x3ED74DC", Offset = "0x3ED74DC", Length = "0x24")]
	[Token(Token = "0x6001530")]
	public Task<TResult> FromAsync(Func<TArg1, AsyncCallback, Object, IAsyncResult> beginMethod, Func<IAsyncResult, TResult> endMethod, TArg1 arg1, object state) { }

	[Address(RVA = "0x5F37BF0", Offset = "0x5F37BF0", Length = "0x210")]
	[Token(Token = "0x600152D")]
	private static void FromAsyncCoreLogic(IAsyncResult iar, Func<IAsyncResult, TResult> endFunction, Action<IAsyncResult> endAction, Task<TResult> promise, bool requiresSynchronization) { }

	[Address(RVA = "0x5F37E28", Offset = "0x5F37E28", Length = "0x648")]
	[Token(Token = "0x600152F")]
	internal static Task<TResult> FromAsyncImpl(Func<AsyncCallback, Object, IAsyncResult> beginMethod, Func<IAsyncResult, TResult> endFunction, Action<IAsyncResult> endAction, object state, TaskCreationOptions creationOptions) { }

	[Address(RVA = "0x3ED7500", Offset = "0x3ED7500", Length = "0x60C")]
	[Token(Token = "0x6001531")]
	internal static Task<TResult> FromAsyncImpl(Func<TArg1, AsyncCallback, Object, IAsyncResult> beginMethod, Func<IAsyncResult, TResult> endFunction, Action<IAsyncResult> endAction, TArg1 arg1, object state, TaskCreationOptions creationOptions) { }

	[Address(RVA = "0x3ED7B0C", Offset = "0x3ED7B0C", Length = "0x628")]
	[Token(Token = "0x6001532")]
	internal static Task<TResult> FromAsyncImpl(Func<TArg1, TArg2, AsyncCallback, Object, IAsyncResult> beginMethod, Func<IAsyncResult, TResult> endFunction, Action<IAsyncResult> endAction, TArg1 arg1, TArg2 arg2, object state, TaskCreationOptions creationOptions) { }

	[Address(RVA = "0x3ED7348", Offset = "0x3ED7348", Length = "0x194")]
	[Token(Token = "0x6001533")]
	internal static Task<TResult> FromAsyncTrim(TInstance thisRef, TArgs args, Func<TInstance, TArgs, AsyncCallback, Object, IAsyncResult> beginMethod, Func<TInstance, IAsyncResult, TResult> endMethod) { }

	[Address(RVA = "0x5F37B40", Offset = "0x5F37B40", Length = "0xB0")]
	[Token(Token = "0x600152C")]
	public Task<TResult> StartNew(Func<Object, TResult> function, object state, CancellationToken cancellationToken, TaskCreationOptions creationOptions, TaskScheduler scheduler) { }

}

