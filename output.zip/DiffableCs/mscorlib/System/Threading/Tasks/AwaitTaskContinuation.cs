namespace System.Threading.Tasks;

[Token(Token = "0x200027D")]
internal class AwaitTaskContinuation : TaskContinuation, IThreadPoolWorkItem
{
	[Token(Token = "0x4000B74")]
	private static ContextCallback s_invokeActionCallback; //Field offset: 0x0
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000B72")]
	private readonly ExecutionContext m_capturedContext; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000B73")]
	protected readonly Action m_action; //Field offset: 0x18

	[Token(Token = "0x1700024A")]
	internal static bool IsValidLocationForInlining
	{
		[Address(RVA = "0x7482EAC", Offset = "0x7482EAC", Length = "0x12C")]
		[Token(Token = "0x6001605")]
		internal get { } //Length: 300
	}

	[Address(RVA = "0x74821B0", Offset = "0x74821B0", Length = "0xA4")]
	[Token(Token = "0x6001602")]
	internal AwaitTaskContinuation(Action action, bool flowExecutionContext) { }

	[Address(RVA = "0x7482C5C", Offset = "0x7482C5C", Length = "0x90")]
	[Token(Token = "0x6001603")]
	protected Task CreateTask(Action<Object> action, object state, TaskScheduler scheduler) { }

	[Address(RVA = "0x7482EAC", Offset = "0x7482EAC", Length = "0x12C")]
	[Token(Token = "0x6001605")]
	internal static bool get_IsValidLocationForInlining() { }

	[Address(RVA = "0x748317C", Offset = "0x748317C", Length = "0xB8")]
	[Token(Token = "0x6001608")]
	protected static ContextCallback GetInvokeActionCallback() { }

	[Address(RVA = "0x7483110", Offset = "0x7483110", Length = "0x6C")]
	[Token(Token = "0x6001607")]
	private static void InvokeAction(object state) { }

	[Address(RVA = "0x7483234", Offset = "0x7483234", Length = "0x4")]
	[Token(Token = "0x600160D")]
	public override void MarkAborted(ThreadAbortException e) { }

	[Address(RVA = "0x7482B30", Offset = "0x7482B30", Length = "0x12C")]
	[Token(Token = "0x6001604")]
	internal virtual void Run(Task ignored, bool canInlineContinuationTask) { }

	[Address(RVA = "0x7482454", Offset = "0x7482454", Length = "0x178")]
	[Token(Token = "0x6001609")]
	protected void RunCallback(ContextCallback callback, object state, ref Task currentTask) { }

	[Address(RVA = "0x747F564", Offset = "0x747F564", Length = "0x170")]
	[Token(Token = "0x600160A")]
	internal static void RunOrScheduleAction(Action action, bool allowInlining, ref Task currentTask) { }

	[Address(RVA = "0x7482FD8", Offset = "0x7482FD8", Length = "0x138")]
	[Token(Token = "0x6001606")]
	private override void System.Threading.IThreadPoolWorkItem.ExecuteWorkItem() { }

	[Address(RVA = "0x7482E54", Offset = "0x7482E54", Length = "0x58")]
	[Token(Token = "0x600160C")]
	protected static void ThrowAsyncIfNecessary(Exception exc) { }

	[Address(RVA = "0x747E840", Offset = "0x747E840", Length = "0x68")]
	[Token(Token = "0x600160B")]
	internal static void UnsafeScheduleAction(Action action) { }

}

