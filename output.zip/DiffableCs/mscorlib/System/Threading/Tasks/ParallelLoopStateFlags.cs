namespace System.Threading.Tasks;

[Token(Token = "0x2000250")]
internal class ParallelLoopStateFlags
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000ACB")]
	private int _loopStateFlags; //Field offset: 0x10

	[Token(Token = "0x17000223")]
	internal int LoopStateFlags
	{
		[Address(RVA = "0x74787B4", Offset = "0x74787B4", Length = "0x18")]
		[Token(Token = "0x60014E2")]
		internal get { } //Length: 24
	}

	[Address(RVA = "0x747882C", Offset = "0x747882C", Length = "0x8")]
	[Token(Token = "0x60014E8")]
	public ParallelLoopStateFlags() { }

	[Address(RVA = "0x74787CC", Offset = "0x74787CC", Length = "0x1C")]
	[Token(Token = "0x60014E3")]
	internal bool AtomicLoopStateUpdate(int newState, int illegalStates) { }

	[Address(RVA = "0x747864C", Offset = "0x747864C", Length = "0xD8")]
	[Token(Token = "0x60014E4")]
	internal bool AtomicLoopStateUpdate(int newState, int illegalStates, ref int oldState) { }

	[Address(RVA = "0x7478808", Offset = "0x7478808", Length = "0x24")]
	[Token(Token = "0x60014E7")]
	internal bool Cancel() { }

	[Address(RVA = "0x74787B4", Offset = "0x74787B4", Length = "0x18")]
	[Token(Token = "0x60014E2")]
	internal int get_LoopStateFlags() { }

	[Address(RVA = "0x74787E8", Offset = "0x74787E8", Length = "0x20")]
	[Token(Token = "0x60014E5")]
	internal void SetExceptional() { }

	[Address(RVA = "0x7478420", Offset = "0x7478420", Length = "0x78")]
	[Token(Token = "0x60014E6")]
	internal void Stop() { }

}

