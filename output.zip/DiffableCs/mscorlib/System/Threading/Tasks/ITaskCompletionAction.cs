namespace System.Threading.Tasks;

[Token(Token = "0x2000270")]
internal interface ITaskCompletionAction
{

	[Token(Token = "0x17000248")]
	public bool InvokeMayRunArbitraryCode
	{
		[Token(Token = "0x60015DC")]
		 get { } //Length: 0
	}

	[Token(Token = "0x60015DC")]
	public bool get_InvokeMayRunArbitraryCode() { }

	[Token(Token = "0x60015DB")]
	public void Invoke(Task completingTask) { }

}

