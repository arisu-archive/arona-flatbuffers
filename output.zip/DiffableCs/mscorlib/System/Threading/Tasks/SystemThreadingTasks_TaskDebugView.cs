namespace System.Threading.Tasks;

[Token(Token = "0x200026A")]
internal class SystemThreadingTasks_TaskDebugView
{

}

