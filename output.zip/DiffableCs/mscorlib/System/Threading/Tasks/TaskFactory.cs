namespace System.Threading.Tasks;

[Token(Token = "0x200027F")]
public class TaskFactory
{
	[Token(Token = "0x2000280")]
	public sealed class CompleteOnInvokePromise : Task<Task>, ITaskCompletionAction
	{
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x4000B7E")]
		private IList<Task> _tasks; //Field offset: 0x58

		[Token(Token = "0x1700024C")]
		public override bool InvokeMayRunArbitraryCode
		{
			[Address(RVA = "0x74843B0", Offset = "0x74843B0", Length = "0x8")]
			[Token(Token = "0x600162C")]
			 get { } //Length: 8
		}

		[Address(RVA = "0x7484044", Offset = "0x7484044", Length = "0x120")]
		[Token(Token = "0x600162A")]
		public CompleteOnInvokePromise(IList<Task> tasks) { }

		[Address(RVA = "0x74843B0", Offset = "0x74843B0", Length = "0x8")]
		[Token(Token = "0x600162C")]
		public override bool get_InvokeMayRunArbitraryCode() { }

		[Address(RVA = "0x7484164", Offset = "0x7484164", Length = "0x24C")]
		[Token(Token = "0x600162B")]
		public override void Invoke(Task completingTask) { }

	}

	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000B7A")]
	private readonly CancellationToken m_defaultCancellationToken; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000B7B")]
	private readonly TaskScheduler m_defaultScheduler; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000B7C")]
	private readonly TaskCreationOptions m_defaultCreationOptions; //Field offset: 0x20
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x4000B7D")]
	private readonly TaskContinuationOptions m_defaultContinuationOptions; //Field offset: 0x24

	[Address(RVA = "0x7481990", Offset = "0x7481990", Length = "0x14")]
	[Token(Token = "0x600161C")]
	public TaskFactory() { }

	[Address(RVA = "0x7483CEC", Offset = "0x7483CEC", Length = "0x6C")]
	[Token(Token = "0x600161D")]
	public TaskFactory(CancellationToken cancellationToken, TaskCreationOptions creationOptions, TaskContinuationOptions continuationOptions, TaskScheduler scheduler) { }

	[Address(RVA = "0x7483E60", Offset = "0x7483E60", Length = "0x60")]
	[Token(Token = "0x600161E")]
	internal static void CheckCreationOptions(TaskCreationOptions creationOptions) { }

	[Address(RVA = "0x7483F50", Offset = "0x7483F50", Length = "0xF4")]
	[Token(Token = "0x6001627")]
	internal static void CheckFromAsyncOptions(TaskCreationOptions creationOptions, bool hasBeginMethod) { }

	[Address(RVA = "0x7483D58", Offset = "0x7483D58", Length = "0x108")]
	[Token(Token = "0x6001629")]
	internal static void CheckMultiTaskContinuationOptions(TaskContinuationOptions continuationOptions) { }

	[Address(RVA = "0x7480D60", Offset = "0x7480D60", Length = "0x23C")]
	[Token(Token = "0x6001628")]
	internal static Task<Task> CommonCWAnyLogic(IList<Task> tasks) { }

	[Address(RVA = "0x445942C", Offset = "0x445942C", Length = "0x14")]
	[Token(Token = "0x6001623")]
	public Task FromAsync(Func<TArg1, AsyncCallback, Object, IAsyncResult> beginMethod, Action<IAsyncResult> endMethod, TArg1 arg1, object state) { }

	[Address(RVA = "0x4459440", Offset = "0x4459440", Length = "0x18")]
	[Token(Token = "0x6001624")]
	public Task FromAsync(Func<TArg1, AsyncCallback, Object, IAsyncResult> beginMethod, Action<IAsyncResult> endMethod, TArg1 arg1, object state, TaskCreationOptions creationOptions) { }

	[Address(RVA = "0x4459458", Offset = "0x4459458", Length = "0x14")]
	[Token(Token = "0x6001625")]
	public Task FromAsync(Func<TArg1, TArg2, AsyncCallback, Object, IAsyncResult> beginMethod, Action<IAsyncResult> endMethod, TArg1 arg1, TArg2 arg2, object state) { }

	[Address(RVA = "0x4459480", Offset = "0x4459480", Length = "0x18")]
	[Token(Token = "0x6001626")]
	public Task FromAsync(Func<TArg1, TArg2, AsyncCallback, Object, IAsyncResult> beginMethod, Action<IAsyncResult> endMethod, TArg1 arg1, TArg2 arg2, object state, TaskCreationOptions creationOptions) { }

	[Address(RVA = "0x7483C38", Offset = "0x7483C38", Length = "0xB4")]
	[Token(Token = "0x600161B")]
	private TaskScheduler GetDefaultScheduler(Task currTask) { }

	[Address(RVA = "0x7483EC0", Offset = "0x7483EC0", Length = "0x90")]
	[Token(Token = "0x600161F")]
	public Task StartNew(Action<Object> action, object state, CancellationToken cancellationToken, TaskCreationOptions creationOptions, TaskScheduler scheduler) { }

	[Address(RVA = "0x4459850", Offset = "0x4459850", Length = "0x9C")]
	[Token(Token = "0x6001620")]
	public Task<TResult> StartNew(Func<TResult> function, CancellationToken cancellationToken, TaskCreationOptions creationOptions, TaskScheduler scheduler) { }

	[Address(RVA = "0x44594B0", Offset = "0x44594B0", Length = "0xE8")]
	[Token(Token = "0x6001621")]
	public Task<TResult> StartNew(Func<Object, TResult> function, object state) { }

	[Address(RVA = "0x44598EC", Offset = "0x44598EC", Length = "0xAC")]
	[Token(Token = "0x6001622")]
	public Task<TResult> StartNew(Func<Object, TResult> function, object state, CancellationToken cancellationToken, TaskCreationOptions creationOptions, TaskScheduler scheduler) { }

}

