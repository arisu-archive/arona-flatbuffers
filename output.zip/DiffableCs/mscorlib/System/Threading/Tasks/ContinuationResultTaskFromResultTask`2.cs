namespace System.Threading.Tasks;

[Token(Token = "0x2000276")]
internal sealed class ContinuationResultTaskFromResultTask : Task<TResult>
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000B67")]
	private Task<TAntecedentResult> m_antecedent; //Field offset: 0x0

	[Address(RVA = "0x6E2A870", Offset = "0x6E2A870", Length = "0xD8")]
	[Token(Token = "0x60015EE")]
	public ContinuationResultTaskFromResultTask`2(Task<TAntecedentResult> antecedent, Delegate function, object state, TaskCreationOptions creationOptions, InternalTaskOptions internalOptions) { }

	[Address(RVA = "0x6E2A948", Offset = "0x6E2A948", Length = "0xE4")]
	[Token(Token = "0x60015EF")]
	internal virtual void InnerInvoke() { }

}

