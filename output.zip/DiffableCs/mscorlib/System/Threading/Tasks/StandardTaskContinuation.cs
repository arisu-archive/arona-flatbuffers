namespace System.Threading.Tasks;

[Token(Token = "0x2000278")]
internal class StandardTaskContinuation : TaskContinuation
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000B68")]
	internal readonly Task m_task; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000B69")]
	internal readonly TaskContinuationOptions m_options; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000B6A")]
	private readonly TaskScheduler m_taskScheduler; //Field offset: 0x20

	[Address(RVA = "0x747FE10", Offset = "0x747FE10", Length = "0x144")]
	[Token(Token = "0x60015F3")]
	internal StandardTaskContinuation(Task task, TaskContinuationOptions options, TaskScheduler scheduler) { }

	[Address(RVA = "0x7482014", Offset = "0x7482014", Length = "0x19C")]
	[Token(Token = "0x60015F4")]
	internal virtual void Run(Task completedTask, bool bCanInlineContinuationTask) { }

}

