namespace System.Threading.Tasks;

[Token(Token = "0x2000285")]
public class UnobservedTaskExceptionEventArgs : EventArgs
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000B88")]
	private AggregateException m_exception; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000B89")]
	internal bool m_observed; //Field offset: 0x18

	[Address(RVA = "0x748343C", Offset = "0x748343C", Length = "0x74")]
	[Token(Token = "0x6001645")]
	public UnobservedTaskExceptionEventArgs(AggregateException exception) { }

}

