namespace System.Threading.Tasks;

[IsReadOnly]
[Token(Token = "0x2000246")]
internal struct ForceAsyncAwaiter : ICriticalNotifyCompletion, INotifyCompletion
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000AAF")]
	private readonly Task _task; //Field offset: 0x0

	[Token(Token = "0x1700021C")]
	public bool IsCompleted
	{
		[Address(RVA = "0x74775C0", Offset = "0x74775C0", Length = "0x8")]
		[Token(Token = "0x60014BE")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x74775B0", Offset = "0x74775B0", Length = "0x8")]
	[Token(Token = "0x60014BC")]
	internal ForceAsyncAwaiter(Task task) { }

	[Address(RVA = "0x74775C0", Offset = "0x74775C0", Length = "0x8")]
	[Token(Token = "0x60014BE")]
	public bool get_IsCompleted() { }

	[Address(RVA = "0x74775B8", Offset = "0x74775B8", Length = "0x8")]
	[Token(Token = "0x60014BD")]
	public ForceAsyncAwaiter GetAwaiter() { }

	[Address(RVA = "0x74775C8", Offset = "0x74775C8", Length = "0x38")]
	[Token(Token = "0x60014BF")]
	public void GetResult() { }

	[Address(RVA = "0x7477600", Offset = "0x7477600", Length = "0x54")]
	[Token(Token = "0x60014C0")]
	public override void OnCompleted(Action action) { }

	[Address(RVA = "0x7477654", Offset = "0x7477654", Length = "0x54")]
	[Token(Token = "0x60014C1")]
	public override void UnsafeOnCompleted(Action action) { }

}

