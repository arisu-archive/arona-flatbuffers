namespace System.Threading.Tasks;

[Token(Token = "0x2000279")]
internal sealed class SynchronizationContextAwaitTaskContinuation : AwaitTaskContinuation
{
	[CompilerGenerated]
	[Token(Token = "0x200027A")]
	private sealed class <>c
	{
		[Token(Token = "0x4000B6E")]
		public static readonly <>c <>9; //Field offset: 0x0

		[Address(RVA = "0x7482800", Offset = "0x7482800", Length = "0x70")]
		[Token(Token = "0x60015FA")]
		private static <>c() { }

		[Address(RVA = "0x7482870", Offset = "0x7482870", Length = "0x8")]
		[Token(Token = "0x60015FB")]
		public <>c() { }

		[Address(RVA = "0x7482878", Offset = "0x7482878", Length = "0x6C")]
		[Token(Token = "0x60015FC")]
		internal void <.cctor>b__7_0(object state) { }

	}

	[Token(Token = "0x4000B6B")]
	private static readonly SendOrPostCallback s_postCallback; //Field offset: 0x0
	[Token(Token = "0x4000B6C")]
	private static ContextCallback s_postActionCallback; //Field offset: 0x8
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000B6D")]
	private readonly SynchronizationContext m_syncContext; //Field offset: 0x20

	[Address(RVA = "0x7482730", Offset = "0x7482730", Length = "0xD0")]
	[Token(Token = "0x60015F9")]
	private static SynchronizationContextAwaitTaskContinuation() { }

	[Address(RVA = "0x747E6A0", Offset = "0x747E6A0", Length = "0x34")]
	[Token(Token = "0x60015F5")]
	internal SynchronizationContextAwaitTaskContinuation(SynchronizationContext context, Action action, bool flowExecutionContext) { }

	[Address(RVA = "0x7482660", Offset = "0x7482660", Length = "0xD0")]
	[Token(Token = "0x60015F8")]
	private static ContextCallback GetPostActionCallback() { }

	[Address(RVA = "0x74825CC", Offset = "0x74825CC", Length = "0x94")]
	[Token(Token = "0x60015F7")]
	private static void PostAction(object state) { }

	[Address(RVA = "0x7482254", Offset = "0x7482254", Length = "0x200")]
	[Token(Token = "0x60015F6")]
	internal virtual void Run(Task ignored, bool canInlineContinuationTask) { }

}

