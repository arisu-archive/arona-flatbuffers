namespace System.Threading.Tasks;

[DebuggerDisplay("Id = {Id}, Status = {Status}, Method = {DebuggerDisplayMethodDescription}")]
[DebuggerTypeProxy(typeof(SystemThreadingTasks_TaskDebugView))]
[Token(Token = "0x2000264")]
public class Task : IThreadPoolWorkItem, IAsyncResult, IDisposable
{
	[CompilerGenerated]
	[Token(Token = "0x2000268")]
	private sealed class <>c
	{
		[Token(Token = "0x4000B39")]
		public static readonly <>c <>9; //Field offset: 0x0
		[Token(Token = "0x4000B3A")]
		public static Action<Object> <>9__247_0; //Field offset: 0x8
		[Token(Token = "0x4000B3B")]
		public static TimerCallback <>9__247_1; //Field offset: 0x10

		[Address(RVA = "0x7481B14", Offset = "0x7481B14", Length = "0x70")]
		[Token(Token = "0x60015CE")]
		private static <>c() { }

		[Address(RVA = "0x7481B84", Offset = "0x7481B84", Length = "0x8")]
		[Token(Token = "0x60015CF")]
		public <>c() { }

		[Address(RVA = "0x7481C4C", Offset = "0x7481C4C", Length = "0x6C")]
		[Token(Token = "0x60015D2")]
		internal ContingentProperties <.cctor>b__271_0() { }

		[Address(RVA = "0x7481CB8", Offset = "0x7481CB8", Length = "0x20")]
		[Token(Token = "0x60015D3")]
		internal bool <.cctor>b__271_1(Task t) { }

		[Address(RVA = "0x7481CD8", Offset = "0x7481CD8", Length = "0xC")]
		[Token(Token = "0x60015D4")]
		internal bool <.cctor>b__271_2(object tc) { }

		[Address(RVA = "0x7481B8C", Offset = "0x7481B8C", Length = "0x60")]
		[Token(Token = "0x60015D0")]
		internal void <Delay>b__247_0(object state) { }

		[Address(RVA = "0x7481BEC", Offset = "0x7481BEC", Length = "0x60")]
		[Token(Token = "0x60015D1")]
		internal void <Delay>b__247_1(object state) { }

	}

	[Token(Token = "0x2000265")]
	public class ContingentProperties
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000B2E")]
		internal ExecutionContext m_capturedContext; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000B2F")]
		internal ManualResetEventSlim m_completionEvent; //Field offset: 0x18
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000B30")]
		internal TaskExceptionHolder m_exceptionsHolder; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4000B31")]
		internal CancellationToken m_cancellationToken; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4000B32")]
		internal object m_cancellationRegistration; //Field offset: 0x30
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4000B33")]
		internal int m_internalCancellationRequested; //Field offset: 0x38
		[FieldOffset(Offset = "0x3C")]
		[Token(Token = "0x4000B34")]
		internal int m_completionCountdown; //Field offset: 0x3C
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4000B35")]
		internal LowLevelListWithIList<Task> m_exceptionalChildren; //Field offset: 0x40

		[Address(RVA = "0x7479E84", Offset = "0x7479E84", Length = "0x24")]
		[Token(Token = "0x60015C8")]
		public ContingentProperties() { }

		[Address(RVA = "0x747D534", Offset = "0x747D534", Length = "0x28")]
		[Token(Token = "0x60015C6")]
		internal void SetCompleted() { }

		[Address(RVA = "0x747D55C", Offset = "0x747D55C", Length = "0x114")]
		[Token(Token = "0x60015C7")]
		internal void UnregisterCancellationCallback() { }

	}

	[Token(Token = "0x2000267")]
	private sealed class DelayPromise : Task<VoidTaskResult>
	{
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x4000B36")]
		internal readonly CancellationToken Token; //Field offset: 0x58
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x4000B37")]
		internal CancellationTokenRegistration Registration; //Field offset: 0x60
		[FieldOffset(Offset = "0x78")]
		[Token(Token = "0x4000B38")]
		internal Timer Timer; //Field offset: 0x78

		[Address(RVA = "0x7480A98", Offset = "0x7480A98", Length = "0x120")]
		[Token(Token = "0x60015CC")]
		internal DelayPromise(CancellationToken token) { }

		[Address(RVA = "0x74819B4", Offset = "0x74819B4", Length = "0x160")]
		[Token(Token = "0x60015CD")]
		internal void Complete() { }

	}

	[Token(Token = "0x2000266")]
	private sealed class SetOnInvokeMres : ManualResetEventSlim, ITaskCompletionAction
	{

		[Token(Token = "0x17000247")]
		public override bool InvokeMayRunArbitraryCode
		{
			[Address(RVA = "0x74819AC", Offset = "0x74819AC", Length = "0x8")]
			[Token(Token = "0x60015CB")]
			 get { } //Length: 8
		}

		[Address(RVA = "0x747F344", Offset = "0x747F344", Length = "0x60")]
		[Token(Token = "0x60015C9")]
		internal SetOnInvokeMres() { }

		[Address(RVA = "0x74819AC", Offset = "0x74819AC", Length = "0x8")]
		[Token(Token = "0x60015CB")]
		public override bool get_InvokeMayRunArbitraryCode() { }

		[Address(RVA = "0x74819A4", Offset = "0x74819A4", Length = "0x8")]
		[Token(Token = "0x60015CA")]
		public override void Invoke(Task completingTask) { }

	}

	[ThreadStatic]
	[Token(Token = "0x4000B24")]
	internal static Task t_currentTask; //Field offset: 0x80000000
	[ThreadStatic]
	[Token(Token = "0x4000B25")]
	private static StackGuard t_stackGuard; //Field offset: 0x80000008
	[Token(Token = "0x4000B08")]
	internal static int s_taskIdCounter; //Field offset: 0x0
	[Token(Token = "0x4000B1E")]
	private const int CANCELLATION_REQUESTED = 1; //Field offset: 0x0
	[Token(Token = "0x4000B1D")]
	private const int TASK_STATE_COMPLETED_MASK = 23068672; //Field offset: 0x0
	[Token(Token = "0x4000B1C")]
	internal const int TASK_STATE_WAIT_COMPLETION_NOTIFICATION = 268435456; //Field offset: 0x0
	[Token(Token = "0x4000B1B")]
	internal const int TASK_STATE_THREAD_WAS_ABORTED = 134217728; //Field offset: 0x0
	[Token(Token = "0x4000B19")]
	internal const int TASK_STATE_WAITINGFORACTIVATION = 33554432; //Field offset: 0x0
	[Token(Token = "0x4000B18")]
	internal const int TASK_STATE_RAN_TO_COMPLETION = 16777216; //Field offset: 0x0
	[Token(Token = "0x4000B17")]
	internal const int TASK_STATE_WAITING_ON_CHILDREN = 8388608; //Field offset: 0x0
	[Token(Token = "0x4000B16")]
	internal const int TASK_STATE_CANCELED = 4194304; //Field offset: 0x0
	[Token(Token = "0x4000B15")]
	internal const int TASK_STATE_FAULTED = 2097152; //Field offset: 0x0
	[Token(Token = "0x4000B1A")]
	internal const int TASK_STATE_COMPLETION_RESERVED = 67108864; //Field offset: 0x0
	[Token(Token = "0x4000B13")]
	internal const int TASK_STATE_EXCEPTIONOBSERVEDBYPARENT = 524288; //Field offset: 0x0
	[Token(Token = "0x4000B12")]
	internal const int TASK_STATE_DISPOSED = 262144; //Field offset: 0x0
	[Token(Token = "0x4000B11")]
	internal const int TASK_STATE_DELEGATE_INVOKED = 131072; //Field offset: 0x0
	[Token(Token = "0x4000B10")]
	internal const int TASK_STATE_STARTED = 65536; //Field offset: 0x0
	[Token(Token = "0x4000B0F")]
	private const int OptionsMask = 65535; //Field offset: 0x0
	[Token(Token = "0x4000B14")]
	internal const int TASK_STATE_CANCELLATIONACKNOWLEDGED = 1048576; //Field offset: 0x0
	[Token(Token = "0x4000B20")]
	private static readonly object s_taskCompletionSentinel; //Field offset: 0x8
	[Token(Token = "0x4000B21")]
	internal static bool s_asyncDebuggingEnabled; //Field offset: 0x10
	[Token(Token = "0x4000B23")]
	private static readonly Action<Object> s_taskCancelCallback; //Field offset: 0x18
	[Token(Token = "0x4000B26")]
	private static readonly Func<ContingentProperties> s_createContingentProperties; //Field offset: 0x20
	[CompilerGenerated]
	[Token(Token = "0x4000B27")]
	private static readonly TaskFactory <Factory>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	[Token(Token = "0x4000B28")]
	private static readonly Task <CompletedTask>k__BackingField; //Field offset: 0x30
	[Token(Token = "0x4000B29")]
	private static readonly Predicate<Task> s_IsExceptionObservedByParentPredicate; //Field offset: 0x38
	[Token(Token = "0x4000B2A")]
	private static ContextCallback s_ecCallback; //Field offset: 0x40
	[Token(Token = "0x4000B2B")]
	private static readonly Predicate<Object> s_IsTaskContinuationNullPredicate; //Field offset: 0x48
	[Token(Token = "0x4000B2C")]
	private static readonly Dictionary<Int32, Task> s_currentActiveTasks; //Field offset: 0x50
	[Token(Token = "0x4000B2D")]
	private static readonly object s_activeTasksLock; //Field offset: 0x58
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000B09")]
	private int m_taskId; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000B0A")]
	internal Delegate m_action; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000B0B")]
	internal object m_stateObject; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000B0C")]
	internal TaskScheduler m_taskScheduler; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000B0D")]
	internal readonly Task m_parent; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000B0E")]
	internal int m_stateFlags; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000B1F")]
	private object m_continuationObject; //Field offset: 0x40
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000B22")]
	internal ContingentProperties m_contingentProperties; //Field offset: 0x48

	[Token(Token = "0x1700023C")]
	public override object AsyncState
	{
		[Address(RVA = "0x747C4EC", Offset = "0x747C4EC", Length = "0x8")]
		[Token(Token = "0x600156E")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000236")]
	internal CancellationToken CancellationToken
	{
		[Address(RVA = "0x7475F50", Offset = "0x7475F50", Length = "0x24")]
		[Token(Token = "0x6001567")]
		internal get { } //Length: 36
	}

	[Token(Token = "0x17000244")]
	internal ExecutionContext CapturedContext
	{
		[Address(RVA = "0x747C624", Offset = "0x747C624", Length = "0x70")]
		[Token(Token = "0x6001576")]
		internal get { } //Length: 112
		[Address(RVA = "0x747A6CC", Offset = "0x747A6CC", Length = "0xB0")]
		[Token(Token = "0x6001577")]
		internal set { } //Length: 176
	}

	[Token(Token = "0x17000241")]
	internal ManualResetEventSlim CompletedEvent
	{
		[Address(RVA = "0x747C3FC", Offset = "0x747C3FC", Length = "0xF0")]
		[Token(Token = "0x6001573")]
		internal get { } //Length: 240
	}

	[Token(Token = "0x17000240")]
	public static Task CompletedTask
	{
		[Address(RVA = "0x747C55C", Offset = "0x747C55C", Length = "0x58")]
		[CompilerGenerated]
		[Token(Token = "0x6001572")]
		 get { } //Length: 88
	}

	[Token(Token = "0x1700023A")]
	public TaskCreationOptions CreationOptions
	{
		[Address(RVA = "0x747A34C", Offset = "0x747A34C", Length = "0x14")]
		[Token(Token = "0x600156C")]
		 get { } //Length: 20
	}

	[Token(Token = "0x1700022F")]
	public static Nullable<Int32> CurrentId
	{
		[Address(RVA = "0x747BDAC", Offset = "0x747BDAC", Length = "0xBC")]
		[Token(Token = "0x600155D")]
		 get { } //Length: 188
	}

	[Token(Token = "0x17000231")]
	internal static StackGuard CurrentStackGuard
	{
		[Address(RVA = "0x747BEC0", Offset = "0x747BEC0", Length = "0xC4")]
		[Token(Token = "0x6001560")]
		internal get { } //Length: 196
	}

	[Token(Token = "0x17000232")]
	public AggregateException Exception
	{
		[Address(RVA = "0x747BF8C", Offset = "0x747BF8C", Length = "0x3C")]
		[Token(Token = "0x6001561")]
		 get { } //Length: 60
	}

	[Token(Token = "0x17000242")]
	internal bool ExceptionRecorded
	{
		[Address(RVA = "0x747C5B4", Offset = "0x747C5B4", Length = "0x54")]
		[Token(Token = "0x6001574")]
		internal get { } //Length: 84
	}

	[Token(Token = "0x1700023E")]
	internal TaskScheduler ExecutingTaskScheduler
	{
		[Address(RVA = "0x747C4FC", Offset = "0x747C4FC", Length = "0x8")]
		[Token(Token = "0x6001570")]
		internal get { } //Length: 8
	}

	[Token(Token = "0x1700023F")]
	public static TaskFactory Factory
	{
		[Address(RVA = "0x747C504", Offset = "0x747C504", Length = "0x58")]
		[CompilerGenerated]
		[Token(Token = "0x6001571")]
		 get { } //Length: 88
	}

	[Token(Token = "0x1700022E")]
	public int Id
	{
		[Address(RVA = "0x7479A6C", Offset = "0x7479A6C", Length = "0x90")]
		[Token(Token = "0x600155C")]
		 get { } //Length: 144
	}

	[Token(Token = "0x17000230")]
	internal static Task InternalCurrent
	{
		[Address(RVA = "0x747BE68", Offset = "0x747BE68", Length = "0x58")]
		[Token(Token = "0x600155E")]
		internal get { } //Length: 88
	}

	[Token(Token = "0x17000234")]
	public bool IsCanceled
	{
		[Address(RVA = "0x747C198", Offset = "0x747C198", Length = "0x20")]
		[Token(Token = "0x6001563")]
		 get { } //Length: 32
	}

	[Token(Token = "0x17000237")]
	internal bool IsCancellationAcknowledged
	{
		[Address(RVA = "0x747C334", Offset = "0x747C334", Length = "0x18")]
		[Token(Token = "0x6001568")]
		internal get { } //Length: 24
	}

	[Token(Token = "0x17000235")]
	internal bool IsCancellationRequested
	{
		[Address(RVA = "0x747C1B8", Offset = "0x747C1B8", Length = "0x90")]
		[Token(Token = "0x6001564")]
		internal get { } //Length: 144
	}

	[Token(Token = "0x17000238")]
	public override bool IsCompleted
	{
		[Address(RVA = "0x74761DC", Offset = "0x74761DC", Length = "0x64")]
		[Token(Token = "0x6001569")]
		 get { } //Length: 100
	}

	[Token(Token = "0x17000239")]
	public bool IsCompletedSuccessfully
	{
		[Address(RVA = "0x747C34C", Offset = "0x747C34C", Length = "0x28")]
		[Token(Token = "0x600156B")]
		 get { } //Length: 40
	}

	[Token(Token = "0x17000246")]
	internal bool IsDelegateInvoked
	{
		[Address(RVA = "0x747CEA4", Offset = "0x747CEA4", Length = "0x18")]
		[Token(Token = "0x6001583")]
		internal get { } //Length: 24
	}

	[Token(Token = "0x17000245")]
	internal bool IsExceptionObservedByParent
	{
		[Address(RVA = "0x747CE8C", Offset = "0x747CE8C", Length = "0x18")]
		[Token(Token = "0x6001582")]
		internal get { } //Length: 24
	}

	[Token(Token = "0x17000243")]
	public bool IsFaulted
	{
		[Address(RVA = "0x747BFC8", Offset = "0x747BFC8", Length = "0x18")]
		[Token(Token = "0x6001575")]
		 get { } //Length: 24
	}

	[Token(Token = "0x1700022D")]
	internal bool IsWaitNotificationEnabled
	{
		[Address(RVA = "0x747B310", Offset = "0x747B310", Length = "0x18")]
		[Token(Token = "0x6001553")]
		internal get { } //Length: 24
	}

	[Token(Token = "0x1700022B")]
	internal bool IsWaitNotificationEnabledOrNotRanToCompletion
	{
		[Address(RVA = "0x747B350", Offset = "0x747B350", Length = "0x28")]
		[Token(Token = "0x6001551")]
		internal get { } //Length: 40
	}

	[Token(Token = "0x1700022A")]
	internal TaskCreationOptions Options
	{
		[Address(RVA = "0x747A7BC", Offset = "0x747A7BC", Length = "0x5C")]
		[Token(Token = "0x600154B")]
		internal get { } //Length: 92
	}

	[Token(Token = "0x1700022C")]
	internal override bool ShouldNotifyDebuggerOfWaitCompletion
	{
		[Address(RVA = "0x747B378", Offset = "0x747B378", Length = "0x18")]
		[Token(Token = "0x6001552")]
		internal get { } //Length: 24
	}

	[Token(Token = "0x17000233")]
	public TaskStatus Status
	{
		[Address(RVA = "0x747C138", Offset = "0x747C138", Length = "0x60")]
		[Token(Token = "0x6001562")]
		 get { } //Length: 96
	}

	[Token(Token = "0x1700023B")]
	private override WaitHandle System.IAsyncResult.AsyncWaitHandle
	{
		[Address(RVA = "0x747C374", Offset = "0x747C374", Length = "0x88")]
		[Token(Token = "0x600156D")]
		private get { } //Length: 136
	}

	[Token(Token = "0x1700023D")]
	private override bool System.IAsyncResult.CompletedSynchronously
	{
		[Address(RVA = "0x747C4F4", Offset = "0x747C4F4", Length = "0x8")]
		[Token(Token = "0x600156F")]
		private get { } //Length: 8
	}

	[Address(RVA = "0x748164C", Offset = "0x748164C", Length = "0x344")]
	[Token(Token = "0x60015C5")]
	private static Task() { }

	[Address(RVA = "0x747A1DC", Offset = "0x747A1DC", Length = "0xD4")]
	[Token(Token = "0x6001544")]
	internal Task(Delegate action, object state, Task parent, CancellationToken cancellationToken, TaskCreationOptions creationOptions, InternalTaskOptions internalOptions, TaskScheduler scheduler) { }

	[Address(RVA = "0x74794C4", Offset = "0x74794C4", Length = "0xA4")]
	[Token(Token = "0x6001543")]
	public Task(Action<Object> action, object state, CancellationToken cancellationToken, TaskCreationOptions creationOptions) { }

	[Address(RVA = "0x7479098", Offset = "0x7479098", Length = "0x2C")]
	[Token(Token = "0x6001542")]
	public Task(Action<Object> action, object state) { }

	[Address(RVA = "0x7479DAC", Offset = "0x7479DAC", Length = "0xD8")]
	[Token(Token = "0x600153E")]
	internal Task(bool canceled, TaskCreationOptions creationOptions, CancellationToken ct) { }

	[Address(RVA = "0x7479ED0", Offset = "0x7479ED0", Length = "0x130")]
	[Token(Token = "0x6001540")]
	internal Task(object state, TaskCreationOptions creationOptions, bool promiseStyle) { }

	[Address(RVA = "0x7479EA8", Offset = "0x7479EA8", Length = "0x28")]
	[Token(Token = "0x600153F")]
	internal Task() { }

	[Address(RVA = "0x747A1AC", Offset = "0x747A1AC", Length = "0x30")]
	[Token(Token = "0x6001541")]
	public Task(Action action, CancellationToken cancellationToken) { }

	[Address(RVA = "0x747FF54", Offset = "0x747FF54", Length = "0x8")]
	[Token(Token = "0x60015A9")]
	internal void AddCompletionAction(ITaskCompletionAction action) { }

	[Address(RVA = "0x747F3A4", Offset = "0x747F3A4", Length = "0xD4")]
	[Token(Token = "0x60015AA")]
	private void AddCompletionAction(ITaskCompletionAction action, bool addBeforeOthers) { }

	[Address(RVA = "0x747C7EC", Offset = "0x747C7EC", Length = "0x1A0")]
	[Token(Token = "0x600157C")]
	internal void AddException(object exceptionObject, bool representsCancellation) { }

	[Address(RVA = "0x747AF70", Offset = "0x747AF70", Length = "0x8")]
	[Token(Token = "0x600157B")]
	internal void AddException(object exceptionObject) { }

	[Address(RVA = "0x747D144", Offset = "0x747D144", Length = "0x3F0")]
	[Token(Token = "0x6001588")]
	internal void AddExceptionsFromChildren() { }

	[Address(RVA = "0x747A360", Offset = "0x747A360", Length = "0x74")]
	[Token(Token = "0x6001556")]
	internal void AddNewChild() { }

	[Address(RVA = "0x747E7AC", Offset = "0x747E7AC", Length = "0x94")]
	[Token(Token = "0x60015AC")]
	private bool AddTaskContinuation(object tc, bool addBeforeOthers) { }

	[Address(RVA = "0x747FF5C", Offset = "0x747FF5C", Length = "0x2E4")]
	[Token(Token = "0x60015AB")]
	private bool AddTaskContinuationComplex(object tc, bool addBeforeOthers) { }

	[Address(RVA = "0x74813C4", Offset = "0x74813C4", Length = "0x14C")]
	[FriendAccessAllowed]
	[Token(Token = "0x60015C1")]
	internal static bool AddToActiveTasks(Task task) { }

	[Address(RVA = "0x747A3D4", Offset = "0x747A3D4", Length = "0x2F8")]
	[Token(Token = "0x6001546")]
	private void AssignCancellationToken(CancellationToken cancellationToken, Task antecedent, TaskContinuation continuation) { }

	[Address(RVA = "0x747AD54", Offset = "0x747AD54", Length = "0xC0")]
	[Token(Token = "0x600154D")]
	internal bool AtomicStateUpdate(int newBits, int illegalBits) { }

	[Address(RVA = "0x747B10C", Offset = "0x747B10C", Length = "0xD8")]
	[Token(Token = "0x600154E")]
	internal bool AtomicStateUpdate(int newBits, int illegalBits, ref int oldFlags) { }

	[Address(RVA = "0x747AE50", Offset = "0x747AE50", Length = "0x120")]
	[Token(Token = "0x600159C")]
	internal void CancellationCleanupLogic() { }

	[Address(RVA = "0x74764C4", Offset = "0x74764C4", Length = "0x30")]
	[Token(Token = "0x6001590")]
	public ConfiguredTaskAwaitable ConfigureAwait(bool continueOnCapturedContext) { }

	[Address(RVA = "0x747FC80", Offset = "0x747FC80", Length = "0xC")]
	[Token(Token = "0x60015A2")]
	public Task ContinueWith(Action<Task, Object> continuationAction, object state, TaskScheduler scheduler) { }

	[Address(RVA = "0x747F76C", Offset = "0x747F76C", Length = "0x74")]
	[Token(Token = "0x60015A0")]
	public Task ContinueWith(Action<Task> continuationAction) { }

	[Address(RVA = "0x747F7E0", Offset = "0x747F7E0", Length = "0x164")]
	[Token(Token = "0x60015A1")]
	private Task ContinueWith(Action<Task> continuationAction, TaskScheduler scheduler, CancellationToken cancellationToken, TaskContinuationOptions continuationOptions) { }

	[Address(RVA = "0x747FDFC", Offset = "0x747FDFC", Length = "0x14")]
	[Token(Token = "0x60015A3")]
	public Task ContinueWith(Action<Task, Object> continuationAction, object state, CancellationToken cancellationToken, TaskContinuationOptions continuationOptions, TaskScheduler scheduler) { }

	[Address(RVA = "0x747FC8C", Offset = "0x747FC8C", Length = "0x170")]
	[Token(Token = "0x60015A4")]
	private Task ContinueWith(Action<Task, Object> continuationAction, object state, TaskScheduler scheduler, CancellationToken cancellationToken, TaskContinuationOptions continuationOptions) { }

	[Address(RVA = "0x4457724", Offset = "0x4457724", Length = "0x88")]
	[Token(Token = "0x60015A5")]
	public Task<TResult> ContinueWith(Func<Task, TResult> continuationFunction) { }

	[Address(RVA = "0x44577AC", Offset = "0x44577AC", Length = "0x180")]
	[Token(Token = "0x60015A6")]
	private Task<TResult> ContinueWith(Func<Task, TResult> continuationFunction, TaskScheduler scheduler, CancellationToken cancellationToken, TaskContinuationOptions continuationOptions) { }

	[Address(RVA = "0x747FB2C", Offset = "0x747FB2C", Length = "0x154")]
	[Token(Token = "0x60015A8")]
	internal void ContinueWithCore(Task continuationTask, TaskScheduler scheduler, CancellationToken cancellationToken, TaskContinuationOptions options) { }

	[Address(RVA = "0x445792C", Offset = "0x445792C", Length = "0x74")]
	[Token(Token = "0x60015C0")]
	public static Task<TResult> CreateUnwrapPromise(Task outerTask, bool lookForOce) { }

	[Address(RVA = "0x747F944", Offset = "0x747F944", Length = "0x12C")]
	[Token(Token = "0x60015A7")]
	internal static void CreationOptionsFromContinuationOptions(TaskContinuationOptions continuationOptions, out TaskCreationOptions creationOptions, out InternalTaskOptions internalOptions) { }

	[Address(RVA = "0x74806E4", Offset = "0x74806E4", Length = "0x3B4")]
	[Token(Token = "0x60015BD")]
	public static Task Delay(int millisecondsDelay, CancellationToken cancellationToken) { }

	[Address(RVA = "0x748068C", Offset = "0x748068C", Length = "0x58")]
	[Token(Token = "0x60015BC")]
	public static Task Delay(int millisecondsDelay) { }

	[Address(RVA = "0x747C700", Offset = "0x747C700", Length = "0xEC")]
	[Token(Token = "0x6001579")]
	protected override void Dispose(bool disposing) { }

	[Address(RVA = "0x747C694", Offset = "0x747C694", Length = "0x6C")]
	[Token(Token = "0x6001578")]
	public override void Dispose() { }

	[Address(RVA = "0x747A9D8", Offset = "0x747A9D8", Length = "0x48")]
	[Token(Token = "0x6001557")]
	internal void DisregardChild() { }

	[Address(RVA = "0x747A77C", Offset = "0x747A77C", Length = "0x40")]
	[Token(Token = "0x6001565")]
	internal ContingentProperties EnsureContingentPropertiesInitialized(bool needsProtection) { }

	[Address(RVA = "0x747C248", Offset = "0x747C248", Length = "0xEC")]
	[Token(Token = "0x6001566")]
	private ContingentProperties EnsureContingentPropertiesInitializedCore(bool needsProtection) { }

	[Address(RVA = "0x747DE8C", Offset = "0x747DE8C", Length = "0xAC")]
	[Token(Token = "0x6001589")]
	private void Execute() { }

	[Address(RVA = "0x747E048", Offset = "0x747E048", Length = "0x118")]
	[Token(Token = "0x600158B")]
	internal bool ExecuteEntry(bool bPreventDoubleExecution) { }

	[Address(RVA = "0x747E160", Offset = "0x747E160", Length = "0x1E0")]
	[Token(Token = "0x60015C4")]
	private void ExecuteWithThreadLocal(ref Task currentTaskSlot) { }

	[Address(RVA = "0x747E340", Offset = "0x747E340", Length = "0x78")]
	[Token(Token = "0x600158C")]
	private static void ExecutionContextCallback(object obj) { }

	[Address(RVA = "0x747AF78", Offset = "0x747AF78", Length = "0x18C")]
	[Token(Token = "0x6001584")]
	internal void Finish(bool bUserDelegateExecuted) { }

	[Address(RVA = "0x747D87C", Offset = "0x747D87C", Length = "0x610")]
	[Token(Token = "0x600159E")]
	internal void FinishContinuations() { }

	[Address(RVA = "0x747D670", Offset = "0x747D670", Length = "0x60")]
	[Token(Token = "0x6001586")]
	internal void FinishStageThree() { }

	[Address(RVA = "0x747CEBC", Offset = "0x747CEBC", Length = "0x288")]
	[Token(Token = "0x6001585")]
	internal void FinishStageTwo() { }

	[Address(RVA = "0x4457A14", Offset = "0x4457A14", Length = "0x6C")]
	[Token(Token = "0x60015B4")]
	public static Task<TResult> FromCanceled(CancellationToken cancellationToken) { }

	[Address(RVA = "0x74770D4", Offset = "0x74770D4", Length = "0x54")]
	[Token(Token = "0x60015B2")]
	public static Task FromCanceled(CancellationToken cancellationToken) { }

	[Address(RVA = "0x4457D60", Offset = "0x4457D60", Length = "0xB8")]
	[Token(Token = "0x60015B5")]
	internal static Task<TResult> FromCancellation(OperationCanceledException exception) { }

	[Address(RVA = "0x4457B58", Offset = "0x4457B58", Length = "0x104")]
	[Token(Token = "0x60015B3")]
	internal static Task<TResult> FromCancellation(CancellationToken cancellationToken) { }

	[Address(RVA = "0x7480240", Offset = "0x7480240", Length = "0xEC")]
	[Token(Token = "0x60015B1")]
	internal static Task FromCancellation(CancellationToken cancellationToken) { }

	[Address(RVA = "0x4458294", Offset = "0x4458294", Length = "0xB4")]
	[Token(Token = "0x60015B0")]
	public static Task<TResult> FromException(Exception exception) { }

	[Address(RVA = "0x7476C1C", Offset = "0x7476C1C", Length = "0x6C")]
	[Token(Token = "0x60015AF")]
	public static Task FromException(Exception exception) { }

	[Address(RVA = "0x44584B0", Offset = "0x44584B0", Length = "0x64")]
	[Token(Token = "0x60015AE")]
	public static Task<TResult> FromResult(TResult result) { }

	[Address(RVA = "0x747C4EC", Offset = "0x747C4EC", Length = "0x8")]
	[Token(Token = "0x600156E")]
	public override object get_AsyncState() { }

	[Address(RVA = "0x7475F50", Offset = "0x7475F50", Length = "0x24")]
	[Token(Token = "0x6001567")]
	internal CancellationToken get_CancellationToken() { }

	[Address(RVA = "0x747C624", Offset = "0x747C624", Length = "0x70")]
	[Token(Token = "0x6001576")]
	internal ExecutionContext get_CapturedContext() { }

	[Address(RVA = "0x747C3FC", Offset = "0x747C3FC", Length = "0xF0")]
	[Token(Token = "0x6001573")]
	internal ManualResetEventSlim get_CompletedEvent() { }

	[Address(RVA = "0x747C55C", Offset = "0x747C55C", Length = "0x58")]
	[CompilerGenerated]
	[Token(Token = "0x6001572")]
	public static Task get_CompletedTask() { }

	[Address(RVA = "0x747A34C", Offset = "0x747A34C", Length = "0x14")]
	[Token(Token = "0x600156C")]
	public TaskCreationOptions get_CreationOptions() { }

	[Address(RVA = "0x747BDAC", Offset = "0x747BDAC", Length = "0xBC")]
	[Token(Token = "0x600155D")]
	public static Nullable<Int32> get_CurrentId() { }

	[Address(RVA = "0x747BEC0", Offset = "0x747BEC0", Length = "0xC4")]
	[Token(Token = "0x6001560")]
	internal static StackGuard get_CurrentStackGuard() { }

	[Address(RVA = "0x747BF8C", Offset = "0x747BF8C", Length = "0x3C")]
	[Token(Token = "0x6001561")]
	public AggregateException get_Exception() { }

	[Address(RVA = "0x747C5B4", Offset = "0x747C5B4", Length = "0x54")]
	[Token(Token = "0x6001574")]
	internal bool get_ExceptionRecorded() { }

	[Address(RVA = "0x747C4FC", Offset = "0x747C4FC", Length = "0x8")]
	[Token(Token = "0x6001570")]
	internal TaskScheduler get_ExecutingTaskScheduler() { }

	[Address(RVA = "0x747C504", Offset = "0x747C504", Length = "0x58")]
	[CompilerGenerated]
	[Token(Token = "0x6001571")]
	public static TaskFactory get_Factory() { }

	[Address(RVA = "0x7479A6C", Offset = "0x7479A6C", Length = "0x90")]
	[Token(Token = "0x600155C")]
	public int get_Id() { }

	[Address(RVA = "0x747BE68", Offset = "0x747BE68", Length = "0x58")]
	[Token(Token = "0x600155E")]
	internal static Task get_InternalCurrent() { }

	[Address(RVA = "0x747C198", Offset = "0x747C198", Length = "0x20")]
	[Token(Token = "0x6001563")]
	public bool get_IsCanceled() { }

	[Address(RVA = "0x747C334", Offset = "0x747C334", Length = "0x18")]
	[Token(Token = "0x6001568")]
	internal bool get_IsCancellationAcknowledged() { }

	[Address(RVA = "0x747C1B8", Offset = "0x747C1B8", Length = "0x90")]
	[Token(Token = "0x6001564")]
	internal bool get_IsCancellationRequested() { }

	[Address(RVA = "0x74761DC", Offset = "0x74761DC", Length = "0x64")]
	[Token(Token = "0x6001569")]
	public override bool get_IsCompleted() { }

	[Address(RVA = "0x747C34C", Offset = "0x747C34C", Length = "0x28")]
	[Token(Token = "0x600156B")]
	public bool get_IsCompletedSuccessfully() { }

	[Address(RVA = "0x747CEA4", Offset = "0x747CEA4", Length = "0x18")]
	[Token(Token = "0x6001583")]
	internal bool get_IsDelegateInvoked() { }

	[Address(RVA = "0x747CE8C", Offset = "0x747CE8C", Length = "0x18")]
	[Token(Token = "0x6001582")]
	internal bool get_IsExceptionObservedByParent() { }

	[Address(RVA = "0x747BFC8", Offset = "0x747BFC8", Length = "0x18")]
	[Token(Token = "0x6001575")]
	public bool get_IsFaulted() { }

	[Address(RVA = "0x747B310", Offset = "0x747B310", Length = "0x18")]
	[Token(Token = "0x6001553")]
	internal bool get_IsWaitNotificationEnabled() { }

	[Address(RVA = "0x747B350", Offset = "0x747B350", Length = "0x28")]
	[Token(Token = "0x6001551")]
	internal bool get_IsWaitNotificationEnabledOrNotRanToCompletion() { }

	[Address(RVA = "0x747A7BC", Offset = "0x747A7BC", Length = "0x5C")]
	[Token(Token = "0x600154B")]
	internal TaskCreationOptions get_Options() { }

	[Address(RVA = "0x747B378", Offset = "0x747B378", Length = "0x18")]
	[Token(Token = "0x6001552")]
	internal override bool get_ShouldNotifyDebuggerOfWaitCompletion() { }

	[Address(RVA = "0x747C138", Offset = "0x747C138", Length = "0x60")]
	[Token(Token = "0x6001562")]
	public TaskStatus get_Status() { }

	[Address(RVA = "0x74764A0", Offset = "0x74764A0", Length = "0x1C")]
	[Token(Token = "0x600158F")]
	public TaskAwaiter GetAwaiter() { }

	[Address(RVA = "0x747CD44", Offset = "0x747CD44", Length = "0x30")]
	[Token(Token = "0x600157F")]
	internal ExceptionDispatchInfo GetCancellationExceptionDispatchInfo() { }

	[Address(RVA = "0x747CBAC", Offset = "0x747CBAC", Length = "0x10C")]
	[Token(Token = "0x600157E")]
	internal ReadOnlyCollection<ExceptionDispatchInfo> GetExceptionDispatchInfos() { }

	[Address(RVA = "0x747BFE0", Offset = "0x747BFE0", Length = "0x158")]
	[Token(Token = "0x600157D")]
	private AggregateException GetExceptions(bool includeTaskCanceledExceptions) { }

	[Address(RVA = "0x747DF38", Offset = "0x747DF38", Length = "0x108")]
	[Token(Token = "0x600158E")]
	private void HandleException(Exception unhandledException) { }

	[Address(RVA = "0x747E3B8", Offset = "0x747E3B8", Length = "0xB4")]
	[Token(Token = "0x600158D")]
	internal override void InnerInvoke() { }

	[Address(RVA = "0x747A818", Offset = "0x747A818", Length = "0x1C0")]
	[Token(Token = "0x6001598")]
	internal bool InternalCancel(bool bCancelNonExecutingOnly) { }

	[Address(RVA = "0x747A2B0", Offset = "0x747A2B0", Length = "0x9C")]
	[Token(Token = "0x600155F")]
	internal static Task InternalCurrentIfAttached(TaskCreationOptions creationOptions) { }

	[Address(RVA = "0x747B5BC", Offset = "0x747B5BC", Length = "0x2D8")]
	[Token(Token = "0x600155A")]
	internal void InternalRunSynchronously(TaskScheduler scheduler, bool waitForCompletion) { }

	[Address(RVA = "0x747BCA0", Offset = "0x747BCA0", Length = "0x10C")]
	[Token(Token = "0x600155B")]
	internal static Task InternalStartNew(Task creatingTask, Delegate action, object state, CancellationToken cancellationToken, TaskScheduler scheduler, TaskCreationOptions options, InternalTaskOptions internalOptions) { }

	[Address(RVA = "0x747E9FC", Offset = "0x747E9FC", Length = "0x708")]
	[Token(Token = "0x6001595")]
	internal bool InternalWait(int millisecondsTimeout, CancellationToken cancellationToken) { }

	[Address(RVA = "0x747B39C", Offset = "0x747B39C", Length = "0x10")]
	[Token(Token = "0x600156A")]
	private static bool IsCompletedMethod(int flags) { }

	[Address(RVA = "0x747F718", Offset = "0x747F718", Length = "0x54")]
	[Token(Token = "0x600159F")]
	private void LogFinishCompletionNotification() { }

	[Address(RVA = "0x748163C", Offset = "0x748163C", Length = "0x4")]
	[Token(Token = "0x60015C3")]
	public override void MarkAborted(ThreadAbortException e) { }

	[Address(RVA = "0x747B390", Offset = "0x747B390", Length = "0xC")]
	[Token(Token = "0x6001555")]
	internal bool MarkStarted() { }

	[Address(RVA = "0x747B328", Offset = "0x747B328", Length = "0x28")]
	[Token(Token = "0x6001554")]
	private void NotifyDebuggerOfWaitCompletion() { }

	[Address(RVA = "0x747B2C0", Offset = "0x747B2C0", Length = "0x50")]
	[Token(Token = "0x6001550")]
	internal bool NotifyDebuggerOfWaitCompletionIfNecessary() { }

	[Address(RVA = "0x747B104", Offset = "0x747B104", Length = "0x8")]
	[Token(Token = "0x600154C")]
	internal static TaskCreationOptions OptionsMethod(int flags) { }

	[Address(RVA = "0x747D6D0", Offset = "0x747D6D0", Length = "0x1AC")]
	[Token(Token = "0x6001587")]
	internal void ProcessChildCompletion(Task childTask) { }

	[Address(RVA = "0x747F4C0", Offset = "0x747F4C0", Length = "0xA4")]
	[Token(Token = "0x600159A")]
	internal void RecordInternalCancellationRequest(CancellationToken tokenToRecord) { }

	[Address(RVA = "0x747F478", Offset = "0x747F478", Length = "0x48")]
	[Token(Token = "0x6001599")]
	internal void RecordInternalCancellationRequest() { }

	[Address(RVA = "0x747AE14", Offset = "0x747AE14", Length = "0x3C")]
	[Token(Token = "0x600159B")]
	internal void RecordInternalCancellationRequest(CancellationToken tokenToRecord, object cancellationException) { }

	[Address(RVA = "0x747AB10", Offset = "0x747AB10", Length = "0x244")]
	[Token(Token = "0x60015AD")]
	internal void RemoveContinuation(object continuationObject) { }

	[Address(RVA = "0x7481510", Offset = "0x7481510", Length = "0x12C")]
	[FriendAccessAllowed]
	[Token(Token = "0x60015C2")]
	internal static void RemoveFromActiveTasks(int taskId) { }

	[Address(RVA = "0x748032C", Offset = "0x748032C", Length = "0xD0")]
	[Token(Token = "0x60015B6")]
	public static Task Run(Action action) { }

	[Address(RVA = "0x4458BB4", Offset = "0x4458BB4", Length = "0x70")]
	[Token(Token = "0x60015BA")]
	public static Task<TResult> Run(Func<Task`1<TResult>> function) { }

	[Address(RVA = "0x445898C", Offset = "0x445898C", Length = "0xB8")]
	[Token(Token = "0x60015B7")]
	public static Task<TResult> Run(Func<TResult> function) { }

	[Address(RVA = "0x74803FC", Offset = "0x74803FC", Length = "0x58")]
	[Token(Token = "0x60015B8")]
	public static Task Run(Func<Task> function) { }

	[Address(RVA = "0x7480454", Offset = "0x7480454", Length = "0x238")]
	[Token(Token = "0x60015B9")]
	public static Task Run(Func<Task> function, CancellationToken cancellationToken) { }

	[Address(RVA = "0x4458D4C", Offset = "0x4458D4C", Length = "0x238")]
	[Token(Token = "0x60015BB")]
	public static Task<TResult> Run(Func<Task`1<TResult>> function, CancellationToken cancellationToken) { }

	[Address(RVA = "0x74790FC", Offset = "0x74790FC", Length = "0x5C")]
	[Token(Token = "0x6001559")]
	public void RunSynchronously(TaskScheduler scheduler) { }

	[Address(RVA = "0x747B3AC", Offset = "0x747B3AC", Length = "0x210")]
	[Token(Token = "0x600157A")]
	internal void ScheduleAndStart(bool needsProtection) { }

	[Address(RVA = "0x747A6CC", Offset = "0x747A6CC", Length = "0xB0")]
	[Token(Token = "0x6001577")]
	internal void set_CapturedContext(ExecutionContext value) { }

	[Address(RVA = "0x747E46C", Offset = "0x747E46C", Length = "0x2C")]
	[Token(Token = "0x600159D")]
	private void SetCancellationAcknowledged() { }

	[Address(RVA = "0x747E498", Offset = "0x747E498", Length = "0x208")]
	[Token(Token = "0x6001591")]
	internal void SetContinuationForAwait(Action continuationAction, bool continueOnCapturedContext, bool flowExecutionContext) { }

	[Address(RVA = "0x747B1E4", Offset = "0x747B1E4", Length = "0xDC")]
	[Token(Token = "0x600154F")]
	internal void SetNotificationForWaitCompletion(bool enabled) { }

	[Address(RVA = "0x747BA78", Offset = "0x747BA78", Length = "0x1AC")]
	[Token(Token = "0x6001596")]
	private bool SpinThenBlockingWait(int millisecondsTimeout, CancellationToken cancellationToken) { }

	[Address(RVA = "0x747F270", Offset = "0x747F270", Length = "0xD4")]
	[Token(Token = "0x6001597")]
	private bool SpinWait(int millisecondsTimeout) { }

	[Address(RVA = "0x7479568", Offset = "0x7479568", Length = "0x198")]
	[Token(Token = "0x6001558")]
	public void Start(TaskScheduler scheduler) { }

	[Address(RVA = "0x747C374", Offset = "0x747C374", Length = "0x88")]
	[Token(Token = "0x600156D")]
	private override WaitHandle System.IAsyncResult.get_AsyncWaitHandle() { }

	[Address(RVA = "0x747C4F4", Offset = "0x747C4F4", Length = "0x8")]
	[Token(Token = "0x600156F")]
	private override bool System.IAsyncResult.get_CompletedSynchronously() { }

	[Address(RVA = "0x747E040", Offset = "0x747E040", Length = "0x8")]
	[Token(Token = "0x600158A")]
	private override void System.Threading.IThreadPoolWorkItem.ExecuteWorkItem() { }

	[Address(RVA = "0x747AA20", Offset = "0x747AA20", Length = "0xF0")]
	[Token(Token = "0x6001547")]
	private static void TaskCancelCallback(object o) { }

	[Address(RVA = "0x747A000", Offset = "0x747A000", Length = "0x1AC")]
	[Token(Token = "0x6001545")]
	internal void TaskConstructorCore(Delegate action, object state, CancellationToken cancellationToken, TaskCreationOptions creationOptions, InternalTaskOptions internalOptions, TaskScheduler scheduler) { }

	[Address(RVA = "0x747CD74", Offset = "0x747CD74", Length = "0x44")]
	[Token(Token = "0x6001580")]
	internal void ThrowIfExceptional(bool includeTaskCanceledExceptions) { }

	[Address(RVA = "0x7476BC4", Offset = "0x7476BC4", Length = "0x58")]
	[Token(Token = "0x6001549")]
	internal bool TrySetCanceled(CancellationToken tokenToRecord, object cancellationException) { }

	[Address(RVA = "0x7477520", Offset = "0x7477520", Length = "0x8")]
	[Token(Token = "0x6001548")]
	internal bool TrySetCanceled(CancellationToken tokenToRecord) { }

	[Address(RVA = "0x7477528", Offset = "0x7477528", Length = "0x6C")]
	[Token(Token = "0x600154A")]
	internal bool TrySetException(object exceptionObject) { }

	[Address(RVA = "0x747CDB8", Offset = "0x747CDB8", Length = "0xD4")]
	[Token(Token = "0x6001581")]
	internal void UpdateExceptionObservedStatus() { }

	[Address(RVA = "0x747E8A8", Offset = "0x747E8A8", Length = "0x154")]
	[Token(Token = "0x6001593")]
	public bool Wait(int millisecondsTimeout, CancellationToken cancellationToken) { }

	[Address(RVA = "0x7479194", Offset = "0x7479194", Length = "0xC")]
	[Token(Token = "0x6001592")]
	public void Wait() { }

	[Address(RVA = "0x7480BB8", Offset = "0x7480BB8", Length = "0x1A8")]
	[Token(Token = "0x60015BE")]
	public static Task<Task> WhenAny(Task[] tasks) { }

	[Address(RVA = "0x7480F9C", Offset = "0x7480F9C", Length = "0x428")]
	[Token(Token = "0x60015BF")]
	public static Task<Task> WhenAny(IEnumerable<Task> tasks) { }

	[Address(RVA = "0x747F104", Offset = "0x747F104", Length = "0xD8")]
	[Token(Token = "0x6001594")]
	private bool WrappedTryRunInline() { }

}

