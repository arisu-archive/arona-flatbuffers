namespace System.Threading.Tasks;

[Token(Token = "0x2000255")]
internal class RangeManager
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000AD9")]
	internal readonly IndexRange[] _indexRanges; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000ADA")]
	internal readonly bool _use32BitCurrentIndex; //Field offset: 0x18
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x4000ADB")]
	internal int _nCurrentIndexRangeToAssign; //Field offset: 0x1C
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000ADC")]
	internal long _nStep; //Field offset: 0x20

	[Address(RVA = "0x7478B8C", Offset = "0x7478B8C", Length = "0x180")]
	[Token(Token = "0x60014F0")]
	internal RangeManager(long nFromInclusive, long nToExclusive, long nStep, int nNumExpectedWorkers) { }

	[Address(RVA = "0x7478D0C", Offset = "0x7478D0C", Length = "0x84")]
	[Token(Token = "0x60014F1")]
	internal RangeWorker RegisterNewWorker() { }

}

