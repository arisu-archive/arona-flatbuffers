namespace System.Threading.Tasks;

[Token(Token = "0x200028B")]
internal enum CausalitySynchronousWork
{
	CompletionNotification = 0,
	ProgressNotification = 1,
	Execution = 2,
}

