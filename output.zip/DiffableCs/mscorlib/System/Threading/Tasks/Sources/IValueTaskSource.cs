namespace System.Threading.Tasks.Sources;

[Token(Token = "0x200028F")]
public interface IValueTaskSource
{

	[Token(Token = "0x6001657")]
	public void GetResult(short token) { }

	[Token(Token = "0x6001655")]
	public ValueTaskSourceStatus GetStatus(short token) { }

	[Token(Token = "0x6001656")]
	public void OnCompleted(Action<Object> continuation, object state, short token, ValueTaskSourceOnCompletedFlags flags) { }

}

