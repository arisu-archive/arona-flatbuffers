namespace System.Threading.Tasks.Sources;

[Flags]
[Token(Token = "0x200028D")]
public enum ValueTaskSourceOnCompletedFlags
{
	None = 0,
	UseSchedulingContext = 1,
	FlowExecutionContext = 2,
}

