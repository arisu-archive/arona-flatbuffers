namespace System.Threading.Tasks.Sources;

[Token(Token = "0x2000290")]
public interface IValueTaskSource
{

	[Token(Token = "0x600165A")]
	public TResult GetResult(short token) { }

	[Token(Token = "0x6001658")]
	public ValueTaskSourceStatus GetStatus(short token) { }

	[Token(Token = "0x6001659")]
	public void OnCompleted(Action<Object> continuation, object state, short token, ValueTaskSourceOnCompletedFlags flags) { }

}

