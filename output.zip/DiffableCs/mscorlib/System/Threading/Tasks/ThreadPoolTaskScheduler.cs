namespace System.Threading.Tasks;

[Token(Token = "0x2000286")]
internal sealed class ThreadPoolTaskScheduler : TaskScheduler
{
	[CompilerGenerated]
	[Token(Token = "0x2000287")]
	private sealed class <>c
	{
		[Token(Token = "0x4000B8B")]
		public static readonly <>c <>9; //Field offset: 0x0

		[Address(RVA = "0x7484CF4", Offset = "0x7484CF4", Length = "0x70")]
		[Token(Token = "0x600164D")]
		private static <>c() { }

		[Address(RVA = "0x7484D64", Offset = "0x7484D64", Length = "0x8")]
		[Token(Token = "0x600164E")]
		public <>c() { }

		[Address(RVA = "0x7484D6C", Offset = "0x7484D6C", Length = "0x84")]
		[Token(Token = "0x600164F")]
		internal void <.cctor>b__10_0(object s) { }

	}

	[Token(Token = "0x4000B8A")]
	private static readonly ParameterizedThreadStart s_longRunningThreadWork; //Field offset: 0x0

	[Token(Token = "0x17000254")]
	internal virtual bool RequiresAtomicStartTransition
	{
		[Address(RVA = "0x7484C1C", Offset = "0x7484C1C", Length = "0x8")]
		[Token(Token = "0x600164B")]
		internal get { } //Length: 8
	}

	[Address(RVA = "0x7484C24", Offset = "0x7484C24", Length = "0xD0")]
	[Token(Token = "0x600164C")]
	private static ThreadPoolTaskScheduler() { }

	[Address(RVA = "0x7484674", Offset = "0x7484674", Length = "0x58")]
	[Token(Token = "0x6001646")]
	internal ThreadPoolTaskScheduler() { }

	[Address(RVA = "0x7484C1C", Offset = "0x7484C1C", Length = "0x8")]
	[Token(Token = "0x600164B")]
	internal virtual bool get_RequiresAtomicStartTransition() { }

	[Address(RVA = "0x7484C0C", Offset = "0x7484C0C", Length = "0x10")]
	[Token(Token = "0x600164A")]
	internal virtual void NotifyWorkItemProgress() { }

	[Address(RVA = "0x7484968", Offset = "0x7484968", Length = "0x1CC")]
	[Token(Token = "0x6001647")]
	protected private virtual void QueueTask(Task task) { }

	[Address(RVA = "0x7484C04", Offset = "0x7484C04", Length = "0x8")]
	[Token(Token = "0x6001649")]
	protected private virtual bool TryDequeue(Task task) { }

	[Address(RVA = "0x7484B34", Offset = "0x7484B34", Length = "0xD0")]
	[Token(Token = "0x6001648")]
	protected virtual bool TryExecuteTaskInline(Task task, bool taskWasPreviouslyQueued) { }

}

