namespace System.Threading.Tasks;

[Token(Token = "0x2000275")]
internal sealed class ContinuationTaskFromResultTask : Task
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000B66")]
	private Task<TAntecedentResult> m_antecedent; //Field offset: 0x0

	[Address(RVA = "0x6E2B164", Offset = "0x6E2B164", Length = "0xC4")]
	[Token(Token = "0x60015EC")]
	public ContinuationTaskFromResultTask`1(Task<TAntecedentResult> antecedent, Delegate action, object state, TaskCreationOptions creationOptions, InternalTaskOptions internalOptions) { }

	[Address(RVA = "0x6E2B228", Offset = "0x6E2B228", Length = "0xF4")]
	[Token(Token = "0x60015ED")]
	internal virtual void InnerInvoke() { }

}

