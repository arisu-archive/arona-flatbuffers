namespace System.Threading.Tasks;

[Token(Token = "0x2000248")]
public class ParallelOptions
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000AB1")]
	private TaskScheduler _scheduler; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000AB2")]
	private int _maxDegreeOfParallelism; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000AB3")]
	private CancellationToken _cancellationToken; //Field offset: 0x20

	[Token(Token = "0x17000220")]
	public CancellationToken CancellationToken
	{
		[Address(RVA = "0x74778A4", Offset = "0x74778A4", Length = "0x8")]
		[Token(Token = "0x60014C7")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000221")]
	internal int EffectiveMaxConcurrencyLevel
	{
		[Address(RVA = "0x74778AC", Offset = "0x74778AC", Length = "0xB4")]
		[Token(Token = "0x60014C8")]
		internal get { } //Length: 180
	}

	[Token(Token = "0x1700021E")]
	internal TaskScheduler EffectiveTaskScheduler
	{
		[Address(RVA = "0x7477798", Offset = "0x7477798", Length = "0x64")]
		[Token(Token = "0x60014C5")]
		internal get { } //Length: 100
	}

	[Token(Token = "0x1700021F")]
	public int MaxDegreeOfParallelism
	{
		[Address(RVA = "0x747789C", Offset = "0x747789C", Length = "0x8")]
		[Token(Token = "0x60014C6")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700021D")]
	public TaskScheduler TaskScheduler
	{
		[Address(RVA = "0x7477790", Offset = "0x7477790", Length = "0x8")]
		[Token(Token = "0x60014C4")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x74776A8", Offset = "0x74776A8", Length = "0xE8")]
	[Token(Token = "0x60014C3")]
	public ParallelOptions() { }

	[Address(RVA = "0x74778A4", Offset = "0x74778A4", Length = "0x8")]
	[Token(Token = "0x60014C7")]
	public CancellationToken get_CancellationToken() { }

	[Address(RVA = "0x74778AC", Offset = "0x74778AC", Length = "0xB4")]
	[Token(Token = "0x60014C8")]
	internal int get_EffectiveMaxConcurrencyLevel() { }

	[Address(RVA = "0x7477798", Offset = "0x7477798", Length = "0x64")]
	[Token(Token = "0x60014C5")]
	internal TaskScheduler get_EffectiveTaskScheduler() { }

	[Address(RVA = "0x747789C", Offset = "0x747789C", Length = "0x8")]
	[Token(Token = "0x60014C6")]
	public int get_MaxDegreeOfParallelism() { }

	[Address(RVA = "0x7477790", Offset = "0x7477790", Length = "0x8")]
	[Token(Token = "0x60014C4")]
	public TaskScheduler get_TaskScheduler() { }

}

