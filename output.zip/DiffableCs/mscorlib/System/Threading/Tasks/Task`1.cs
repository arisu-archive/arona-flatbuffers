namespace System.Threading.Tasks;

[DebuggerDisplay("Id = {Id}, Status = {Status}, Method = {DebuggerDisplayMethodDescription}, Result = {DebuggerDisplayResultDescription}")]
[DebuggerTypeProxy(typeof(SystemThreadingTasks_FutureDebugView`1))]
[Token(Token = "0x200025C")]
public class Task : Task
{
	[Token(Token = "0x4000AEE")]
	private static TaskFactory<TResult> s_defaultFactory; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000AED")]
	internal TResult m_result; //Field offset: 0x0

	[Token(Token = "0x17000229")]
	public static TaskFactory<TResult> Factory
	{
		[Address(RVA = "0x5F4436C", Offset = "0x5F4436C", Length = "0x124")]
		[Token(Token = "0x600151E")]
		 get { } //Length: 292
	}

	[DebuggerBrowsable(DebuggerBrowsableState::Never (0))]
	[Token(Token = "0x17000227")]
	public TResult Result
	{
		[Address(RVA = "0x5F44284", Offset = "0x5F44284", Length = "0x68")]
		[Token(Token = "0x600151B")]
		 get { } //Length: 104
	}

	[Token(Token = "0x17000228")]
	internal TResult ResultOnSuccess
	{
		[Address(RVA = "0x5F442EC", Offset = "0x5F442EC", Length = "0x8")]
		[Token(Token = "0x600151C")]
		internal get { } //Length: 8
	}

	[Address(RVA = "0x5F43A80", Offset = "0x5F43A80", Length = "0x58")]
	[Token(Token = "0x600150F")]
	internal Task`1() { }

	[Address(RVA = "0x5F43AD8", Offset = "0x5F43AD8", Length = "0x74")]
	[Token(Token = "0x6001510")]
	internal Task`1(object state, TaskCreationOptions options) { }

	[Address(RVA = "0x5F43B4C", Offset = "0x5F43B4C", Length = "0x78")]
	[Token(Token = "0x6001511")]
	internal Task`1(TResult result) { }

	[Address(RVA = "0x5F43BC4", Offset = "0x5F43BC4", Length = "0x90")]
	[Token(Token = "0x6001512")]
	internal Task`1(bool canceled, TResult result, TaskCreationOptions creationOptions, CancellationToken ct) { }

	[Address(RVA = "0x5F43C54", Offset = "0x5F43C54", Length = "0x2C")]
	[Token(Token = "0x6001513")]
	public Task`1(Func<TResult> function, CancellationToken cancellationToken) { }

	[Address(RVA = "0x5F43C80", Offset = "0x5F43C80", Length = "0xC8")]
	[Token(Token = "0x6001514")]
	public Task`1(Func<Object, TResult> function, object state, CancellationToken cancellationToken, TaskCreationOptions creationOptions) { }

	[Address(RVA = "0x5F43D48", Offset = "0x5F43D48", Length = "0xB0")]
	[Token(Token = "0x6001515")]
	internal Task`1(Func<TResult> valueSelector, Task parent, CancellationToken cancellationToken, TaskCreationOptions creationOptions, InternalTaskOptions internalOptions, TaskScheduler scheduler) { }

	[Address(RVA = "0x5F43DF8", Offset = "0x5F43DF8", Length = "0xB0")]
	[Token(Token = "0x6001516")]
	internal Task`1(Delegate valueSelector, object state, Task parent, CancellationToken cancellationToken, TaskCreationOptions creationOptions, InternalTaskOptions internalOptions, TaskScheduler scheduler) { }

	[Address(RVA = "0x5F4455C", Offset = "0x5F4455C", Length = "0x3C")]
	[Token(Token = "0x6001521")]
	public ConfiguredTaskAwaitable<TResult> ConfigureAwait(bool continueOnCapturedContext) { }

	[Address(RVA = "0x3ED98C8", Offset = "0x3ED98C8", Length = "0x88")]
	[Token(Token = "0x6001527")]
	public Task<TNewResult> ContinueWith(Func<Task`1<TResult>, TNewResult> continuationFunction) { }

	[Address(RVA = "0x5F447E8", Offset = "0x5F447E8", Length = "0x190")]
	[Token(Token = "0x6001526")]
	internal Task ContinueWith(Action<Task`1<TResult>, Object> continuationAction, object state, TaskScheduler scheduler, CancellationToken cancellationToken, TaskContinuationOptions continuationOptions) { }

	[Address(RVA = "0x5F447CC", Offset = "0x5F447CC", Length = "0x1C")]
	[Token(Token = "0x6001525")]
	public Task ContinueWith(Action<Task`1<TResult>, Object> continuationAction, object state, TaskScheduler scheduler) { }

	[Address(RVA = "0x5F44640", Offset = "0x5F44640", Length = "0x18C")]
	[Token(Token = "0x6001524")]
	internal Task ContinueWith(Action<Task`1<TResult>> continuationAction, TaskScheduler scheduler, CancellationToken cancellationToken, TaskContinuationOptions continuationOptions) { }

	[Address(RVA = "0x5F44624", Offset = "0x5F44624", Length = "0x1C")]
	[Token(Token = "0x6001523")]
	public Task ContinueWith(Action<Task`1<TResult>> continuationAction, TaskScheduler scheduler) { }

	[Address(RVA = "0x5F44598", Offset = "0x5F44598", Length = "0x8C")]
	[Token(Token = "0x6001522")]
	public Task ContinueWith(Action<Task`1<TResult>> continuationAction) { }

	[Address(RVA = "0x3ED9744", Offset = "0x3ED9744", Length = "0x184")]
	[Token(Token = "0x6001529")]
	internal Task<TNewResult> ContinueWith(Func<Task`1<TResult>, TNewResult> continuationFunction, TaskScheduler scheduler, CancellationToken cancellationToken, TaskContinuationOptions continuationOptions) { }

	[Address(RVA = "0x3ED96B0", Offset = "0x3ED96B0", Length = "0x94")]
	[Token(Token = "0x6001528")]
	public Task<TNewResult> ContinueWith(Func<Task`1<TResult>, TNewResult> continuationFunction, TaskContinuationOptions continuationOptions) { }

	[Address(RVA = "0x5F44228", Offset = "0x5F44228", Length = "0x5C")]
	[Token(Token = "0x600151A")]
	internal void DangerousSetResult(TResult result) { }

	[Address(RVA = "0x5F4436C", Offset = "0x5F4436C", Length = "0x124")]
	[Token(Token = "0x600151E")]
	public static TaskFactory<TResult> get_Factory() { }

	[Address(RVA = "0x5F44284", Offset = "0x5F44284", Length = "0x68")]
	[Token(Token = "0x600151B")]
	public TResult get_Result() { }

	[Address(RVA = "0x5F442EC", Offset = "0x5F442EC", Length = "0x8")]
	[Token(Token = "0x600151C")]
	internal TResult get_ResultOnSuccess() { }

	[Address(RVA = "0x5F44540", Offset = "0x5F44540", Length = "0x1C")]
	[Token(Token = "0x6001520")]
	public TaskAwaiter<TResult> GetAwaiter() { }

	[Address(RVA = "0x5F442F4", Offset = "0x5F442F4", Length = "0x78")]
	[Token(Token = "0x600151D")]
	internal TResult GetResultCore(bool waitCompletionNotification) { }

	[Address(RVA = "0x5F44490", Offset = "0x5F44490", Length = "0xB0")]
	[Token(Token = "0x600151F")]
	internal virtual void InnerInvoke() { }

	[Address(RVA = "0x5F44010", Offset = "0x5F44010", Length = "0x17C")]
	[Token(Token = "0x6001518")]
	internal static Task<TResult> StartNew(Task parent, Func<Object, TResult> function, object state, CancellationToken cancellationToken, TaskCreationOptions creationOptions, InternalTaskOptions internalOptions, TaskScheduler scheduler) { }

	[Address(RVA = "0x5F43EA8", Offset = "0x5F43EA8", Length = "0x168")]
	[Token(Token = "0x6001517")]
	internal static Task<TResult> StartNew(Task parent, Func<TResult> function, CancellationToken cancellationToken, TaskCreationOptions creationOptions, InternalTaskOptions internalOptions, TaskScheduler scheduler) { }

	[Address(RVA = "0x5F4418C", Offset = "0x5F4418C", Length = "0x9C")]
	[Token(Token = "0x6001519")]
	internal bool TrySetResult(TResult result) { }

}

