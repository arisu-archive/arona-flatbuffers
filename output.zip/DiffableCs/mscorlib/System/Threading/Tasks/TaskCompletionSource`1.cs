namespace System.Threading.Tasks;

[Token(Token = "0x200023A")]
public class TaskCompletionSource
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000A98")]
	private readonly Task<TResult> _task; //Field offset: 0x0

	[Token(Token = "0x17000212")]
	public Task<TResult> Task
	{
		[Address(RVA = "0x5F37058", Offset = "0x5F37058", Length = "0x8")]
		[Token(Token = "0x600147D")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x5F36F34", Offset = "0x5F36F34", Length = "0x6C")]
	[Token(Token = "0x6001479")]
	public TaskCompletionSource`1() { }

	[Address(RVA = "0x5F36FA0", Offset = "0x5F36FA0", Length = "0x1C")]
	[Token(Token = "0x600147A")]
	public TaskCompletionSource`1(TaskCreationOptions creationOptions) { }

	[Address(RVA = "0x5F36FBC", Offset = "0x5F36FBC", Length = "0x18")]
	[Token(Token = "0x600147B")]
	public TaskCompletionSource`1(object state) { }

	[Address(RVA = "0x5F36FD4", Offset = "0x5F36FD4", Length = "0x84")]
	[Token(Token = "0x600147C")]
	public TaskCompletionSource`1(object state, TaskCreationOptions creationOptions) { }

	[Address(RVA = "0x5F37058", Offset = "0x5F37058", Length = "0x8")]
	[Token(Token = "0x600147D")]
	public Task<TResult> get_Task() { }

	[Address(RVA = "0x5F372D4", Offset = "0x5F372D4", Length = "0x34")]
	[Token(Token = "0x6001485")]
	public void SetCanceled() { }

	[Address(RVA = "0x5F3715C", Offset = "0x5F3715C", Length = "0x60")]
	[Token(Token = "0x6001480")]
	public void SetException(Exception exception) { }

	[Address(RVA = "0x5F37220", Offset = "0x5F37220", Length = "0x34")]
	[Token(Token = "0x6001482")]
	public void SetResult(TResult result) { }

	[Address(RVA = "0x5F37060", Offset = "0x5F37060", Length = "0x80")]
	[Token(Token = "0x600147E")]
	private void SpinUntilCompleted() { }

	[Address(RVA = "0x5F37254", Offset = "0x5F37254", Length = "0x18")]
	[Token(Token = "0x6001483")]
	public bool TrySetCanceled() { }

	[Address(RVA = "0x5F3726C", Offset = "0x5F3726C", Length = "0x68")]
	[Token(Token = "0x6001484")]
	public bool TrySetCanceled(CancellationToken cancellationToken) { }

	[Address(RVA = "0x5F370E0", Offset = "0x5F370E0", Length = "0x7C")]
	[Token(Token = "0x600147F")]
	public bool TrySetException(Exception exception) { }

	[Address(RVA = "0x5F371BC", Offset = "0x5F371BC", Length = "0x64")]
	[Token(Token = "0x6001481")]
	public bool TrySetResult(TResult result) { }

}

