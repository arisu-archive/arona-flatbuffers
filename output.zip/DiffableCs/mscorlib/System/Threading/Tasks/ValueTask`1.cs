namespace System.Threading.Tasks;

[AsyncMethodBuilder(typeof(AsyncValueTaskMethodBuilder`1))]
[IsReadOnly]
[Token(Token = "0x2000242")]
public struct ValueTask : IEquatable<ValueTask`1<TResult>>
{
	[Token(Token = "0x2000243")]
	private sealed class ValueTaskSourceAsTask : Task<TResult>
	{
		[CompilerGenerated]
		[Token(Token = "0x2000244")]
		private sealed class <>c
		{
			[Token(Token = "0x4000AAE")]
			public static readonly <>c<TResult> <>9; //Field offset: 0x0

			[Address(RVA = "0x4563F40", Offset = "0x4563F40", Length = "0xEC")]
			[Token(Token = "0x60014B8")]
			private static <>c() { }

			[Address(RVA = "0x456402C", Offset = "0x456402C", Length = "0x8")]
			[Token(Token = "0x60014B9")]
			public <>c() { }

			[Address(RVA = "0x4564034", Offset = "0x4564034", Length = "0x2C4")]
			[Token(Token = "0x60014BA")]
			internal void <.cctor>b__4_0(object state) { }

		}

		[Token(Token = "0x4000AAB")]
		private static readonly Action<Object> s_completionAction; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AAC")]
		private IValueTaskSource<TResult> _source; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000AAD")]
		private readonly short _token; //Field offset: 0x0

		[Address(RVA = "0x6146B58", Offset = "0x6146B58", Length = "0x130")]
		[Token(Token = "0x60014B7")]
		private static ValueTaskSourceAsTask() { }

		[Address(RVA = "0x6146A30", Offset = "0x6146A30", Length = "0x128")]
		[Token(Token = "0x60014B6")]
		public ValueTaskSourceAsTask(IValueTaskSource<TResult> source, short token) { }

	}

	[Token(Token = "0x4000AA6")]
	private static Task<TResult> s_canceledTask; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000AA7")]
	internal readonly object _obj; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000AA8")]
	internal readonly TResult _result; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000AA9")]
	internal readonly short _token; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000AAA")]
	internal readonly bool _continueOnCapturedContext; //Field offset: 0x0

	[Token(Token = "0x17000219")]
	public bool IsCompleted
	{
		[Address(RVA = "0x6147828", Offset = "0x6147828", Length = "0x11C")]
		[Token(Token = "0x60014B0")]
		 get { } //Length: 284
	}

	[Token(Token = "0x1700021A")]
	public bool IsCompletedSuccessfully
	{
		[Address(RVA = "0x6147944", Offset = "0x6147944", Length = "0x11C")]
		[Token(Token = "0x60014B1")]
		 get { } //Length: 284
	}

	[Token(Token = "0x1700021B")]
	public TResult Result
	{
		[Address(RVA = "0x6147A60", Offset = "0x6147A60", Length = "0x17C")]
		[Token(Token = "0x60014B2")]
		 get { } //Length: 380
	}

	[Address(RVA = "0x6146EE0", Offset = "0x6146EE0", Length = "0x2C")]
	[Token(Token = "0x60014A7")]
	public ValueTask`1(TResult result) { }

	[Address(RVA = "0x6146F0C", Offset = "0x6146F0C", Length = "0x48")]
	[Token(Token = "0x60014A8")]
	public ValueTask`1(Task<TResult> task) { }

	[Address(RVA = "0x6146F54", Offset = "0x6146F54", Length = "0x4C")]
	[Token(Token = "0x60014A9")]
	public ValueTask`1(IValueTaskSource<TResult> source, short token) { }

	[Address(RVA = "0x6146FA0", Offset = "0x6146FA0", Length = "0x40")]
	[Token(Token = "0x60014AA")]
	private ValueTask`1(object obj, TResult result, short token, bool continueOnCapturedContext) { }

	[Address(RVA = "0x61471C8", Offset = "0x61471C8", Length = "0x13C")]
	[Token(Token = "0x60014AE")]
	public Task<TResult> AsTask() { }

	[Address(RVA = "0x6147C24", Offset = "0x6147C24", Length = "0xA0")]
	[Token(Token = "0x60014B4")]
	public ConfiguredValueTaskAwaitable<TResult> ConfigureAwait(bool continueOnCapturedContext) { }

	[Address(RVA = "0x6147030", Offset = "0x6147030", Length = "0xE4")]
	[Token(Token = "0x60014AC")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x6147114", Offset = "0x6147114", Length = "0xB4")]
	[Token(Token = "0x60014AD")]
	public override bool Equals(ValueTask<TResult> other) { }

	[Address(RVA = "0x6147828", Offset = "0x6147828", Length = "0x11C")]
	[Token(Token = "0x60014B0")]
	public bool get_IsCompleted() { }

	[Address(RVA = "0x6147944", Offset = "0x6147944", Length = "0x11C")]
	[Token(Token = "0x60014B1")]
	public bool get_IsCompletedSuccessfully() { }

	[Address(RVA = "0x6147A60", Offset = "0x6147A60", Length = "0x17C")]
	[Token(Token = "0x60014B2")]
	public TResult get_Result() { }

	[Address(RVA = "0x6147BDC", Offset = "0x6147BDC", Length = "0x48")]
	[Token(Token = "0x60014B3")]
	public ValueTaskAwaiter<TResult> GetAwaiter() { }

	[Address(RVA = "0x6146FE0", Offset = "0x6146FE0", Length = "0x50")]
	[Token(Token = "0x60014AB")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x6147304", Offset = "0x6147304", Length = "0x524")]
	[Token(Token = "0x60014AF")]
	private Task<TResult> GetTaskForValueTaskSource(IValueTaskSource<TResult> t) { }

	[Address(RVA = "0x6147CC4", Offset = "0x6147CC4", Length = "0xC8")]
	[Token(Token = "0x60014B5")]
	public virtual string ToString() { }

}

