namespace System.Threading.Tasks;

[Token(Token = "0x2000271")]
internal sealed class UnwrapPromise : Task<TResult>, ITaskCompletionAction
{
	[CompilerGenerated]
	[Token(Token = "0x2000272")]
	private sealed class <>c
	{
		[Token(Token = "0x4000B62")]
		public static readonly <>c<TResult> <>9; //Field offset: 0x0
		[Token(Token = "0x4000B63")]
		public static WaitCallback <>9__8_0; //Field offset: 0x0

		[Address(RVA = "0x45646C0", Offset = "0x45646C0", Length = "0xEC")]
		[Token(Token = "0x60015E5")]
		private static <>c() { }

		[Address(RVA = "0x45647AC", Offset = "0x45647AC", Length = "0x8")]
		[Token(Token = "0x60015E6")]
		public <>c() { }

		[Address(RVA = "0x45647B4", Offset = "0x45647B4", Length = "0xC8")]
		[Token(Token = "0x60015E7")]
		internal void <InvokeCoreAsync>b__8_0(object state) { }

	}

	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000B60")]
	private byte _state; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000B61")]
	private readonly bool _lookForOce; //Field offset: 0x0

	[Token(Token = "0x17000249")]
	public override bool InvokeMayRunArbitraryCode
	{
		[Address(RVA = "0x6087D0C", Offset = "0x6087D0C", Length = "0x8")]
		[Token(Token = "0x60015E4")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x60872F0", Offset = "0x60872F0", Length = "0x1B0")]
	[Token(Token = "0x60015DD")]
	public UnwrapPromise`1(Task outerTask, bool lookForOce) { }

	[Address(RVA = "0x6087D0C", Offset = "0x6087D0C", Length = "0x8")]
	[Token(Token = "0x60015E4")]
	public override bool get_InvokeMayRunArbitraryCode() { }

	[Address(RVA = "0x60874A0", Offset = "0x60874A0", Length = "0x130")]
	[Token(Token = "0x60015DE")]
	public override void Invoke(Task completingTask) { }

	[Address(RVA = "0x60875D0", Offset = "0x60875D0", Length = "0x60")]
	[Token(Token = "0x60015DF")]
	private void InvokeCore(Task completingTask) { }

	[Address(RVA = "0x6087630", Offset = "0x6087630", Length = "0x178")]
	[Token(Token = "0x60015E0")]
	private void InvokeCoreAsync(Task completingTask) { }

	[Address(RVA = "0x60877A8", Offset = "0x60877A8", Length = "0x17C")]
	[Token(Token = "0x60015E1")]
	private void ProcessCompletedOuterTask(Task task) { }

	[Address(RVA = "0x6087C7C", Offset = "0x6087C7C", Length = "0x90")]
	[Token(Token = "0x60015E3")]
	private void ProcessInnerTask(Task task) { }

	[Address(RVA = "0x6087924", Offset = "0x6087924", Length = "0x358")]
	[Token(Token = "0x60015E2")]
	private bool TrySetFromTask(Task task, bool lookForOce) { }

}

