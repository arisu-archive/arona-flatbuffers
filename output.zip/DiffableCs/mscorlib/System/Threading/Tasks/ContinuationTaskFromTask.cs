namespace System.Threading.Tasks;

[Token(Token = "0x2000273")]
internal sealed class ContinuationTaskFromTask : Task
{
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4000B64")]
	private Task m_antecedent; //Field offset: 0x50

	[Address(RVA = "0x747FA70", Offset = "0x747FA70", Length = "0xBC")]
	[Token(Token = "0x60015E8")]
	public ContinuationTaskFromTask(Task antecedent, Delegate action, object state, TaskCreationOptions creationOptions, InternalTaskOptions internalOptions) { }

	[Address(RVA = "0x7481DE8", Offset = "0x7481DE8", Length = "0xDC")]
	[Token(Token = "0x60015E9")]
	internal virtual void InnerInvoke() { }

}

