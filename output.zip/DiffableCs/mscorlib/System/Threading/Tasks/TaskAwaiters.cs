namespace System.Threading.Tasks;

[Extension]
[Token(Token = "0x2000245")]
internal static class TaskAwaiters
{

	[Address(RVA = "0x7477594", Offset = "0x7477594", Length = "0x1C")]
	[Extension]
	[Token(Token = "0x60014BB")]
	public static ForceAsyncAwaiter ForceAsync(Task task) { }

}

