namespace System.Threading.Tasks;

[Token(Token = "0x200026F")]
internal struct VoidTaskResult
{

}

