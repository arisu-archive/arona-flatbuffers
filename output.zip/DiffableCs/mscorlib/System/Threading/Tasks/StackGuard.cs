namespace System.Threading.Tasks;

[Token(Token = "0x200026E")]
internal class StackGuard
{
	[Token(Token = "0x4000B5F")]
	private const int MAX_UNCHECKED_INLINING_DEPTH = 20; //Field offset: 0x0
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000B5E")]
	private int m_inliningDepth; //Field offset: 0x10

	[Address(RVA = "0x747BF84", Offset = "0x747BF84", Length = "0x8")]
	[Token(Token = "0x60015DA")]
	public StackGuard() { }

	[Address(RVA = "0x7481DD0", Offset = "0x7481DD0", Length = "0x18")]
	[Token(Token = "0x60015D9")]
	internal void EndInliningScope() { }

	[Address(RVA = "0x7481D90", Offset = "0x7481D90", Length = "0x40")]
	[Token(Token = "0x60015D8")]
	internal bool TryBeginInliningScope() { }

}

