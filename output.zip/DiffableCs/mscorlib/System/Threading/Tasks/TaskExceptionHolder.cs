namespace System.Threading.Tasks;

[Token(Token = "0x200027E")]
internal class TaskExceptionHolder
{
	[Token(Token = "0x4000B75")]
	private static readonly bool s_failFastOnUnobservedException; //Field offset: 0x0
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000B76")]
	private readonly Task m_task; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000B77")]
	private LowLevelListWithIList<ExceptionDispatchInfo> m_faultExceptions; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000B78")]
	private ExceptionDispatchInfo m_cancellationException; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000B79")]
	private bool m_isHandled; //Field offset: 0x28

	[Token(Token = "0x1700024B")]
	internal bool ContainsFaultList
	{
		[Address(RVA = "0x747C608", Offset = "0x747C608", Length = "0x1C")]
		[Token(Token = "0x6001611")]
		internal get { } //Length: 28
	}

	[Address(RVA = "0x7483BF0", Offset = "0x7483BF0", Length = "0x48")]
	[Token(Token = "0x600161A")]
	private static TaskExceptionHolder() { }

	[Address(RVA = "0x747C98C", Offset = "0x747C98C", Length = "0x30")]
	[Token(Token = "0x600160E")]
	internal TaskExceptionHolder(Task task) { }

	[Address(RVA = "0x747C9BC", Offset = "0x747C9BC", Length = "0xC")]
	[Token(Token = "0x6001612")]
	internal void Add(object exceptionObject, bool representsCancellation) { }

	[Address(RVA = "0x74836B0", Offset = "0x74836B0", Length = "0x4C8")]
	[Token(Token = "0x6001614")]
	private void AddFaultException(object exceptionObject) { }

	[Address(RVA = "0x747C9C8", Offset = "0x747C9C8", Length = "0x1E4")]
	[Token(Token = "0x6001617")]
	internal AggregateException CreateExceptionObject(bool calledFromFinalizer, Exception includeThisException) { }

	[Address(RVA = "0x7483240", Offset = "0x7483240", Length = "0x1FC")]
	[Token(Token = "0x6001610")]
	protected virtual void Finalize() { }

	[Address(RVA = "0x747C608", Offset = "0x747C608", Length = "0x1C")]
	[Token(Token = "0x6001611")]
	internal bool get_ContainsFaultList() { }

	[Address(RVA = "0x7483BE8", Offset = "0x7483BE8", Length = "0x8")]
	[Token(Token = "0x6001619")]
	internal ExceptionDispatchInfo GetCancellationExceptionDispatchInfo() { }

	[Address(RVA = "0x747CCB8", Offset = "0x747CCB8", Length = "0x8C")]
	[Token(Token = "0x6001618")]
	internal ReadOnlyCollection<ExceptionDispatchInfo> GetExceptionDispatchInfos() { }

	[Address(RVA = "0x747BC24", Offset = "0x747BC24", Length = "0x7C")]
	[Token(Token = "0x6001616")]
	internal void MarkAsHandled(bool calledFromFinalizer) { }

	[Address(RVA = "0x7483B78", Offset = "0x7483B78", Length = "0x70")]
	[Token(Token = "0x6001615")]
	private void MarkAsUnhandled() { }

	[Address(RVA = "0x74835EC", Offset = "0x74835EC", Length = "0xC4")]
	[Token(Token = "0x6001613")]
	private void SetCancellationException(object exceptionObject) { }

	[Address(RVA = "0x7483238", Offset = "0x7483238", Length = "0x8")]
	[Token(Token = "0x600160F")]
	private static bool ShouldFailFastOnUnobservedException() { }

}

