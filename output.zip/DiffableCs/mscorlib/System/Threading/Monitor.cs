namespace System.Threading;

[Token(Token = "0x2000210")]
public static class Monitor
{

	[Address(RVA = "0x746CF1C", Offset = "0x746CF1C", Length = "0x4")]
	[Token(Token = "0x6001351")]
	public static void Enter(object obj) { }

	[Address(RVA = "0x746CF20", Offset = "0x746CF20", Length = "0x20")]
	[Token(Token = "0x6001352")]
	public static void Enter(object obj, ref bool lockTaken) { }

	[Address(RVA = "0x746CFBC", Offset = "0x746CFBC", Length = "0x4")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001354")]
	public static void Exit(object obj) { }

	[Address(RVA = "0x746D324", Offset = "0x746D324", Length = "0x4")]
	[Token(Token = "0x600135B")]
	private static void Monitor_pulse(object obj) { }

	[Address(RVA = "0x746D328", Offset = "0x746D328", Length = "0x4")]
	[Token(Token = "0x600135D")]
	private static void Monitor_pulse_all(object obj) { }

	[Address(RVA = "0x746D320", Offset = "0x746D320", Length = "0x4")]
	[Token(Token = "0x600135A")]
	private static bool Monitor_test_synchronised(object obj) { }

	[Address(RVA = "0x746D32C", Offset = "0x746D32C", Length = "0x4")]
	[Token(Token = "0x600135F")]
	private static bool Monitor_wait(object obj, int ms) { }

	[Address(RVA = "0x746D1F8", Offset = "0x746D1F8", Length = "0x68")]
	[Token(Token = "0x600135C")]
	private static void ObjPulse(object obj) { }

	[Address(RVA = "0x746D2B8", Offset = "0x746D2B8", Length = "0x68")]
	[Token(Token = "0x600135E")]
	private static void ObjPulseAll(object obj) { }

	[Address(RVA = "0x746D0DC", Offset = "0x746D0DC", Length = "0xBC")]
	[Token(Token = "0x6001360")]
	private static bool ObjWait(bool exitContext, int millisecondsTimeout, object obj) { }

	[Address(RVA = "0x746D1A0", Offset = "0x746D1A0", Length = "0x58")]
	[Token(Token = "0x6001358")]
	public static void Pulse(object obj) { }

	[Address(RVA = "0x746D260", Offset = "0x746D260", Length = "0x58")]
	[Token(Token = "0x6001359")]
	public static void PulseAll(object obj) { }

	[Address(RVA = "0x746CFB0", Offset = "0x746CFB0", Length = "0xC")]
	[Token(Token = "0x6001363")]
	private static void ReliableEnter(object obj, ref bool lockTaken) { }

	[Address(RVA = "0x746CFE0", Offset = "0x746CFE0", Length = "0x9C")]
	[Token(Token = "0x6001362")]
	private static void ReliableEnterTimeout(object obj, int timeout, ref bool lockTaken) { }

	[Address(RVA = "0x746CF40", Offset = "0x746CF40", Length = "0x70")]
	[Token(Token = "0x6001353")]
	private static void ThrowLockTakenException() { }

	[Address(RVA = "0x746D330", Offset = "0x746D330", Length = "0x4")]
	[Token(Token = "0x6001361")]
	private static void try_enter_with_atomic_var(object obj, int millisecondsTimeout, ref bool lockTaken) { }

	[Address(RVA = "0x746CFC0", Offset = "0x746CFC0", Length = "0x20")]
	[Token(Token = "0x6001355")]
	public static void TryEnter(object obj, ref bool lockTaken) { }

	[Address(RVA = "0x746D198", Offset = "0x746D198", Length = "0x8")]
	[Token(Token = "0x6001357")]
	public static bool Wait(object obj, int millisecondsTimeout) { }

	[Address(RVA = "0x746D07C", Offset = "0x746D07C", Length = "0x60")]
	[Token(Token = "0x6001356")]
	public static bool Wait(object obj, int millisecondsTimeout, bool exitContext) { }

}

