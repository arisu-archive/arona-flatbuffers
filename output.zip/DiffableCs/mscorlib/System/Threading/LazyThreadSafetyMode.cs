namespace System.Threading;

[Token(Token = "0x20001DB")]
public enum LazyThreadSafetyMode
{
	None = 0,
	PublicationOnly = 1,
	ExecutionAndPublication = 2,
}

