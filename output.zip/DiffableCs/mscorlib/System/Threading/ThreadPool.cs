namespace System.Threading;

[Token(Token = "0x2000227")]
public static class ThreadPool
{
	[CompilerGenerated]
	[Token(Token = "0x2000228")]
	private sealed class <>c__DisplayClass17_0
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000A40")]
		public Action<TState> callBack; //Field offset: 0x0

		[Address(RVA = "0x45B2BB4", Offset = "0x45B2BB4", Length = "0x8")]
		[Token(Token = "0x6001406")]
		public <>c__DisplayClass17_0`1() { }

		[Address(RVA = "0x45B2BBC", Offset = "0x45B2BBC", Length = "0x98")]
		[Token(Token = "0x6001407")]
		internal void <QueueUserWorkItem>b__0(object x) { }

	}


	[Token(Token = "0x1700020C")]
	internal static bool IsThreadPoolThread
	{
		[Address(RVA = "0x7472170", Offset = "0x7472170", Length = "0x18")]
		[Token(Token = "0x6001405")]
		internal get { } //Length: 24
	}

	[Address(RVA = "0x7471FA8", Offset = "0x7471FA8", Length = "0x94")]
	[Token(Token = "0x60013FE")]
	private static void EnsureVMInitialized() { }

	[Address(RVA = "0x7472170", Offset = "0x7472170", Length = "0x18")]
	[Token(Token = "0x6001405")]
	internal static bool get_IsThreadPoolThread() { }

	[Address(RVA = "0x7472154", Offset = "0x7472154", Length = "0x4")]
	[Token(Token = "0x6001404")]
	private static void InitializeVMTp(ref bool enableWorkerTracking) { }

	[Address(RVA = "0x747108C", Offset = "0x747108C", Length = "0x4")]
	[Token(Token = "0x60013FF")]
	internal static bool NotifyWorkItemComplete() { }

	[Address(RVA = "0x747215C", Offset = "0x747215C", Length = "0x10")]
	[Token(Token = "0x6001401")]
	internal static void NotifyWorkItemProgress() { }

	[Address(RVA = "0x747216C", Offset = "0x747216C", Length = "0x4")]
	[Token(Token = "0x6001402")]
	internal static void NotifyWorkItemProgressNative() { }

	[Address(RVA = "0x74701DC", Offset = "0x74701DC", Length = "0x4")]
	[Token(Token = "0x6001403")]
	internal static void NotifyWorkItemQueued() { }

	[Address(RVA = "0x746D538", Offset = "0x746D538", Length = "0x28")]
	[Token(Token = "0x60013F6")]
	public static bool QueueUserWorkItem(WaitCallback callBack, object state) { }

	[Address(RVA = "0x7471F7C", Offset = "0x7471F7C", Length = "0x2C")]
	[Token(Token = "0x60013F7")]
	public static bool QueueUserWorkItem(WaitCallback callBack) { }

	[Address(RVA = "0x445A69C", Offset = "0x445A69C", Length = "0x144")]
	[Token(Token = "0x60013F9")]
	public static bool QueueUserWorkItem(Action<TState> callBack, TState state, bool preferLocal) { }

	[Address(RVA = "0x7471E5C", Offset = "0x7471E5C", Length = "0x120")]
	[Token(Token = "0x60013FA")]
	private static bool QueueUserWorkItemHelper(WaitCallback callBack, object state, ref StackCrawlMark stackMark, bool compressStack, bool forceGlobal = true) { }

	[Address(RVA = "0x7471A08", Offset = "0x7471A08", Length = "0x1FC")]
	[Token(Token = "0x60013F4")]
	private static RegisteredWaitHandle RegisterWaitForSingleObject(WaitHandle waitObject, WaitOrTimerCallback callBack, object state, uint millisecondsTimeOutInterval, bool executeOnlyOnce, ref StackCrawlMark stackMark, bool compressStack) { }

	[Address(RVA = "0x7471D28", Offset = "0x7471D28", Length = "0x134")]
	[Token(Token = "0x60013F5")]
	public static RegisteredWaitHandle RegisterWaitForSingleObject(WaitHandle waitObject, WaitOrTimerCallback callBack, object state, TimeSpan timeout, bool executeOnlyOnce) { }

	[Address(RVA = "0x7472158", Offset = "0x7472158", Length = "0x4")]
	[Token(Token = "0x6001400")]
	internal static void ReportThreadStatus(bool isWorking) { }

	[Address(RVA = "0x746FA80", Offset = "0x746FA80", Length = "0x4")]
	[Token(Token = "0x60013FD")]
	internal static bool RequestWorkerThread() { }

	[Address(RVA = "0x74720B8", Offset = "0x74720B8", Length = "0x9C")]
	[Token(Token = "0x60013FC")]
	internal static bool TryPopCustomWorkItem(IThreadPoolWorkItem workItem) { }

	[Address(RVA = "0x747203C", Offset = "0x747203C", Length = "0x7C")]
	[Token(Token = "0x60013FB")]
	internal static void UnsafeQueueCustomWorkItem(IThreadPoolWorkItem workItem, bool forceGlobal) { }

	[Address(RVA = "0x7471D00", Offset = "0x7471D00", Length = "0x28")]
	[Token(Token = "0x60013F8")]
	public static bool UnsafeQueueUserWorkItem(WaitCallback callBack, object state) { }

}

