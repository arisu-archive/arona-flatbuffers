namespace System.Threading;

[ComVisible(True)]
[Token(Token = "0x200021D")]
public sealed class WaitCallback : MulticastDelegate
{

	[Address(RVA = "0x746D3F8", Offset = "0x746D3F8", Length = "0x140")]
	[Token(Token = "0x60013CD")]
	public WaitCallback(object object, IntPtr method) { }

	[Address(RVA = "0x746F538", Offset = "0x746F538", Length = "0x14")]
	[Token(Token = "0x60013CE")]
	public override void Invoke(object state) { }

}

