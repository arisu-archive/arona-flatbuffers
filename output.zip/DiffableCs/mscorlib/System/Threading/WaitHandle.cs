namespace System.Threading;

[ComVisible(True)]
[Token(Token = "0x2000229")]
public abstract class WaitHandle : MarshalByRefObject, IDisposable
{
	[Token(Token = "0x4000A41")]
	public const int WaitTimeout = 258; //Field offset: 0x0
	[Token(Token = "0x4000A42")]
	private const int MAX_WAITHANDLES = 64; //Field offset: 0x0
	[Token(Token = "0x4000A46")]
	private const int WAIT_OBJECT_0 = 0; //Field offset: 0x0
	[Token(Token = "0x4000A47")]
	private const int WAIT_ABANDONED = 128; //Field offset: 0x0
	[Token(Token = "0x4000A48")]
	private const int WAIT_FAILED = 2147483647; //Field offset: 0x0
	[Token(Token = "0x4000A49")]
	private const int ERROR_TOO_MANY_POSTS = 298; //Field offset: 0x0
	[Token(Token = "0x4000A4A")]
	private const int ERROR_NOT_OWNED_BY_CALLER = 299; //Field offset: 0x0
	[Token(Token = "0x4000A4B")]
	protected static readonly IntPtr InvalidHandle; //Field offset: 0x0
	[Token(Token = "0x4000A4C")]
	internal const int MaxWaitHandles = 64; //Field offset: 0x0
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000A43")]
	private IntPtr waitHandle; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000A44")]
	internal SafeWaitHandle safeWaitHandle; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000A45")]
	internal bool hasThreadAffinity; //Field offset: 0x28

	[Obsolete("Use the SafeWaitHandle property instead.")]
	[Token(Token = "0x1700020D")]
	public override IntPtr Handle
	{
		[Address(RVA = "0x747221C", Offset = "0x747221C", Length = "0x104")]
		[Token(Token = "0x600140A")]
		 set { } //Length: 260
	}

	[Token(Token = "0x1700020E")]
	public SafeWaitHandle SafeWaitHandle
	{
		[Address(RVA = "0x7472320", Offset = "0x7472320", Length = "0xC0")]
		[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::MayFail (1))]
		[Token(Token = "0x600140B")]
		 get { } //Length: 192
	}

	[Address(RVA = "0x74732A0", Offset = "0x74732A0", Length = "0x54")]
	[Token(Token = "0x600141E")]
	private static WaitHandle() { }

	[Address(RVA = "0x7472188", Offset = "0x7472188", Length = "0x1C")]
	[Token(Token = "0x6001408")]
	protected WaitHandle() { }

	[Address(RVA = "0x7473178", Offset = "0x7473178", Length = "0x70")]
	[Token(Token = "0x6001418")]
	public override void Close() { }

	[Address(RVA = "0x7473230", Offset = "0x7473230", Length = "0x70")]
	[Token(Token = "0x600141A")]
	public override void Dispose() { }

	[Address(RVA = "0x74731E8", Offset = "0x74731E8", Length = "0x48")]
	[Token(Token = "0x6001419")]
	protected override void Dispose(bool explicitDisposing) { }

	[Address(RVA = "0x7472320", Offset = "0x7472320", Length = "0xC0")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::MayFail (1))]
	[Token(Token = "0x600140B")]
	public SafeWaitHandle get_SafeWaitHandle() { }

	[Address(RVA = "0x74721A4", Offset = "0x74721A4", Length = "0x78")]
	[Token(Token = "0x6001409")]
	private void Init() { }

	[Address(RVA = "0x7472664", Offset = "0x7472664", Length = "0xF4")]
	[Token(Token = "0x6001413")]
	internal static bool InternalWaitOne(SafeHandle waitableSafeHandle, long millisecondsTimeout, bool hasThreadAffinity, bool exitContext) { }

	[Address(RVA = "0x747221C", Offset = "0x747221C", Length = "0x104")]
	[Token(Token = "0x600140A")]
	public override void set_Handle(IntPtr value) { }

	[Address(RVA = "0x74723E0", Offset = "0x74723E0", Length = "0x40")]
	[Token(Token = "0x600140C")]
	internal void SetHandleInternal(SafeWaitHandle handle) { }

	[Address(RVA = "0x747291C", Offset = "0x747291C", Length = "0x40")]
	[Token(Token = "0x6001416")]
	private static void ThrowAbandonedMutexException() { }

	[Address(RVA = "0x7472FF4", Offset = "0x7472FF4", Length = "0x54")]
	[Token(Token = "0x6001417")]
	private static void ThrowAbandonedMutexException(int location, WaitHandle handle) { }

	[Address(RVA = "0x746D658", Offset = "0x746D658", Length = "0x4")]
	[Token(Token = "0x600141D")]
	internal static int Wait_internal(IntPtr* handles, int numHandles, bool waitAll, int ms) { }

	[Address(RVA = "0x7473048", Offset = "0x7473048", Length = "0x130")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::MayFail (1))]
	[Token(Token = "0x6001415")]
	public static int WaitAny(WaitHandle[] waitHandles, TimeSpan timeout, bool exitContext) { }

	[Address(RVA = "0x747295C", Offset = "0x747295C", Length = "0x30C")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::MayFail (1))]
	[Token(Token = "0x6001414")]
	public static int WaitAny(WaitHandle[] waitHandles, int millisecondsTimeout, bool exitContext) { }

	[Address(RVA = "0x7472C68", Offset = "0x7472C68", Length = "0x38C")]
	[Token(Token = "0x600141C")]
	private static int WaitMultiple(WaitHandle[] waitHandles, int millisecondsTimeout, bool exitContext, bool WaitAll) { }

	[Address(RVA = "0x7472654", Offset = "0x7472654", Length = "0x10")]
	[Token(Token = "0x6001411")]
	public override bool WaitOne(TimeSpan timeout) { }

	[Address(RVA = "0x74724A4", Offset = "0x74724A4", Length = "0x80")]
	[Token(Token = "0x6001412")]
	private bool WaitOne(long timeout, bool exitContext) { }

	[Address(RVA = "0x7472630", Offset = "0x7472630", Length = "0x14")]
	[Token(Token = "0x600140F")]
	public override bool WaitOne() { }

	[Address(RVA = "0x7472524", Offset = "0x7472524", Length = "0x10C")]
	[Token(Token = "0x600140E")]
	public override bool WaitOne(TimeSpan timeout, bool exitContext) { }

	[Address(RVA = "0x7472420", Offset = "0x7472420", Length = "0x84")]
	[Token(Token = "0x600140D")]
	public override bool WaitOne(int millisecondsTimeout, bool exitContext) { }

	[Address(RVA = "0x7472644", Offset = "0x7472644", Length = "0x10")]
	[Token(Token = "0x6001410")]
	public override bool WaitOne(int millisecondsTimeout) { }

	[Address(RVA = "0x7472758", Offset = "0x7472758", Length = "0x1C4")]
	[Token(Token = "0x600141B")]
	private static int WaitOneNative(SafeHandle waitableSafeHandle, uint millisecondsTimeout, bool hasThreadAffinity, bool exitContext) { }

}

