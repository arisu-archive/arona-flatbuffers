namespace System.Threading;

[ComVisible(True)]
[Token(Token = "0x2000208")]
public class EventWaitHandle : WaitHandle
{

	[Address(RVA = "0x7463430", Offset = "0x7463430", Length = "0x8")]
	[Token(Token = "0x6001315")]
	public EventWaitHandle(bool initialState, EventResetMode mode) { }

	[Address(RVA = "0x746AE40", Offset = "0x746AE40", Length = "0x2B8")]
	[Token(Token = "0x6001316")]
	public EventWaitHandle(bool initialState, EventResetMode mode, string name) { }

	[Address(RVA = "0x7468F10", Offset = "0x7468F10", Length = "0x64")]
	[Token(Token = "0x6001317")]
	public bool Reset() { }

	[Address(RVA = "0x74651B0", Offset = "0x74651B0", Length = "0x64")]
	[Token(Token = "0x6001318")]
	public bool Set() { }

}

