namespace System.Threading;

[Token(Token = "0x20001F9")]
internal struct SparselyPopulatedArrayAddInfo
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40009B4")]
	private SparselyPopulatedArrayFragment<T> _source; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40009B5")]
	private int _index; //Field offset: 0x0

	[Token(Token = "0x170001E6")]
	internal int Index
	{
		[Address(RVA = "0x5F1C178", Offset = "0x5F1C178", Length = "0x8")]
		[Token(Token = "0x60012CF")]
		internal get { } //Length: 8
	}

	[Token(Token = "0x170001E5")]
	internal SparselyPopulatedArrayFragment<T> Source
	{
		[Address(RVA = "0x5F1C170", Offset = "0x5F1C170", Length = "0x8")]
		[Token(Token = "0x60012CE")]
		internal get { } //Length: 8
	}

	[Address(RVA = "0x5F1C148", Offset = "0x5F1C148", Length = "0x28")]
	[Token(Token = "0x60012CD")]
	internal SparselyPopulatedArrayAddInfo`1(SparselyPopulatedArrayFragment<T> source, int index) { }

	[Address(RVA = "0x5F1C178", Offset = "0x5F1C178", Length = "0x8")]
	[Token(Token = "0x60012CF")]
	internal int get_Index() { }

	[Address(RVA = "0x5F1C170", Offset = "0x5F1C170", Length = "0x8")]
	[Token(Token = "0x60012CE")]
	internal SparselyPopulatedArrayFragment<T> get_Source() { }

}

