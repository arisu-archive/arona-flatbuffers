namespace System.Threading;

[Token(Token = "0x20001DC")]
public class LockRecursionException : Exception
{

	[Address(RVA = "0x74634B8", Offset = "0x74634B8", Length = "0x58")]
	[Token(Token = "0x600124D")]
	public LockRecursionException() { }

	[Address(RVA = "0x7463510", Offset = "0x7463510", Length = "0x68")]
	[Token(Token = "0x600124E")]
	public LockRecursionException(string message) { }

	[Address(RVA = "0x7463578", Offset = "0x7463578", Length = "0x80")]
	[Token(Token = "0x600124F")]
	protected LockRecursionException(SerializationInfo info, StreamingContext context) { }

}

