namespace System.Threading;

[DebuggerDisplay("IsValueCreated={IsValueCreated}, Value={ValueForDebugDisplay}, Count={ValuesCountForDebugDisplay}")]
[DebuggerTypeProxy(typeof(SystemThreading_ThreadLocalDebugView`1))]
[Token(Token = "0x2000202")]
public class ThreadLocal : IDisposable
{
	[Token(Token = "0x2000206")]
	private class FinalizationHelper
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40009E4")]
		internal LinkedSlotVolatile<T>[] SlotArray; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40009E5")]
		private bool m_trackAllValues; //Field offset: 0x0

		[Address(RVA = "0x4D4DA68", Offset = "0x4D4DA68", Length = "0x3C")]
		[Token(Token = "0x6001313")]
		internal FinalizationHelper(LinkedSlotVolatile<T>[] slotArray, bool trackAllValues) { }

		[Address(RVA = "0x4D4DAA4", Offset = "0x4D4DAA4", Length = "0x290")]
		[Token(Token = "0x6001314")]
		protected virtual void Finalize() { }

	}

	[Token(Token = "0x2000205")]
	private class IdManager
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40009E2")]
		private int m_nextIdToTry; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40009E3")]
		private List<Boolean> m_freeIds; //Field offset: 0x0

		[Address(RVA = "0x4ECA3FC", Offset = "0x4ECA3FC", Length = "0x88")]
		[Token(Token = "0x6001312")]
		public IdManager() { }

		[Address(RVA = "0x4ECA104", Offset = "0x4ECA104", Length = "0x1EC")]
		[Token(Token = "0x6001310")]
		internal int GetId() { }

		[Address(RVA = "0x4ECA2F0", Offset = "0x4ECA2F0", Length = "0x10C")]
		[Token(Token = "0x6001311")]
		internal void ReturnId(int id) { }

	}

	[Token(Token = "0x2000204")]
	private sealed class LinkedSlot
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40009DE")]
		internal LinkedSlot<T> Next; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40009DF")]
		internal LinkedSlot<T> Previous; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40009E0")]
		internal LinkedSlotVolatile<T>[] SlotArray; //Field offset: 0x0
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40009E1")]
		internal T Value; //Field offset: 0x0

		[Address(RVA = "0x518229C", Offset = "0x518229C", Length = "0x34")]
		[Token(Token = "0x600130F")]
		internal LinkedSlot(LinkedSlotVolatile<T>[] slotArray) { }

	}

	[Token(Token = "0x2000203")]
	private struct LinkedSlotVolatile
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40009DD")]
		internal LinkedSlot<T> Value; //Field offset: 0x0

	}

	[ThreadStatic]
	[Token(Token = "0x40009D6")]
	private static LinkedSlotVolatile<T>[] ts_slotArray; //Field offset: 0xFFFFFFFF
	[ThreadStatic]
	[Token(Token = "0x40009D7")]
	private static FinalizationHelper<T> ts_finalizationHelper; //Field offset: 0xFFFFFFFF
	[Token(Token = "0x40009DA")]
	private static IdManager<T> s_idManager; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40009D5")]
	private Func<T> m_valueFactory; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40009D8")]
	private int m_idComplement; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40009D9")]
	private bool m_initialized; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40009DB")]
	private LinkedSlot<T> m_linkedSlot; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40009DC")]
	private bool m_trackAllValues; //Field offset: 0x0

	[Token(Token = "0x170001EE")]
	public bool IsValueCreated
	{
		[Address(RVA = "0x5F56B54", Offset = "0x5F56B54", Length = "0xF4")]
		[Token(Token = "0x600130B")]
		 get { } //Length: 244
	}

	[DebuggerBrowsable(DebuggerBrowsableState::Never (0))]
	[Token(Token = "0x170001ED")]
	public T Value
	{
		[Address(RVA = "0x5F56224", Offset = "0x5F56224", Length = "0xDC")]
		[Token(Token = "0x6001306")]
		 get { } //Length: 220
		[Address(RVA = "0x5F56300", Offset = "0x5F56300", Length = "0xFC")]
		[Token(Token = "0x6001307")]
		 set { } //Length: 252
	}

	[Address(RVA = "0x5F56ECC", Offset = "0x5F56ECC", Length = "0xEC")]
	[Token(Token = "0x600130E")]
	private static ThreadLocal`1() { }

	[Address(RVA = "0x5F55D14", Offset = "0x5F55D14", Length = "0xA0")]
	[Token(Token = "0x6001300")]
	public ThreadLocal`1() { }

	[Address(RVA = "0x5F568B0", Offset = "0x5F568B0", Length = "0x2A4")]
	[Token(Token = "0x600130A")]
	private void CreateLinkedSlot(LinkedSlotVolatile<T>[] slotArray, int id, T value) { }

	[Address(RVA = "0x5F55EF4", Offset = "0x5F55EF4", Length = "0x6C")]
	[Token(Token = "0x6001303")]
	public override void Dispose() { }

	[Address(RVA = "0x5F55F60", Offset = "0x5F55F60", Length = "0x294")]
	[Token(Token = "0x6001304")]
	protected override void Dispose(bool disposing) { }

	[Address(RVA = "0x5F55E64", Offset = "0x5F55E64", Length = "0x90")]
	[Token(Token = "0x6001302")]
	protected virtual void Finalize() { }

	[Address(RVA = "0x5F56B54", Offset = "0x5F56B54", Length = "0xF4")]
	[Token(Token = "0x600130B")]
	public bool get_IsValueCreated() { }

	[Address(RVA = "0x5F56224", Offset = "0x5F56224", Length = "0xDC")]
	[Token(Token = "0x6001306")]
	public T get_Value() { }

	[Address(RVA = "0x5F56E8C", Offset = "0x5F56E8C", Length = "0x40")]
	[Token(Token = "0x600130D")]
	private static int GetNewTableSize(int minSize) { }

	[Address(RVA = "0x5F563FC", Offset = "0x5F563FC", Length = "0x160")]
	[Token(Token = "0x6001308")]
	private T GetValueSlow() { }

	[Address(RVA = "0x5F56C48", Offset = "0x5F56C48", Length = "0x244")]
	[Token(Token = "0x600130C")]
	private void GrowTable(ref LinkedSlotVolatile<T>[] table, int minLength) { }

	[Address(RVA = "0x5F55DB4", Offset = "0x5F55DB4", Length = "0xB0")]
	[Token(Token = "0x6001301")]
	private void Initialize(Func<T> valueFactory, bool trackAllValues) { }

	[Address(RVA = "0x5F56300", Offset = "0x5F56300", Length = "0xFC")]
	[Token(Token = "0x6001307")]
	public void set_Value(T value) { }

	[Address(RVA = "0x5F5655C", Offset = "0x5F5655C", Length = "0x354")]
	[Token(Token = "0x6001309")]
	private void SetValueSlow(T value, LinkedSlotVolatile<T>[] slotArray) { }

	[Address(RVA = "0x5F561F4", Offset = "0x5F561F4", Length = "0x30")]
	[Token(Token = "0x6001305")]
	public virtual string ToString() { }

}

