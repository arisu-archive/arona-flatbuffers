namespace System.Threading;

[Token(Token = "0x200021C")]
internal interface IThreadPoolWorkItem
{

	[Token(Token = "0x60013CB")]
	public void ExecuteWorkItem() { }

	[Token(Token = "0x60013CC")]
	public void MarkAborted(ThreadAbortException tae) { }

}

