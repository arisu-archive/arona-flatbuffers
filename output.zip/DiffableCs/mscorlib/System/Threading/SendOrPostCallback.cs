namespace System.Threading;

[Token(Token = "0x20001E0")]
public sealed class SendOrPostCallback : MulticastDelegate
{

	[Address(RVA = "0x74637AC", Offset = "0x74637AC", Length = "0x140")]
	[Token(Token = "0x6001255")]
	public SendOrPostCallback(object object, IntPtr method) { }

	[Address(RVA = "0x74638EC", Offset = "0x74638EC", Length = "0x14")]
	[Token(Token = "0x6001256")]
	public override void Invoke(object state) { }

}

