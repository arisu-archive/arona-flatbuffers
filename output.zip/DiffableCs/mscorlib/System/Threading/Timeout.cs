namespace System.Threading;

[Token(Token = "0x20001E6")]
public static class Timeout
{
	[Token(Token = "0x4000977")]
	public static readonly TimeSpan InfiniteTimeSpan; //Field offset: 0x0

	[Address(RVA = "0x7463AF4", Offset = "0x7463AF4", Length = "0x70")]
	[Token(Token = "0x600125F")]
	private static Timeout() { }

}

