namespace System.Threading;

[Token(Token = "0x2000225")]
internal static class _ThreadPoolWaitCallback
{

	[Address(RVA = "0x74716D0", Offset = "0x74716D0", Length = "0x4C")]
	[Token(Token = "0x60013EE")]
	internal static bool PerformWaitCallback() { }

}

