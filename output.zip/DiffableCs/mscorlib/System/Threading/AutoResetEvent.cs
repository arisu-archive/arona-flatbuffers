namespace System.Threading;

[Token(Token = "0x20001D8")]
public sealed class AutoResetEvent : EventWaitHandle
{

	[Address(RVA = "0x7463424", Offset = "0x7463424", Length = "0xC")]
	[Token(Token = "0x6001243")]
	public AutoResetEvent(bool initialState) { }

}

