namespace System.Threading;

[Token(Token = "0x200020A")]
internal struct ExecutionContextSwitcher
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40009E6")]
	internal Reader outerEC; //Field offset: 0x0
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x40009E7")]
	internal bool outerECBelongsToScope; //Field offset: 0x8
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40009E8")]
	internal object hecsw; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40009E9")]
	internal Thread thread; //Field offset: 0x18

	[Address(RVA = "0x746B194", Offset = "0x746B194", Length = "0xB4")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::MayFail (1))]
	[Token(Token = "0x600131C")]
	internal void Undo() { }

	[Address(RVA = "0x746B10C", Offset = "0x746B10C", Length = "0x88")]
	[HandleProcessCorruptedStateExceptions]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::MayFail (1))]
	[Token(Token = "0x600131B")]
	internal bool UndoNoThrow() { }

}

