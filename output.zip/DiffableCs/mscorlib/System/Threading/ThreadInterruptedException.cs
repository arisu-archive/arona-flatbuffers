namespace System.Threading;

[ComVisible(True)]
[Token(Token = "0x200021B")]
public class ThreadInterruptedException : SystemException
{

	[Address(RVA = "0x746F4B4", Offset = "0x746F4B4", Length = "0x7C")]
	[Token(Token = "0x60013C9")]
	public ThreadInterruptedException() { }

	[Address(RVA = "0x746F530", Offset = "0x746F530", Length = "0x8")]
	[Token(Token = "0x60013CA")]
	protected ThreadInterruptedException(SerializationInfo info, StreamingContext context) { }

}

