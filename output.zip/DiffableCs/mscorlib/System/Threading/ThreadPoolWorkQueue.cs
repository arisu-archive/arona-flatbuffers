namespace System.Threading;

[Token(Token = "0x2000220")]
internal sealed class ThreadPoolWorkQueue
{
	[Token(Token = "0x2000223")]
	public class QueueSegment
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000A35")]
		internal readonly IThreadPoolWorkItem[] nodes; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000A36")]
		private int indexes; //Field offset: 0x18
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000A37")]
		public QueueSegment Next; //Field offset: 0x20

		[Address(RVA = "0x746F7BC", Offset = "0x746F7BC", Length = "0x64")]
		[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::MayFail (1))]
		[Token(Token = "0x60013E7")]
		public QueueSegment() { }

		[Address(RVA = "0x74714E4", Offset = "0x74714E4", Length = "0x6C")]
		[Token(Token = "0x60013E6")]
		private bool CompareExchangeIndexes(ref int prevUpper, int newUpper, ref int prevLower, int newLower) { }

		[Address(RVA = "0x74714B0", Offset = "0x74714B0", Length = "0x34")]
		[Token(Token = "0x60013E5")]
		private void GetIndexes(out int upper, out int lower) { }

		[Address(RVA = "0x7470BFC", Offset = "0x7470BFC", Length = "0x40")]
		[Token(Token = "0x60013E8")]
		public bool IsUsedUp() { }

		[Address(RVA = "0x7470AA8", Offset = "0x7470AA8", Length = "0x154")]
		[Token(Token = "0x60013EA")]
		public bool TryDequeue(out IThreadPoolWorkItem node) { }

		[Address(RVA = "0x747011C", Offset = "0x747011C", Length = "0xC0")]
		[Token(Token = "0x60013E9")]
		public bool TryEnqueue(IThreadPoolWorkItem node) { }

	}

	[Token(Token = "0x2000221")]
	public class SparseArray
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4000A2F")]
		private T[] m_array; //Field offset: 0x0

		[Token(Token = "0x1700020B")]
		internal T[] Current
		{
			[Address(RVA = "0x5F1BD78", Offset = "0x5F1BD78", Length = "0x18")]
			[Token(Token = "0x60013DC")]
			internal get { } //Length: 24
		}

		[Address(RVA = "0x5F1BD1C", Offset = "0x5F1BD1C", Length = "0x5C")]
		[Token(Token = "0x60013DB")]
		internal SparseArray`1(int initialSize) { }

		[Address(RVA = "0x5F1BD90", Offset = "0x5F1BD90", Length = "0x244")]
		[Token(Token = "0x60013DD")]
		internal int Add(T e) { }

		[Address(RVA = "0x5F1BD78", Offset = "0x5F1BD78", Length = "0x18")]
		[Token(Token = "0x60013DC")]
		internal T[] get_Current() { }

		[Address(RVA = "0x5F1BFD4", Offset = "0x5F1BFD4", Length = "0x174")]
		[Token(Token = "0x60013DE")]
		internal void Remove(T e) { }

	}

	[Token(Token = "0x2000222")]
	public class WorkStealingQueue
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000A30")]
		internal IThreadPoolWorkItem[] m_array; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000A31")]
		private int m_mask; //Field offset: 0x18
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4000A32")]
		private int m_headIndex; //Field offset: 0x1C
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4000A33")]
		private int m_tailIndex; //Field offset: 0x20
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x4000A34")]
		private SpinLock m_foreignLock; //Field offset: 0x24

		[Address(RVA = "0x7471410", Offset = "0x7471410", Length = "0xA0")]
		[Token(Token = "0x60013E4")]
		public WorkStealingQueue() { }

		[Address(RVA = "0x7470250", Offset = "0x7470250", Length = "0x354")]
		[Token(Token = "0x60013E0")]
		public bool LocalFindAndPop(IThreadPoolWorkItem obj) { }

		[Address(RVA = "0x747076C", Offset = "0x747076C", Length = "0x33C")]
		[Token(Token = "0x60013E1")]
		public bool LocalPop(out IThreadPoolWorkItem obj) { }

		[Address(RVA = "0x746FC00", Offset = "0x746FC00", Length = "0x51C")]
		[Token(Token = "0x60013DF")]
		public void LocalPush(IThreadPoolWorkItem obj) { }

		[Address(RVA = "0x7470C3C", Offset = "0x7470C3C", Length = "0x8")]
		[Token(Token = "0x60013E2")]
		public bool TrySteal(out IThreadPoolWorkItem obj, ref bool missedSteal) { }

		[Address(RVA = "0x7471130", Offset = "0x7471130", Length = "0x2E0")]
		[Token(Token = "0x60013E3")]
		private bool TrySteal(out IThreadPoolWorkItem obj, ref bool missedSteal, int millisecondsTimeout) { }

	}

	[Token(Token = "0x4000A2D")]
	internal static SparseArray<WorkStealingQueue> allThreadQueues; //Field offset: 0x0
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000A2B")]
	internal QueueSegment queueHead; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000A2C")]
	internal QueueSegment queueTail; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000A2E")]
	private int numOutstandingThreadRequests; //Field offset: 0x20

	[Address(RVA = "0x7471090", Offset = "0x7471090", Length = "0x9C")]
	[Token(Token = "0x60013DA")]
	private static ThreadPoolWorkQueue() { }

	[Address(RVA = "0x746F734", Offset = "0x746F734", Length = "0x88")]
	[Token(Token = "0x60013D2")]
	public ThreadPoolWorkQueue() { }

	[Address(RVA = "0x74705A4", Offset = "0x74705A4", Length = "0x1C8")]
	[Token(Token = "0x60013D8")]
	public void Dequeue(ThreadPoolWorkQueueThreadLocals tl, out IThreadPoolWorkItem callback, out bool missedSteal) { }

	[Address(RVA = "0x7470C44", Offset = "0x7470C44", Length = "0x448")]
	[Token(Token = "0x60013D9")]
	internal static bool Dispatch() { }

	[Address(RVA = "0x746FACC", Offset = "0x746FACC", Length = "0x134")]
	[Token(Token = "0x60013D6")]
	public void Enqueue(IThreadPoolWorkItem callback, bool forceGlobal) { }

	[Address(RVA = "0x746F820", Offset = "0x746F820", Length = "0x94")]
	[Token(Token = "0x60013D3")]
	public ThreadPoolWorkQueueThreadLocals EnsureCurrentThreadHasQueue() { }

	[Address(RVA = "0x746F9E4", Offset = "0x746F9E4", Length = "0x98")]
	[Token(Token = "0x60013D4")]
	internal void EnsureThreadRequested() { }

	[Address(RVA = "0x74701E0", Offset = "0x74701E0", Length = "0x70")]
	[Token(Token = "0x60013D7")]
	internal bool LocalFindAndPop(IThreadPoolWorkItem callback) { }

	[Address(RVA = "0x746FA84", Offset = "0x746FA84", Length = "0x48")]
	[Token(Token = "0x60013D5")]
	internal void MarkThreadRequestSatisfied() { }

}

