namespace System.Threading;

[Token(Token = "0x20001F5")]
internal struct CancellationCallbackCoreWorkArguments
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40009AA")]
	internal SparselyPopulatedArrayFragment<CancellationCallbackInfo> _currArrayFragment; //Field offset: 0x0
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x40009AB")]
	internal int _currArrayIndex; //Field offset: 0x8

	[Address(RVA = "0x7467170", Offset = "0x7467170", Length = "0x28")]
	[Token(Token = "0x60012C5")]
	public CancellationCallbackCoreWorkArguments(SparselyPopulatedArrayFragment<CancellationCallbackInfo> currArrayFragment, int currArrayIndex) { }

}

