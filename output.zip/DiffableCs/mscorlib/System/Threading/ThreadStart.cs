namespace System.Threading;

[Token(Token = "0x20001E3")]
public sealed class ThreadStart : MulticastDelegate
{

	[Address(RVA = "0x7463988", Offset = "0x7463988", Length = "0xD0")]
	[Token(Token = "0x600125A")]
	public ThreadStart(object object, IntPtr method) { }

	[Address(RVA = "0x7463A58", Offset = "0x7463A58", Length = "0x14")]
	[Token(Token = "0x600125B")]
	public override void Invoke() { }

}

