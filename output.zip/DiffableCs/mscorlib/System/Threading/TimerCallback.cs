namespace System.Threading;

[ComVisible(True)]
[Token(Token = "0x2000234")]
public sealed class TimerCallback : MulticastDelegate
{

	[Address(RVA = "0x7475CB0", Offset = "0x7475CB0", Length = "0x140")]
	[Token(Token = "0x600146E")]
	public TimerCallback(object object, IntPtr method) { }

	[Address(RVA = "0x7475DF0", Offset = "0x7475DF0", Length = "0x14")]
	[Token(Token = "0x600146F")]
	public override void Invoke(object state) { }

}

