namespace System.Threading;

[Token(Token = "0x200022A")]
public static class Interlocked
{

	[Address(RVA = "0x7473388", Offset = "0x7473388", Length = "0x4")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001436")]
	public static long Add(ref long location1, long value) { }

	[Address(RVA = "0x7473384", Offset = "0x7473384", Length = "0x4")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001435")]
	public static int Add(ref int location1, int value) { }

	[Address(RVA = "0x746FA7C", Offset = "0x746FA7C", Length = "0x4")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x600141F")]
	public static int CompareExchange(ref int location1, int value, int comparand) { }

	[Address(RVA = "0x747336C", Offset = "0x747336C", Length = "0x4")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x600142D")]
	public static IntPtr CompareExchange(ref IntPtr location1, IntPtr value, IntPtr comparand) { }

	[Address(RVA = "0x7473368", Offset = "0x7473368", Length = "0x4")]
	[Token(Token = "0x600142C")]
	public static long CompareExchange(ref long location1, long value, long comparand) { }

	[Address(RVA = "0x7473370", Offset = "0x7473370", Length = "0x4")]
	[Token(Token = "0x600142E")]
	public static double CompareExchange(ref double location1, double value, double comparand) { }

	[ComVisible(False)]
	[Intrinsic]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x600142F")]
	public static T CompareExchange(ref T location1, T value, T comparand) { }

	[Address(RVA = "0x7473328", Offset = "0x7473328", Length = "0x4")]
	[Token(Token = "0x6001423")]
	public static float CompareExchange(ref float location1, float value, float comparand) { }

	[Address(RVA = "0x74732FC", Offset = "0x74732FC", Length = "0x2C")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001422")]
	public static object CompareExchange(ref object location1, object value, object comparand) { }

	[Address(RVA = "0x74732F8", Offset = "0x74732F8", Length = "0x4")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001421")]
	private static void CompareExchange(ref object location1, ref object value, ref object comparand, ref object result) { }

	[Address(RVA = "0x74732F4", Offset = "0x74732F4", Length = "0x4")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001420")]
	internal static int CompareExchange(ref int location1, int value, int comparand, ref bool succeeded) { }

	[Address(RVA = "0x747332C", Offset = "0x747332C", Length = "0x4")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001424")]
	public static int Decrement(ref int location) { }

	[Address(RVA = "0x7473330", Offset = "0x7473330", Length = "0x4")]
	[Token(Token = "0x6001425")]
	public static long Decrement(ref long location) { }

	[Address(RVA = "0x747337C", Offset = "0x747337C", Length = "0x4")]
	[Token(Token = "0x6001432")]
	public static double Exchange(ref double location1, double value) { }

	[Address(RVA = "0x7473378", Offset = "0x7473378", Length = "0x4")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001431")]
	public static IntPtr Exchange(ref IntPtr location1, IntPtr value) { }

	[Address(RVA = "0x7473374", Offset = "0x7473374", Length = "0x4")]
	[Token(Token = "0x6001430")]
	public static long Exchange(ref long location1, long value) { }

	[ComVisible(False)]
	[Intrinsic]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001433")]
	public static T Exchange(ref T location1, T value) { }

	[Address(RVA = "0x7473364", Offset = "0x7473364", Length = "0x4")]
	[Token(Token = "0x600142B")]
	public static float Exchange(ref float location1, float value) { }

	[Address(RVA = "0x747333C", Offset = "0x747333C", Length = "0x4")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001429")]
	private static void Exchange(ref object location1, ref object value, ref object result) { }

	[Address(RVA = "0x747112C", Offset = "0x747112C", Length = "0x4")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001428")]
	public static int Exchange(ref int location1, int value) { }

	[Address(RVA = "0x7473340", Offset = "0x7473340", Length = "0x24")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x600142A")]
	public static object Exchange(ref object location1, object value) { }

	[Address(RVA = "0x7473338", Offset = "0x7473338", Length = "0x4")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001427")]
	public static long Increment(ref long location) { }

	[Address(RVA = "0x7473334", Offset = "0x7473334", Length = "0x4")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001426")]
	public static int Increment(ref int location) { }

	[Address(RVA = "0x747338C", Offset = "0x747338C", Length = "0x4")]
	[Token(Token = "0x6001437")]
	public static void MemoryBarrier() { }

	[Address(RVA = "0x7473380", Offset = "0x7473380", Length = "0x4")]
	[Token(Token = "0x6001434")]
	public static long Read(ref long location) { }

}

