namespace System.Threading;

[Token(Token = "0x2000218")]
public sealed class Thread : CriticalFinalizerObject
{
	[ThreadStatic]
	[Token(Token = "0x4000A14")]
	private static LocalDataStoreHolder s_LocalDataStore; //Field offset: 0x80000000
	[ThreadStatic]
	[Token(Token = "0x4000A15")]
	internal static CultureInfo m_CurrentCulture; //Field offset: 0x80000008
	[ThreadStatic]
	[Token(Token = "0x4000A16")]
	internal static CultureInfo m_CurrentUICulture; //Field offset: 0x80000010
	[ThreadStatic]
	[Token(Token = "0x4000A1C")]
	private static Thread current_thread; //Field offset: 0x80000018
	[Token(Token = "0x4000A13")]
	private static LocalDataStoreMgr s_LocalDataStoreMgr; //Field offset: 0x0
	[Token(Token = "0x4000A17")]
	private static AsyncLocal<CultureInfo> s_asyncLocalCurrentCulture; //Field offset: 0x8
	[Token(Token = "0x4000A18")]
	private static AsyncLocal<CultureInfo> s_asyncLocalCurrentUICulture; //Field offset: 0x10
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000A19")]
	private InternalThread internal_thread; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000A1A")]
	private object m_ThreadStartArg; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4000A1B")]
	private object pending_exception; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4000A1D")]
	private MulticastDelegate m_Delegate; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4000A1E")]
	private ExecutionContext m_ExecutionContext; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4000A1F")]
	private bool m_ExecutionContextBelongsToOuterScope; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4000A20")]
	private IPrincipal principal; //Field offset: 0x40
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4000A21")]
	private int principal_version; //Field offset: 0x48

	[Token(Token = "0x17000203")]
	public static Context CurrentContext
	{
		[Address(RVA = "0x746F120", Offset = "0x746F120", Length = "0x8")]
		[Token(Token = "0x60013A7")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000201")]
	public CultureInfo CurrentCulture
	{
		[Address(RVA = "0x746ED64", Offset = "0x746ED64", Length = "0x2C")]
		[Token(Token = "0x60013A0")]
		 get { } //Length: 44
		[Address(RVA = "0x746EE3C", Offset = "0x746EE3C", Length = "0x1FC")]
		[Token(Token = "0x60013A1")]
		 set { } //Length: 508
	}

	[Token(Token = "0x17000204")]
	public static Thread CurrentThread
	{
		[Address(RVA = "0x746D6A4", Offset = "0x746D6A4", Length = "0x5C")]
		[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::MayFail (1))]
		[Token(Token = "0x60013AA")]
		 get { } //Length: 92
	}

	[Token(Token = "0x17000205")]
	internal static int CurrentThreadId
	{
		[Address(RVA = "0x746F144", Offset = "0x746F144", Length = "0x24")]
		[Token(Token = "0x60013AB")]
		internal get { } //Length: 36
	}

	[Token(Token = "0x17000200")]
	public CultureInfo CurrentUICulture
	{
		[Address(RVA = "0x746EC8C", Offset = "0x746EC8C", Length = "0x2C")]
		[Token(Token = "0x600139E")]
		 get { } //Length: 44
	}

	[Token(Token = "0x170001FE")]
	internal bool ExecutionContextBelongsToCurrentScope
	{
		[Address(RVA = "0x746EA80", Offset = "0x746EA80", Length = "0x10")]
		[Token(Token = "0x6001390")]
		internal get { } //Length: 16
		[Address(RVA = "0x746EA90", Offset = "0x746EA90", Length = "0xC")]
		[Token(Token = "0x6001391")]
		internal set { } //Length: 12
	}

	[Token(Token = "0x17000202")]
	private InternalThread Internal
	{
		[Address(RVA = "0x746F0FC", Offset = "0x746F0FC", Length = "0x24")]
		[Token(Token = "0x60013A6")]
		private get { } //Length: 36
	}

	[Token(Token = "0x17000208")]
	public bool IsBackground
	{
		[Address(RVA = "0x746F1A8", Offset = "0x746F1A8", Length = "0x5C")]
		[Token(Token = "0x60013B1")]
		 set { } //Length: 92
	}

	[Token(Token = "0x17000206")]
	public bool IsThreadPoolThread
	{
		[Address(RVA = "0x746F178", Offset = "0x746F178", Length = "0x4")]
		[Token(Token = "0x60013AF")]
		 get { } //Length: 4
	}

	[Token(Token = "0x17000207")]
	internal bool IsThreadPoolThreadInternal
	{
		[Address(RVA = "0x746F17C", Offset = "0x746F17C", Length = "0x2C")]
		[Token(Token = "0x60013B0")]
		internal get { } //Length: 44
	}

	[Token(Token = "0x1700020A")]
	public int ManagedThreadId
	{
		[Address(RVA = "0x746F360", Offset = "0x746F360", Length = "0x2C")]
		[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
		[Token(Token = "0x60013C2")]
		 get { } //Length: 44
	}

	[Token(Token = "0x17000209")]
	public string Name
	{
		[Address(RVA = "0x746F2C4", Offset = "0x746F2C4", Length = "0x34")]
		[Token(Token = "0x60013B4")]
		 set { } //Length: 52
	}

	[Token(Token = "0x170001FF")]
	public ThreadPriority Priority
	{
		[Address(RVA = "0x746EAFC", Offset = "0x746EAFC", Length = "0x4")]
		[Token(Token = "0x6001395")]
		 get { } //Length: 4
		[Address(RVA = "0x746EB04", Offset = "0x746EB04", Length = "0x4")]
		[Token(Token = "0x6001396")]
		 set { } //Length: 4
	}

	[Address(RVA = "0x746E510", Offset = "0x746E510", Length = "0x80")]
	[Token(Token = "0x6001389")]
	public Thread(ThreadStart start) { }

	[Address(RVA = "0x746E6C8", Offset = "0x746E6C8", Length = "0x80")]
	[Token(Token = "0x600138A")]
	public Thread(ParameterizedThreadStart start) { }

	[Address(RVA = "0x746E748", Offset = "0x746E748", Length = "0xF0")]
	[Token(Token = "0x600138B")]
	public Thread(ParameterizedThreadStart start, int maxStackSize) { }

	[Address(RVA = "0x746F2FC", Offset = "0x746F2FC", Length = "0x28")]
	[Token(Token = "0x60013B6")]
	public void Abort() { }

	[Address(RVA = "0x746F2F8", Offset = "0x746F2F8", Length = "0x4")]
	[Token(Token = "0x60013B5")]
	private static void Abort_internal(InternalThread thread, object stateInfo) { }

	[Address(RVA = "0x746E4A0", Offset = "0x746E4A0", Length = "0x70")]
	[Token(Token = "0x6001388")]
	private static void AsyncLocalSetCurrentCulture(AsyncLocalValueChangedArgs<CultureInfo> args) { }

	[Address(RVA = "0x746F38C", Offset = "0x746F38C", Length = "0x50")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::MayFail (1))]
	[Token(Token = "0x60013C3")]
	public static void BeginCriticalRegion() { }

	[Address(RVA = "0x746F280", Offset = "0x746F280", Length = "0x4")]
	[Token(Token = "0x60013BB")]
	private static void ClrState(InternalThread thread, ThreadState clr) { }

	[Address(RVA = "0x746F0F8", Offset = "0x746F0F8", Length = "0x4")]
	[Token(Token = "0x60013A5")]
	private void ConstructInternalThread() { }

	[Address(RVA = "0x746F3DC", Offset = "0x746F3DC", Length = "0x50")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x60013C4")]
	public static void EndCriticalRegion() { }

	[Address(RVA = "0x746F170", Offset = "0x746F170", Length = "0x8")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x60013AE")]
	protected virtual void Finalize() { }

	[Address(RVA = "0x746F120", Offset = "0x746F120", Length = "0x8")]
	[Token(Token = "0x60013A7")]
	public static Context get_CurrentContext() { }

	[Address(RVA = "0x746ED64", Offset = "0x746ED64", Length = "0x2C")]
	[Token(Token = "0x60013A0")]
	public CultureInfo get_CurrentCulture() { }

	[Address(RVA = "0x746D6A4", Offset = "0x746D6A4", Length = "0x5C")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::MayFail (1))]
	[Token(Token = "0x60013AA")]
	public static Thread get_CurrentThread() { }

	[Address(RVA = "0x746F144", Offset = "0x746F144", Length = "0x24")]
	[Token(Token = "0x60013AB")]
	internal static int get_CurrentThreadId() { }

	[Address(RVA = "0x746EC8C", Offset = "0x746EC8C", Length = "0x2C")]
	[Token(Token = "0x600139E")]
	public CultureInfo get_CurrentUICulture() { }

	[Address(RVA = "0x746EA80", Offset = "0x746EA80", Length = "0x10")]
	[Token(Token = "0x6001390")]
	internal bool get_ExecutionContextBelongsToCurrentScope() { }

	[Address(RVA = "0x746F0FC", Offset = "0x746F0FC", Length = "0x24")]
	[Token(Token = "0x60013A6")]
	private InternalThread get_Internal() { }

	[Address(RVA = "0x746F178", Offset = "0x746F178", Length = "0x4")]
	[Token(Token = "0x60013AF")]
	public bool get_IsThreadPoolThread() { }

	[Address(RVA = "0x746F17C", Offset = "0x746F17C", Length = "0x2C")]
	[Token(Token = "0x60013B0")]
	internal bool get_IsThreadPoolThreadInternal() { }

	[Address(RVA = "0x746F360", Offset = "0x746F360", Length = "0x2C")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x60013C2")]
	public int get_ManagedThreadId() { }

	[Address(RVA = "0x746EAFC", Offset = "0x746EAFC", Length = "0x4")]
	[Token(Token = "0x6001395")]
	public ThreadPriority get_Priority() { }

	[Address(RVA = "0x746ED90", Offset = "0x746ED90", Length = "0xAC")]
	[Token(Token = "0x60013A2")]
	private CultureInfo GetCurrentCultureNoAppX() { }

	[Address(RVA = "0x746F12C", Offset = "0x746F12C", Length = "0x18")]
	[Token(Token = "0x60013A9")]
	private static Thread GetCurrentThread() { }

	[Address(RVA = "0x746F128", Offset = "0x746F128", Length = "0x4")]
	[Token(Token = "0x60013A8")]
	private static void GetCurrentThread_icall(ref Thread thread) { }

	[Address(RVA = "0x746ECB8", Offset = "0x746ECB8", Length = "0xAC")]
	[Token(Token = "0x600139F")]
	internal CultureInfo GetCurrentUICultureNoAppX() { }

	[Address(RVA = "0x746F168", Offset = "0x746F168", Length = "0x4")]
	[Token(Token = "0x60013AC")]
	public static int GetDomainID() { }

	[Address(RVA = "0x746D7DC", Offset = "0x746D7DC", Length = "0x1C")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x600138F")]
	internal Reader GetExecutionContextReader() { }

	[Address(RVA = "0x746F42C", Offset = "0x746F42C", Length = "0x4")]
	[ComVisible(False)]
	[Token(Token = "0x60013C5")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x746D700", Offset = "0x746D700", Length = "0xA0")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::MayFail (1))]
	[Token(Token = "0x6001392")]
	internal ExecutionContext GetMutableExecutionContext() { }

	[Address(RVA = "0x746EB00", Offset = "0x746EB00", Length = "0x4")]
	[Token(Token = "0x6001397")]
	private int GetPriorityNative() { }

	[Address(RVA = "0x746EB94", Offset = "0x746EB94", Length = "0xAC")]
	[Token(Token = "0x60013C0")]
	private static int GetProcessDefaultStackSize(int maxStackSize) { }

	[Address(RVA = "0x746F350", Offset = "0x746F350", Length = "0x4")]
	[Token(Token = "0x60013BC")]
	private static ThreadState GetState(InternalThread thread) { }

	[Address(RVA = "0x746F0F4", Offset = "0x746F0F4", Length = "0x4")]
	[Token(Token = "0x60013A4")]
	public static void MemoryBarrier() { }

	[Address(RVA = "0x746F038", Offset = "0x746F038", Length = "0xBC")]
	[Token(Token = "0x60013A3")]
	private static void nativeInitCultureAccessors() { }

	[Address(RVA = "0x746EE3C", Offset = "0x746EE3C", Length = "0x1FC")]
	[Token(Token = "0x60013A1")]
	public void set_CurrentCulture(CultureInfo value) { }

	[Address(RVA = "0x746EA90", Offset = "0x746EA90", Length = "0xC")]
	[Token(Token = "0x6001391")]
	internal void set_ExecutionContextBelongsToCurrentScope(bool value) { }

	[Address(RVA = "0x746F1A8", Offset = "0x746F1A8", Length = "0x5C")]
	[Token(Token = "0x60013B1")]
	public void set_IsBackground(bool value) { }

	[Address(RVA = "0x746F2C4", Offset = "0x746F2C4", Length = "0x34")]
	[Token(Token = "0x60013B4")]
	public void set_Name(string value) { }

	[Address(RVA = "0x746EB04", Offset = "0x746EB04", Length = "0x4")]
	[Token(Token = "0x6001396")]
	public void set_Priority(ThreadPriority value) { }

	[Address(RVA = "0x746EACC", Offset = "0x746EACC", Length = "0x30")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001394")]
	internal void SetExecutionContext(Reader value, bool belongsToCurrentScope) { }

	[Address(RVA = "0x746EA9C", Offset = "0x746EA9C", Length = "0x30")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6001393")]
	internal void SetExecutionContext(ExecutionContext value, bool belongsToCurrentScope) { }

	[Address(RVA = "0x746F284", Offset = "0x746F284", Length = "0x4")]
	[Token(Token = "0x60013B2")]
	private static void SetName_icall(InternalThread thread, Char* name, int nameLength) { }

	[Address(RVA = "0x746F288", Offset = "0x746F288", Length = "0x3C")]
	[Token(Token = "0x60013B3")]
	private static void SetName_internal(InternalThread thread, string name) { }

	[Address(RVA = "0x746EB08", Offset = "0x746EB08", Length = "0x4")]
	[Token(Token = "0x6001398")]
	private void SetPriorityNative(int priority) { }

	[Address(RVA = "0x746EC40", Offset = "0x746EC40", Length = "0x4C")]
	[Token(Token = "0x60013C1")]
	private void SetStart(MulticastDelegate start, int maxStackSize) { }

	[Address(RVA = "0x746E590", Offset = "0x746E590", Length = "0x138")]
	[Token(Token = "0x600139D")]
	private void SetStartHelper(Delegate start, int maxStackSize) { }

	[Address(RVA = "0x746F27C", Offset = "0x746F27C", Length = "0x4")]
	[Token(Token = "0x60013BA")]
	private static void SetState(InternalThread thread, ThreadState set) { }

	[Address(RVA = "0x746EB10", Offset = "0x746EB10", Length = "0x7C")]
	[Token(Token = "0x600139A")]
	public static void Sleep(int millisecondsTimeout) { }

	[Address(RVA = "0x746EB0C", Offset = "0x746EB0C", Length = "0x4")]
	[Token(Token = "0x6001399")]
	private static void SleepInternal(int millisecondsTimeout) { }

	[Address(RVA = "0x746F328", Offset = "0x746F328", Length = "0x28")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x60013B8")]
	public static void SpinWait(int iterations) { }

	[Address(RVA = "0x746F324", Offset = "0x746F324", Length = "0x4")]
	[Token(Token = "0x60013B7")]
	private static void SpinWait_nop() { }

	[Address(RVA = "0x746E92C", Offset = "0x746E92C", Length = "0xE0")]
	[Token(Token = "0x600138D")]
	public void Start(object parameter) { }

	[Address(RVA = "0x746E854", Offset = "0x746E854", Length = "0xD8")]
	[Token(Token = "0x600138E")]
	private void Start(ref StackCrawlMark stackMark) { }

	[Address(RVA = "0x746E838", Offset = "0x746E838", Length = "0x1C")]
	[Token(Token = "0x600138C")]
	public void Start() { }

	[Address(RVA = "0x746EA0C", Offset = "0x746EA0C", Length = "0x74")]
	[Token(Token = "0x60013B9")]
	private void StartInternal(object principal, ref StackCrawlMark stackMark) { }

	[Address(RVA = "0x746F35C", Offset = "0x746F35C", Length = "0x4")]
	[Token(Token = "0x60013BF")]
	private static int SystemMaxStackStize() { }

	[Address(RVA = "0x746F16C", Offset = "0x746F16C", Length = "0x4")]
	[Token(Token = "0x60013AD")]
	private bool Thread_internal(MulticastDelegate start) { }

	[Address(RVA = "0x746F204", Offset = "0x746F204", Length = "0x78")]
	[Token(Token = "0x60013C6")]
	private ThreadState ValidateThreadState() { }

	[Address(RVA = "0x746F354", Offset = "0x746F354", Length = "0x4")]
	[Token(Token = "0x60013BD")]
	public static object VolatileRead(ref object address) { }

	[Address(RVA = "0x746F358", Offset = "0x746F358", Length = "0x4")]
	[Token(Token = "0x60013BE")]
	public static void VolatileWrite(ref int address, int value) { }

	[Address(RVA = "0x746EB90", Offset = "0x746EB90", Length = "0x4")]
	[Token(Token = "0x600139C")]
	public static bool Yield() { }

	[Address(RVA = "0x746EB8C", Offset = "0x746EB8C", Length = "0x4")]
	[Token(Token = "0x600139B")]
	private static bool YieldInternal() { }

}

