namespace System.Threading;

[Token(Token = "0x20001ED")]
internal static class PlatformHelper
{
	[Token(Token = "0x4000990")]
	private static int s_processorCount; //Field offset: 0x0
	[Token(Token = "0x4000991")]
	private static int s_lastProcessorCountRefreshTicks; //Field offset: 0x4
	[Token(Token = "0x4000992")]
	internal static readonly bool IsSingleProcessor; //Field offset: 0x8

	[Token(Token = "0x170001DD")]
	internal static int ProcessorCount
	{
		[Address(RVA = "0x7466084", Offset = "0x7466084", Length = "0xEC")]
		[Token(Token = "0x6001297")]
		internal get { } //Length: 236
	}

	[Address(RVA = "0x7466170", Offset = "0x7466170", Length = "0x54")]
	[Token(Token = "0x6001298")]
	private static PlatformHelper() { }

	[Address(RVA = "0x7466084", Offset = "0x7466084", Length = "0xEC")]
	[Token(Token = "0x6001297")]
	internal static int get_ProcessorCount() { }

}

