namespace System.Threading;

[Token(Token = "0x20001EB")]
public struct NativeOverlapped
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000989")]
	public IntPtr InternalLow; //Field offset: 0x0
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x400098A")]
	public IntPtr InternalHigh; //Field offset: 0x8
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x400098B")]
	public int OffsetLow; //Field offset: 0x10
	[FieldOffset(Offset = "0x14")]
	[Token(Token = "0x400098C")]
	public int OffsetHigh; //Field offset: 0x14
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400098D")]
	public IntPtr EventHandle; //Field offset: 0x18

}

