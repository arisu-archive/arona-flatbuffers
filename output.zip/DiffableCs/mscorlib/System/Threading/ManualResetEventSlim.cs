namespace System.Threading;

[DebuggerDisplay("Set = {IsSet}")]
[Token(Token = "0x20001EA")]
public class ManualResetEventSlim : IDisposable
{
	[Token(Token = "0x400097B")]
	private const int DEFAULT_SPIN_SP = 1; //Field offset: 0x0
	[Token(Token = "0x400097F")]
	private const int SignalledState_BitMask = -2147483648; //Field offset: 0x0
	[Token(Token = "0x4000980")]
	private const int SignalledState_ShiftCount = 31; //Field offset: 0x0
	[Token(Token = "0x4000981")]
	private const int Dispose_BitMask = 1073741824; //Field offset: 0x0
	[Token(Token = "0x4000982")]
	private const int SpinCountState_BitMask = 1073217536; //Field offset: 0x0
	[Token(Token = "0x4000983")]
	private const int SpinCountState_ShiftCount = 19; //Field offset: 0x0
	[Token(Token = "0x4000984")]
	private const int SpinCountState_MaxValue = 2047; //Field offset: 0x0
	[Token(Token = "0x4000985")]
	private const int NumWaitersState_BitMask = 524287; //Field offset: 0x0
	[Token(Token = "0x4000986")]
	private const int NumWaitersState_ShiftCount = 0; //Field offset: 0x0
	[Token(Token = "0x4000987")]
	private const int NumWaitersState_MaxValue = 524287; //Field offset: 0x0
	[Token(Token = "0x4000988")]
	private static Action<Object> s_cancellationTokenCallback; //Field offset: 0x0
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x400097C")]
	private object m_lock; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400097D")]
	private ManualResetEvent m_eventObj; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400097E")]
	private int m_combinedState; //Field offset: 0x20

	[Token(Token = "0x170001D8")]
	public private bool IsSet
	{
		[Address(RVA = "0x7464BF4", Offset = "0x7464BF4", Length = "0x5C")]
		[Token(Token = "0x600127A")]
		 get { } //Length: 92
		[Address(RVA = "0x7464C58", Offset = "0x7464C58", Length = "0x20")]
		[Token(Token = "0x600127B")]
		private set { } //Length: 32
	}

	[Token(Token = "0x170001D9")]
	public private int SpinCount
	{
		[Address(RVA = "0x7464D50", Offset = "0x7464D50", Length = "0x5C")]
		[Token(Token = "0x600127C")]
		 get { } //Length: 92
		[Address(RVA = "0x7464DB8", Offset = "0x7464DB8", Length = "0x34")]
		[Token(Token = "0x600127D")]
		private set { } //Length: 52
	}

	[Token(Token = "0x170001DA")]
	private int Waiters
	{
		[Address(RVA = "0x7464DEC", Offset = "0x7464DEC", Length = "0x5C")]
		[Token(Token = "0x600127E")]
		private get { } //Length: 92
		[Address(RVA = "0x7464E48", Offset = "0x7464E48", Length = "0x94")]
		[Token(Token = "0x600127F")]
		private set { } //Length: 148
	}

	[Token(Token = "0x170001D7")]
	public WaitHandle WaitHandle
	{
		[Address(RVA = "0x74649DC", Offset = "0x74649DC", Length = "0x3C")]
		[Token(Token = "0x6001279")]
		 get { } //Length: 60
	}

	[Address(RVA = "0x7465D34", Offset = "0x7465D34", Length = "0xA0")]
	[Token(Token = "0x600128F")]
	private static ManualResetEventSlim() { }

	[Address(RVA = "0x7464EDC", Offset = "0x7464EDC", Length = "0x7C")]
	[Token(Token = "0x6001280")]
	public ManualResetEventSlim(bool initialState) { }

	[Address(RVA = "0x7465008", Offset = "0x7465008", Length = "0x120")]
	[Token(Token = "0x6001281")]
	public ManualResetEventSlim(bool initialState, int spinCount) { }

	[Address(RVA = "0x7465BB8", Offset = "0x7465BB8", Length = "0x124")]
	[Token(Token = "0x600128B")]
	private static void CancellationTokenCallback(object obj) { }

	[Address(RVA = "0x7465AB8", Offset = "0x7465AB8", Length = "0x100")]
	[Token(Token = "0x6001289")]
	protected override void Dispose(bool disposing) { }

	[Address(RVA = "0x7465A4C", Offset = "0x7465A4C", Length = "0x6C")]
	[Token(Token = "0x6001288")]
	public override void Dispose() { }

	[Address(RVA = "0x7465128", Offset = "0x7465128", Length = "0x88")]
	[Token(Token = "0x6001283")]
	private void EnsureLockObjectCreated() { }

	[Address(RVA = "0x7464C50", Offset = "0x7464C50", Length = "0x8")]
	[Token(Token = "0x600128E")]
	private static int ExtractStatePortion(int state, int mask) { }

	[Address(RVA = "0x7464DAC", Offset = "0x7464DAC", Length = "0xC")]
	[Token(Token = "0x600128D")]
	private static int ExtractStatePortionAndShiftRight(int state, int mask, int rightBitShiftCount) { }

	[Address(RVA = "0x7464BF4", Offset = "0x7464BF4", Length = "0x5C")]
	[Token(Token = "0x600127A")]
	public bool get_IsSet() { }

	[Address(RVA = "0x7464D50", Offset = "0x7464D50", Length = "0x5C")]
	[Token(Token = "0x600127C")]
	public int get_SpinCount() { }

	[Address(RVA = "0x7464DEC", Offset = "0x7464DEC", Length = "0x5C")]
	[Token(Token = "0x600127E")]
	private int get_Waiters() { }

	[Address(RVA = "0x74649DC", Offset = "0x74649DC", Length = "0x3C")]
	[Token(Token = "0x6001279")]
	public WaitHandle get_WaitHandle() { }

	[Address(RVA = "0x7464F58", Offset = "0x7464F58", Length = "0xB0")]
	[Token(Token = "0x6001282")]
	private void Initialize(bool initialState, int spinCount) { }

	[Address(RVA = "0x7464A7C", Offset = "0x7464A7C", Length = "0x178")]
	[Token(Token = "0x6001284")]
	private bool LazyInitializeEvent() { }

	[Address(RVA = "0x746521C", Offset = "0x746521C", Length = "0x1B8")]
	[Token(Token = "0x6001286")]
	private void Set(bool duringCancellation) { }

	[Address(RVA = "0x7465214", Offset = "0x7465214", Length = "0x8")]
	[Token(Token = "0x6001285")]
	public void Set() { }

	[Address(RVA = "0x7464C58", Offset = "0x7464C58", Length = "0x20")]
	[Token(Token = "0x600127B")]
	private void set_IsSet(bool value) { }

	[Address(RVA = "0x7464DB8", Offset = "0x7464DB8", Length = "0x34")]
	[Token(Token = "0x600127D")]
	private void set_SpinCount(int value) { }

	[Address(RVA = "0x7464E48", Offset = "0x7464E48", Length = "0x94")]
	[Token(Token = "0x600127F")]
	private void set_Waiters(int value) { }

	[Address(RVA = "0x7464A18", Offset = "0x7464A18", Length = "0x64")]
	[Token(Token = "0x600128A")]
	private void ThrowIfDisposed() { }

	[Address(RVA = "0x7464C78", Offset = "0x7464C78", Length = "0xD8")]
	[Token(Token = "0x600128C")]
	private void UpdateStateAtomically(int newBits, int updateBitsMask) { }

	[Address(RVA = "0x74653D4", Offset = "0x74653D4", Length = "0x538")]
	[Token(Token = "0x6001287")]
	public bool Wait(int millisecondsTimeout, CancellationToken cancellationToken) { }

}

