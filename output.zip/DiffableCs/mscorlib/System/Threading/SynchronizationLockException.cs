namespace System.Threading;

[Token(Token = "0x20001E1")]
public class SynchronizationLockException : SystemException
{

	[Address(RVA = "0x7463900", Offset = "0x7463900", Length = "0x5C")]
	[Token(Token = "0x6001257")]
	public SynchronizationLockException() { }

	[Address(RVA = "0x746395C", Offset = "0x746395C", Length = "0x24")]
	[Token(Token = "0x6001258")]
	public SynchronizationLockException(string message) { }

	[Address(RVA = "0x7463980", Offset = "0x7463980", Length = "0x8")]
	[Token(Token = "0x6001259")]
	protected SynchronizationLockException(SerializationInfo info, StreamingContext context) { }

}

