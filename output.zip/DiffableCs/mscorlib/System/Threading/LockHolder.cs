namespace System.Threading;

[ReflectionBlocked]
[Token(Token = "0x20001FB")]
public struct LockHolder : IDisposable
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40009BA")]
	private Lock _lock; //Field offset: 0x0

	[Address(RVA = "0x74682D0", Offset = "0x74682D0", Length = "0x20")]
	[Token(Token = "0x60012D7")]
	public override void Dispose() { }

	[Address(RVA = "0x7468284", Offset = "0x7468284", Length = "0x40")]
	[Token(Token = "0x60012D6")]
	public static LockHolder Hold(Lock l) { }

}

