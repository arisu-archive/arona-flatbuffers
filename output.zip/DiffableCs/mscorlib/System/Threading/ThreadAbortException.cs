namespace System.Threading;

[ComVisible(True)]
[Token(Token = "0x200021A")]
public sealed class ThreadAbortException : SystemException
{

	[Address(RVA = "0x746F430", Offset = "0x746F430", Length = "0x7C")]
	[Token(Token = "0x60013C7")]
	private ThreadAbortException() { }

	[Address(RVA = "0x746F4AC", Offset = "0x746F4AC", Length = "0x8")]
	[Token(Token = "0x60013C8")]
	internal ThreadAbortException(SerializationInfo info, StreamingContext context) { }

}

