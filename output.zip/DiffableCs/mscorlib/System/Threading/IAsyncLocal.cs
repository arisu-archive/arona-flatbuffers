namespace System.Threading;

[Token(Token = "0x20001D6")]
internal interface IAsyncLocal
{

	[Token(Token = "0x6001240")]
	public void OnValueChanged(object previousValue, object currentValue, bool contextChanged) { }

}

