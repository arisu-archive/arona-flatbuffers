namespace System.Threading;

[Token(Token = "0x2000213")]
internal class OSSpecificSynchronizationContext : SynchronizationContext
{
	[CompilerGenerated]
	[Token(Token = "0x2000216")]
	private sealed class <>c
	{
		[Token(Token = "0x4000A0D")]
		public static readonly <>c <>9; //Field offset: 0x0
		[Token(Token = "0x4000A0E")]
		public static CreateValueCallback<Object, OSSpecificSynchronizationContext> <>9__3_0; //Field offset: 0x8

		[Address(RVA = "0x746DFD8", Offset = "0x746DFD8", Length = "0x70")]
		[Token(Token = "0x600137F")]
		private static <>c() { }

		[Address(RVA = "0x746E048", Offset = "0x746E048", Length = "0x8")]
		[Token(Token = "0x6001380")]
		public <>c() { }

		[Address(RVA = "0x746E050", Offset = "0x746E050", Length = "0x70")]
		[Token(Token = "0x6001381")]
		internal OSSpecificSynchronizationContext <Get>b__3_0(object _osContext) { }

	}

	[Token(Token = "0x2000215")]
	private class InvocationContext
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4000A0B")]
		private SendOrPostCallback m_Delegate; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4000A0C")]
		private object m_State; //Field offset: 0x18

		[Address(RVA = "0x746DEBC", Offset = "0x746DEBC", Length = "0x44")]
		[Token(Token = "0x600137D")]
		public InvocationContext(SendOrPostCallback d, object state) { }

		[Address(RVA = "0x746DF04", Offset = "0x746DF04", Length = "0x28")]
		[Token(Token = "0x600137E")]
		public void Invoke() { }

	}

	[Token(Token = "0x2000214")]
	private sealed class InvocationEntryDelegate : MulticastDelegate
	{

		[Address(RVA = "0x746DDE4", Offset = "0x746DDE4", Length = "0xD8")]
		[Token(Token = "0x600137B")]
		public InvocationEntryDelegate(object object, IntPtr method) { }

		[Address(RVA = "0x746DFC4", Offset = "0x746DFC4", Length = "0x14")]
		[Token(Token = "0x600137C")]
		public override void Invoke(IntPtr arg) { }

	}

	[Token(Token = "0x4000A0A")]
	private static readonly ConditionalWeakTable<Object, OSSpecificSynchronizationContext> s_ContextCache; //Field offset: 0x0
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4000A09")]
	private object m_OSSynchronizationContext; //Field offset: 0x18

	[Address(RVA = "0x746DF2C", Offset = "0x746DF2C", Length = "0x98")]
	[Token(Token = "0x600137A")]
	private static OSSpecificSynchronizationContext() { }

	[Address(RVA = "0x746DBA8", Offset = "0x746DBA8", Length = "0x30")]
	[Token(Token = "0x6001372")]
	private OSSpecificSynchronizationContext(object osContext) { }

	[Address(RVA = "0x746DBDC", Offset = "0x746DBDC", Length = "0x74")]
	[Token(Token = "0x6001374")]
	public virtual SynchronizationContext CreateCopy() { }

	[Address(RVA = "0x746D880", Offset = "0x746D880", Length = "0x164")]
	[Token(Token = "0x6001373")]
	public static OSSpecificSynchronizationContext Get() { }

	[Address(RVA = "0x746DBD8", Offset = "0x746DBD8", Length = "0x4")]
	[Token(Token = "0x6001378")]
	private static object GetOSContext() { }

	[Address(RVA = "0x746DA44", Offset = "0x746DA44", Length = "0x164")]
	[MonoPInvokeCallback(typeof(InvocationEntryDelegate))]
	[Token(Token = "0x6001377")]
	private static void InvocationEntry(IntPtr arg) { }

	[Address(RVA = "0x746DC90", Offset = "0x746DC90", Length = "0x154")]
	[Token(Token = "0x6001376")]
	public virtual void Post(SendOrPostCallback d, object state) { }

	[Address(RVA = "0x746DF00", Offset = "0x746DF00", Length = "0x4")]
	[Token(Token = "0x6001379")]
	private static void PostInternal(object osSynchronizationContext, IntPtr callback, IntPtr arg) { }

	[Address(RVA = "0x746DC50", Offset = "0x746DC50", Length = "0x40")]
	[Token(Token = "0x6001375")]
	public virtual void Send(SendOrPostCallback d, object state) { }

}

