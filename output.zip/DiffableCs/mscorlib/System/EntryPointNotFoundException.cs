namespace System;

[Token(Token = "0x20000AB")]
public class EntryPointNotFoundException : TypeLoadException
{

	[Address(RVA = "0x73E2E1C", Offset = "0x73E2E1C", Length = "0x5C")]
	[Token(Token = "0x60006C4")]
	public EntryPointNotFoundException() { }

	[Address(RVA = "0x73E2E78", Offset = "0x73E2E78", Length = "0x24")]
	[Token(Token = "0x60006C5")]
	public EntryPointNotFoundException(string message) { }

	[Address(RVA = "0x73E2E9C", Offset = "0x73E2E9C", Length = "0x8")]
	[Token(Token = "0x60006C6")]
	protected EntryPointNotFoundException(SerializationInfo info, StreamingContext context) { }

}

