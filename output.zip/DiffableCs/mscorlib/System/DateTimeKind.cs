namespace System;

[Token(Token = "0x20000A5")]
public enum DateTimeKind
{
	Unspecified = 0,
	Utc = 1,
	Local = 2,
}

