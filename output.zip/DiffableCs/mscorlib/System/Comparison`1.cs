namespace System;

[Token(Token = "0x2000087")]
public sealed class Comparison : MulticastDelegate
{

	[Address(RVA = "0x6DCCA20", Offset = "0x6DCCA20", Length = "0xD8")]
	[Token(Token = "0x60003D6")]
	public Comparison`1(object object, IntPtr method) { }

	[Address(RVA = "0x6DCCAF8", Offset = "0x6DCCAF8", Length = "0x14")]
	[Token(Token = "0x60003D7")]
	public override int Invoke(T x, T y) { }

}

