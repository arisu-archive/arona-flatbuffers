namespace System;

[Token(Token = "0x20000DF")]
public class InvalidCastException : SystemException
{

	[Address(RVA = "0x73FB624", Offset = "0x73FB624", Length = "0x5C")]
	[Token(Token = "0x6000846")]
	public InvalidCastException() { }

	[Address(RVA = "0x73F8C24", Offset = "0x73F8C24", Length = "0x24")]
	[Token(Token = "0x6000847")]
	public InvalidCastException(string message) { }

	[Address(RVA = "0x73FB680", Offset = "0x73FB680", Length = "0x24")]
	[Token(Token = "0x6000848")]
	public InvalidCastException(string message, Exception innerException) { }

	[Address(RVA = "0x73FB6A4", Offset = "0x73FB6A4", Length = "0x8")]
	[Token(Token = "0x6000849")]
	protected InvalidCastException(SerializationInfo info, StreamingContext context) { }

}

