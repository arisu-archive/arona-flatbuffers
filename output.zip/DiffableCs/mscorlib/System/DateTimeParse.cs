namespace System;

[Token(Token = "0x20000B6")]
internal static class DateTimeParse
{
	[CompilerGenerated]
	[Token(Token = "0x20000BB")]
	private sealed class <>c
	{
		[Token(Token = "0x40002C1")]
		public static readonly <>c <>9; //Field offset: 0x0
		[Token(Token = "0x40002C2")]
		public static Func<MatchNumberDelegate> <>9__98_0; //Field offset: 0x8

		[Address(RVA = "0x73F125C", Offset = "0x73F125C", Length = "0x70")]
		[Token(Token = "0x6000753")]
		private static <>c() { }

		[Address(RVA = "0x73F12CC", Offset = "0x73F12CC", Length = "0x8")]
		[Token(Token = "0x6000754")]
		public <>c() { }

		[Address(RVA = "0x73F12D4", Offset = "0x73F12D4", Length = "0x74")]
		[Token(Token = "0x6000755")]
		internal MatchNumberDelegate <DoStrictParse>b__98_0() { }

	}

	[Token(Token = "0x20000BA")]
	public enum DS
	{
		BEGIN = 0,
		N = 1,
		NN = 2,
		D_Nd = 3,
		D_NN = 4,
		D_NNd = 5,
		D_M = 6,
		D_MN = 7,
		D_NM = 8,
		D_MNd = 9,
		D_NDS = 10,
		D_Y = 11,
		D_YN = 12,
		D_YNd = 13,
		D_YM = 14,
		D_YMd = 15,
		D_S = 16,
		T_S = 17,
		T_Nt = 18,
		T_NNt = 19,
		ERROR = 20,
		DX_NN = 21,
		DX_NNN = 22,
		DX_MN = 23,
		DX_NM = 24,
		DX_MNN = 25,
		DX_DS = 26,
		DX_DSN = 27,
		DX_NDS = 28,
		DX_NNDS = 29,
		DX_YNN = 30,
		DX_YMN = 31,
		DX_YN = 32,
		DX_YM = 33,
		TX_N = 34,
		TX_NN = 35,
		TX_NNN = 36,
		TX_TS = 37,
		DX_NNY = 38,
	}

	[Token(Token = "0x20000B8")]
	public enum DTT
	{
		End = 0,
		NumEnd = 1,
		NumAmpm = 2,
		NumSpace = 3,
		NumDatesep = 4,
		NumTimesep = 5,
		MonthEnd = 6,
		MonthSpace = 7,
		MonthDatesep = 8,
		NumDatesuff = 9,
		NumTimesuff = 10,
		DayOfWeek = 11,
		YearSpace = 12,
		YearDateSep = 13,
		YearEnd = 14,
		TimeZone = 15,
		Era = 16,
		NumUTCTimeMark = 17,
		Unk = 18,
		NumLocalTimeMark = 19,
		Max = 20,
	}

	[Token(Token = "0x20000B7")]
	public sealed class MatchNumberDelegate : MulticastDelegate
	{

		[Address(RVA = "0x73F115C", Offset = "0x73F115C", Length = "0xEC")]
		[Token(Token = "0x6000751")]
		public MatchNumberDelegate(object object, IntPtr method) { }

		[Address(RVA = "0x73F1248", Offset = "0x73F1248", Length = "0x14")]
		[Token(Token = "0x6000752")]
		public override bool Invoke(ref __DTString str, int digitLen, out int result) { }

	}

	[Token(Token = "0x20000B9")]
	public enum TM
	{
		NotSet = -1,
		AM = 0,
		PM = 1,
	}

	[Token(Token = "0x400027D")]
	internal static MatchNumberDelegate m_hebrewNumberParser; //Field offset: 0x0
	[Token(Token = "0x400027E")]
	private static DS[][] dateParsingStates; //Field offset: 0x8

	[Address(RVA = "0x73F08EC", Offset = "0x73F08EC", Length = "0x870")]
	[Token(Token = "0x6000750")]
	private static DateTimeParse() { }

	[Address(RVA = "0x73EB32C", Offset = "0x73EB32C", Length = "0x58")]
	[Token(Token = "0x6000726")]
	private static bool AdjustHour(ref int hour, TM timeMark) { }

	[Address(RVA = "0x73EB26C", Offset = "0x73EB26C", Length = "0xC0")]
	[Token(Token = "0x6000725")]
	private static void AdjustTimeMark(DateTimeFormatInfo dtfi, ref DateTimeRawInfo raw) { }

	[Address(RVA = "0x73ED270", Offset = "0x73ED270", Length = "0x2A4")]
	[Token(Token = "0x6000738")]
	private static bool AdjustTimeZoneToLocal(ref DateTimeResult result, bool bTimeOnly) { }

	[Address(RVA = "0x73ED148", Offset = "0x73ED148", Length = "0x128")]
	[Token(Token = "0x6000737")]
	private static bool AdjustTimeZoneToUniversal(ref DateTimeResult result) { }

	[Address(RVA = "0x73ECA34", Offset = "0x73ECA34", Length = "0x288")]
	[Token(Token = "0x6000749")]
	private static bool CheckDefaultDateTime(ref DateTimeResult result, ref Calendar cal, DateTimeStyles styles) { }

	[Address(RVA = "0x73EEF88", Offset = "0x73EEF88", Length = "0xC4")]
	[Token(Token = "0x6000747")]
	private static bool CheckNewValue(ref int currentValue, int newValue, char patternChar, ref DateTimeResult result) { }

	[Address(RVA = "0x73ECF10", Offset = "0x73ECF10", Length = "0x238")]
	[Token(Token = "0x6000736")]
	private static bool DateTimeOffsetTimeZonePostProcessing(ref __DTString str, ref DateTimeResult result, DateTimeStyles styles) { }

	[Address(RVA = "0x73ECCBC", Offset = "0x73ECCBC", Length = "0x254")]
	[Token(Token = "0x6000735")]
	private static bool DetermineTimeZoneAdjustments(ref __DTString str, ref DateTimeResult result, DateTimeStyles styles, bool bTimeOnly) { }

	[Address(RVA = "0x73E6E54", Offset = "0x73E6E54", Length = "0x800")]
	[Token(Token = "0x600074E")]
	private static bool DoStrictParse(ReadOnlySpan<Char> s, ReadOnlySpan<Char> formatParam, DateTimeStyles styles, DateTimeFormatInfo dtfi, ref DateTimeResult result) { }

	[Address(RVA = "0x73EF04C", Offset = "0x73EF04C", Length = "0x3DC")]
	[Token(Token = "0x600074A")]
	private static string ExpandPredefinedFormat(ReadOnlySpan<Char> format, ref DateTimeFormatInfo dtfi, ref ParsingInfo parseInfo, ref DateTimeResult result) { }

	[Address(RVA = "0x73EB4D8", Offset = "0x73EB4D8", Length = "0x58")]
	[Token(Token = "0x600072A")]
	private static bool GetDateOfDSN(ref DateTimeResult result, ref DateTimeRawInfo raw) { }

	[Address(RVA = "0x73EB530", Offset = "0x73EB530", Length = "0xB4")]
	[Token(Token = "0x600072B")]
	private static bool GetDateOfNDS(ref DateTimeResult result, ref DateTimeRawInfo raw) { }

	[Address(RVA = "0x73EB5E4", Offset = "0x73EB5E4", Length = "0x22C")]
	[Token(Token = "0x600072C")]
	private static bool GetDateOfNNDS(ref DateTimeResult result, ref DateTimeRawInfo raw, DateTimeFormatInfo dtfi) { }

	[Address(RVA = "0x73E9FC4", Offset = "0x73E9FC4", Length = "0x108")]
	[Token(Token = "0x6000748")]
	private static DateTime GetDateTimeNow(ref DateTimeResult result, ref DateTimeStyles styles) { }

	[Address(RVA = "0x73E6C98", Offset = "0x73E6C98", Length = "0x1BC")]
	[Token(Token = "0x600074F")]
	private static Exception GetDateTimeParseException(ref DateTimeResult result) { }

	[Address(RVA = "0x73EA504", Offset = "0x73EA504", Length = "0x224")]
	[Token(Token = "0x600071C")]
	private static bool GetDayOfMN(ref DateTimeResult result, ref DateTimeStyles styles, ref DateTimeRawInfo raw, DateTimeFormatInfo dtfi) { }

	[Address(RVA = "0x73EAAAC", Offset = "0x73EAAAC", Length = "0x2E4")]
	[Token(Token = "0x600071F")]
	private static bool GetDayOfMNN(ref DateTimeResult result, ref DateTimeRawInfo raw, DateTimeFormatInfo dtfi) { }

	[Address(RVA = "0x73EA888", Offset = "0x73EA888", Length = "0x224")]
	[Token(Token = "0x600071E")]
	private static bool GetDayOfNM(ref DateTimeResult result, ref DateTimeStyles styles, ref DateTimeRawInfo raw, DateTimeFormatInfo dtfi) { }

	[Address(RVA = "0x73EA0CC", Offset = "0x73EA0CC", Length = "0x184")]
	[Token(Token = "0x600071A")]
	private static bool GetDayOfNN(ref DateTimeResult result, ref DateTimeStyles styles, ref DateTimeRawInfo raw, DateTimeFormatInfo dtfi) { }

	[Address(RVA = "0x73EA250", Offset = "0x73EA250", Length = "0x2B4")]
	[Token(Token = "0x600071B")]
	private static bool GetDayOfNNN(ref DateTimeResult result, ref DateTimeRawInfo raw, DateTimeFormatInfo dtfi) { }

	[Address(RVA = "0x73EAED4", Offset = "0x73EAED4", Length = "0x184")]
	[Token(Token = "0x6000721")]
	private static bool GetDayOfNNY(ref DateTimeResult result, ref DateTimeRawInfo raw, DateTimeFormatInfo dtfi) { }

	[Address(RVA = "0x73EB1D0", Offset = "0x73EB1D0", Length = "0x9C")]
	[Token(Token = "0x6000724")]
	private static bool GetDayOfYM(ref DateTimeResult result, ref DateTimeRawInfo raw) { }

	[Address(RVA = "0x73EB058", Offset = "0x73EB058", Length = "0xBC")]
	[Token(Token = "0x6000722")]
	private static bool GetDayOfYMN(ref DateTimeResult result, ref DateTimeRawInfo raw) { }

	[Address(RVA = "0x73EB114", Offset = "0x73EB114", Length = "0xBC")]
	[Token(Token = "0x6000723")]
	private static bool GetDayOfYN(ref DateTimeResult result, ref DateTimeRawInfo raw) { }

	[Address(RVA = "0x73EAD90", Offset = "0x73EAD90", Length = "0x144")]
	[Token(Token = "0x6000720")]
	private static bool GetDayOfYNN(ref DateTimeResult result, ref DateTimeRawInfo raw, DateTimeFormatInfo dtfi) { }

	[Address(RVA = "0x73E9F28", Offset = "0x73E9F28", Length = "0x9C")]
	[Token(Token = "0x6000719")]
	private static void GetDefaultYear(ref DateTimeResult result, ref DateTimeStyles styles) { }

	[Address(RVA = "0x73EA728", Offset = "0x73EA728", Length = "0x160")]
	[Token(Token = "0x600071D")]
	private static bool GetHebrewDayOfNM(ref DateTimeResult result, ref DateTimeRawInfo raw, DateTimeFormatInfo dtfi) { }

	[Address(RVA = "0x73E926C", Offset = "0x73E926C", Length = "0xF0")]
	[Token(Token = "0x600070E")]
	private static Calendar GetJapaneseCalendarDefaultInstance() { }

	[Address(RVA = "0x73E9A84", Offset = "0x73E9A84", Length = "0x1FC")]
	[Token(Token = "0x6000713")]
	private static bool GetMonthDayOrder(string pattern, DateTimeFormatInfo dtfi, out int order) { }

	[Address(RVA = "0x73E935C", Offset = "0x73E935C", Length = "0xF0")]
	[Token(Token = "0x600070F")]
	internal static Calendar GetTaiwanCalendarDefaultInstance() { }

	[Address(RVA = "0x73EB384", Offset = "0x73EB384", Length = "0x60")]
	[Token(Token = "0x6000727")]
	private static bool GetTimeOfN(ref DateTimeResult result, ref DateTimeRawInfo raw) { }

	[Address(RVA = "0x73EB3E4", Offset = "0x73EB3E4", Length = "0x70")]
	[Token(Token = "0x6000728")]
	private static bool GetTimeOfNN(ref DateTimeResult result, ref DateTimeRawInfo raw) { }

	[Address(RVA = "0x73EB454", Offset = "0x73EB454", Length = "0x84")]
	[Token(Token = "0x6000729")]
	private static bool GetTimeOfNNN(ref DateTimeResult result, ref DateTimeRawInfo raw) { }

	[Address(RVA = "0x73E7A80", Offset = "0x73E7A80", Length = "0xB0")]
	[Token(Token = "0x6000708")]
	private static bool GetTimeZoneName(ref __DTString str) { }

	[Address(RVA = "0x73E962C", Offset = "0x73E962C", Length = "0x29C")]
	[Token(Token = "0x6000711")]
	private static bool GetYearMonthDayOrder(string datePattern, DateTimeFormatInfo dtfi, out int order) { }

	[Address(RVA = "0x73E98C8", Offset = "0x73E98C8", Length = "0x1BC")]
	[Token(Token = "0x6000712")]
	private static bool GetYearMonthOrder(string pattern, DateTimeFormatInfo dtfi, out int order) { }

	[Address(RVA = "0x73E7F48", Offset = "0x73E7F48", Length = "0x198")]
	[Token(Token = "0x600070C")]
	private static bool HandleTimeZone(ref __DTString str, ref DateTimeResult result) { }

	[Address(RVA = "0x73E7B30", Offset = "0x73E7B30", Length = "0x14")]
	[Token(Token = "0x6000709")]
	internal static bool IsDigit(char ch) { }

	[Address(RVA = "0x73E80E0", Offset = "0x73E80E0", Length = "0xE0C")]
	[Token(Token = "0x600070D")]
	private static bool Lex(DS dps, ref __DTString str, ref DateTimeToken dtok, ref DateTimeRawInfo raw, ref DateTimeResult result, ref DateTimeFormatInfo dtfi, DateTimeStyles styles) { }

	[Address(RVA = "0x73EE360", Offset = "0x73EE360", Length = "0x250")]
	[Token(Token = "0x6000742")]
	private static bool MatchAbbreviatedDayName(ref __DTString str, DateTimeFormatInfo dtfi, ref int result) { }

	[Address(RVA = "0x73EDD68", Offset = "0x73EDD68", Length = "0x2D0")]
	[Token(Token = "0x6000740")]
	private static bool MatchAbbreviatedMonthName(ref __DTString str, DateTimeFormatInfo dtfi, ref int result) { }

	[Address(RVA = "0x73EEE38", Offset = "0x73EEE38", Length = "0x150")]
	[Token(Token = "0x6000746")]
	private static bool MatchAbbreviatedTimeMark(ref __DTString str, DateTimeFormatInfo dtfi, ref TM result) { }

	[Address(RVA = "0x73EE5B0", Offset = "0x73EE5B0", Length = "0x250")]
	[Token(Token = "0x6000743")]
	private static bool MatchDayName(ref __DTString str, DateTimeFormatInfo dtfi, ref int result) { }

	[Address(RVA = "0x73EE800", Offset = "0x73EE800", Length = "0x31C")]
	[Token(Token = "0x6000744")]
	private static bool MatchEraName(ref __DTString str, DateTimeFormatInfo dtfi, ref int result) { }

	[Address(RVA = "0x73ED5A4", Offset = "0x73ED5A4", Length = "0x110")]
	[Token(Token = "0x600073A")]
	internal static bool MatchHebrewDigits(ref __DTString str, int digitLen, out int number) { }

	[Address(RVA = "0x73EE038", Offset = "0x73EE038", Length = "0x328")]
	[Token(Token = "0x6000741")]
	private static bool MatchMonthName(ref __DTString str, DateTimeFormatInfo dtfi, ref int result) { }

	[Address(RVA = "0x73EEB1C", Offset = "0x73EEB1C", Length = "0x31C")]
	[Token(Token = "0x6000745")]
	private static bool MatchTimeMark(ref __DTString str, DateTimeFormatInfo dtfi, ref TM result) { }

	[Address(RVA = "0x73E78C0", Offset = "0x73E78C0", Length = "0x1C0")]
	[Token(Token = "0x6000707")]
	private static bool MatchWord(ref __DTString str, string target) { }

	[Address(RVA = "0x73DFE34", Offset = "0x73DFE34", Length = "0x108")]
	[Token(Token = "0x6000731")]
	internal static DateTime Parse(ReadOnlySpan<Char> s, DateTimeFormatInfo dtfi, DateTimeStyles styles, out TimeSpan offset) { }

	[Address(RVA = "0x73DB9B0", Offset = "0x73DB9B0", Length = "0xF0")]
	[Token(Token = "0x6000730")]
	internal static DateTime Parse(ReadOnlySpan<Char> s, DateTimeFormatInfo dtfi, DateTimeStyles styles) { }

	[Address(RVA = "0x73EF530", Offset = "0x73EF530", Length = "0x12CC")]
	[Token(Token = "0x600074C")]
	private static bool ParseByFormat(ref __DTString str, ref __DTString format, ref ParsingInfo parseInfo, DateTimeFormatInfo dtfi, ref DateTimeResult result) { }

	[Address(RVA = "0x73ED6B4", Offset = "0x73ED6B4", Length = "0x1A4")]
	[Token(Token = "0x600073C")]
	internal static bool ParseDigits(ref __DTString str, int minDigitLen, int maxDigitLen, out int result) { }

	[Address(RVA = "0x73ED514", Offset = "0x73ED514", Length = "0x90")]
	[Token(Token = "0x600073B")]
	internal static bool ParseDigits(ref __DTString str, int digitLen, out int result) { }

	[Address(RVA = "0x73E0154", Offset = "0x73E0154", Length = "0x154")]
	[Token(Token = "0x6000701")]
	internal static DateTime ParseExact(ReadOnlySpan<Char> s, ReadOnlySpan<Char> format, DateTimeFormatInfo dtfi, DateTimeStyles style, out TimeSpan offset) { }

	[Address(RVA = "0x73DBE2C", Offset = "0x73DBE2C", Length = "0x108")]
	[Token(Token = "0x6000700")]
	internal static DateTime ParseExact(ReadOnlySpan<Char> s, ReadOnlySpan<Char> format, DateTimeFormatInfo dtfi, DateTimeStyles style) { }

	[Address(RVA = "0x73DC218", Offset = "0x73DC218", Length = "0xF8")]
	[Token(Token = "0x6000705")]
	internal static DateTime ParseExactMultiple(ReadOnlySpan<Char> s, String[] formats, DateTimeFormatInfo dtfi, DateTimeStyles style) { }

	[Address(RVA = "0x73E7B44", Offset = "0x73E7B44", Length = "0xEC")]
	[Token(Token = "0x600070A")]
	private static bool ParseFraction(ref __DTString str, out double result) { }

	[Address(RVA = "0x73ED858", Offset = "0x73ED858", Length = "0x268")]
	[Token(Token = "0x600073D")]
	private static bool ParseFractionExact(ref __DTString str, int maxDigitLen, ref double result) { }

	[Address(RVA = "0x73EC424", Offset = "0x73EC424", Length = "0x610")]
	[Token(Token = "0x6000739")]
	private static bool ParseISO8601(ref DateTimeRawInfo raw, ref __DTString str, DateTimeStyles styles, ref DateTimeResult result) { }

	[Address(RVA = "0x73EF428", Offset = "0x73EF428", Length = "0x108")]
	[Token(Token = "0x600074B")]
	private static bool ParseJapaneseEraStart(ref __DTString str, DateTimeFormatInfo dtfi) { }

	[Address(RVA = "0x73EDAC0", Offset = "0x73EDAC0", Length = "0xB8")]
	[Token(Token = "0x600073E")]
	private static bool ParseSign(ref __DTString str, ref bool result) { }

	[Address(RVA = "0x73E7C30", Offset = "0x73E7C30", Length = "0x318")]
	[Token(Token = "0x600070B")]
	private static bool ParseTimeZone(ref __DTString str, ref TimeSpan result) { }

	[Address(RVA = "0x73EDB78", Offset = "0x73EDB78", Length = "0x1F0")]
	[Token(Token = "0x600073F")]
	private static bool ParseTimeZoneOffset(ref __DTString str, int len, ref TimeSpan result) { }

	[Address(RVA = "0x73EB810", Offset = "0x73EB810", Length = "0x118")]
	[Token(Token = "0x600072D")]
	private static bool ProcessDateTimeSuffix(ref DateTimeResult result, ref DateTimeRawInfo raw, ref DateTimeToken dtok) { }

	[Address(RVA = "0x73EB928", Offset = "0x73EB928", Length = "0x37C")]
	[Token(Token = "0x600072E")]
	internal static bool ProcessHebrewTerminalState(DS dps, ref __DTString str, ref DateTimeResult result, ref DateTimeStyles styles, ref DateTimeRawInfo raw, DateTimeFormatInfo dtfi) { }

	[Address(RVA = "0x73E8EEC", Offset = "0x73E8EEC", Length = "0x380")]
	[Token(Token = "0x600072F")]
	internal static bool ProcessTerminalState(DS dps, ref __DTString str, ref DateTimeResult result, ref DateTimeStyles styles, ref DateTimeRawInfo raw, DateTimeFormatInfo dtfi) { }

	[Address(RVA = "0x73E9E30", Offset = "0x73E9E30", Length = "0x7C")]
	[Token(Token = "0x6000717")]
	private static bool SetDateDMY(ref DateTimeResult result, int day, int month, int year) { }

	[Address(RVA = "0x73E9DB4", Offset = "0x73E9DB4", Length = "0x7C")]
	[Token(Token = "0x6000716")]
	private static bool SetDateMDY(ref DateTimeResult result, int month, int day, int year) { }

	[Address(RVA = "0x73E9EAC", Offset = "0x73E9EAC", Length = "0x7C")]
	[Token(Token = "0x6000718")]
	private static bool SetDateYDM(ref DateTimeResult result, int year, int day, int month) { }

	[Address(RVA = "0x73E9D44", Offset = "0x73E9D44", Length = "0x70")]
	[Token(Token = "0x6000715")]
	private static bool SetDateYMD(ref DateTimeResult result, int year, int month, int day) { }

	[Address(RVA = "0x73E9C80", Offset = "0x73E9C80", Length = "0xC4")]
	[Token(Token = "0x6000714")]
	private static bool TryAdjustYear(ref DateTimeResult result, int year, out int adjustedYear) { }

	[Address(RVA = "0x73EBCA4", Offset = "0x73EBCA4", Length = "0x780")]
	[Token(Token = "0x6000734")]
	internal static bool TryParse(ReadOnlySpan<Char> s, DateTimeFormatInfo dtfi, DateTimeStyles styles, ref DateTimeResult result) { }

	[Address(RVA = "0x73E0DC8", Offset = "0x73E0DC8", Length = "0x150")]
	[Token(Token = "0x6000733")]
	internal static bool TryParse(ReadOnlySpan<Char> s, DateTimeFormatInfo dtfi, DateTimeStyles styles, out DateTime result, out TimeSpan offset) { }

	[Address(RVA = "0x73DCAC8", Offset = "0x73DCAC8", Length = "0xFC")]
	[Token(Token = "0x6000732")]
	internal static bool TryParse(ReadOnlySpan<Char> s, DateTimeFormatInfo dtfi, DateTimeStyles styles, out DateTime result) { }

	[Address(RVA = "0x73E6B94", Offset = "0x73E6B94", Length = "0x104")]
	[Token(Token = "0x6000704")]
	internal static bool TryParseExact(ReadOnlySpan<Char> s, ReadOnlySpan<Char> format, DateTimeFormatInfo dtfi, DateTimeStyles style, ref DateTimeResult result) { }

	[Address(RVA = "0x73E110C", Offset = "0x73E110C", Length = "0x168")]
	[Token(Token = "0x6000703")]
	internal static bool TryParseExact(ReadOnlySpan<Char> s, ReadOnlySpan<Char> format, DateTimeFormatInfo dtfi, DateTimeStyles style, out DateTime result, out TimeSpan offset) { }

	[Address(RVA = "0x73DCE90", Offset = "0x73DCE90", Length = "0x114")]
	[Token(Token = "0x6000702")]
	internal static bool TryParseExact(ReadOnlySpan<Char> s, ReadOnlySpan<Char> format, DateTimeFormatInfo dtfi, DateTimeStyles style, out DateTime result) { }

	[Address(RVA = "0x73E7654", Offset = "0x73E7654", Length = "0x26C")]
	[Token(Token = "0x6000706")]
	internal static bool TryParseExactMultiple(ReadOnlySpan<Char> s, String[] formats, DateTimeFormatInfo dtfi, DateTimeStyles style, ref DateTimeResult result) { }

	[Address(RVA = "0x73F07FC", Offset = "0x73F07FC", Length = "0xF0")]
	[Token(Token = "0x600074D")]
	internal static bool TryParseQuoteString(ReadOnlySpan<Char> format, int pos, StringBuilder result, out int returnValue) { }

	[Address(RVA = "0x73E944C", Offset = "0x73E944C", Length = "0x1E0")]
	[Token(Token = "0x6000710")]
	private static bool VerifyValidPunctuation(ref __DTString str) { }

}

