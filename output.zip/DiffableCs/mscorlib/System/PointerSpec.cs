namespace System;

[Token(Token = "0x20001BC")]
internal class PointerSpec : ModifierSpec
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40008E5")]
	private int pointer_level; //Field offset: 0x10

	[Address(RVA = "0x7457BF0", Offset = "0x7457BF0", Length = "0x8")]
	[Token(Token = "0x600115C")]
	internal PointerSpec(int pointer_level) { }

	[Address(RVA = "0x7457C4C", Offset = "0x7457C4C", Length = "0x24")]
	[Token(Token = "0x600115E")]
	public override StringBuilder Append(StringBuilder sb) { }

	[Address(RVA = "0x7457BF8", Offset = "0x7457BF8", Length = "0x54")]
	[Token(Token = "0x600115D")]
	public override Type Resolve(Type type) { }

	[Address(RVA = "0x7457C70", Offset = "0x7457C70", Length = "0x74")]
	[Token(Token = "0x600115F")]
	public virtual string ToString() { }

}

