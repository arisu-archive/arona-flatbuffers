namespace System;

[Token(Token = "0x2000148")]
internal static class DecimalDecCalc
{

	[Address(RVA = "0x741EF00", Offset = "0x741EF00", Length = "0x38")]
	[Token(Token = "0x6000D05")]
	private static uint D32DivMod1E9(uint hi32, ref uint lo32) { }

	[Address(RVA = "0x741EF38", Offset = "0x741EF38", Length = "0x84")]
	[Token(Token = "0x6000D06")]
	internal static uint DecDivMod1E9(ref MutableDecimal value) { }

}

