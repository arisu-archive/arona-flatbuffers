namespace System;

[Token(Token = "0x2000095")]
public sealed class AsyncCallback : MulticastDelegate
{

	[Address(RVA = "0x73516C0", Offset = "0x73516C0", Length = "0x140")]
	[Token(Token = "0x600042F")]
	public AsyncCallback(object object, IntPtr method) { }

	[Address(RVA = "0x7351814", Offset = "0x7351814", Length = "0x20")]
	[Token(Token = "0x6000431")]
	public override IAsyncResult BeginInvoke(IAsyncResult ar, AsyncCallback callback, object object) { }

	[Address(RVA = "0x7351834", Offset = "0x7351834", Length = "0xC")]
	[Token(Token = "0x6000432")]
	public override void EndInvoke(IAsyncResult result) { }

	[Address(RVA = "0x7351800", Offset = "0x7351800", Length = "0x14")]
	[Token(Token = "0x6000430")]
	public override void Invoke(IAsyncResult ar) { }

}

