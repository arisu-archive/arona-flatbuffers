namespace System;

[Token(Token = "0x20000CC")]
public interface IAsyncResult
{

	[Token(Token = "0x17000091")]
	public object AsyncState
	{
		[Token(Token = "0x60007BF")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000090")]
	public WaitHandle AsyncWaitHandle
	{
		[Token(Token = "0x60007BE")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000092")]
	public bool CompletedSynchronously
	{
		[Token(Token = "0x60007C0")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700008F")]
	public bool IsCompleted
	{
		[Token(Token = "0x60007BD")]
		 get { } //Length: 0
	}

	[Token(Token = "0x60007BF")]
	public object get_AsyncState() { }

	[Token(Token = "0x60007BE")]
	public WaitHandle get_AsyncWaitHandle() { }

	[Token(Token = "0x60007C0")]
	public bool get_CompletedSynchronously() { }

	[Token(Token = "0x60007BD")]
	public bool get_IsCompleted() { }

}

