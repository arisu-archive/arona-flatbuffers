namespace System.Resources;

[Token(Token = "0x20004D8")]
public class MissingManifestResourceException : SystemException
{

	[Address(RVA = "0x73057F8", Offset = "0x73057F8", Length = "0x5C")]
	[Token(Token = "0x6002494")]
	public MissingManifestResourceException() { }

	[Address(RVA = "0x7305854", Offset = "0x7305854", Length = "0x24")]
	[Token(Token = "0x6002495")]
	public MissingManifestResourceException(string message) { }

	[Address(RVA = "0x7305878", Offset = "0x7305878", Length = "0x8")]
	[Token(Token = "0x6002496")]
	protected MissingManifestResourceException(SerializationInfo info, StreamingContext context) { }

}

