namespace System.Resources;

[ComVisible(True)]
[Token(Token = "0x20004E5")]
public class ResourceManager
{
	[Token(Token = "0x20004E6")]
	public class CultureNameResourceSetPair
	{

		[Address(RVA = "0x730BC08", Offset = "0x730BC08", Length = "0x8")]
		[Token(Token = "0x60024E6")]
		public CultureNameResourceSetPair() { }

	}

	[Token(Token = "0x20004E7")]
	public class ResourceManagerMediator
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x400140F")]
		private ResourceManager _rm; //Field offset: 0x10

		[Token(Token = "0x170004E1")]
		internal string BaseName
		{
			[Address(RVA = "0x730BEC4", Offset = "0x730BEC4", Length = "0x20")]
			[Token(Token = "0x60024F6")]
			internal get { } //Length: 32
		}

		[Token(Token = "0x170004DA")]
		internal string BaseNameField
		{
			[Address(RVA = "0x730BCE4", Offset = "0x730BCE4", Length = "0x1C")]
			[Token(Token = "0x60024EB")]
			internal get { } //Length: 28
		}

		[Token(Token = "0x170004DF")]
		internal RuntimeAssembly CallingAssembly
		{
			[Address(RVA = "0x730BE24", Offset = "0x730BE24", Length = "0x1C")]
			[Token(Token = "0x60024F4")]
			internal get { } //Length: 28
		}

		[Token(Token = "0x170004DE")]
		internal UltimateResourceFallbackLocation FallbackLoc
		{
			[Address(RVA = "0x730BE08", Offset = "0x730BE08", Length = "0x1C")]
			[Token(Token = "0x60024F3")]
			internal get { } //Length: 28
		}

		[Token(Token = "0x170004D8")]
		internal Type LocationInfo
		{
			[Address(RVA = "0x730BCAC", Offset = "0x730BCAC", Length = "0x1C")]
			[Token(Token = "0x60024E9")]
			internal get { } //Length: 28
		}

		[Token(Token = "0x170004DC")]
		internal bool LookedForSatelliteContractVersion
		{
			[Address(RVA = "0x730BD3C", Offset = "0x730BD3C", Length = "0x1C")]
			[Token(Token = "0x60024EE")]
			internal get { } //Length: 28
			[Address(RVA = "0x730BD58", Offset = "0x730BD58", Length = "0x20")]
			[Token(Token = "0x60024EF")]
			internal set { } //Length: 32
		}

		[Token(Token = "0x170004E0")]
		internal RuntimeAssembly MainAssembly
		{
			[Address(RVA = "0x730BE40", Offset = "0x730BE40", Length = "0x84")]
			[Token(Token = "0x60024F5")]
			internal get { } //Length: 132
		}

		[Token(Token = "0x170004D7")]
		internal string ModuleDir
		{
			[Address(RVA = "0x730BC90", Offset = "0x730BC90", Length = "0x1C")]
			[Token(Token = "0x60024E8")]
			internal get { } //Length: 28
		}

		[Token(Token = "0x170004DB")]
		internal CultureInfo NeutralResourcesCulture
		{
			[Address(RVA = "0x730BD00", Offset = "0x730BD00", Length = "0x1C")]
			[Token(Token = "0x60024EC")]
			internal get { } //Length: 28
		}

		[Token(Token = "0x170004DD")]
		internal Version SatelliteContractVersion
		{
			[Address(RVA = "0x730BD78", Offset = "0x730BD78", Length = "0x1C")]
			[Token(Token = "0x60024F0")]
			internal get { } //Length: 28
			[Address(RVA = "0x730BD94", Offset = "0x730BD94", Length = "0x1C")]
			[Token(Token = "0x60024F1")]
			internal set { } //Length: 28
		}

		[Token(Token = "0x170004D9")]
		internal Type UserResourceSet
		{
			[Address(RVA = "0x730BCC8", Offset = "0x730BCC8", Length = "0x1C")]
			[Token(Token = "0x60024EA")]
			internal get { } //Length: 28
		}

		[Address(RVA = "0x730BC10", Offset = "0x730BC10", Length = "0x80")]
		[Token(Token = "0x60024E7")]
		internal ResourceManagerMediator(ResourceManager rm) { }

		[Address(RVA = "0x730BEC4", Offset = "0x730BEC4", Length = "0x20")]
		[Token(Token = "0x60024F6")]
		internal string get_BaseName() { }

		[Address(RVA = "0x730BCE4", Offset = "0x730BCE4", Length = "0x1C")]
		[Token(Token = "0x60024EB")]
		internal string get_BaseNameField() { }

		[Address(RVA = "0x730BE24", Offset = "0x730BE24", Length = "0x1C")]
		[Token(Token = "0x60024F4")]
		internal RuntimeAssembly get_CallingAssembly() { }

		[Address(RVA = "0x730BE08", Offset = "0x730BE08", Length = "0x1C")]
		[Token(Token = "0x60024F3")]
		internal UltimateResourceFallbackLocation get_FallbackLoc() { }

		[Address(RVA = "0x730BCAC", Offset = "0x730BCAC", Length = "0x1C")]
		[Token(Token = "0x60024E9")]
		internal Type get_LocationInfo() { }

		[Address(RVA = "0x730BD3C", Offset = "0x730BD3C", Length = "0x1C")]
		[Token(Token = "0x60024EE")]
		internal bool get_LookedForSatelliteContractVersion() { }

		[Address(RVA = "0x730BE40", Offset = "0x730BE40", Length = "0x84")]
		[Token(Token = "0x60024F5")]
		internal RuntimeAssembly get_MainAssembly() { }

		[Address(RVA = "0x730BC90", Offset = "0x730BC90", Length = "0x1C")]
		[Token(Token = "0x60024E8")]
		internal string get_ModuleDir() { }

		[Address(RVA = "0x730BD00", Offset = "0x730BD00", Length = "0x1C")]
		[Token(Token = "0x60024EC")]
		internal CultureInfo get_NeutralResourcesCulture() { }

		[Address(RVA = "0x730BD78", Offset = "0x730BD78", Length = "0x1C")]
		[Token(Token = "0x60024F0")]
		internal Version get_SatelliteContractVersion() { }

		[Address(RVA = "0x730BCC8", Offset = "0x730BCC8", Length = "0x1C")]
		[Token(Token = "0x60024EA")]
		internal Type get_UserResourceSet() { }

		[Address(RVA = "0x730BD1C", Offset = "0x730BD1C", Length = "0x20")]
		[Token(Token = "0x60024ED")]
		internal string GetResourceFileName(CultureInfo culture) { }

		[Address(RVA = "0x730BDB0", Offset = "0x730BDB0", Length = "0x58")]
		[Token(Token = "0x60024F2")]
		internal Version ObtainSatelliteContractVersion(Assembly a) { }

		[Address(RVA = "0x730BD58", Offset = "0x730BD58", Length = "0x20")]
		[Token(Token = "0x60024EF")]
		internal void set_LookedForSatelliteContractVersion(bool value) { }

		[Address(RVA = "0x730BD94", Offset = "0x730BD94", Length = "0x1C")]
		[Token(Token = "0x60024F1")]
		internal void set_SatelliteContractVersion(Version value) { }

	}

	[Token(Token = "0x4001408")]
	public static readonly int MagicNumber; //Field offset: 0x0
	[Token(Token = "0x4001409")]
	public static readonly int HeaderVersionNumber; //Field offset: 0x4
	[Token(Token = "0x400140A")]
	private static readonly Type _minResourceSet; //Field offset: 0x8
	[Token(Token = "0x400140B")]
	internal static readonly string ResReaderTypeName; //Field offset: 0x10
	[Token(Token = "0x400140C")]
	internal static readonly string ResSetTypeName; //Field offset: 0x18
	[Token(Token = "0x400140D")]
	internal static readonly string MscorlibName; //Field offset: 0x20
	[Token(Token = "0x400140E")]
	internal static readonly int DEBUG; //Field offset: 0x28
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40013F6")]
	protected string BaseNameField; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Obsolete("call InternalGetResourceSet instead")]
	[Token(Token = "0x40013F7")]
	protected Hashtable ResourceSets; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40013F8")]
	private Dictionary<String, ResourceSet> _resourceSets; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40013F9")]
	private string moduleDir; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40013FA")]
	protected Assembly MainAssembly; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40013FB")]
	private Type _locationInfo; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40013FC")]
	private Type _userResourceSet; //Field offset: 0x40
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40013FD")]
	private CultureInfo _neutralResourcesCulture; //Field offset: 0x48
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40013FE")]
	private CultureNameResourceSetPair _lastUsedResourceCache; //Field offset: 0x50
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40013FF")]
	private bool _ignoreCase; //Field offset: 0x58
	[FieldOffset(Offset = "0x59")]
	[Token(Token = "0x4001400")]
	private bool UseManifest; //Field offset: 0x59
	[FieldOffset(Offset = "0x5A")]
	[OptionalField(VersionAdded = 1)]
	[Token(Token = "0x4001401")]
	private bool UseSatelliteAssem; //Field offset: 0x5A
	[FieldOffset(Offset = "0x5C")]
	[OptionalField]
	[Token(Token = "0x4001402")]
	private UltimateResourceFallbackLocation _fallbackLoc; //Field offset: 0x5C
	[FieldOffset(Offset = "0x60")]
	[OptionalField]
	[Token(Token = "0x4001403")]
	private Version _satelliteContractVersion; //Field offset: 0x60
	[FieldOffset(Offset = "0x68")]
	[OptionalField]
	[Token(Token = "0x4001404")]
	private bool _lookedForSatelliteContractVersion; //Field offset: 0x68
	[FieldOffset(Offset = "0x70")]
	[OptionalField(VersionAdded = 1)]
	[Token(Token = "0x4001405")]
	private Assembly _callingAssembly; //Field offset: 0x70
	[FieldOffset(Offset = "0x78")]
	[OptionalField(VersionAdded = 4)]
	[Token(Token = "0x4001406")]
	private RuntimeAssembly m_callingAssembly; //Field offset: 0x78
	[FieldOffset(Offset = "0x80")]
	[Token(Token = "0x4001407")]
	private IResourceGroveler resourceGroveler; //Field offset: 0x80

	[Token(Token = "0x170004D4")]
	public override string BaseName
	{
		[Address(RVA = "0x730A540", Offset = "0x730A540", Length = "0x8")]
		[Token(Token = "0x60024D9")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170004D6")]
	protected UltimateResourceFallbackLocation FallbackLocation
	{
		[Address(RVA = "0x730A550", Offset = "0x730A550", Length = "0x8")]
		[Token(Token = "0x60024DB")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170004D5")]
	public override bool IgnoreCase
	{
		[Address(RVA = "0x730A548", Offset = "0x730A548", Length = "0x8")]
		[Token(Token = "0x60024DA")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x730BA70", Offset = "0x730BA70", Length = "0x198")]
	[Token(Token = "0x60024E5")]
	private static ResourceManager() { }

	[Address(RVA = "0x7309C40", Offset = "0x7309C40", Length = "0xF8")]
	[Token(Token = "0x60024D3")]
	protected ResourceManager() { }

	[Address(RVA = "0x7309D38", Offset = "0x7309D38", Length = "0x378")]
	[Token(Token = "0x60024D4")]
	public ResourceManager(Type resourceSource) { }

	[Address(RVA = "0x730A9D8", Offset = "0x730A9D8", Length = "0x19C")]
	[Token(Token = "0x60024E0")]
	private static void AddResourceSet(Dictionary<String, ResourceSet> localResourceSets, string cultureName, ref ResourceSet rs) { }

	[Address(RVA = "0x730A0B4", Offset = "0x730A0B4", Length = "0x1A4")]
	[Token(Token = "0x60024D8")]
	private void CommonAssemblyInit() { }

	[Address(RVA = "0x73098C4", Offset = "0x73098C4", Length = "0x250")]
	[Token(Token = "0x60024E3")]
	internal static bool CompareNames(string asmTypeName1, string typeName2, AssemblyName asmName2) { }

	[Address(RVA = "0x730A540", Offset = "0x730A540", Length = "0x8")]
	[Token(Token = "0x60024D9")]
	public override string get_BaseName() { }

	[Address(RVA = "0x730A550", Offset = "0x730A550", Length = "0x8")]
	[Token(Token = "0x60024DB")]
	protected UltimateResourceFallbackLocation get_FallbackLocation() { }

	[Address(RVA = "0x730A548", Offset = "0x730A548", Length = "0x8")]
	[Token(Token = "0x60024DA")]
	public override bool get_IgnoreCase() { }

	[Address(RVA = "0x730BA5C", Offset = "0x730BA5C", Length = "0x14")]
	[Token(Token = "0x60024E2")]
	protected static CultureInfo GetNeutralResourcesLanguage(Assembly a) { }

	[Address(RVA = "0x730A558", Offset = "0x730A558", Length = "0x13C")]
	[Token(Token = "0x60024DC")]
	protected override string GetResourceFileName(CultureInfo culture) { }

	[Address(RVA = "0x730A694", Offset = "0x730A694", Length = "0x344")]
	[Token(Token = "0x60024DD")]
	public override ResourceSet GetResourceSet(CultureInfo culture, bool createIfNotExists, bool tryParents) { }

	[Address(RVA = "0x730B334", Offset = "0x730B334", Length = "0x728")]
	[Token(Token = "0x60024E1")]
	protected static Version GetSatelliteContractVersion(Assembly a) { }

	[Address(RVA = "0x7309B14", Offset = "0x7309B14", Length = "0x12C")]
	[Token(Token = "0x60024D2")]
	private void Init() { }

	[Address(RVA = "0x730AB74", Offset = "0x730AB74", Length = "0x1C")]
	[Token(Token = "0x60024DE")]
	protected override ResourceSet InternalGetResourceSet(CultureInfo culture, bool createIfNotExists, bool tryParents) { }

	[Address(RVA = "0x730AB90", Offset = "0x730AB90", Length = "0x7A4")]
	[Token(Token = "0x60024DF")]
	private ResourceSet InternalGetResourceSet(CultureInfo requestedCulture, bool createIfNotExists, bool tryParents, ref StackCrawlMark stackMark) { }

	[Address(RVA = "0x730A290", Offset = "0x730A290", Length = "0x22C")]
	[OnDeserialized]
	[Token(Token = "0x60024D6")]
	private void OnDeserialized(StreamingContext ctx) { }

	[Address(RVA = "0x730A258", Offset = "0x730A258", Length = "0x38")]
	[OnDeserializing]
	[Token(Token = "0x60024D5")]
	private void OnDeserializing(StreamingContext ctx) { }

	[Address(RVA = "0x730A4BC", Offset = "0x730A4BC", Length = "0x84")]
	[OnSerializing]
	[Token(Token = "0x60024D7")]
	private void OnSerializing(StreamingContext ctx) { }

	[Address(RVA = "0x730A0B0", Offset = "0x730A0B0", Length = "0x4")]
	[Token(Token = "0x60024E4")]
	private void SetAppXConfiguration() { }

}

