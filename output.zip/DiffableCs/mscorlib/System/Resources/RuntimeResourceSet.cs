namespace System.Resources;

[Token(Token = "0x20004DE")]
internal sealed class RuntimeResourceSet : ResourceSet, IEnumerable
{
	[Token(Token = "0x40013EA")]
	internal const int Version = 2; //Field offset: 0x0
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40013EB")]
	private Dictionary<String, ResourceLocator> _resCache; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40013EC")]
	private ResourceReader _defaultReader; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40013ED")]
	private Dictionary<String, ResourceLocator> _caseInsensitiveTable; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40013EE")]
	private bool _haveReadFromReader; //Field offset: 0x40

	[Address(RVA = "0x7305D64", Offset = "0x7305D64", Length = "0x168")]
	[Token(Token = "0x60024A6")]
	internal RuntimeResourceSet(string fileName) { }

	[Address(RVA = "0x7305ECC", Offset = "0x7305ECC", Length = "0x12C")]
	[Token(Token = "0x60024A7")]
	internal RuntimeResourceSet(Stream stream) { }

	[Address(RVA = "0x7305FF8", Offset = "0x7305FF8", Length = "0x168")]
	[Token(Token = "0x60024A8")]
	protected virtual void Dispose(bool disposing) { }

	[Address(RVA = "0x7306160", Offset = "0x7306160", Length = "0x4")]
	[Token(Token = "0x60024A9")]
	public virtual IDictionaryEnumerator GetEnumerator() { }

	[Address(RVA = "0x7306164", Offset = "0x7306164", Length = "0x100")]
	[Token(Token = "0x60024AB")]
	private IDictionaryEnumerator GetEnumeratorHelper() { }

	[Address(RVA = "0x7306C3C", Offset = "0x7306C3C", Length = "0xC")]
	[Token(Token = "0x60024AE")]
	public virtual object GetObject(string key) { }

	[Address(RVA = "0x7306C48", Offset = "0x7306C48", Length = "0x8")]
	[Token(Token = "0x60024AF")]
	public virtual object GetObject(string key, bool ignoreCase) { }

	[Address(RVA = "0x73062D8", Offset = "0x73062D8", Length = "0x8E8")]
	[Token(Token = "0x60024B0")]
	private object GetObject(string key, bool ignoreCase, bool isString) { }

	[Address(RVA = "0x7306268", Offset = "0x7306268", Length = "0x70")]
	[Token(Token = "0x60024AC")]
	public virtual string GetString(string key) { }

	[Address(RVA = "0x7306BC0", Offset = "0x7306BC0", Length = "0x7C")]
	[Token(Token = "0x60024AD")]
	public virtual string GetString(string key, bool ignoreCase) { }

	[Address(RVA = "0x7306C50", Offset = "0x7306C50", Length = "0x188")]
	[Token(Token = "0x60024B1")]
	private object ResolveResourceLocator(ResourceLocator resLocation, string key, Dictionary<String, ResourceLocator> copyOfCache, bool keyInWrongCase) { }

	[Address(RVA = "0x7306264", Offset = "0x7306264", Length = "0x4")]
	[Token(Token = "0x60024AA")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

