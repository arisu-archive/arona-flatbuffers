namespace System.Resources;

[Token(Token = "0x20004E8")]
internal struct ResourceLocator
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001410")]
	internal object _value; //Field offset: 0x0
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x4001411")]
	internal int _dataPos; //Field offset: 0x8

	[Token(Token = "0x170004E2")]
	internal int DataPosition
	{
		[Address(RVA = "0x730BEF8", Offset = "0x730BEF8", Length = "0x8")]
		[Token(Token = "0x60024F8")]
		internal get { } //Length: 8
	}

	[Token(Token = "0x170004E3")]
	internal object Value
	{
		[Address(RVA = "0x730BF00", Offset = "0x730BF00", Length = "0x8")]
		[Token(Token = "0x60024F9")]
		internal get { } //Length: 8
		[Address(RVA = "0x730BF08", Offset = "0x730BF08", Length = "0x8")]
		[Token(Token = "0x60024FA")]
		internal set { } //Length: 8
	}

	[Address(RVA = "0x730BEE4", Offset = "0x730BEE4", Length = "0x14")]
	[Token(Token = "0x60024F7")]
	internal ResourceLocator(int dataPos, object value) { }

	[Address(RVA = "0x730BF10", Offset = "0x730BF10", Length = "0xC")]
	[Token(Token = "0x60024FB")]
	internal static bool CanCache(ResourceTypeCode value) { }

	[Address(RVA = "0x730BEF8", Offset = "0x730BEF8", Length = "0x8")]
	[Token(Token = "0x60024F8")]
	internal int get_DataPosition() { }

	[Address(RVA = "0x730BF00", Offset = "0x730BF00", Length = "0x8")]
	[Token(Token = "0x60024F9")]
	internal object get_Value() { }

	[Address(RVA = "0x730BF08", Offset = "0x730BF08", Length = "0x8")]
	[Token(Token = "0x60024FA")]
	internal void set_Value(object value) { }

}

