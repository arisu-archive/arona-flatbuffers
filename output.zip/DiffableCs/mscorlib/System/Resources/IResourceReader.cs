namespace System.Resources;

[Token(Token = "0x20004D7")]
public interface IResourceReader : IEnumerable, IDisposable
{

	[Token(Token = "0x6002492")]
	public void Close() { }

	[Token(Token = "0x6002493")]
	public IDictionaryEnumerator GetEnumerator() { }

}

