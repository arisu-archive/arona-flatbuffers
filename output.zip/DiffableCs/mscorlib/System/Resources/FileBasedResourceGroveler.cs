namespace System.Resources;

[Token(Token = "0x20004E2")]
internal class FileBasedResourceGroveler : IResourceGroveler
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40013F4")]
	private ResourceManagerMediator _mediator; //Field offset: 0x10

	[Address(RVA = "0x7307328", Offset = "0x7307328", Length = "0x30")]
	[Token(Token = "0x60024C0")]
	public FileBasedResourceGroveler(ResourceManagerMediator mediator) { }

	[Address(RVA = "0x73076FC", Offset = "0x73076FC", Length = "0x2DC")]
	[Token(Token = "0x60024C3")]
	private ResourceSet CreateResourceSet(string file) { }

	[Address(RVA = "0x7307640", Offset = "0x7307640", Length = "0xBC")]
	[Token(Token = "0x60024C2")]
	private string FindResourceFile(CultureInfo culture, string fileName) { }

	[Address(RVA = "0x7307358", Offset = "0x7307358", Length = "0x2E8")]
	[Token(Token = "0x60024C1")]
	public override ResourceSet GrovelForResourceSet(CultureInfo culture, Dictionary<String, ResourceSet> localResourceSets, bool tryParents, bool createIfNotExists, ref StackCrawlMark stackMark) { }

}

