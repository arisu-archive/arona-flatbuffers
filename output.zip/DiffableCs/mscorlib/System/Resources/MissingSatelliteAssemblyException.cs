namespace System.Resources;

[Token(Token = "0x20004D9")]
public class MissingSatelliteAssemblyException : SystemException
{
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x40013C9")]
	private string _cultureName; //Field offset: 0x90

	[Address(RVA = "0x7305880", Offset = "0x7305880", Length = "0x5C")]
	[Token(Token = "0x6002497")]
	public MissingSatelliteAssemblyException() { }

	[Address(RVA = "0x73058DC", Offset = "0x73058DC", Length = "0x3C")]
	[Token(Token = "0x6002498")]
	public MissingSatelliteAssemblyException(string message, string cultureName) { }

	[Address(RVA = "0x7305918", Offset = "0x7305918", Length = "0x8")]
	[Token(Token = "0x6002499")]
	protected MissingSatelliteAssemblyException(SerializationInfo info, StreamingContext context) { }

}

