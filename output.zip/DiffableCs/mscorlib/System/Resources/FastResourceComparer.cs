namespace System.Resources;

[Token(Token = "0x20004E1")]
internal sealed class FastResourceComparer : IComparer, IEqualityComparer, IComparer<String>, IEqualityComparer<String>
{
	[Token(Token = "0x40013F3")]
	internal static readonly FastResourceComparer Default; //Field offset: 0x0

	[Address(RVA = "0x73072B8", Offset = "0x73072B8", Length = "0x70")]
	[Token(Token = "0x60024BF")]
	private static FastResourceComparer() { }

	[Address(RVA = "0x73072B0", Offset = "0x73072B0", Length = "0x8")]
	[Token(Token = "0x60024BE")]
	public FastResourceComparer() { }

	[Address(RVA = "0x7306FAC", Offset = "0x7306FAC", Length = "0x9C")]
	[Token(Token = "0x60024B7")]
	public override int Compare(object a, object b) { }

	[Address(RVA = "0x7307048", Offset = "0x7307048", Length = "0x10")]
	[Token(Token = "0x60024B8")]
	public override int Compare(string a, string b) { }

	[Address(RVA = "0x7307104", Offset = "0x7307104", Length = "0xB0")]
	[Token(Token = "0x60024BB")]
	public static int CompareOrdinal(string a, Byte[] bytes, int bCharLength) { }

	[Address(RVA = "0x73071B4", Offset = "0x73071B4", Length = "0x74")]
	[Token(Token = "0x60024BC")]
	public static int CompareOrdinal(Byte[] bytes, int aCharLength, string b) { }

	[Address(RVA = "0x7307228", Offset = "0x7307228", Length = "0x88")]
	[Token(Token = "0x60024BD")]
	internal static int CompareOrdinal(Byte* a, int byteLen, string b) { }

	[Address(RVA = "0x7307058", Offset = "0x7307058", Length = "0x10")]
	[Token(Token = "0x60024B9")]
	public override bool Equals(string a, string b) { }

	[Address(RVA = "0x7307068", Offset = "0x7307068", Length = "0x9C")]
	[Token(Token = "0x60024BA")]
	public override bool Equals(object a, object b) { }

	[Address(RVA = "0x7306E60", Offset = "0x7306E60", Length = "0x8C")]
	[Token(Token = "0x60024B4")]
	public override int GetHashCode(object key) { }

	[Address(RVA = "0x7306F58", Offset = "0x7306F58", Length = "0x54")]
	[Token(Token = "0x60024B5")]
	public override int GetHashCode(string key) { }

	[Address(RVA = "0x7306EEC", Offset = "0x7306EEC", Length = "0x6C")]
	[Token(Token = "0x60024B6")]
	internal static int HashFunction(string key) { }

}

