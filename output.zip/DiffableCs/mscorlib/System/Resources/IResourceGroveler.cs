namespace System.Resources;

[Token(Token = "0x20004E3")]
internal interface IResourceGroveler
{

	[Token(Token = "0x60024C4")]
	public ResourceSet GrovelForResourceSet(CultureInfo culture, Dictionary<String, ResourceSet> localResourceSets, bool tryParents, bool createIfNotExists, ref StackCrawlMark stackMark) { }

}

