namespace System.Resources;

[Token(Token = "0x20004DB")]
internal class ResourceFallbackManager : IEnumerable<CultureInfo>, IEnumerable
{
	[CompilerGenerated]
	[Token(Token = "0x20004DC")]
	private sealed class <GetEnumerator>d__5 : IEnumerator<CultureInfo>, IDisposable, IEnumerator
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x40013CF")]
		private int <>1__state; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x40013D0")]
		private CultureInfo <>2__current; //Field offset: 0x18
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40013D1")]
		public ResourceFallbackManager <>4__this; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x40013D2")]
		private bool <reachedNeutralResourcesCulture>5__2; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x40013D3")]
		private CultureInfo <currentCulture>5__3; //Field offset: 0x30

		[Token(Token = "0x170004D1")]
		private override CultureInfo System.Collections.Generic.IEnumerator<System.Globalization.CultureInfo>.Current
		{
			[Address(RVA = "0x7305D14", Offset = "0x7305D14", Length = "0x8")]
			[DebuggerHidden]
			[Token(Token = "0x60024A3")]
			private get { } //Length: 8
		}

		[Token(Token = "0x170004D2")]
		private override object System.Collections.IEnumerator.Current
		{
			[Address(RVA = "0x7305D5C", Offset = "0x7305D5C", Length = "0x8")]
			[DebuggerHidden]
			[Token(Token = "0x60024A5")]
			private get { } //Length: 8
		}

		[Address(RVA = "0x7305AE4", Offset = "0x7305AE4", Length = "0x28")]
		[DebuggerHidden]
		[Token(Token = "0x60024A0")]
		public <GetEnumerator>d__5(int <>1__state) { }

		[Address(RVA = "0x7305B10", Offset = "0x7305B10", Length = "0x204")]
		[Token(Token = "0x60024A2")]
		private override bool MoveNext() { }

		[Address(RVA = "0x7305D14", Offset = "0x7305D14", Length = "0x8")]
		[DebuggerHidden]
		[Token(Token = "0x60024A3")]
		private override CultureInfo System.Collections.Generic.IEnumerator<System.Globalization.CultureInfo>.get_Current() { }

		[Address(RVA = "0x7305D5C", Offset = "0x7305D5C", Length = "0x8")]
		[DebuggerHidden]
		[Token(Token = "0x60024A5")]
		private override object System.Collections.IEnumerator.get_Current() { }

		[Address(RVA = "0x7305D1C", Offset = "0x7305D1C", Length = "0x40")]
		[DebuggerHidden]
		[Token(Token = "0x60024A4")]
		private override void System.Collections.IEnumerator.Reset() { }

		[Address(RVA = "0x7305B0C", Offset = "0x7305B0C", Length = "0x4")]
		[DebuggerHidden]
		[Token(Token = "0x60024A1")]
		private override void System.IDisposable.Dispose() { }

	}

	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40013CC")]
	private CultureInfo m_startingCulture; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40013CD")]
	private CultureInfo m_neutralResourcesCulture; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40013CE")]
	private bool m_useParents; //Field offset: 0x20

	[Address(RVA = "0x73059B8", Offset = "0x73059B8", Length = "0xB4")]
	[Token(Token = "0x600249D")]
	internal ResourceFallbackManager(CultureInfo startingCulture, CultureInfo neutralResourcesCulture, bool useParents) { }

	[Address(RVA = "0x7305A70", Offset = "0x7305A70", Length = "0x74")]
	[IteratorStateMachine(typeof(<GetEnumerator>d__5))]
	[Token(Token = "0x600249F")]
	public override IEnumerator<CultureInfo> GetEnumerator() { }

	[Address(RVA = "0x7305A6C", Offset = "0x7305A6C", Length = "0x4")]
	[Token(Token = "0x600249E")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

