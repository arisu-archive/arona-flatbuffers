namespace System.Resources;

[Token(Token = "0x20004E4")]
internal class ManifestBasedResourceGroveler : IResourceGroveler
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40013F5")]
	private ResourceManagerMediator _mediator; //Field offset: 0x10

	[Address(RVA = "0x73079D8", Offset = "0x73079D8", Length = "0x30")]
	[Token(Token = "0x60024C5")]
	public ManifestBasedResourceGroveler(ResourceManagerMediator mediator) { }

	[Address(RVA = "0x7309370", Offset = "0x7309370", Length = "0x15C")]
	[Token(Token = "0x60024CD")]
	private bool CanUseDefaultResourceClasses(string readerTypeName, string resSetTypeName) { }

	[Address(RVA = "0x73094CC", Offset = "0x73094CC", Length = "0x390")]
	[Token(Token = "0x60024CB")]
	private Stream CaseInsensitiveManifestResourceStreamLookup(RuntimeAssembly satellite, string name) { }

	[Address(RVA = "0x7308394", Offset = "0x7308394", Length = "0x938")]
	[Token(Token = "0x60024C9")]
	internal ResourceSet CreateResourceSet(Stream store, Assembly assembly) { }

	[Address(RVA = "0x73082B0", Offset = "0x73082B0", Length = "0xE4")]
	[Token(Token = "0x60024CA")]
	private Stream GetManifestResourceStream(RuntimeAssembly satellite, string fileName, ref StackCrawlMark stackMark) { }

	[Address(RVA = "0x7308FC0", Offset = "0x7308FC0", Length = "0x32C")]
	[Token(Token = "0x60024C8")]
	internal static CultureInfo GetNeutralResourcesLanguage(Assembly a, ref UltimateResourceFallbackLocation fallbackLocation) { }

	[Address(RVA = "0x73092EC", Offset = "0x73092EC", Length = "0x84")]
	[Token(Token = "0x60024D1")]
	private static bool GetNeutralResourcesLanguageAttribute(Assembly assembly, ref string cultureName, ref short fallbackLocation) { }

	[Address(RVA = "0x7307DB8", Offset = "0x7307DB8", Length = "0x190")]
	[Token(Token = "0x60024CC")]
	private RuntimeAssembly GetSatelliteAssembly(CultureInfo lookForCulture, ref StackCrawlMark stackMark) { }

	[Address(RVA = "0x730985C", Offset = "0x730985C", Length = "0x68")]
	[Token(Token = "0x60024CE")]
	private string GetSatelliteAssemblyName() { }

	[Address(RVA = "0x7307A08", Offset = "0x7307A08", Length = "0x2A0")]
	[Token(Token = "0x60024C6")]
	public override ResourceSet GrovelForResourceSet(CultureInfo culture, Dictionary<String, ResourceSet> localResourceSets, bool tryParents, bool createIfNotExists, ref StackCrawlMark stackMark) { }

	[Address(RVA = "0x7308CCC", Offset = "0x7308CCC", Length = "0x2F4")]
	[Token(Token = "0x60024D0")]
	private void HandleResourceStreamMissing(string fileName) { }

	[Address(RVA = "0x7307F48", Offset = "0x7307F48", Length = "0x368")]
	[Token(Token = "0x60024CF")]
	private void HandleSatelliteMissing() { }

	[Address(RVA = "0x7307CA8", Offset = "0x7307CA8", Length = "0x110")]
	[Token(Token = "0x60024C7")]
	private CultureInfo UltimateFallbackFixup(CultureInfo lookForCulture) { }

}

