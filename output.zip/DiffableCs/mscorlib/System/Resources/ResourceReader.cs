namespace System.Resources;

[ComVisible(True)]
[Token(Token = "0x20004E9")]
public sealed class ResourceReader : IResourceReader, IEnumerable, IDisposable
{
	[Token(Token = "0x20004EA")]
	public sealed class ResourceEnumerator : IDictionaryEnumerator, IEnumerator
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001420")]
		private ResourceReader _reader; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4001421")]
		private bool _currentIsValid; //Field offset: 0x18
		[FieldOffset(Offset = "0x1C")]
		[Token(Token = "0x4001422")]
		private int _currentName; //Field offset: 0x1C
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4001423")]
		private int _dataPosition; //Field offset: 0x20

		[Token(Token = "0x170004E5")]
		public override object Current
		{
			[Address(RVA = "0x730FC2C", Offset = "0x730FC2C", Length = "0x64")]
			[Token(Token = "0x6002519")]
			 get { } //Length: 100
		}

		[Token(Token = "0x170004E6")]
		internal int DataPosition
		{
			[Address(RVA = "0x730FFC0", Offset = "0x730FFC0", Length = "0x8")]
			[Token(Token = "0x600251A")]
			internal get { } //Length: 8
		}

		[Token(Token = "0x170004E7")]
		public override DictionaryEntry Entry
		{
			[Address(RVA = "0x730FC90", Offset = "0x730FC90", Length = "0x330")]
			[Token(Token = "0x600251B")]
			 get { } //Length: 816
		}

		[Token(Token = "0x170004E4")]
		public override object Key
		{
			[Address(RVA = "0x730FB74", Offset = "0x730FB74", Length = "0xB8")]
			[Token(Token = "0x6002518")]
			 get { } //Length: 184
		}

		[Token(Token = "0x170004E8")]
		public override object Value
		{
			[Address(RVA = "0x730FFC8", Offset = "0x730FFC8", Length = "0xB0")]
			[Token(Token = "0x600251C")]
			 get { } //Length: 176
		}

		[Address(RVA = "0x730C5A0", Offset = "0x730C5A0", Length = "0x44")]
		[Token(Token = "0x6002516")]
		internal ResourceEnumerator(ResourceReader reader) { }

		[Address(RVA = "0x730FC2C", Offset = "0x730FC2C", Length = "0x64")]
		[Token(Token = "0x6002519")]
		public override object get_Current() { }

		[Address(RVA = "0x730FFC0", Offset = "0x730FFC0", Length = "0x8")]
		[Token(Token = "0x600251A")]
		internal int get_DataPosition() { }

		[Address(RVA = "0x730FC90", Offset = "0x730FC90", Length = "0x330")]
		[Token(Token = "0x600251B")]
		public override DictionaryEntry get_Entry() { }

		[Address(RVA = "0x730FB74", Offset = "0x730FB74", Length = "0xB8")]
		[Token(Token = "0x6002518")]
		public override object get_Key() { }

		[Address(RVA = "0x730FFC8", Offset = "0x730FFC8", Length = "0xB0")]
		[Token(Token = "0x600251C")]
		public override object get_Value() { }

		[Address(RVA = "0x730FB2C", Offset = "0x730FB2C", Length = "0x48")]
		[Token(Token = "0x6002517")]
		public override bool MoveNext() { }

		[Address(RVA = "0x7310078", Offset = "0x7310078", Length = "0x8C")]
		[Token(Token = "0x600251D")]
		public override void Reset() { }

	}

	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001412")]
	private BinaryReader _store; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001413")]
	internal Dictionary<String, ResourceLocator> _resCache; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4001414")]
	private long _nameSectionOffset; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4001415")]
	private long _dataSectionOffset; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4001416")]
	private Int32[] _nameHashes; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4001417")]
	private Int32* _nameHashesPtr; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4001418")]
	private Int32[] _namePositions; //Field offset: 0x40
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4001419")]
	private Int32* _namePositionsPtr; //Field offset: 0x48
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x400141A")]
	private RuntimeType[] _typeTable; //Field offset: 0x50
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x400141B")]
	private Int32[] _typeNamePositions; //Field offset: 0x58
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x400141C")]
	private BinaryFormatter _objFormatter; //Field offset: 0x60
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x400141D")]
	private int _numResources; //Field offset: 0x68
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x400141E")]
	private UnmanagedMemoryStream _ums; //Field offset: 0x70
	[FieldOffset(Offset = "0x78")]
	[Token(Token = "0x400141F")]
	private int _version; //Field offset: 0x78

	[Address(RVA = "0x730E020", Offset = "0x730E020", Length = "0x884")]
	[Token(Token = "0x600250F")]
	private object _LoadObjectV1(int pos) { }

	[Address(RVA = "0x730EA74", Offset = "0x730EA74", Length = "0x768")]
	[Token(Token = "0x6002511")]
	private object _LoadObjectV2(int pos, out ResourceTypeCode typeCode) { }

	[Address(RVA = "0x730F1DC", Offset = "0x730F1DC", Length = "0x6E0")]
	[Token(Token = "0x6002514")]
	private void _ReadResources() { }

	[Address(RVA = "0x730BF1C", Offset = "0x730BF1C", Length = "0x144")]
	[Token(Token = "0x60024FC")]
	internal ResourceReader(Stream stream, Dictionary<String, ResourceLocator> resCache) { }

	[Address(RVA = "0x730CC08", Offset = "0x730CC08", Length = "0x87C")]
	[Token(Token = "0x6002509")]
	private string AllocateStringForNameIndex(int index, out int dataOffset) { }

	[Address(RVA = "0x730C1E0", Offset = "0x730C1E0", Length = "0x8")]
	[Token(Token = "0x60024FD")]
	public override void Close() { }

	[Address(RVA = "0x730C9F8", Offset = "0x730C9F8", Length = "0x210")]
	[Token(Token = "0x6002508")]
	private bool CompareStringEqualsName(string name) { }

	[Address(RVA = "0x730E8A4", Offset = "0x730E8A4", Length = "0x1D0")]
	[Token(Token = "0x6002512")]
	private object DeserializeObject(int typeIndex) { }

	[Address(RVA = "0x730C290", Offset = "0x730C290", Length = "0x8")]
	[Token(Token = "0x60024FE")]
	public override void Dispose() { }

	[Address(RVA = "0x730C1E8", Offset = "0x730C1E8", Length = "0xA8")]
	[Token(Token = "0x60024FF")]
	private void Dispose(bool disposing) { }

	[Address(RVA = "0x730C664", Offset = "0x730C664", Length = "0x394")]
	[Token(Token = "0x6002507")]
	internal int FindPosForResource(string name) { }

	[Address(RVA = "0x730DBB8", Offset = "0x730DBB8", Length = "0x3A4")]
	[Token(Token = "0x6002515")]
	private RuntimeType FindType(int typeIndex) { }

	[Address(RVA = "0x730C4C0", Offset = "0x730C4C0", Length = "0xE0")]
	[Token(Token = "0x6002505")]
	public override IDictionaryEnumerator GetEnumerator() { }

	[Address(RVA = "0x730C5E4", Offset = "0x730C5E4", Length = "0x80")]
	[Token(Token = "0x6002506")]
	internal ResourceEnumerator GetEnumeratorInternal() { }

	[Address(RVA = "0x730C358", Offset = "0x730C358", Length = "0x44")]
	[Token(Token = "0x6002502")]
	private int GetNameHash(int index) { }

	[Address(RVA = "0x730C39C", Offset = "0x730C39C", Length = "0x120")]
	[Token(Token = "0x6002503")]
	private int GetNamePosition(int index) { }

	[Address(RVA = "0x730D484", Offset = "0x730D484", Length = "0x288")]
	[Token(Token = "0x600250A")]
	private object GetValueForNameIndex(int index) { }

	[Address(RVA = "0x730DF88", Offset = "0x730DF88", Length = "0x98")]
	[Token(Token = "0x600250D")]
	internal object LoadObject(int pos, out ResourceTypeCode typeCode) { }

	[Address(RVA = "0x730DF5C", Offset = "0x730DF5C", Length = "0x2C")]
	[Token(Token = "0x600250C")]
	internal object LoadObject(int pos) { }

	[Address(RVA = "0x730D70C", Offset = "0x730D70C", Length = "0x100")]
	[Token(Token = "0x600250E")]
	internal object LoadObjectV1(int pos) { }

	[Address(RVA = "0x730D80C", Offset = "0x730D80C", Length = "0x100")]
	[Token(Token = "0x6002510")]
	internal object LoadObjectV2(int pos, out ResourceTypeCode typeCode) { }

	[Address(RVA = "0x730D90C", Offset = "0x730D90C", Length = "0x2AC")]
	[Token(Token = "0x600250B")]
	internal string LoadString(int pos) { }

	[Address(RVA = "0x730C060", Offset = "0x730C060", Length = "0x180")]
	[Token(Token = "0x6002513")]
	private void ReadResources() { }

	[Address(RVA = "0x730C298", Offset = "0x730C298", Length = "0x8")]
	[Token(Token = "0x6002500")]
	internal static int ReadUnalignedI4(Int32* p) { }

	[Address(RVA = "0x730C2A0", Offset = "0x730C2A0", Length = "0xB8")]
	[Token(Token = "0x6002501")]
	private void SkipString() { }

	[Address(RVA = "0x730C4BC", Offset = "0x730C4BC", Length = "0x4")]
	[Token(Token = "0x6002504")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

