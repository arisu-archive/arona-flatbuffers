namespace System.Resources;

[ComVisible(True)]
[Token(Token = "0x20004EB")]
public class ResourceSet : IDisposable, IEnumerable
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001424")]
	protected IResourceReader Reader; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001425")]
	protected Hashtable Table; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4001426")]
	private Hashtable _caseInsensitiveTable; //Field offset: 0x20

	[Address(RVA = "0x7310104", Offset = "0x7310104", Length = "0x1C")]
	[Token(Token = "0x600251E")]
	protected ResourceSet() { }

	[Address(RVA = "0x7310188", Offset = "0x7310188", Length = "0x8")]
	[Token(Token = "0x600251F")]
	internal ResourceSet(bool junk) { }

	[Address(RVA = "0x7310120", Offset = "0x7310120", Length = "0x68")]
	[Token(Token = "0x6002520")]
	private void CommonInit() { }

	[Address(RVA = "0x7310190", Offset = "0x7310190", Length = "0xE4")]
	[Token(Token = "0x6002521")]
	protected override void Dispose(bool disposing) { }

	[Address(RVA = "0x7310274", Offset = "0x7310274", Length = "0x10")]
	[Token(Token = "0x6002522")]
	public override void Dispose() { }

	[Address(RVA = "0x7310750", Offset = "0x7310750", Length = "0x2DC")]
	[Token(Token = "0x600252B")]
	private object GetCaseInsensitiveObjectInternal(string name) { }

	[Address(RVA = "0x7310284", Offset = "0x7310284", Length = "0x4")]
	[ComVisible(False)]
	[Token(Token = "0x6002523")]
	public override IDictionaryEnumerator GetEnumerator() { }

	[Address(RVA = "0x7310288", Offset = "0x7310288", Length = "0x84")]
	[Token(Token = "0x6002525")]
	private IDictionaryEnumerator GetEnumeratorHelper() { }

	[Address(RVA = "0x7310A2C", Offset = "0x7310A2C", Length = "0x4")]
	[Token(Token = "0x6002528")]
	public override object GetObject(string name) { }

	[Address(RVA = "0x7310A30", Offset = "0x7310A30", Length = "0x40")]
	[Token(Token = "0x6002529")]
	public override object GetObject(string name, bool ignoreCase) { }

	[Address(RVA = "0x7310478", Offset = "0x7310478", Length = "0xD4")]
	[Token(Token = "0x600252A")]
	private object GetObjectInternal(string name) { }

	[Address(RVA = "0x7310310", Offset = "0x7310310", Length = "0x168")]
	[Token(Token = "0x6002526")]
	public override string GetString(string name) { }

	[Address(RVA = "0x731054C", Offset = "0x731054C", Length = "0x204")]
	[Token(Token = "0x6002527")]
	public override string GetString(string name, bool ignoreCase) { }

	[Address(RVA = "0x731030C", Offset = "0x731030C", Length = "0x4")]
	[Token(Token = "0x6002524")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

