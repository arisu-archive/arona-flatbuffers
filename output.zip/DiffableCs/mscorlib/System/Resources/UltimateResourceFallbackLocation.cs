namespace System.Resources;

[Token(Token = "0x20004E0")]
public enum UltimateResourceFallbackLocation
{
	MainAssembly = 0,
	Satellite = 1,
}

