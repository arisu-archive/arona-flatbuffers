namespace System.Resources;

[AttributeUsage(AttributeTargets::Assembly (1), AllowMultiple = False)]
[Token(Token = "0x20004DA")]
public sealed class NeutralResourcesLanguageAttribute : Attribute
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40013CA")]
	private readonly string <CultureName>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40013CB")]
	private readonly UltimateResourceFallbackLocation <Location>k__BackingField; //Field offset: 0x18

	[Token(Token = "0x170004CF")]
	public string CultureName
	{
		[Address(RVA = "0x73059A8", Offset = "0x73059A8", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x600249B")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170004D0")]
	public UltimateResourceFallbackLocation Location
	{
		[Address(RVA = "0x73059B0", Offset = "0x73059B0", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x600249C")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x7305920", Offset = "0x7305920", Length = "0x88")]
	[Token(Token = "0x600249A")]
	public NeutralResourcesLanguageAttribute(string cultureName) { }

	[Address(RVA = "0x73059A8", Offset = "0x73059A8", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x600249B")]
	public string get_CultureName() { }

	[Address(RVA = "0x73059B0", Offset = "0x73059B0", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x600249C")]
	public UltimateResourceFallbackLocation get_Location() { }

}

