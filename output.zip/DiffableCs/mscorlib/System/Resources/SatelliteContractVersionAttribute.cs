namespace System.Resources;

[AttributeUsage(AttributeTargets::Assembly (1), AllowMultiple = False)]
[Token(Token = "0x20004DF")]
public sealed class SatelliteContractVersionAttribute : Attribute
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40013EF")]
	private readonly string <Version>k__BackingField; //Field offset: 0x10

	[Token(Token = "0x170004D3")]
	public string Version
	{
		[Address(RVA = "0x7306E58", Offset = "0x7306E58", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x60024B3")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x7306DD8", Offset = "0x7306DD8", Length = "0x80")]
	[Token(Token = "0x60024B2")]
	public SatelliteContractVersionAttribute(string version) { }

	[Address(RVA = "0x7306E58", Offset = "0x7306E58", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x60024B3")]
	public string get_Version() { }

}

