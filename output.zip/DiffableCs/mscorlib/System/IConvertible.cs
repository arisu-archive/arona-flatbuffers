namespace System;

[CLSCompliant(False)]
[Token(Token = "0x20000D0")]
public interface IConvertible
{

	[Token(Token = "0x60007C4")]
	public TypeCode GetTypeCode() { }

	[Token(Token = "0x60007C5")]
	public bool ToBoolean(IFormatProvider provider) { }

	[Token(Token = "0x60007C8")]
	public byte ToByte(IFormatProvider provider) { }

	[Token(Token = "0x60007C6")]
	public char ToChar(IFormatProvider provider) { }

	[Token(Token = "0x60007D2")]
	public DateTime ToDateTime(IFormatProvider provider) { }

	[Token(Token = "0x60007D1")]
	public decimal ToDecimal(IFormatProvider provider) { }

	[Token(Token = "0x60007D0")]
	public double ToDouble(IFormatProvider provider) { }

	[Token(Token = "0x60007C9")]
	public short ToInt16(IFormatProvider provider) { }

	[Token(Token = "0x60007CB")]
	public int ToInt32(IFormatProvider provider) { }

	[Token(Token = "0x60007CD")]
	public long ToInt64(IFormatProvider provider) { }

	[Token(Token = "0x60007C7")]
	public sbyte ToSByte(IFormatProvider provider) { }

	[Token(Token = "0x60007CF")]
	public float ToSingle(IFormatProvider provider) { }

	[Token(Token = "0x60007D3")]
	public string ToString(IFormatProvider provider) { }

	[Token(Token = "0x60007D4")]
	public object ToType(Type conversionType, IFormatProvider provider) { }

	[Token(Token = "0x60007CA")]
	public ushort ToUInt16(IFormatProvider provider) { }

	[Token(Token = "0x60007CC")]
	public uint ToUInt32(IFormatProvider provider) { }

	[Token(Token = "0x60007CE")]
	public ulong ToUInt64(IFormatProvider provider) { }

}

