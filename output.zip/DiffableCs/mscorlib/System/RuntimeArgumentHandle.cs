namespace System;

[IsByRefLike]
[Token(Token = "0x20001A8")]
public struct RuntimeArgumentHandle
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40006F5")]
	internal IntPtr args; //Field offset: 0x0

}

