namespace System;

[Token(Token = "0x200015B")]
public static class AppContext
{
	[Flags]
	[Token(Token = "0x200015C")]
	private enum SwitchValueState
	{
		HasFalseValue = 1,
		HasTrueValue = 2,
		HasLookedForOverride = 4,
		UnknownValue = 8,
	}

	[Token(Token = "0x400053C")]
	private static readonly Dictionary<String, SwitchValueState> s_switchMap; //Field offset: 0x0
	[Token(Token = "0x400053D")]
	private static bool s_defaultsInitialized; //Field offset: 0x8

	[Address(RVA = "0x742788C", Offset = "0x742788C", Length = "0xAC")]
	[Token(Token = "0x6000E31")]
	private static AppContext() { }

	[Address(RVA = "0x7427354", Offset = "0x7427354", Length = "0x168")]
	[Token(Token = "0x6000E2F")]
	private static void InitializeDefaultSwitchValues() { }

	[Address(RVA = "0x74274BC", Offset = "0x74274BC", Length = "0x3D0")]
	[Token(Token = "0x6000E30")]
	public static bool TryGetSwitch(string switchName, out bool isEnabled) { }

}

