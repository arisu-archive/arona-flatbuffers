namespace System;

[Token(Token = "0x2000142")]
public sealed class ConsoleCancelEventArgs : EventArgs
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4000474")]
	private readonly ConsoleSpecialKey _type; //Field offset: 0x10
	[CompilerGenerated]
	[FieldOffset(Offset = "0x14")]
	[Token(Token = "0x4000475")]
	private bool <Cancel>k__BackingField; //Field offset: 0x14

	[Token(Token = "0x1700014A")]
	public bool Cancel
	{
		[Address(RVA = "0x741ED30", Offset = "0x741ED30", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6000CFD")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x741ECC4", Offset = "0x741ECC4", Length = "0x6C")]
	[Token(Token = "0x6000CFC")]
	internal ConsoleCancelEventArgs(ConsoleSpecialKey type) { }

	[Address(RVA = "0x741ED38", Offset = "0x741ED38", Length = "0x38")]
	[Token(Token = "0x6000CFE")]
	internal ConsoleCancelEventArgs() { }

	[Address(RVA = "0x741ED30", Offset = "0x741ED30", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6000CFD")]
	public bool get_Cancel() { }

}

