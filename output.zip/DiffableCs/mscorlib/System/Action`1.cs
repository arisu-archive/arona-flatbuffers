namespace System;

[Token(Token = "0x2000076")]
public sealed class Action : MulticastDelegate
{

	[Address(RVA = "0x4DE5A88", Offset = "0x4DE5A88", Length = "0xD8")]
	[Token(Token = "0x60003B4")]
	public Action`1(object object, IntPtr method) { }

	[Address(RVA = "0x4DE5B60", Offset = "0x4DE5B60", Length = "0x14")]
	[Token(Token = "0x60003B5")]
	public override void Invoke(T obj) { }

}

