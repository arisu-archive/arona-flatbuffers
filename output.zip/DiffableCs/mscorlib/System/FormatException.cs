namespace System;

[Token(Token = "0x20000B2")]
public class FormatException : SystemException
{

	[Address(RVA = "0x73E318C", Offset = "0x73E318C", Length = "0x5C")]
	[Token(Token = "0x60006D4")]
	public FormatException() { }

	[Address(RVA = "0x73E31E8", Offset = "0x73E31E8", Length = "0x24")]
	[Token(Token = "0x60006D5")]
	public FormatException(string message) { }

	[Address(RVA = "0x73E320C", Offset = "0x73E320C", Length = "0x24")]
	[Token(Token = "0x60006D6")]
	public FormatException(string message, Exception innerException) { }

	[Address(RVA = "0x73E3230", Offset = "0x73E3230", Length = "0x8")]
	[Token(Token = "0x60006D7")]
	protected FormatException(SerializationInfo info, StreamingContext context) { }

}

