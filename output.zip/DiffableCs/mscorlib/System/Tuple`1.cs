namespace System;

[Token(Token = "0x2000120")]
public class Tuple : IStructuralEquatable, IStructuralComparable, IComparable, ITupleInternal, ITuple
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40003FB")]
	private readonly T1 m_Item1; //Field offset: 0x0

	[Token(Token = "0x170000BF")]
	public T1 Item1
	{
		[Address(RVA = "0x5F7E9F8", Offset = "0x5F7E9F8", Length = "0x8")]
		[Token(Token = "0x6000ABC")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170000C1")]
	private override object System.Runtime.CompilerServices.ITuple.Item
	{
		[Address(RVA = "0x5F7F1DC", Offset = "0x5F7F1DC", Length = "0x5C")]
		[Token(Token = "0x6000AC8")]
		private get { } //Length: 92
	}

	[Token(Token = "0x170000C0")]
	private override int System.Runtime.CompilerServices.ITuple.Length
	{
		[Address(RVA = "0x5F7F1D4", Offset = "0x5F7F1D4", Length = "0x8")]
		[Token(Token = "0x6000AC7")]
		private get { } //Length: 8
	}

	[Address(RVA = "0x5F7EA00", Offset = "0x5F7EA00", Length = "0x30")]
	[Token(Token = "0x6000ABD")]
	public Tuple`1(T1 item1) { }

	[Address(RVA = "0x5F7EA30", Offset = "0x5F7EA30", Length = "0xD0")]
	[Token(Token = "0x6000ABE")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x5F7E9F8", Offset = "0x5F7E9F8", Length = "0x8")]
	[Token(Token = "0x6000ABC")]
	public T1 get_Item1() { }

	[Address(RVA = "0x5F7EE9C", Offset = "0x5F7EE9C", Length = "0xC4")]
	[Token(Token = "0x6000AC2")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x5F7ECE8", Offset = "0x5F7ECE8", Length = "0x1B4")]
	[Token(Token = "0x6000AC1")]
	private override int System.Collections.IStructuralComparable.CompareTo(object other, IComparer comparer) { }

	[Address(RVA = "0x5F7EB00", Offset = "0x5F7EB00", Length = "0x118")]
	[Token(Token = "0x6000ABF")]
	private override bool System.Collections.IStructuralEquatable.Equals(object other, IEqualityComparer comparer) { }

	[Address(RVA = "0x5F7EF60", Offset = "0x5F7EF60", Length = "0xAC")]
	[Token(Token = "0x6000AC3")]
	private override int System.Collections.IStructuralEquatable.GetHashCode(IEqualityComparer comparer) { }

	[Address(RVA = "0x5F7EC18", Offset = "0x5F7EC18", Length = "0xD0")]
	[Token(Token = "0x6000AC0")]
	private override int System.IComparable.CompareTo(object obj) { }

	[Address(RVA = "0x5F7F00C", Offset = "0x5F7F00C", Length = "0xA8")]
	[Token(Token = "0x6000AC4")]
	private override int System.ITupleInternal.GetHashCode(IEqualityComparer comparer) { }

	[Address(RVA = "0x5F7F190", Offset = "0x5F7F190", Length = "0x44")]
	[Token(Token = "0x6000AC6")]
	private override string System.ITupleInternal.ToString(StringBuilder sb) { }

	[Address(RVA = "0x5F7F1DC", Offset = "0x5F7F1DC", Length = "0x5C")]
	[Token(Token = "0x6000AC8")]
	private override object System.Runtime.CompilerServices.ITuple.get_Item(int index) { }

	[Address(RVA = "0x5F7F1D4", Offset = "0x5F7F1D4", Length = "0x8")]
	[Token(Token = "0x6000AC7")]
	private override int System.Runtime.CompilerServices.ITuple.get_Length() { }

	[Address(RVA = "0x5F7F0B4", Offset = "0x5F7F0B4", Length = "0xDC")]
	[Token(Token = "0x6000AC5")]
	public virtual string ToString() { }

}

