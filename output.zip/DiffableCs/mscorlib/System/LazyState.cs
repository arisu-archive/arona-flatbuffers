namespace System;

[Token(Token = "0x20000E3")]
internal enum LazyState
{
	NoneViaConstructor = 0,
	NoneViaFactory = 1,
	NoneException = 2,
	PublicationOnlyViaConstructor = 3,
	PublicationOnlyViaFactory = 4,
	PublicationOnlyWait = 5,
	PublicationOnlyException = 6,
	ExecutionAndPublicationViaConstructor = 7,
	ExecutionAndPublicationViaFactory = 8,
	ExecutionAndPublicationException = 9,
}

