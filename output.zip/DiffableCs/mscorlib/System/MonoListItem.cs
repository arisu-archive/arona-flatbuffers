namespace System;

[Token(Token = "0x20001A2")]
internal sealed class MonoListItem
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40006E9")]
	private MonoListItem next; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40006EA")]
	private object data; //Field offset: 0x18

	[Address(RVA = "0x744F1C4", Offset = "0x744F1C4", Length = "0x4")]
	[Token(Token = "0x60010B1")]
	public MonoListItem() { }

}

