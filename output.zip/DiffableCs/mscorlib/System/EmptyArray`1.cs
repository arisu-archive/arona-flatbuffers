namespace System;

[Token(Token = "0x2000192")]
internal static class EmptyArray
{
	[Token(Token = "0x40006D2")]
	public static readonly T[] Value; //Field offset: 0x0

	[Address(RVA = "0x470AD50", Offset = "0x470AD50", Length = "0xA8")]
	[Token(Token = "0x6001074")]
	private static EmptyArray`1() { }

}

