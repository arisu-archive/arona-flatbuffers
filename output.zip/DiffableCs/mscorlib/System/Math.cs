namespace System;

[Token(Token = "0x20000E8")]
public static class Math
{
	[Token(Token = "0x400038B")]
	private static double doubleRoundLimit; //Field offset: 0x0
	[Token(Token = "0x400038C")]
	private static Double[] roundPower10Double; //Field offset: 0x8

	[Address(RVA = "0x73FD490", Offset = "0x73FD490", Length = "0xB4")]
	[Token(Token = "0x60008AF")]
	private static Math() { }

	[Address(RVA = "0x73FD444", Offset = "0x73FD444", Length = "0x8")]
	[Token(Token = "0x600089F")]
	public static float Abs(float value) { }

	[Address(RVA = "0x73FD43C", Offset = "0x73FD43C", Length = "0x8")]
	[Token(Token = "0x600089E")]
	public static double Abs(double value) { }

	[Address(RVA = "0x73FC30C", Offset = "0x73FC30C", Length = "0x64")]
	[Token(Token = "0x6000872")]
	public static int Abs(int value) { }

	[Address(RVA = "0x73FC424", Offset = "0x73FC424", Length = "0x84")]
	[Token(Token = "0x6000874")]
	public static decimal Abs(decimal value) { }

	[Address(RVA = "0x73FC3C0", Offset = "0x73FC3C0", Length = "0x64")]
	[Token(Token = "0x6000873")]
	public static long Abs(long value) { }

	[Address(RVA = "0x73FD44C", Offset = "0x73FD44C", Length = "0x4")]
	[Token(Token = "0x60008A0")]
	public static double Acos(double d) { }

	[Address(RVA = "0x73FD450", Offset = "0x73FD450", Length = "0x4")]
	[Token(Token = "0x60008A1")]
	public static double Asin(double d) { }

	[Address(RVA = "0x73FD454", Offset = "0x73FD454", Length = "0x4")]
	[Token(Token = "0x60008A2")]
	public static double Atan(double d) { }

	[Address(RVA = "0x73FD458", Offset = "0x73FD458", Length = "0x4")]
	[Token(Token = "0x60008A3")]
	public static double Atan2(double y, double x) { }

	[Address(RVA = "0x73FD45C", Offset = "0x73FD45C", Length = "0x8")]
	[Token(Token = "0x60008A4")]
	public static double Ceiling(double a) { }

	[Address(RVA = "0x73FC4E4", Offset = "0x73FC4E4", Length = "0x9C")]
	[Token(Token = "0x6000879")]
	public static int Clamp(int value, int min, int max) { }

	[Address(RVA = "0x73FC580", Offset = "0x73FC580", Length = "0x9C")]
	[Token(Token = "0x600087A")]
	public static long Clamp(long value, long min, long max) { }

	[Address(RVA = "0x73FD464", Offset = "0x73FD464", Length = "0x4")]
	[Token(Token = "0x60008A5")]
	public static double Cos(double d) { }

	[Address(RVA = "0x73FC4A8", Offset = "0x73FC4A8", Length = "0x14")]
	[Token(Token = "0x6000876")]
	public static int DivRem(int a, int b, out int result) { }

	[Address(RVA = "0x73FC4BC", Offset = "0x73FC4BC", Length = "0x14")]
	[Token(Token = "0x6000877")]
	public static long DivRem(long a, long b, out long result) { }

	[Address(RVA = "0x73FC4D0", Offset = "0x73FC4D0", Length = "0x14")]
	[Token(Token = "0x6000878")]
	internal static uint DivRem(uint a, uint b, out uint result) { }

	[Address(RVA = "0x73FD468", Offset = "0x73FD468", Length = "0x4")]
	[Token(Token = "0x60008A6")]
	public static double Exp(double d) { }

	[Address(RVA = "0x73FD46C", Offset = "0x73FD46C", Length = "0x8")]
	[Token(Token = "0x60008A7")]
	public static double Floor(double d) { }

	[Address(RVA = "0x73FC61C", Offset = "0x73FC61C", Length = "0x27C")]
	[Token(Token = "0x600087B")]
	public static double IEEERemainder(double x, double y) { }

	[Address(RVA = "0x73FC914", Offset = "0x73FC914", Length = "0x150")]
	[Token(Token = "0x600087C")]
	public static double Log(double a, double newBase) { }

	[Address(RVA = "0x73FD474", Offset = "0x73FD474", Length = "0x4")]
	[Token(Token = "0x60008A8")]
	public static double Log(double d) { }

	[Address(RVA = "0x73FD478", Offset = "0x73FD478", Length = "0x4")]
	[Token(Token = "0x60008A9")]
	public static double Log10(double d) { }

	[Address(RVA = "0x73FCA64", Offset = "0x73FCA64", Length = "0x14")]
	[NonVersionable]
	[Token(Token = "0x600087D")]
	public static byte Max(byte val1, byte val2) { }

	[Address(RVA = "0x73FCA78", Offset = "0x73FCA78", Length = "0x98")]
	[Token(Token = "0x600087E")]
	public static decimal Max(decimal val1, decimal val2) { }

	[Address(RVA = "0x73FCB98", Offset = "0x73FCB98", Length = "0xC")]
	[NonVersionable]
	[Token(Token = "0x6000881")]
	public static int Max(int val1, int val2) { }

	[Address(RVA = "0x73FCC58", Offset = "0x73FCC58", Length = "0xC")]
	[CLSCompliant(False)]
	[NonVersionable]
	[Token(Token = "0x6000887")]
	public static ulong Max(ulong val1, ulong val2) { }

	[Address(RVA = "0x73FCC4C", Offset = "0x73FCC4C", Length = "0xC")]
	[CLSCompliant(False)]
	[NonVersionable]
	[Token(Token = "0x6000886")]
	public static uint Max(uint val1, uint val2) { }

	[Address(RVA = "0x73FCC38", Offset = "0x73FCC38", Length = "0x14")]
	[CLSCompliant(False)]
	[NonVersionable]
	[Token(Token = "0x6000885")]
	public static ushort Max(ushort val1, ushort val2) { }

	[Address(RVA = "0x73FCB10", Offset = "0x73FCB10", Length = "0x74")]
	[Token(Token = "0x600087F")]
	public static double Max(double val1, double val2) { }

	[Address(RVA = "0x73FCBB0", Offset = "0x73FCBB0", Length = "0x14")]
	[CLSCompliant(False)]
	[NonVersionable]
	[Token(Token = "0x6000883")]
	public static sbyte Max(sbyte val1, sbyte val2) { }

	[Address(RVA = "0x73FCBA4", Offset = "0x73FCBA4", Length = "0xC")]
	[NonVersionable]
	[Token(Token = "0x6000882")]
	public static long Max(long val1, long val2) { }

	[Address(RVA = "0x73FCB84", Offset = "0x73FCB84", Length = "0x14")]
	[NonVersionable]
	[Token(Token = "0x6000880")]
	public static short Max(short val1, short val2) { }

	[Address(RVA = "0x73FCBC4", Offset = "0x73FCBC4", Length = "0x74")]
	[Token(Token = "0x6000884")]
	public static float Max(float val1, float val2) { }

	[Address(RVA = "0x73FCE58", Offset = "0x73FCE58", Length = "0xC")]
	[CLSCompliant(False)]
	[NonVersionable]
	[Token(Token = "0x6000892")]
	public static ulong Min(ulong val1, ulong val2) { }

	[Address(RVA = "0x73FCDC4", Offset = "0x73FCDC4", Length = "0x74")]
	[Token(Token = "0x600088F")]
	public static float Min(float val1, float val2) { }

	[Address(RVA = "0x73FCC64", Offset = "0x73FCC64", Length = "0x14")]
	[NonVersionable]
	[Token(Token = "0x6000888")]
	public static byte Min(byte val1, byte val2) { }

	[Address(RVA = "0x73FCC78", Offset = "0x73FCC78", Length = "0x98")]
	[Token(Token = "0x6000889")]
	public static decimal Min(decimal val1, decimal val2) { }

	[Address(RVA = "0x73FCD10", Offset = "0x73FCD10", Length = "0x74")]
	[Token(Token = "0x600088A")]
	public static double Min(double val1, double val2) { }

	[Address(RVA = "0x73FCD84", Offset = "0x73FCD84", Length = "0x14")]
	[NonVersionable]
	[Token(Token = "0x600088B")]
	public static short Min(short val1, short val2) { }

	[Address(RVA = "0x73FCD98", Offset = "0x73FCD98", Length = "0xC")]
	[NonVersionable]
	[Token(Token = "0x600088C")]
	public static int Min(int val1, int val2) { }

	[Address(RVA = "0x73FCDA4", Offset = "0x73FCDA4", Length = "0xC")]
	[NonVersionable]
	[Token(Token = "0x600088D")]
	public static long Min(long val1, long val2) { }

	[Address(RVA = "0x73FCDB0", Offset = "0x73FCDB0", Length = "0x14")]
	[CLSCompliant(False)]
	[NonVersionable]
	[Token(Token = "0x600088E")]
	public static sbyte Min(sbyte val1, sbyte val2) { }

	[Address(RVA = "0x73FCE4C", Offset = "0x73FCE4C", Length = "0xC")]
	[CLSCompliant(False)]
	[NonVersionable]
	[Token(Token = "0x6000891")]
	public static uint Min(uint val1, uint val2) { }

	[Address(RVA = "0x73FCE38", Offset = "0x73FCE38", Length = "0x14")]
	[CLSCompliant(False)]
	[NonVersionable]
	[Token(Token = "0x6000890")]
	public static ushort Min(ushort val1, ushort val2) { }

	[Address(RVA = "0x73FD2D0", Offset = "0x73FD2D0", Length = "0x4")]
	[Token(Token = "0x60008AE")]
	private static double ModF(double x, Double* intptr) { }

	[Address(RVA = "0x73FD47C", Offset = "0x73FD47C", Length = "0x4")]
	[Token(Token = "0x60008AA")]
	public static double Pow(double x, double y) { }

	[Address(RVA = "0x73FCF54", Offset = "0x73FCF54", Length = "0x68")]
	[Token(Token = "0x6000895")]
	public static double Round(double value, int digits) { }

	[Address(RVA = "0x73FCED0", Offset = "0x73FCED0", Length = "0x84")]
	[Token(Token = "0x6000894")]
	public static double Round(double a) { }

	[Address(RVA = "0x73FD268", Offset = "0x73FD268", Length = "0x68")]
	[Token(Token = "0x6000896")]
	public static double Round(double value, MidpointRounding mode) { }

	[Address(RVA = "0x73FCFBC", Offset = "0x73FCFBC", Length = "0x2AC")]
	[Token(Token = "0x6000897")]
	public static double Round(double value, int digits, MidpointRounding mode) { }

	[Address(RVA = "0x73FCE64", Offset = "0x73FCE64", Length = "0x6C")]
	[Token(Token = "0x6000893")]
	public static decimal Round(decimal d) { }

	[Address(RVA = "0x73FC898", Offset = "0x73FC898", Length = "0x7C")]
	[Token(Token = "0x6000898")]
	public static int Sign(double value) { }

	[Address(RVA = "0x73FD2E8", Offset = "0x73FD2E8", Length = "0x7C")]
	[Token(Token = "0x600089A")]
	public static int Sign(float value) { }

	[Address(RVA = "0x73FD2D4", Offset = "0x73FD2D4", Length = "0x14")]
	[Token(Token = "0x6000899")]
	public static int Sign(long value) { }

	[Address(RVA = "0x73FD480", Offset = "0x73FD480", Length = "0x4")]
	[Token(Token = "0x60008AB")]
	public static double Sin(double a) { }

	[Address(RVA = "0x73FD484", Offset = "0x73FD484", Length = "0x8")]
	[Token(Token = "0x60008AC")]
	public static double Sqrt(double d) { }

	[Address(RVA = "0x73FD48C", Offset = "0x73FD48C", Length = "0x4")]
	[Token(Token = "0x60008AD")]
	public static double Tan(double a) { }

	[Address(RVA = "0x73FC370", Offset = "0x73FC370", Length = "0x50")]
	[StackTraceHidden]
	[Token(Token = "0x6000875")]
	private static void ThrowAbsOverflow() { }

	[Address(RVA = "0x4376AE8", Offset = "0x4376AE8", Length = "0xB0")]
	[Token(Token = "0x600089D")]
	private static void ThrowMinMaxException(T min, T max) { }

	[Address(RVA = "0x73FD364", Offset = "0x73FD364", Length = "0x68")]
	[Token(Token = "0x600089B")]
	public static decimal Truncate(decimal d) { }

	[Address(RVA = "0x73FD3CC", Offset = "0x73FD3CC", Length = "0x70")]
	[Token(Token = "0x600089C")]
	public static double Truncate(double d) { }

}

