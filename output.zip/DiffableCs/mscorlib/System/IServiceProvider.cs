namespace System;

[Token(Token = "0x2000140")]
public interface IServiceProvider
{

	[Token(Token = "0x6000CF9")]
	public object GetService(Type serviceType) { }

}

