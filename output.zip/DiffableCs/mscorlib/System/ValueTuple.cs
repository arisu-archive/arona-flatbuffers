namespace System;

[Token(Token = "0x2000133")]
public struct ValueTuple : IEquatable<ValueTuple>, IStructuralEquatable, IStructuralComparable, IComparable, IComparable<ValueTuple>, IValueTupleInternal, ITuple
{

	[Token(Token = "0x17000131")]
	private override object System.Runtime.CompilerServices.ITuple.Item
	{
		[Address(RVA = "0x741D4DC", Offset = "0x741D4DC", Length = "0x40")]
		[Token(Token = "0x6000C59")]
		private get { } //Length: 64
	}

	[Token(Token = "0x17000130")]
	private override int System.Runtime.CompilerServices.ITuple.Length
	{
		[Address(RVA = "0x741D4D4", Offset = "0x741D4D4", Length = "0x8")]
		[Token(Token = "0x6000C58")]
		private get { } //Length: 8
	}

	[Address(RVA = "0x741D898", Offset = "0x741D898", Length = "0xC0")]
	[Token(Token = "0x6000C60")]
	internal static int CombineHashCodes(int h1, int h2, int h3, int h4, int h5, int h6, int h7, int h8) { }

	[Address(RVA = "0x741D740", Offset = "0x741D740", Length = "0xA8")]
	[Token(Token = "0x6000C5E")]
	internal static int CombineHashCodes(int h1, int h2, int h3, int h4, int h5, int h6) { }

	[Address(RVA = "0x741D6A8", Offset = "0x741D6A8", Length = "0x98")]
	[Token(Token = "0x6000C5D")]
	internal static int CombineHashCodes(int h1, int h2, int h3, int h4, int h5) { }

	[Address(RVA = "0x741D618", Offset = "0x741D618", Length = "0x90")]
	[Token(Token = "0x6000C5C")]
	internal static int CombineHashCodes(int h1, int h2, int h3, int h4) { }

	[Address(RVA = "0x741D598", Offset = "0x741D598", Length = "0x80")]
	[Token(Token = "0x6000C5B")]
	internal static int CombineHashCodes(int h1, int h2, int h3) { }

	[Address(RVA = "0x741D51C", Offset = "0x741D51C", Length = "0x7C")]
	[Token(Token = "0x6000C5A")]
	internal static int CombineHashCodes(int h1, int h2) { }

	[Address(RVA = "0x741D7E8", Offset = "0x741D7E8", Length = "0xB0")]
	[Token(Token = "0x6000C5F")]
	internal static int CombineHashCodes(int h1, int h2, int h3, int h4, int h5, int h6, int h7) { }

	[Address(RVA = "0x741D31C", Offset = "0x741D31C", Length = "0x8")]
	[Token(Token = "0x6000C51")]
	public override int CompareTo(ValueTuple other) { }

	[Address(RVA = "0x741D144", Offset = "0x741D144", Length = "0x5C")]
	[Token(Token = "0x6000C4D")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x741D1A0", Offset = "0x741D1A0", Length = "0x8")]
	[Token(Token = "0x6000C4E")]
	public override bool Equals(ValueTuple other) { }

	[Address(RVA = "0x741D43C", Offset = "0x741D43C", Length = "0x8")]
	[Token(Token = "0x6000C53")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x741D324", Offset = "0x741D324", Length = "0x118")]
	[Token(Token = "0x6000C52")]
	private override int System.Collections.IStructuralComparable.CompareTo(object other, IComparer comparer) { }

	[Address(RVA = "0x741D1A8", Offset = "0x741D1A8", Length = "0x5C")]
	[Token(Token = "0x6000C4F")]
	private override bool System.Collections.IStructuralEquatable.Equals(object other, IEqualityComparer comparer) { }

	[Address(RVA = "0x741D444", Offset = "0x741D444", Length = "0x8")]
	[Token(Token = "0x6000C54")]
	private override int System.Collections.IStructuralEquatable.GetHashCode(IEqualityComparer comparer) { }

	[Address(RVA = "0x741D204", Offset = "0x741D204", Length = "0x118")]
	[Token(Token = "0x6000C50")]
	private override int System.IComparable.CompareTo(object other) { }

	[Address(RVA = "0x741D44C", Offset = "0x741D44C", Length = "0x8")]
	[Token(Token = "0x6000C55")]
	private override int System.IValueTupleInternal.GetHashCode(IEqualityComparer comparer) { }

	[Address(RVA = "0x741D494", Offset = "0x741D494", Length = "0x40")]
	[Token(Token = "0x6000C57")]
	private override string System.IValueTupleInternal.ToStringEnd() { }

	[Address(RVA = "0x741D4DC", Offset = "0x741D4DC", Length = "0x40")]
	[Token(Token = "0x6000C59")]
	private override object System.Runtime.CompilerServices.ITuple.get_Item(int index) { }

	[Address(RVA = "0x741D4D4", Offset = "0x741D4D4", Length = "0x8")]
	[Token(Token = "0x6000C58")]
	private override int System.Runtime.CompilerServices.ITuple.get_Length() { }

	[Address(RVA = "0x741D454", Offset = "0x741D454", Length = "0x40")]
	[Token(Token = "0x6000C56")]
	public virtual string ToString() { }

}

