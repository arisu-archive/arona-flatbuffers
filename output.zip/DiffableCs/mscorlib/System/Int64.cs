namespace System;

[IsReadOnly]
[Token(Token = "0x20000DE")]
public struct long : IComparable, IConvertible, IFormattable, IComparable<Int64>, IEquatable<Int64>, ISpanFormattable
{
	[Token(Token = "0x4000373")]
	public const long MaxValue = 9223372036854775807; //Field offset: 0x0
	[Token(Token = "0x4000374")]
	public const long MinValue = -9223372036854775808; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000372")]
	private readonly long m_value; //Field offset: 0x0

	[Address(RVA = "0x73F9DFC", Offset = "0x73F9DFC", Length = "0xD0")]
	[Token(Token = "0x6000827")]
	public override int CompareTo(object value) { }

	[Address(RVA = "0x73F9ECC", Offset = "0x73F9ECC", Length = "0x14")]
	[Token(Token = "0x6000828")]
	public override int CompareTo(long value) { }

	[Address(RVA = "0x73F9EE0", Offset = "0x73F9EE0", Length = "0x78")]
	[Token(Token = "0x6000829")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x73F9F58", Offset = "0x73F9F58", Length = "0x10")]
	[NonVersionable]
	[Token(Token = "0x600082A")]
	public override bool Equals(long obj) { }

	[Address(RVA = "0x73F9F68", Offset = "0x73F9F68", Length = "0xC")]
	[Token(Token = "0x600082B")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x73FB090", Offset = "0x73FB090", Length = "0x8")]
	[Token(Token = "0x6000836")]
	public override TypeCode GetTypeCode() { }

	[Address(RVA = "0x73FA93C", Offset = "0x73FA93C", Length = "0xC0")]
	[Token(Token = "0x6000831")]
	public static long Parse(string s) { }

	[Address(RVA = "0x73FABB8", Offset = "0x73FABB8", Length = "0xD0")]
	[Token(Token = "0x6000832")]
	public static long Parse(string s, IFormatProvider provider) { }

	[Address(RVA = "0x73FAC88", Offset = "0x73FAC88", Length = "0xE0")]
	[Token(Token = "0x6000833")]
	public static long Parse(string s, NumberStyles style, IFormatProvider provider) { }

	[Address(RVA = "0x73FB098", Offset = "0x73FB098", Length = "0x5C")]
	[Token(Token = "0x6000837")]
	private override bool System.IConvertible.ToBoolean(IFormatProvider provider) { }

	[Address(RVA = "0x73FB1AC", Offset = "0x73FB1AC", Length = "0x5C")]
	[Token(Token = "0x600083A")]
	private override byte System.IConvertible.ToByte(IFormatProvider provider) { }

	[Address(RVA = "0x73FB0F4", Offset = "0x73FB0F4", Length = "0x5C")]
	[Token(Token = "0x6000838")]
	private override char System.IConvertible.ToChar(IFormatProvider provider) { }

	[Address(RVA = "0x73FB4F0", Offset = "0x73FB4F0", Length = "0x88")]
	[Token(Token = "0x6000844")]
	private override DateTime System.IConvertible.ToDateTime(IFormatProvider provider) { }

	[Address(RVA = "0x73FB494", Offset = "0x73FB494", Length = "0x5C")]
	[Token(Token = "0x6000843")]
	private override decimal System.IConvertible.ToDecimal(IFormatProvider provider) { }

	[Address(RVA = "0x73FB438", Offset = "0x73FB438", Length = "0x5C")]
	[Token(Token = "0x6000842")]
	private override double System.IConvertible.ToDouble(IFormatProvider provider) { }

	[Address(RVA = "0x73FB208", Offset = "0x73FB208", Length = "0x5C")]
	[Token(Token = "0x600083B")]
	private override short System.IConvertible.ToInt16(IFormatProvider provider) { }

	[Address(RVA = "0x73FB2C0", Offset = "0x73FB2C0", Length = "0x5C")]
	[Token(Token = "0x600083D")]
	private override int System.IConvertible.ToInt32(IFormatProvider provider) { }

	[Address(RVA = "0x73FB378", Offset = "0x73FB378", Length = "0x8")]
	[Token(Token = "0x600083F")]
	private override long System.IConvertible.ToInt64(IFormatProvider provider) { }

	[Address(RVA = "0x73FB150", Offset = "0x73FB150", Length = "0x5C")]
	[Token(Token = "0x6000839")]
	private override sbyte System.IConvertible.ToSByte(IFormatProvider provider) { }

	[Address(RVA = "0x73FB3DC", Offset = "0x73FB3DC", Length = "0x5C")]
	[Token(Token = "0x6000841")]
	private override float System.IConvertible.ToSingle(IFormatProvider provider) { }

	[Address(RVA = "0x73FB578", Offset = "0x73FB578", Length = "0xAC")]
	[Token(Token = "0x6000845")]
	private override object System.IConvertible.ToType(Type type, IFormatProvider provider) { }

	[Address(RVA = "0x73FB264", Offset = "0x73FB264", Length = "0x5C")]
	[Token(Token = "0x600083C")]
	private override ushort System.IConvertible.ToUInt16(IFormatProvider provider) { }

	[Address(RVA = "0x73FB31C", Offset = "0x73FB31C", Length = "0x5C")]
	[Token(Token = "0x600083E")]
	private override uint System.IConvertible.ToUInt32(IFormatProvider provider) { }

	[Address(RVA = "0x73FB380", Offset = "0x73FB380", Length = "0x5C")]
	[Token(Token = "0x6000840")]
	private override ulong System.IConvertible.ToUInt64(IFormatProvider provider) { }

	[Address(RVA = "0x73FA478", Offset = "0x73FA478", Length = "0xB4")]
	[Token(Token = "0x600082F")]
	public override string ToString(string format, IFormatProvider provider) { }

	[Address(RVA = "0x73FA3C8", Offset = "0x73FA3C8", Length = "0xB0")]
	[Token(Token = "0x600082E")]
	public string ToString(string format) { }

	[Address(RVA = "0x73F9F74", Offset = "0x73F9F74", Length = "0x94")]
	[Token(Token = "0x600082C")]
	public virtual string ToString() { }

	[Address(RVA = "0x73FA330", Offset = "0x73FA330", Length = "0x98")]
	[Token(Token = "0x600082D")]
	public override string ToString(IFormatProvider provider) { }

	[Address(RVA = "0x73FA52C", Offset = "0x73FA52C", Length = "0xA0")]
	[Token(Token = "0x6000830")]
	public override bool TryFormat(Span<Char> destination, out int charsWritten, ReadOnlySpan<Char> format = null, IFormatProvider provider = null) { }

	[Address(RVA = "0x73FAF9C", Offset = "0x73FAF9C", Length = "0xF4")]
	[Token(Token = "0x6000835")]
	public static bool TryParse(string s, NumberStyles style, IFormatProvider provider, out long result) { }

	[Address(RVA = "0x73FAD68", Offset = "0x73FAD68", Length = "0xD0")]
	[Token(Token = "0x6000834")]
	public static bool TryParse(string s, out long result) { }

}

