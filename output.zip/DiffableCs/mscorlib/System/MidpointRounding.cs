namespace System;

[Token(Token = "0x20000EF")]
public enum MidpointRounding
{
	ToEven = 0,
	AwayFromZero = 1,
}

