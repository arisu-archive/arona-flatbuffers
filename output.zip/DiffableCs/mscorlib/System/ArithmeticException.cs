namespace System;

[Token(Token = "0x200008F")]
public class ArithmeticException : SystemException
{

	[Address(RVA = "0x73513E4", Offset = "0x73513E4", Length = "0x5C")]
	[Token(Token = "0x6000405")]
	public ArithmeticException() { }

	[Address(RVA = "0x7351440", Offset = "0x7351440", Length = "0x24")]
	[Token(Token = "0x6000406")]
	public ArithmeticException(string message) { }

	[Address(RVA = "0x7351464", Offset = "0x7351464", Length = "0x24")]
	[Token(Token = "0x6000407")]
	public ArithmeticException(string message, Exception innerException) { }

	[Address(RVA = "0x7351488", Offset = "0x7351488", Length = "0x8")]
	[Token(Token = "0x6000408")]
	protected ArithmeticException(SerializationInfo info, StreamingContext context) { }

}

