namespace System.IO;

[Token(Token = "0x2000594")]
public enum MatchType
{
	Simple = 0,
	Win32 = 1,
}

