namespace System.IO;

[Token(Token = "0x200057E")]
public abstract class TextReader : MarshalByRefObject, IDisposable
{
	[CompilerGenerated]
	[Token(Token = "0x2000581")]
	private sealed class <>c
	{
		[Token(Token = "0x40016CD")]
		public static readonly <>c <>9; //Field offset: 0x0
		[Token(Token = "0x40016CE")]
		public static Func<Object, Int32> <>9__17_0; //Field offset: 0x8

		[Address(RVA = "0x7338F20", Offset = "0x7338F20", Length = "0x70")]
		[Token(Token = "0x6002A4E")]
		private static <>c() { }

		[Address(RVA = "0x7338F90", Offset = "0x7338F90", Length = "0x8")]
		[Token(Token = "0x6002A4F")]
		public <>c() { }

		[Address(RVA = "0x7338F98", Offset = "0x7338F98", Length = "0xEC")]
		[Token(Token = "0x6002A50")]
		internal int <ReadAsyncInternal>b__17_0(object state) { }

	}

	[Token(Token = "0x200057F")]
	private sealed class NullTextReader : TextReader
	{

		[Address(RVA = "0x7338B6C", Offset = "0x7338B6C", Length = "0x58")]
		[Token(Token = "0x6002A42")]
		public NullTextReader() { }

		[Address(RVA = "0x7338BC4", Offset = "0x7338BC4", Length = "0x8")]
		[Token(Token = "0x6002A43")]
		public virtual int Read(Char[] buffer, int index, int count) { }

		[Address(RVA = "0x7338BCC", Offset = "0x7338BCC", Length = "0x8")]
		[Token(Token = "0x6002A44")]
		public virtual string ReadLine() { }

	}

	[Token(Token = "0x2000580")]
	public sealed class SyncTextReader : TextReader
	{
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x40016CC")]
		internal readonly TextReader _in; //Field offset: 0x18

		[Address(RVA = "0x7338A78", Offset = "0x7338A78", Length = "0x74")]
		[Token(Token = "0x6002A45")]
		internal SyncTextReader(TextReader t) { }

		[Address(RVA = "0x7338BD4", Offset = "0x7338BD4", Length = "0x20")]
		[Token(Token = "0x6002A46")]
		public virtual void Close() { }

		[Address(RVA = "0x7338BF4", Offset = "0x7338BF4", Length = "0xB4")]
		[Token(Token = "0x6002A47")]
		protected virtual void Dispose(bool disposing) { }

		[Address(RVA = "0x7338CA8", Offset = "0x7338CA8", Length = "0x20")]
		[Token(Token = "0x6002A48")]
		public virtual int Peek() { }

		[Address(RVA = "0x7338CC8", Offset = "0x7338CC8", Length = "0x20")]
		[Token(Token = "0x6002A49")]
		public virtual int Read() { }

		[Address(RVA = "0x7338CE8", Offset = "0x7338CE8", Length = "0x20")]
		[Token(Token = "0x6002A4A")]
		public virtual int Read(Char[] buffer, int index, int count) { }

		[Address(RVA = "0x7338D50", Offset = "0x7338D50", Length = "0x1D0")]
		[Token(Token = "0x6002A4D")]
		public virtual Task<Int32> ReadAsync(Char[] buffer, int index, int count) { }

		[Address(RVA = "0x7338D08", Offset = "0x7338D08", Length = "0x24")]
		[Token(Token = "0x6002A4B")]
		public virtual string ReadLine() { }

		[Address(RVA = "0x7338D2C", Offset = "0x7338D2C", Length = "0x24")]
		[Token(Token = "0x6002A4C")]
		public virtual string ReadToEnd() { }

	}

	[Token(Token = "0x40016CB")]
	public static readonly TextReader Null; //Field offset: 0x0

	[Address(RVA = "0x7338AEC", Offset = "0x7338AEC", Length = "0x80")]
	[Token(Token = "0x6002A41")]
	private static TextReader() { }

	[Address(RVA = "0x732E584", Offset = "0x732E584", Length = "0x8")]
	[Token(Token = "0x6002A34")]
	protected TextReader() { }

	[Address(RVA = "0x73382DC", Offset = "0x73382DC", Length = "0x6C")]
	[Token(Token = "0x6002A35")]
	public override void Close() { }

	[Address(RVA = "0x7338348", Offset = "0x7338348", Length = "0x6C")]
	[Token(Token = "0x6002A36")]
	public override void Dispose() { }

	[Address(RVA = "0x73383B4", Offset = "0x73383B4", Length = "0x4")]
	[Token(Token = "0x6002A37")]
	protected override void Dispose(bool disposing) { }

	[Address(RVA = "0x73383B8", Offset = "0x73383B8", Length = "0x8")]
	[Token(Token = "0x6002A38")]
	public override int Peek() { }

	[Address(RVA = "0x73383C0", Offset = "0x73383C0", Length = "0x8")]
	[Token(Token = "0x6002A39")]
	public override int Read() { }

	[Address(RVA = "0x73383C8", Offset = "0x73383C8", Length = "0x1BC")]
	[Token(Token = "0x6002A3A")]
	public override int Read(Char[] buffer, int index, int count) { }

	[Address(RVA = "0x732F470", Offset = "0x732F470", Length = "0x290")]
	[Token(Token = "0x6002A3B")]
	public override int Read(Span<Char> buffer) { }

	[Address(RVA = "0x7330648", Offset = "0x7330648", Length = "0x214")]
	[Token(Token = "0x6002A3E")]
	public override Task<Int32> ReadAsync(Char[] buffer, int index, int count) { }

	[Address(RVA = "0x733876C", Offset = "0x733876C", Length = "0x24C")]
	[Token(Token = "0x6002A3F")]
	internal override ValueTask<Int32> ReadAsyncInternal(Memory<Char> buffer, CancellationToken cancellationToken) { }

	[Address(RVA = "0x733867C", Offset = "0x733867C", Length = "0xF0")]
	[Token(Token = "0x6002A3D")]
	public override string ReadLine() { }

	[Address(RVA = "0x7338584", Offset = "0x7338584", Length = "0xF8")]
	[Token(Token = "0x6002A3C")]
	public override string ReadToEnd() { }

	[Address(RVA = "0x73389B8", Offset = "0x73389B8", Length = "0xC0")]
	[Token(Token = "0x6002A40")]
	public static TextReader Synchronized(TextReader reader) { }

}

