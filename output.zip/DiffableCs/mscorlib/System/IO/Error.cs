namespace System.IO;

[Token(Token = "0x2000568")]
internal static class Error
{

	[Address(RVA = "0x7329CB0", Offset = "0x7329CB0", Length = "0x80")]
	[Token(Token = "0x6002978")]
	internal static Exception GetEndOfFile() { }

	[Address(RVA = "0x7329D30", Offset = "0x7329D30", Length = "0x74")]
	[Token(Token = "0x6002979")]
	internal static Exception GetReadNotSupported() { }

	[Address(RVA = "0x7329C38", Offset = "0x7329C38", Length = "0x78")]
	[Token(Token = "0x6002977")]
	internal static Exception GetStreamIsClosed() { }

	[Address(RVA = "0x7329DA4", Offset = "0x7329DA4", Length = "0x74")]
	[Token(Token = "0x600297A")]
	internal static Exception GetWriteNotSupported() { }

}

