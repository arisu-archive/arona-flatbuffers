namespace System.IO;

[ComVisible(True)]
[Token(Token = "0x20005B4")]
public static class Path
{
	[CompilerGenerated]
	[Token(Token = "0x20005B5")]
	private sealed class <>c
	{
		[Token(Token = "0x40017EA")]
		public static readonly <>c <>9; //Field offset: 0x0
		[Token(Token = "0x40017EB")]
		[TupleElementNames(new IL2CPP_TYPE_STRING[] {"First", "FirstLength", "Second", "SecondLength", "HasSeparator"}])]
		public static SpanAction<Char, ValueTuple`5<IntPtr, Int32, IntPtr, Int32, Boolean>> <>9__56_0; //Field offset: 0x8
		[Token(Token = "0x40017EC")]
		[TupleElementNames(new IL2CPP_TYPE_STRING[] {"First", "FirstLength", "Second", "SecondLength", "Third", "ThirdLength", "FirstHasSeparator", "ThirdHasSeparator", null}])]
		public static SpanAction<Char, ValueTuple`8<IntPtr, Int32, IntPtr, Int32, IntPtr, Int32, Boolean, ValueTuple`1<Boolean>>> <>9__57_0; //Field offset: 0x10

		[Address(RVA = "0x737AFB8", Offset = "0x737AFB8", Length = "0x70")]
		[Token(Token = "0x6002CBB")]
		private static <>c() { }

		[Address(RVA = "0x737B028", Offset = "0x737B028", Length = "0x8")]
		[Token(Token = "0x6002CBC")]
		public <>c() { }

		[Address(RVA = "0x737B030", Offset = "0x737B030", Length = "0x198")]
		[Token(Token = "0x6002CBD")]
		internal void <JoinInternal>b__56_0(Span<Char> destination, ValueTuple<IntPtr, Int32, IntPtr, Int32, Boolean> state) { }

		[Address(RVA = "0x737B1C8", Offset = "0x737B1C8", Length = "0x260")]
		[Token(Token = "0x6002CBE")]
		internal void <JoinInternal>b__57_0(Span<Char> destination, ValueTuple<IntPtr, Int32, IntPtr, Int32, IntPtr, Int32, Boolean, ValueTuple`1<Boolean>> state) { }

	}

	[Obsolete("see GetInvalidPathChars and GetInvalidFileNameChars methods.")]
	[Token(Token = "0x40017E0")]
	public static readonly Char[] InvalidPathChars; //Field offset: 0x0
	[Token(Token = "0x40017E1")]
	public static readonly char AltDirectorySeparatorChar; //Field offset: 0x8
	[Token(Token = "0x40017E2")]
	public static readonly char DirectorySeparatorChar; //Field offset: 0xA
	[Token(Token = "0x40017E3")]
	public static readonly char PathSeparator; //Field offset: 0xC
	[Token(Token = "0x40017E4")]
	internal static readonly string DirectorySeparatorStr; //Field offset: 0x10
	[Token(Token = "0x40017E5")]
	public static readonly char VolumeSeparatorChar; //Field offset: 0x18
	[Token(Token = "0x40017E6")]
	internal static readonly Char[] PathSeparatorChars; //Field offset: 0x20
	[Token(Token = "0x40017E7")]
	private static readonly bool dirEqualsVolume; //Field offset: 0x28
	[Token(Token = "0x40017E8")]
	internal static readonly Char[] trimEndCharsWindows; //Field offset: 0x30
	[Token(Token = "0x40017E9")]
	internal static readonly Char[] trimEndCharsUnix; //Field offset: 0x38

	[Address(RVA = "0x7379B8C", Offset = "0x7379B8C", Length = "0x20C")]
	[Token(Token = "0x6002CB0")]
	private static Path() { }

	[Address(RVA = "0x7379474", Offset = "0x7379474", Length = "0x474")]
	[Token(Token = "0x6002CB1")]
	private static string CanonicalizePath(string path) { }

	[Address(RVA = "0x73785E4", Offset = "0x73785E4", Length = "0x1F4")]
	[Token(Token = "0x6002C9D")]
	public static string ChangeExtension(string path, string extension) { }

	[Address(RVA = "0x7378990", Offset = "0x7378990", Length = "0x454")]
	[Token(Token = "0x6002C9F")]
	internal static string CleanPath(string s) { }

	[Address(RVA = "0x736390C", Offset = "0x736390C", Length = "0x26C")]
	[Token(Token = "0x6002C9E")]
	public static string Combine(string path1, string path2) { }

	[Address(RVA = "0x737A250", Offset = "0x737A250", Length = "0x228")]
	[Token(Token = "0x6002CB4")]
	public static string Combine(string path1, string path2, string path3, string path4) { }

	[Address(RVA = "0x737A084", Offset = "0x737A084", Length = "0x1CC")]
	[Token(Token = "0x6002CB3")]
	public static string Combine(string path1, string path2, string path3) { }

	[Address(RVA = "0x7379D98", Offset = "0x7379D98", Length = "0x2EC")]
	[Token(Token = "0x6002CB2")]
	public static string Combine(String[] paths) { }

	[Address(RVA = "0x73787D8", Offset = "0x73787D8", Length = "0x94")]
	[Token(Token = "0x6002CAF")]
	private static int findExtension(string path) { }

	[Address(RVA = "0x73799F4", Offset = "0x73799F4", Length = "0x4")]
	[Token(Token = "0x6002CAB")]
	private static string get_temp_path() { }

	[Address(RVA = "0x7362738", Offset = "0x7362738", Length = "0x39C")]
	[Token(Token = "0x6002CA0")]
	public static string GetDirectoryName(string path) { }

	[Address(RVA = "0x737921C", Offset = "0x737921C", Length = "0xD0")]
	[Token(Token = "0x6002CA1")]
	public static ReadOnlySpan<Char> GetDirectoryName(ReadOnlySpan<Char> path) { }

	[Address(RVA = "0x73792EC", Offset = "0x73792EC", Length = "0x12C")]
	[Token(Token = "0x6002CA2")]
	public static string GetExtension(string path) { }

	[Address(RVA = "0x737A478", Offset = "0x737A478", Length = "0x140")]
	[Token(Token = "0x6002CB5")]
	public static ReadOnlySpan<Char> GetFileName(ReadOnlySpan<Char> path) { }

	[Address(RVA = "0x7362404", Offset = "0x7362404", Length = "0x110")]
	[Token(Token = "0x6002CA3")]
	public static string GetFileName(string path) { }

	[Address(RVA = "0x7379418", Offset = "0x7379418", Length = "0x5C")]
	[Token(Token = "0x6002CA4")]
	public static string GetFileNameWithoutExtension(string path) { }

	[Address(RVA = "0x736239C", Offset = "0x736239C", Length = "0x68")]
	[Token(Token = "0x6002CA5")]
	public static string GetFullPath(string path) { }

	[Address(RVA = "0x7364D80", Offset = "0x7364D80", Length = "0x54")]
	[Token(Token = "0x6002CA6")]
	internal static string GetFullPathInternal(string path) { }

	[Address(RVA = "0x7379AFC", Offset = "0x7379AFC", Length = "0x90")]
	[Token(Token = "0x6002CAE")]
	public static Char[] GetInvalidPathChars() { }

	[Address(RVA = "0x7378DE4", Offset = "0x7378DE4", Length = "0x438")]
	[Token(Token = "0x6002CA9")]
	public static string GetPathRoot(string path) { }

	[Address(RVA = "0x73798E8", Offset = "0x73798E8", Length = "0x10C")]
	[Token(Token = "0x6002CAA")]
	public static string GetTempPath() { }

	[Address(RVA = "0x7373FB8", Offset = "0x7373FB8", Length = "0x698")]
	[Token(Token = "0x6002CA7")]
	internal static string InsecureGetFullPath(string path) { }

	[Address(RVA = "0x736F2E8", Offset = "0x736F2E8", Length = "0x90")]
	[Token(Token = "0x6002CA8")]
	internal static bool IsDirectorySeparator(char c) { }

	[Address(RVA = "0x73799F8", Offset = "0x73799F8", Length = "0x104")]
	[Token(Token = "0x6002CAC")]
	public static bool IsPathRooted(ReadOnlySpan<Char> path) { }

	[Address(RVA = "0x737886C", Offset = "0x737886C", Length = "0x124")]
	[Token(Token = "0x6002CAD")]
	public static bool IsPathRooted(string path) { }

	[Address(RVA = "0x737A5B8", Offset = "0x737A5B8", Length = "0xB8")]
	[Token(Token = "0x6002CB6")]
	public static string Join(ReadOnlySpan<Char> path1, ReadOnlySpan<Char> path2) { }

	[Address(RVA = "0x737A8F0", Offset = "0x737A8F0", Length = "0x110")]
	[Token(Token = "0x6002CB7")]
	public static string Join(ReadOnlySpan<Char> path1, ReadOnlySpan<Char> path2, ReadOnlySpan<Char> path3) { }

	[Address(RVA = "0x737A670", Offset = "0x737A670", Length = "0x280")]
	[Token(Token = "0x6002CB9")]
	private static string JoinInternal(ReadOnlySpan<Char> first, ReadOnlySpan<Char> second) { }

	[Address(RVA = "0x737AA00", Offset = "0x737AA00", Length = "0x364")]
	[Token(Token = "0x6002CBA")]
	private static string JoinInternal(ReadOnlySpan<Char> first, ReadOnlySpan<Char> second, ReadOnlySpan<Char> third) { }

	[Address(RVA = "0x737AD64", Offset = "0x737AD64", Length = "0x254")]
	[Token(Token = "0x6002CB8")]
	public static bool TryJoin(ReadOnlySpan<Char> path1, ReadOnlySpan<Char> path2, Span<Char> destination, out int charsWritten) { }

}

