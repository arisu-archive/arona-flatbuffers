namespace System.IO;

[Token(Token = "0x20005A7")]
internal static class __Error
{

	[Address(RVA = "0x736F07C", Offset = "0x736F07C", Length = "0x60")]
	[Token(Token = "0x6002BE9")]
	internal static void EndOfFile() { }

	[Address(RVA = "0x736F0DC", Offset = "0x736F0DC", Length = "0x64")]
	[Token(Token = "0x6002BEA")]
	internal static void FileNotOpen() { }

	[Address(RVA = "0x736F1A4", Offset = "0x736F1A4", Length = "0x144")]
	[Token(Token = "0x6002BEC")]
	internal static string GetDisplayablePath(string path, bool isInvalidPath) { }

	[Address(RVA = "0x736F140", Offset = "0x736F140", Length = "0x64")]
	[Token(Token = "0x6002BEB")]
	internal static void ReaderClosed() { }

	[Address(RVA = "0x736F378", Offset = "0x736F378", Length = "0x59C")]
	[Token(Token = "0x6002BED")]
	internal static void WinIOError(int errorCode, string maybeFullPath) { }

	[Address(RVA = "0x736F914", Offset = "0x736F914", Length = "0x64")]
	[Token(Token = "0x6002BEE")]
	internal static void WriterClosed() { }

}

