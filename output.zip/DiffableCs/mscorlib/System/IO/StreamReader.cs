namespace System.IO;

[Token(Token = "0x2000575")]
public class StreamReader : TextReader
{
	[CompilerGenerated]
	[Token(Token = "0x2000577")]
	private struct <ReadAsyncInternal>d__66 : IAsyncStateMachine
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001675")]
		public int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x4001676")]
		public AsyncValueTaskMethodBuilder<Int32> <>t__builder; //Field offset: 0x8
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4001677")]
		public StreamReader <>4__this; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4001678")]
		public Memory<Char> buffer; //Field offset: 0x30
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4001679")]
		public CancellationToken cancellationToken; //Field offset: 0x40
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x400167A")]
		private int <charsRead>5__2; //Field offset: 0x48
		[FieldOffset(Offset = "0x4C")]
		[Token(Token = "0x400167B")]
		private bool <readToUserBuffer>5__3; //Field offset: 0x4C
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x400167C")]
		private Byte[] <tmpByteBuffer>5__4; //Field offset: 0x50
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x400167D")]
		private Stream <tmpStream>5__5; //Field offset: 0x58
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x400167E")]
		private int <count>5__6; //Field offset: 0x60
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x400167F")]
		private ConfiguredTaskAwaiter<Int32> <>u__1; //Field offset: 0x68
		[FieldOffset(Offset = "0x78")]
		[Token(Token = "0x4001680")]
		private int <n>5__7; //Field offset: 0x78
		[FieldOffset(Offset = "0x80")]
		[Token(Token = "0x4001681")]
		private ConfiguredValueTaskAwaiter<Int32> <>u__2; //Field offset: 0x80

		[Address(RVA = "0x7330CC8", Offset = "0x7330CC8", Length = "0xCA4")]
		[Token(Token = "0x60029FF")]
		private override void MoveNext() { }

		[Address(RVA = "0x733196C", Offset = "0x733196C", Length = "0x58")]
		[DebuggerHidden]
		[Token(Token = "0x6002A00")]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x2000578")]
	private struct <ReadBufferAsync>d__69 : IAsyncStateMachine
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001682")]
		public int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x4001683")]
		public AsyncTaskMethodBuilder<Int32> <>t__builder; //Field offset: 0x8
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4001684")]
		public StreamReader <>4__this; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4001685")]
		private Byte[] <tmpByteBuffer>5__2; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4001686")]
		private Stream <tmpStream>5__3; //Field offset: 0x30
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4001687")]
		private ConfiguredValueTaskAwaiter<Int32> <>u__1; //Field offset: 0x38

		[Address(RVA = "0x73319C4", Offset = "0x73319C4", Length = "0x7C4")]
		[Token(Token = "0x6002A01")]
		private override void MoveNext() { }

		[Address(RVA = "0x7332188", Offset = "0x7332188", Length = "0x7C")]
		[DebuggerHidden]
		[Token(Token = "0x6002A02")]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[Token(Token = "0x2000576")]
	private class NullStreamReader : StreamReader
	{

		[Token(Token = "0x17000628")]
		public virtual Stream BaseStream
		{
			[Address(RVA = "0x7330BF4", Offset = "0x7330BF4", Length = "0x58")]
			[Token(Token = "0x60029F6")]
			 get { } //Length: 88
		}

		[Token(Token = "0x17000629")]
		public virtual Encoding CurrentEncoding
		{
			[Address(RVA = "0x7330C4C", Offset = "0x7330C4C", Length = "0x8")]
			[Token(Token = "0x60029F7")]
			 get { } //Length: 8
		}

		[Address(RVA = "0x7330B58", Offset = "0x7330B58", Length = "0x9C")]
		[Token(Token = "0x60029F5")]
		internal NullStreamReader() { }

		[Address(RVA = "0x7330C54", Offset = "0x7330C54", Length = "0x4")]
		[Token(Token = "0x60029F8")]
		protected virtual void Dispose(bool disposing) { }

		[Address(RVA = "0x7330BF4", Offset = "0x7330BF4", Length = "0x58")]
		[Token(Token = "0x60029F6")]
		public virtual Stream get_BaseStream() { }

		[Address(RVA = "0x7330C4C", Offset = "0x7330C4C", Length = "0x8")]
		[Token(Token = "0x60029F7")]
		public virtual Encoding get_CurrentEncoding() { }

		[Address(RVA = "0x7330C58", Offset = "0x7330C58", Length = "0x8")]
		[Token(Token = "0x60029F9")]
		public virtual int Peek() { }

		[Address(RVA = "0x7330C60", Offset = "0x7330C60", Length = "0x8")]
		[Token(Token = "0x60029FA")]
		public virtual int Read() { }

		[Address(RVA = "0x7330C68", Offset = "0x7330C68", Length = "0x8")]
		[Token(Token = "0x60029FB")]
		public virtual int Read(Char[] buffer, int index, int count) { }

		[Address(RVA = "0x7330CC0", Offset = "0x7330CC0", Length = "0x8")]
		[Token(Token = "0x60029FE")]
		internal virtual int ReadBuffer() { }

		[Address(RVA = "0x7330C70", Offset = "0x7330C70", Length = "0x8")]
		[Token(Token = "0x60029FC")]
		public virtual string ReadLine() { }

		[Address(RVA = "0x7330C78", Offset = "0x7330C78", Length = "0x48")]
		[Token(Token = "0x60029FD")]
		public virtual string ReadToEnd() { }

	}

	[Token(Token = "0x4001665")]
	public static readonly StreamReader Null; //Field offset: 0x0
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001666")]
	private Stream _stream; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4001667")]
	private Encoding _encoding; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4001668")]
	private Decoder _decoder; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4001669")]
	private Byte[] _byteBuffer; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400166A")]
	private Char[] _charBuffer; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400166B")]
	private int _charPos; //Field offset: 0x40
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x400166C")]
	private int _charLen; //Field offset: 0x44
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x400166D")]
	private int _byteLen; //Field offset: 0x48
	[FieldOffset(Offset = "0x4C")]
	[Token(Token = "0x400166E")]
	private int _bytePos; //Field offset: 0x4C
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x400166F")]
	private int _maxCharsPerBuffer; //Field offset: 0x50
	[FieldOffset(Offset = "0x54")]
	[Token(Token = "0x4001670")]
	private bool _detectEncoding; //Field offset: 0x54
	[FieldOffset(Offset = "0x55")]
	[Token(Token = "0x4001671")]
	private bool _checkPreamble; //Field offset: 0x55
	[FieldOffset(Offset = "0x56")]
	[Token(Token = "0x4001672")]
	private bool _isBlocked; //Field offset: 0x56
	[FieldOffset(Offset = "0x57")]
	[Token(Token = "0x4001673")]
	private bool _closable; //Field offset: 0x57
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x4001674")]
	private Task _asyncReadTask; //Field offset: 0x58

	[Token(Token = "0x17000625")]
	public override Stream BaseStream
	{
		[Address(RVA = "0x732ED64", Offset = "0x732ED64", Length = "0x8")]
		[Token(Token = "0x60029E1")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000624")]
	public override Encoding CurrentEncoding
	{
		[Address(RVA = "0x732ED5C", Offset = "0x732ED5C", Length = "0x8")]
		[Token(Token = "0x60029E0")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000627")]
	public bool EndOfStream
	{
		[Address(RVA = "0x732ED6C", Offset = "0x732ED6C", Length = "0x9C")]
		[Token(Token = "0x60029E3")]
		 get { } //Length: 156
	}

	[Token(Token = "0x17000626")]
	internal bool LeaveOpen
	{
		[Address(RVA = "0x732ED4C", Offset = "0x732ED4C", Length = "0x10")]
		[Token(Token = "0x60029E2")]
		internal get { } //Length: 16
	}

	[Address(RVA = "0x7330AD8", Offset = "0x7330AD8", Length = "0x80")]
	[Token(Token = "0x60029F4")]
	private static StreamReader() { }

	[Address(RVA = "0x732EA1C", Offset = "0x732EA1C", Length = "0x254")]
	[Token(Token = "0x60029DB")]
	public StreamReader(string path, Encoding encoding, bool detectEncodingFromByteOrderMarks, int bufferSize) { }

	[Address(RVA = "0x732E4C0", Offset = "0x732E4C0", Length = "0xC4")]
	[Token(Token = "0x60029D2")]
	internal StreamReader() { }

	[Address(RVA = "0x732E58C", Offset = "0x732E58C", Length = "0x3C")]
	[Token(Token = "0x60029D3")]
	public StreamReader(Stream stream) { }

	[Address(RVA = "0x732E5C8", Offset = "0x732E5C8", Length = "0x40")]
	[Token(Token = "0x60029D4")]
	public StreamReader(Stream stream, bool detectEncodingFromByteOrderMarks) { }

	[Address(RVA = "0x732E830", Offset = "0x732E830", Length = "0x10")]
	[Token(Token = "0x60029D5")]
	public StreamReader(Stream stream, Encoding encoding) { }

	[Address(RVA = "0x732E608", Offset = "0x732E608", Length = "0x228")]
	[Token(Token = "0x60029D6")]
	public StreamReader(Stream stream, Encoding encoding, bool detectEncodingFromByteOrderMarks, int bufferSize, bool leaveOpen) { }

	[Address(RVA = "0x732E9A8", Offset = "0x732E9A8", Length = "0x38")]
	[Token(Token = "0x60029D7")]
	public StreamReader(string path) { }

	[Address(RVA = "0x732E9E0", Offset = "0x732E9E0", Length = "0x3C")]
	[Token(Token = "0x60029D8")]
	public StreamReader(string path, bool detectEncodingFromByteOrderMarks) { }

	[Address(RVA = "0x732EC70", Offset = "0x732EC70", Length = "0xC")]
	[Token(Token = "0x60029D9")]
	public StreamReader(string path, Encoding encoding) { }

	[Address(RVA = "0x732EC7C", Offset = "0x732EC7C", Length = "0x8")]
	[Token(Token = "0x60029DA")]
	public StreamReader(string path, Encoding encoding, bool detectEncodingFromByteOrderMarks) { }

	[Address(RVA = "0x732E404", Offset = "0x732E404", Length = "0x6C")]
	[Token(Token = "0x60029D0")]
	private void CheckAsyncTaskInProgress() { }

	[Address(RVA = "0x732ECA8", Offset = "0x732ECA8", Length = "0x10")]
	[Token(Token = "0x60029DE")]
	public virtual void Close() { }

	[Address(RVA = "0x732FB28", Offset = "0x732FB28", Length = "0x44")]
	[Token(Token = "0x60029EA")]
	private void CompressBuffer(int n) { }

	[Address(RVA = "0x7330AC8", Offset = "0x7330AC8", Length = "0x10")]
	[Token(Token = "0x60029F3")]
	internal bool DataAvailable() { }

	[Address(RVA = "0x732FB6C", Offset = "0x732FB6C", Length = "0x2E0")]
	[Token(Token = "0x60029EB")]
	private void DetectEncoding() { }

	[Address(RVA = "0x732ECB8", Offset = "0x732ECB8", Length = "0x94")]
	[Token(Token = "0x60029DF")]
	protected virtual void Dispose(bool disposing) { }

	[Address(RVA = "0x732ED64", Offset = "0x732ED64", Length = "0x8")]
	[Token(Token = "0x60029E1")]
	public override Stream get_BaseStream() { }

	[Address(RVA = "0x732ED5C", Offset = "0x732ED5C", Length = "0x8")]
	[Token(Token = "0x60029E0")]
	public override Encoding get_CurrentEncoding() { }

	[Address(RVA = "0x732ED6C", Offset = "0x732ED6C", Length = "0x9C")]
	[Token(Token = "0x60029E3")]
	public bool get_EndOfStream() { }

	[Address(RVA = "0x732ED4C", Offset = "0x732ED4C", Length = "0x10")]
	[Token(Token = "0x60029E2")]
	internal bool get_LeaveOpen() { }

	[Address(RVA = "0x732E840", Offset = "0x732E840", Length = "0x168")]
	[Token(Token = "0x60029DC")]
	private void Init(Stream stream, Encoding encoding, bool detectEncodingFromByteOrderMarks, int bufferSize, bool leaveOpen) { }

	[Address(RVA = "0x732EC84", Offset = "0x732EC84", Length = "0x24")]
	[Token(Token = "0x60029DD")]
	internal void Init(Stream stream) { }

	[Address(RVA = "0x732FE4C", Offset = "0x732FE4C", Length = "0x118")]
	[Token(Token = "0x60029EC")]
	private bool IsPreamble() { }

	[Address(RVA = "0x732EE08", Offset = "0x732EE08", Length = "0xC8")]
	[Token(Token = "0x60029E4")]
	public virtual int Peek() { }

	[Address(RVA = "0x732EF98", Offset = "0x732EF98", Length = "0x1C0")]
	[Token(Token = "0x60029E6")]
	public virtual int Read(Char[] buffer, int index, int count) { }

	[Address(RVA = "0x732F394", Offset = "0x732F394", Length = "0xDC")]
	[Token(Token = "0x60029E7")]
	public virtual int Read(Span<Char> buffer) { }

	[Address(RVA = "0x732EED0", Offset = "0x732EED0", Length = "0xC8")]
	[Token(Token = "0x60029E5")]
	public virtual int Read() { }

	[Address(RVA = "0x7330334", Offset = "0x7330334", Length = "0x314")]
	[Token(Token = "0x60029F0")]
	public virtual Task<Int32> ReadAsync(Char[] buffer, int index, int count) { }

	[Address(RVA = "0x733085C", Offset = "0x733085C", Length = "0x154")]
	[AsyncStateMachine(typeof(<ReadAsyncInternal>d__66))]
	[Token(Token = "0x60029F1")]
	internal virtual ValueTask<Int32> ReadAsyncInternal(Memory<Char> buffer, CancellationToken cancellationToken) { }

	[Address(RVA = "0x732FF64", Offset = "0x732FF64", Length = "0x164")]
	[Token(Token = "0x60029ED")]
	internal override int ReadBuffer() { }

	[Address(RVA = "0x732F700", Offset = "0x732F700", Length = "0x30C")]
	[Token(Token = "0x60029EE")]
	private int ReadBuffer(Span<Char> userBuffer, out bool readToUserBuffer) { }

	[Address(RVA = "0x73309B0", Offset = "0x73309B0", Length = "0x118")]
	[AsyncStateMachine(typeof(<ReadBufferAsync>d__69))]
	[Token(Token = "0x60029F2")]
	private Task<Int32> ReadBufferAsync() { }

	[Address(RVA = "0x73300C8", Offset = "0x73300C8", Length = "0x26C")]
	[Token(Token = "0x60029EF")]
	public virtual string ReadLine() { }

	[Address(RVA = "0x732F158", Offset = "0x732F158", Length = "0x23C")]
	[Token(Token = "0x60029E8")]
	private int ReadSpan(Span<Char> buffer) { }

	[Address(RVA = "0x732FA0C", Offset = "0x732FA0C", Length = "0x11C")]
	[Token(Token = "0x60029E9")]
	public virtual string ReadToEnd() { }

	[Address(RVA = "0x732E470", Offset = "0x732E470", Length = "0x50")]
	[Token(Token = "0x60029D1")]
	private static void ThrowAsyncIOInProgress() { }

}

