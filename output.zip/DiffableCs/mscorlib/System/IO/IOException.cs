namespace System.IO;

[Token(Token = "0x200056F")]
public class IOException : SystemException
{

	[Address(RVA = "0x732A880", Offset = "0x732A880", Length = "0x5C")]
	[Token(Token = "0x600298F")]
	public IOException() { }

	[Address(RVA = "0x7329B58", Offset = "0x7329B58", Length = "0x24")]
	[Token(Token = "0x6002990")]
	public IOException(string message) { }

	[Address(RVA = "0x732A8DC", Offset = "0x732A8DC", Length = "0x28")]
	[Token(Token = "0x6002991")]
	public IOException(string message, int hresult) { }

	[Address(RVA = "0x732A904", Offset = "0x732A904", Length = "0x24")]
	[Token(Token = "0x6002992")]
	public IOException(string message, Exception innerException) { }

	[Address(RVA = "0x7329BA8", Offset = "0x7329BA8", Length = "0x8")]
	[Token(Token = "0x6002993")]
	protected IOException(SerializationInfo info, StreamingContext context) { }

}

