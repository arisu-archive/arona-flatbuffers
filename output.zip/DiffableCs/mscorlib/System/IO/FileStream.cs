namespace System.IO;

[ComVisible(True)]
[Token(Token = "0x20005AC")]
public class FileStream : Stream
{
	[Token(Token = "0x20005AD")]
	private sealed class ReadDelegate : MulticastDelegate
	{

		[Address(RVA = "0x7376598", Offset = "0x7376598", Length = "0xEC")]
		[Token(Token = "0x6002C70")]
		public ReadDelegate(object object, IntPtr method) { }

		[Address(RVA = "0x7376684", Offset = "0x7376684", Length = "0xA8")]
		[Token(Token = "0x6002C72")]
		public override IAsyncResult BeginInvoke(Byte[] buffer, int offset, int count, AsyncCallback callback, object object) { }

		[Address(RVA = "0x7376890", Offset = "0x7376890", Length = "0x28")]
		[Token(Token = "0x6002C73")]
		public override int EndInvoke(IAsyncResult result) { }

		[Address(RVA = "0x73781D8", Offset = "0x73781D8", Length = "0x14")]
		[Token(Token = "0x6002C71")]
		public override int Invoke(Byte[] buffer, int offset, int count) { }

	}

	[Token(Token = "0x20005AE")]
	private sealed class WriteDelegate : MulticastDelegate
	{

		[Address(RVA = "0x737726C", Offset = "0x737726C", Length = "0xEC")]
		[Token(Token = "0x6002C74")]
		public WriteDelegate(object object, IntPtr method) { }

		[Address(RVA = "0x7377358", Offset = "0x7377358", Length = "0xA8")]
		[Token(Token = "0x6002C76")]
		public override IAsyncResult BeginInvoke(Byte[] buffer, int offset, int count, AsyncCallback callback, object object) { }

		[Address(RVA = "0x7377568", Offset = "0x7377568", Length = "0xC")]
		[Token(Token = "0x6002C77")]
		public override void EndInvoke(IAsyncResult result) { }

		[Address(RVA = "0x73781EC", Offset = "0x73781EC", Length = "0x14")]
		[Token(Token = "0x6002C75")]
		public override void Invoke(Byte[] buffer, int offset, int count) { }

	}

	[Token(Token = "0x400179D")]
	private static Byte[] buf_recycle; //Field offset: 0x0
	[Token(Token = "0x400179E")]
	private static readonly object buf_recycle_lock; //Field offset: 0x8
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400179F")]
	private Byte[] buf; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40017A0")]
	private string name; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40017A1")]
	private SafeFileHandle safeHandle; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40017A2")]
	private bool isExposed; //Field offset: 0x40
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40017A3")]
	private long append_startpos; //Field offset: 0x48
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40017A4")]
	private FileAccess access; //Field offset: 0x50
	[FieldOffset(Offset = "0x54")]
	[Token(Token = "0x40017A5")]
	private bool owner; //Field offset: 0x54
	[FieldOffset(Offset = "0x55")]
	[Token(Token = "0x40017A6")]
	private bool async; //Field offset: 0x55
	[FieldOffset(Offset = "0x56")]
	[Token(Token = "0x40017A7")]
	private bool canseek; //Field offset: 0x56
	[FieldOffset(Offset = "0x57")]
	[Token(Token = "0x40017A8")]
	private bool anonymous; //Field offset: 0x57
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40017A9")]
	private bool buf_dirty; //Field offset: 0x58
	[FieldOffset(Offset = "0x5C")]
	[Token(Token = "0x40017AA")]
	private int buf_size; //Field offset: 0x5C
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x40017AB")]
	private int buf_length; //Field offset: 0x60
	[FieldOffset(Offset = "0x64")]
	[Token(Token = "0x40017AC")]
	private int buf_offset; //Field offset: 0x64
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x40017AD")]
	private long buf_start; //Field offset: 0x68

	[Token(Token = "0x1700066D")]
	public virtual bool CanRead
	{
		[Address(RVA = "0x73754B4", Offset = "0x73754B4", Length = "0x14")]
		[Token(Token = "0x6002C4B")]
		 get { } //Length: 20
	}

	[Token(Token = "0x1700066F")]
	public virtual bool CanSeek
	{
		[Address(RVA = "0x73754DC", Offset = "0x73754DC", Length = "0x8")]
		[Token(Token = "0x6002C4D")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700066E")]
	public virtual bool CanWrite
	{
		[Address(RVA = "0x73754C8", Offset = "0x73754C8", Length = "0x14")]
		[Token(Token = "0x6002C4C")]
		 get { } //Length: 20
	}

	[Token(Token = "0x17000671")]
	public virtual long Length
	{
		[Address(RVA = "0x73754EC", Offset = "0x73754EC", Length = "0x164")]
		[Token(Token = "0x6002C4F")]
		 get { } //Length: 356
	}

	[Token(Token = "0x17000670")]
	public override string Name
	{
		[Address(RVA = "0x73754E4", Offset = "0x73754E4", Length = "0x8")]
		[Token(Token = "0x6002C4E")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000672")]
	public virtual long Position
	{
		[Address(RVA = "0x7375788", Offset = "0x7375788", Length = "0x170")]
		[Token(Token = "0x6002C50")]
		 get { } //Length: 368
		[Address(RVA = "0x73758F8", Offset = "0x73758F8", Length = "0x90")]
		[Token(Token = "0x6002C51")]
		 set { } //Length: 144
	}

	[Token(Token = "0x17000673")]
	public override SafeFileHandle SafeFileHandle
	{
		[Address(RVA = "0x7375988", Offset = "0x7375988", Length = "0x3C")]
		[Token(Token = "0x6002C52")]
		 get { } //Length: 60
	}

	[Address(RVA = "0x737815C", Offset = "0x737815C", Length = "0x7C")]
	[Token(Token = "0x6002C6F")]
	private static FileStream() { }

	[Address(RVA = "0x73737B8", Offset = "0x73737B8", Length = "0x750")]
	[Token(Token = "0x6002C49")]
	internal FileStream(string path, FileMode mode, FileAccess access, FileShare share, int bufferSize, bool anonymous, FileOptions options) { }

	[Address(RVA = "0x7373F34", Offset = "0x7373F34", Length = "0x18")]
	[Token(Token = "0x6002C48")]
	internal FileStream(string path, FileMode mode, FileAccess access, FileShare share, int bufferSize, bool isAsync, bool anonymous) { }

	[Address(RVA = "0x7362148", Offset = "0x7362148", Length = "0x20")]
	[Token(Token = "0x6002C47")]
	public FileStream(string path, FileMode mode, FileAccess access, FileShare share, int bufferSize, FileOptions options) { }

	[Address(RVA = "0x7373F90", Offset = "0x7373F90", Length = "0x28")]
	[Token(Token = "0x6002C46")]
	public FileStream(string path, FileMode mode, FileAccess access, FileShare share, int bufferSize, bool useAsync) { }

	[Address(RVA = "0x73732DC", Offset = "0x73732DC", Length = "0x1B4")]
	[Token(Token = "0x6002C41")]
	internal FileStream(IntPtr handle, FileAccess access, bool ownsHandle, int bufferSize, bool isAsync, bool isConsoleWrapper) { }

	[Address(RVA = "0x7373F4C", Offset = "0x7373F4C", Length = "0x24")]
	[Token(Token = "0x6002C44")]
	public FileStream(string path, FileMode mode, FileAccess access, FileShare share) { }

	[Address(RVA = "0x7373F08", Offset = "0x7373F08", Length = "0x2C")]
	[Token(Token = "0x6002C43")]
	public FileStream(string path, FileMode mode, FileAccess access) { }

	[Address(RVA = "0x7373784", Offset = "0x7373784", Length = "0x34")]
	[Token(Token = "0x6002C42")]
	public FileStream(string path, FileMode mode) { }

	[Address(RVA = "0x7373F70", Offset = "0x7373F70", Length = "0x20")]
	[Token(Token = "0x6002C45")]
	public FileStream(string path, FileMode mode, FileAccess access, FileShare share, int bufferSize) { }

	[Address(RVA = "0x73762F4", Offset = "0x73762F4", Length = "0x2A4")]
	[Token(Token = "0x6002C58")]
	public virtual IAsyncResult BeginRead(Byte[] array, int offset, int numBytes, AsyncCallback userCallback, object stateObject) { }

	[Address(RVA = "0x7376E74", Offset = "0x7376E74", Length = "0x2EC")]
	[Token(Token = "0x6002C5C")]
	public virtual IAsyncResult BeginWrite(Byte[] array, int offset, int numBytes, AsyncCallback userCallback, object stateObject) { }

	[Address(RVA = "0x7377C34", Offset = "0x7377C34", Length = "0x348")]
	[Token(Token = "0x6002C62")]
	protected virtual void Dispose(bool disposing) { }

	[Address(RVA = "0x737672C", Offset = "0x737672C", Length = "0x164")]
	[Token(Token = "0x6002C59")]
	public virtual int EndRead(IAsyncResult asyncResult) { }

	[Address(RVA = "0x7377400", Offset = "0x7377400", Length = "0x168")]
	[Token(Token = "0x6002C5D")]
	public virtual void EndWrite(IAsyncResult asyncResult) { }

	[Address(RVA = "0x737534C", Offset = "0x737534C", Length = "0x28")]
	[Token(Token = "0x6002C53")]
	private void ExposeHandle() { }

	[Address(RVA = "0x7377BA4", Offset = "0x7377BA4", Length = "0x90")]
	[Token(Token = "0x6002C61")]
	protected virtual void Finalize() { }

	[Address(RVA = "0x7377B2C", Offset = "0x7377B2C", Length = "0x78")]
	[Token(Token = "0x6002C60")]
	public virtual void Flush() { }

	[Address(RVA = "0x7377F80", Offset = "0x7377F80", Length = "0x88")]
	[Token(Token = "0x6002C63")]
	public virtual Task FlushAsync(CancellationToken cancellationToken) { }

	[Address(RVA = "0x73759C4", Offset = "0x73759C4", Length = "0x178")]
	[Token(Token = "0x6002C68")]
	private void FlushBuffer() { }

	[Address(RVA = "0x7375650", Offset = "0x7375650", Length = "0x10")]
	[Token(Token = "0x6002C69")]
	private void FlushBufferIfDirty() { }

	[Address(RVA = "0x73754B4", Offset = "0x73754B4", Length = "0x14")]
	[Token(Token = "0x6002C4B")]
	public virtual bool get_CanRead() { }

	[Address(RVA = "0x73754DC", Offset = "0x73754DC", Length = "0x8")]
	[Token(Token = "0x6002C4D")]
	public virtual bool get_CanSeek() { }

	[Address(RVA = "0x73754C8", Offset = "0x73754C8", Length = "0x14")]
	[Token(Token = "0x6002C4C")]
	public virtual bool get_CanWrite() { }

	[Address(RVA = "0x73754EC", Offset = "0x73754EC", Length = "0x164")]
	[Token(Token = "0x6002C4F")]
	public virtual long get_Length() { }

	[Address(RVA = "0x73754E4", Offset = "0x73754E4", Length = "0x8")]
	[Token(Token = "0x6002C4E")]
	public override string get_Name() { }

	[Address(RVA = "0x7375788", Offset = "0x7375788", Length = "0x170")]
	[Token(Token = "0x6002C50")]
	public virtual long get_Position() { }

	[Address(RVA = "0x7375988", Offset = "0x7375988", Length = "0x3C")]
	[Token(Token = "0x6002C52")]
	public override SafeFileHandle get_SafeFileHandle() { }

	[Address(RVA = "0x7374794", Offset = "0x7374794", Length = "0x84")]
	[Token(Token = "0x6002C6D")]
	private string GetSecureFileName(string filename) { }

	[Address(RVA = "0x7374650", Offset = "0x7374650", Length = "0xA8")]
	[Token(Token = "0x6002C6E")]
	private string GetSecureFileName(string filename, bool full) { }

	[Address(RVA = "0x7373490", Offset = "0x7373490", Length = "0x2F4")]
	[Token(Token = "0x6002C4A")]
	private void Init(SafeFileHandle safeHandle, FileAccess access, bool ownsHandle, int bufferSize, bool isAsync, bool isConsoleWrapper) { }

	[Address(RVA = "0x7375088", Offset = "0x7375088", Length = "0x2C4")]
	[Token(Token = "0x6002C6C")]
	private void InitBuffer(int size, bool isZeroSize) { }

	[Address(RVA = "0x7375F38", Offset = "0x7375F38", Length = "0x268")]
	[Token(Token = "0x6002C56")]
	public virtual int Read(out Byte[] array, int offset, int count) { }

	[Address(RVA = "0x7378008", Offset = "0x7378008", Length = "0x4")]
	[Token(Token = "0x6002C64")]
	public virtual Task<Int32> ReadAsync(Byte[] buffer, int offset, int count, CancellationToken cancellationToken) { }

	[Address(RVA = "0x7375B3C", Offset = "0x7375B3C", Length = "0x148")]
	[Token(Token = "0x6002C54")]
	public virtual int ReadByte() { }

	[Address(RVA = "0x7375C84", Offset = "0x7375C84", Length = "0x128")]
	[Token(Token = "0x6002C6B")]
	private int ReadData(SafeHandle safeHandle, Byte[] buf, int offset, int count) { }

	[Address(RVA = "0x73761A0", Offset = "0x73761A0", Length = "0x9C")]
	[Token(Token = "0x6002C57")]
	private int ReadInternal(Byte[] dest, int offset, int count) { }

	[Address(RVA = "0x737623C", Offset = "0x737623C", Length = "0xB8")]
	[Token(Token = "0x6002C66")]
	private int ReadSegment(Byte[] dest, int dest_offset, int count) { }

	[Address(RVA = "0x7375DAC", Offset = "0x7375DAC", Length = "0x30")]
	[Token(Token = "0x6002C6A")]
	private void RefillBuffer() { }

	[Address(RVA = "0x7377574", Offset = "0x7377574", Length = "0x274")]
	[Token(Token = "0x6002C5E")]
	public virtual long Seek(long offset, SeekOrigin origin) { }

	[Address(RVA = "0x73758F8", Offset = "0x73758F8", Length = "0x90")]
	[Token(Token = "0x6002C51")]
	public virtual void set_Position(long value) { }

	[Address(RVA = "0x73777E8", Offset = "0x73777E8", Length = "0x210")]
	[Token(Token = "0x6002C5F")]
	public virtual void SetLength(long value) { }

	[Address(RVA = "0x73768B8", Offset = "0x73768B8", Length = "0x23C")]
	[Token(Token = "0x6002C5A")]
	public virtual void Write(Byte[] array, int offset, int count) { }

	[Address(RVA = "0x737800C", Offset = "0x737800C", Length = "0x4")]
	[Token(Token = "0x6002C65")]
	public virtual Task WriteAsync(Byte[] buffer, int offset, int count, CancellationToken cancellationToken) { }

	[Address(RVA = "0x7375DDC", Offset = "0x7375DDC", Length = "0x15C")]
	[Token(Token = "0x6002C55")]
	public virtual void WriteByte(byte value) { }

	[Address(RVA = "0x7376AF4", Offset = "0x7376AF4", Length = "0x1BC")]
	[Token(Token = "0x6002C5B")]
	private void WriteInternal(Byte[] src, int offset, int count) { }

	[Address(RVA = "0x7376DFC", Offset = "0x7376DFC", Length = "0x78")]
	[Token(Token = "0x6002C67")]
	private int WriteSegment(Byte[] src, int src_offset, int count) { }

}

