namespace System.IO;

[Token(Token = "0x2000567")]
public class EndOfStreamException : IOException
{

	[Address(RVA = "0x7329BB0", Offset = "0x7329BB0", Length = "0x5C")]
	[Token(Token = "0x6002974")]
	public EndOfStreamException() { }

	[Address(RVA = "0x7329C0C", Offset = "0x7329C0C", Length = "0x24")]
	[Token(Token = "0x6002975")]
	public EndOfStreamException(string message) { }

	[Address(RVA = "0x7329C30", Offset = "0x7329C30", Length = "0x8")]
	[Token(Token = "0x6002976")]
	protected EndOfStreamException(SerializationInfo info, StreamingContext context) { }

}

