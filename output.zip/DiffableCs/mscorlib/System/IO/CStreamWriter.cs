namespace System.IO;

[Token(Token = "0x20005B9")]
internal class CStreamWriter : StreamWriter
{
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x40017F0")]
	private TermInfoDriver driver; //Field offset: 0x70

	[Address(RVA = "0x737C3F0", Offset = "0x737C3F0", Length = "0x134")]
	[Token(Token = "0x6002CD3")]
	public CStreamWriter(Stream stream, Encoding encoding, bool leaveOpen) { }

	[Address(RVA = "0x737CA00", Offset = "0x737CA00", Length = "0x84")]
	[Token(Token = "0x6002CD7")]
	public void InternalWriteChar(char val) { }

	[Address(RVA = "0x737CB08", Offset = "0x737CB08", Length = "0x8C")]
	[Token(Token = "0x6002CD8")]
	public void InternalWriteChars(Char[] buffer, int n) { }

	[Address(RVA = "0x737CA84", Offset = "0x737CA84", Length = "0x84")]
	[Token(Token = "0x6002CD6")]
	public void InternalWriteString(string val) { }

	[Address(RVA = "0x737C524", Offset = "0x737C524", Length = "0x35C")]
	[Token(Token = "0x6002CD4")]
	public virtual void Write(Char[] buffer, int index, int count) { }

	[Address(RVA = "0x737C880", Offset = "0x737C880", Length = "0x180")]
	[Token(Token = "0x6002CD5")]
	public virtual void Write(char val) { }

	[Address(RVA = "0x737CB94", Offset = "0x737CB94", Length = "0x28")]
	[Token(Token = "0x6002CD9")]
	public virtual void Write(Char[] val) { }

	[Address(RVA = "0x737CBBC", Offset = "0x737CBBC", Length = "0xCC")]
	[Token(Token = "0x6002CDA")]
	public virtual void Write(string val) { }

	[Address(RVA = "0x737CC88", Offset = "0x737CC88", Length = "0x44")]
	[Token(Token = "0x6002CDB")]
	public virtual void WriteLine(string val) { }

}

