namespace System.IO;

[Token(Token = "0x20005B7")]
internal class UnexceptionalStreamWriter : StreamWriter
{

	[Address(RVA = "0x737BB8C", Offset = "0x737BB8C", Length = "0x78")]
	[Token(Token = "0x6002CC7")]
	public UnexceptionalStreamWriter(Stream stream, Encoding encoding) { }

	[Address(RVA = "0x737BC04", Offset = "0x737BC04", Length = "0x84")]
	[Token(Token = "0x6002CC8")]
	public virtual void Flush() { }

	[Address(RVA = "0x737BC88", Offset = "0x737BC88", Length = "0x84")]
	[Token(Token = "0x6002CC9")]
	public virtual void Write(Char[] buffer, int index, int count) { }

	[Address(RVA = "0x737BD0C", Offset = "0x737BD0C", Length = "0x84")]
	[Token(Token = "0x6002CCA")]
	public virtual void Write(char value) { }

	[Address(RVA = "0x737BD90", Offset = "0x737BD90", Length = "0x84")]
	[Token(Token = "0x6002CCB")]
	public virtual void Write(Char[] value) { }

	[Address(RVA = "0x737BE14", Offset = "0x737BE14", Length = "0x84")]
	[Token(Token = "0x6002CCC")]
	public virtual void Write(string value) { }

}

