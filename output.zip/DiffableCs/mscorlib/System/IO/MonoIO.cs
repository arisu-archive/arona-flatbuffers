namespace System.IO;

[Token(Token = "0x20005B1")]
internal static class MonoIO
{
	[Token(Token = "0x40017BD")]
	public static readonly IntPtr InvalidHandle; //Field offset: 0x0
	[Token(Token = "0x40017BE")]
	private static bool dump_handles; //Field offset: 0x8

	[Token(Token = "0x1700067D")]
	public static char AltDirectorySeparatorChar
	{
		[Address(RVA = "0x737854C", Offset = "0x737854C", Length = "0x4")]
		[Token(Token = "0x6002C98")]
		 get { } //Length: 4
	}

	[Token(Token = "0x1700067A")]
	public static IntPtr ConsoleError
	{
		[Address(RVA = "0x737853C", Offset = "0x737853C", Length = "0x4")]
		[Token(Token = "0x6002C94")]
		 get { } //Length: 4
	}

	[Token(Token = "0x17000679")]
	public static IntPtr ConsoleInput
	{
		[Address(RVA = "0x7378538", Offset = "0x7378538", Length = "0x4")]
		[Token(Token = "0x6002C93")]
		 get { } //Length: 4
	}

	[Token(Token = "0x17000678")]
	public static IntPtr ConsoleOutput
	{
		[Address(RVA = "0x7378534", Offset = "0x7378534", Length = "0x4")]
		[Token(Token = "0x6002C92")]
		 get { } //Length: 4
	}

	[Token(Token = "0x1700067C")]
	public static char DirectorySeparatorChar
	{
		[Address(RVA = "0x7378548", Offset = "0x7378548", Length = "0x4")]
		[Token(Token = "0x6002C97")]
		 get { } //Length: 4
	}

	[Token(Token = "0x1700067E")]
	public static char PathSeparator
	{
		[Address(RVA = "0x7378550", Offset = "0x7378550", Length = "0x4")]
		[Token(Token = "0x6002C99")]
		 get { } //Length: 4
	}

	[Token(Token = "0x1700067B")]
	public static char VolumeSeparatorChar
	{
		[Address(RVA = "0x7378544", Offset = "0x7378544", Length = "0x4")]
		[Token(Token = "0x6002C96")]
		 get { } //Length: 4
	}

	[Address(RVA = "0x7378558", Offset = "0x7378558", Length = "0x8C")]
	[Token(Token = "0x6002C9C")]
	private static MonoIO() { }

	[Address(RVA = "0x73783F8", Offset = "0x73783F8", Length = "0x128")]
	[Token(Token = "0x6002C86")]
	internal static bool Cancel(SafeHandle safeHandle, out MonoIOError error) { }

	[Address(RVA = "0x73783F4", Offset = "0x73783F4", Length = "0x4")]
	[Token(Token = "0x6002C85")]
	private static bool Cancel_internal(IntPtr handle, out MonoIOError error) { }

	[Address(RVA = "0x7377F7C", Offset = "0x7377F7C", Length = "0x4")]
	[Token(Token = "0x6002C87")]
	public static bool Close(IntPtr handle, out MonoIOError error) { }

	[Address(RVA = "0x73783E4", Offset = "0x73783E4", Length = "0x4")]
	[Token(Token = "0x6002C9A")]
	private static void DumpHandles() { }

	[Address(RVA = "0x7378540", Offset = "0x7378540", Length = "0x4")]
	[Token(Token = "0x6002C95")]
	public static bool DuplicateHandle(IntPtr source_process_handle, IntPtr source_handle, IntPtr target_process_handle, out IntPtr target_handle, int access, int inherit, int options, out MonoIOError error) { }

	[Address(RVA = "0x737854C", Offset = "0x737854C", Length = "0x4")]
	[Token(Token = "0x6002C98")]
	public static char get_AltDirectorySeparatorChar() { }

	[Address(RVA = "0x737853C", Offset = "0x737853C", Length = "0x4")]
	[Token(Token = "0x6002C94")]
	public static IntPtr get_ConsoleError() { }

	[Address(RVA = "0x7378538", Offset = "0x7378538", Length = "0x4")]
	[Token(Token = "0x6002C93")]
	public static IntPtr get_ConsoleInput() { }

	[Address(RVA = "0x7378534", Offset = "0x7378534", Length = "0x4")]
	[Token(Token = "0x6002C92")]
	public static IntPtr get_ConsoleOutput() { }

	[Address(RVA = "0x7378548", Offset = "0x7378548", Length = "0x4")]
	[Token(Token = "0x6002C97")]
	public static char get_DirectorySeparatorChar() { }

	[Address(RVA = "0x7378550", Offset = "0x7378550", Length = "0x4")]
	[Token(Token = "0x6002C99")]
	public static char get_PathSeparator() { }

	[Address(RVA = "0x7378544", Offset = "0x7378544", Length = "0x4")]
	[Token(Token = "0x6002C96")]
	public static char get_VolumeSeparatorChar() { }

	[Address(RVA = "0x73783E8", Offset = "0x73783E8", Length = "0x4")]
	[Token(Token = "0x6002C80")]
	public static string GetCurrentDirectory(out MonoIOError error) { }

	[Address(RVA = "0x73782B4", Offset = "0x73782B4", Length = "0x130")]
	[Token(Token = "0x6002C7E")]
	public static Exception GetException(MonoIOError error) { }

	[Address(RVA = "0x7374818", Offset = "0x7374818", Length = "0x748")]
	[Token(Token = "0x6002C7F")]
	public static Exception GetException(string path, MonoIOError error) { }

	[Address(RVA = "0x7374F60", Offset = "0x7374F60", Length = "0x128")]
	[Token(Token = "0x6002C82")]
	public static MonoFileType GetFileType(SafeHandle safeHandle, out MonoIOError error) { }

	[Address(RVA = "0x73783EC", Offset = "0x73783EC", Length = "0x4")]
	[Token(Token = "0x6002C81")]
	private static MonoFileType GetFileType(IntPtr handle, out MonoIOError error) { }

	[Address(RVA = "0x737852C", Offset = "0x737852C", Length = "0x4")]
	[Token(Token = "0x6002C8E")]
	private static long GetLength(IntPtr handle, out MonoIOError error) { }

	[Address(RVA = "0x7375660", Offset = "0x7375660", Length = "0x128")]
	[Token(Token = "0x6002C8F")]
	public static long GetLength(SafeHandle safeHandle, out MonoIOError error) { }

	[Address(RVA = "0x73746F8", Offset = "0x73746F8", Length = "0x9C")]
	[Token(Token = "0x6002C84")]
	public static IntPtr Open(string filename, FileMode mode, FileAccess access, FileShare share, FileOptions options, out MonoIOError error) { }

	[Address(RVA = "0x73783F0", Offset = "0x73783F0", Length = "0x4")]
	[Token(Token = "0x6002C83")]
	private static IntPtr Open(Char* filename, FileMode mode, FileAccess access, FileShare share, FileOptions options, out MonoIOError error) { }

	[Address(RVA = "0x7378010", Offset = "0x7378010", Length = "0x14C")]
	[Token(Token = "0x6002C89")]
	public static int Read(SafeHandle safeHandle, Byte[] dest, int dest_offset, int count, out MonoIOError error) { }

	[Address(RVA = "0x7378520", Offset = "0x7378520", Length = "0x4")]
	[Token(Token = "0x6002C88")]
	private static int Read(IntPtr handle, Byte[] dest, int dest_offset, int count, out MonoIOError error) { }

	[Address(RVA = "0x7378554", Offset = "0x7378554", Length = "0x4")]
	[Token(Token = "0x6002C9B")]
	public static bool RemapPath(string path, out string newPath) { }

	[Address(RVA = "0x7378528", Offset = "0x7378528", Length = "0x4")]
	[Token(Token = "0x6002C8C")]
	private static long Seek(IntPtr handle, long offset, SeekOrigin origin, out MonoIOError error) { }

	[Address(RVA = "0x7375374", Offset = "0x7375374", Length = "0x140")]
	[Token(Token = "0x6002C8D")]
	public static long Seek(SafeHandle safeHandle, long offset, SeekOrigin origin, out MonoIOError error) { }

	[Address(RVA = "0x7378530", Offset = "0x7378530", Length = "0x4")]
	[Token(Token = "0x6002C90")]
	private static bool SetLength(IntPtr handle, long length, out MonoIOError error) { }

	[Address(RVA = "0x73779F8", Offset = "0x73779F8", Length = "0x134")]
	[Token(Token = "0x6002C91")]
	public static bool SetLength(SafeHandle safeHandle, long length, out MonoIOError error) { }

	[Address(RVA = "0x7376CB0", Offset = "0x7376CB0", Length = "0x14C")]
	[Token(Token = "0x6002C8B")]
	public static int Write(SafeHandle safeHandle, Byte[] src, int src_offset, int count, out MonoIOError error) { }

	[Address(RVA = "0x7378524", Offset = "0x7378524", Length = "0x4")]
	[Token(Token = "0x6002C8A")]
	private static int Write(IntPtr handle, in Byte[] src, int src_offset, int count, out MonoIOError error) { }

}

