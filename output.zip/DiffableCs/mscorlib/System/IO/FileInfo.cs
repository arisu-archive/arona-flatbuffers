namespace System.IO;

[Token(Token = "0x200058F")]
public sealed class FileInfo : FileSystemInfo
{

	[Token(Token = "0x17000649")]
	public DirectoryInfo Directory
	{
		[Address(RVA = "0x7362AD4", Offset = "0x7362AD4", Length = "0x7C")]
		[Token(Token = "0x6002B13")]
		 get { } //Length: 124
	}

	[Token(Token = "0x17000648")]
	public string DirectoryName
	{
		[Address(RVA = "0x73626E0", Offset = "0x73626E0", Length = "0x58")]
		[Token(Token = "0x6002B12")]
		 get { } //Length: 88
	}

	[Token(Token = "0x17000647")]
	public long Length
	{
		[Address(RVA = "0x7362514", Offset = "0x7362514", Length = "0x8C")]
		[Token(Token = "0x6002B11")]
		 get { } //Length: 140
	}

	[Token(Token = "0x1700064A")]
	public virtual string Name
	{
		[Address(RVA = "0x7362F40", Offset = "0x7362F40", Length = "0x8")]
		[Token(Token = "0x6002B18")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x73621D0", Offset = "0x73621D0", Length = "0x4")]
	[Token(Token = "0x6002B0E")]
	private FileInfo() { }

	[Address(RVA = "0x7362248", Offset = "0x7362248", Length = "0x10")]
	[Token(Token = "0x6002B0F")]
	public FileInfo(string fileName) { }

	[Address(RVA = "0x7362258", Offset = "0x7362258", Length = "0x144")]
	[Token(Token = "0x6002B10")]
	internal FileInfo(string originalPath, string fullPath = null, string fileName = null, bool isNormalized = false) { }

	[Address(RVA = "0x7362DDC", Offset = "0x7362DDC", Length = "0x4")]
	[Token(Token = "0x6002B17")]
	private FileInfo(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x7362BBC", Offset = "0x7362BBC", Length = "0x6C")]
	[Token(Token = "0x6002B15")]
	public StreamWriter AppendText() { }

	[Address(RVA = "0x7362B50", Offset = "0x7362B50", Length = "0x6C")]
	[Token(Token = "0x6002B14")]
	public StreamWriter CreateText() { }

	[Address(RVA = "0x7362C28", Offset = "0x7362C28", Length = "0x8")]
	[Token(Token = "0x6002B16")]
	public virtual void Delete() { }

	[Address(RVA = "0x7362AD4", Offset = "0x7362AD4", Length = "0x7C")]
	[Token(Token = "0x6002B13")]
	public DirectoryInfo get_Directory() { }

	[Address(RVA = "0x73626E0", Offset = "0x73626E0", Length = "0x58")]
	[Token(Token = "0x6002B12")]
	public string get_DirectoryName() { }

	[Address(RVA = "0x7362514", Offset = "0x7362514", Length = "0x8C")]
	[Token(Token = "0x6002B11")]
	public long get_Length() { }

	[Address(RVA = "0x7362F40", Offset = "0x7362F40", Length = "0x8")]
	[Token(Token = "0x6002B18")]
	public virtual string get_Name() { }

}

