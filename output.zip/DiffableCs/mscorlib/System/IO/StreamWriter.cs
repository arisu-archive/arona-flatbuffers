namespace System.IO;

[Token(Token = "0x2000579")]
public class StreamWriter : TextWriter
{
	[CompilerGenerated]
	[Token(Token = "0x200057D")]
	private struct <FlushAsyncInternal>d__74 : IAsyncStateMachine
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40016BC")]
		public int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x40016BD")]
		public AsyncTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40016BE")]
		public bool haveWrittenPreamble; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x40016BF")]
		public StreamWriter _this; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x40016C0")]
		public Encoding encoding; //Field offset: 0x30
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x40016C1")]
		public Stream stream; //Field offset: 0x38
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x40016C2")]
		public CancellationToken cancellationToken; //Field offset: 0x40
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x40016C3")]
		public Encoder encoder; //Field offset: 0x48
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x40016C4")]
		public Char[] charBuffer; //Field offset: 0x50
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x40016C5")]
		public int charPos; //Field offset: 0x58
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x40016C6")]
		public Byte[] byteBuffer; //Field offset: 0x60
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x40016C7")]
		public bool flushEncoder; //Field offset: 0x68
		[FieldOffset(Offset = "0x69")]
		[Token(Token = "0x40016C8")]
		public bool flushStream; //Field offset: 0x69
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x40016C9")]
		private ConfiguredValueTaskAwaiter <>u__1; //Field offset: 0x70
		[FieldOffset(Offset = "0x80")]
		[Token(Token = "0x40016CA")]
		private ConfiguredTaskAwaiter <>u__2; //Field offset: 0x80

		[Address(RVA = "0x73378B4", Offset = "0x73378B4", Length = "0x9C0")]
		[Token(Token = "0x6002A32")]
		private override void MoveNext() { }

		[Address(RVA = "0x7338274", Offset = "0x7338274", Length = "0x68")]
		[DebuggerHidden]
		[Token(Token = "0x6002A33")]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x200057A")]
	private struct <WriteAsyncInternal>d__57 : IAsyncStateMachine
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001694")]
		public int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x4001695")]
		public AsyncTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4001696")]
		public int charPos; //Field offset: 0x20
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x4001697")]
		public int charLen; //Field offset: 0x24
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4001698")]
		public StreamWriter _this; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4001699")]
		public Char[] charBuffer; //Field offset: 0x30
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x400169A")]
		public char value; //Field offset: 0x38
		[FieldOffset(Offset = "0x3A")]
		[Token(Token = "0x400169B")]
		public bool appendNewLine; //Field offset: 0x3A
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x400169C")]
		public Char[] coreNewLine; //Field offset: 0x40
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x400169D")]
		public bool autoFlush; //Field offset: 0x48
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x400169E")]
		private ConfiguredTaskAwaiter <>u__1; //Field offset: 0x50
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x400169F")]
		private int <i>5__2; //Field offset: 0x60

		[Address(RVA = "0x7336730", Offset = "0x7336730", Length = "0x4B0")]
		[Token(Token = "0x6002A2C")]
		private override void MoveNext() { }

		[Address(RVA = "0x7336BE0", Offset = "0x7336BE0", Length = "0x68")]
		[DebuggerHidden]
		[Token(Token = "0x6002A2D")]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x200057B")]
	private struct <WriteAsyncInternal>d__59 : IAsyncStateMachine
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40016A0")]
		public int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x40016A1")]
		public AsyncTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40016A2")]
		public string value; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x40016A3")]
		public int charPos; //Field offset: 0x28
		[FieldOffset(Offset = "0x2C")]
		[Token(Token = "0x40016A4")]
		public int charLen; //Field offset: 0x2C
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x40016A5")]
		public StreamWriter _this; //Field offset: 0x30
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x40016A6")]
		public Char[] charBuffer; //Field offset: 0x38
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x40016A7")]
		public bool appendNewLine; //Field offset: 0x40
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x40016A8")]
		public Char[] coreNewLine; //Field offset: 0x48
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x40016A9")]
		public bool autoFlush; //Field offset: 0x50
		[FieldOffset(Offset = "0x54")]
		[Token(Token = "0x40016AA")]
		private int <count>5__2; //Field offset: 0x54
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x40016AB")]
		private int <index>5__3; //Field offset: 0x58
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x40016AC")]
		private ConfiguredTaskAwaiter <>u__1; //Field offset: 0x60
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x40016AD")]
		private int <i>5__4; //Field offset: 0x70

		[Address(RVA = "0x7336C48", Offset = "0x7336C48", Length = "0x504")]
		[Token(Token = "0x6002A2E")]
		private override void MoveNext() { }

		[Address(RVA = "0x733714C", Offset = "0x733714C", Length = "0x68")]
		[DebuggerHidden]
		[Token(Token = "0x6002A2F")]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x200057C")]
	private struct <WriteAsyncInternal>d__62 : IAsyncStateMachine
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40016AE")]
		public int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x40016AF")]
		public AsyncTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40016B0")]
		public int charPos; //Field offset: 0x20
		[FieldOffset(Offset = "0x24")]
		[Token(Token = "0x40016B1")]
		public int charLen; //Field offset: 0x24
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x40016B2")]
		public StreamWriter _this; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x40016B3")]
		public Char[] charBuffer; //Field offset: 0x30
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x40016B4")]
		public CancellationToken cancellationToken; //Field offset: 0x38
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x40016B5")]
		public ReadOnlyMemory<Char> source; //Field offset: 0x40
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x40016B6")]
		public bool appendNewLine; //Field offset: 0x50
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x40016B7")]
		public Char[] coreNewLine; //Field offset: 0x58
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x40016B8")]
		public bool autoFlush; //Field offset: 0x60
		[FieldOffset(Offset = "0x64")]
		[Token(Token = "0x40016B9")]
		private int <copied>5__2; //Field offset: 0x64
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x40016BA")]
		private ConfiguredTaskAwaiter <>u__1; //Field offset: 0x68
		[FieldOffset(Offset = "0x78")]
		[Token(Token = "0x40016BB")]
		private int <i>5__3; //Field offset: 0x78

		[Address(RVA = "0x73371B4", Offset = "0x73371B4", Length = "0x698")]
		[Token(Token = "0x6002A30")]
		private override void MoveNext() { }

		[Address(RVA = "0x733784C", Offset = "0x733784C", Length = "0x68")]
		[DebuggerHidden]
		[Token(Token = "0x6002A31")]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[Token(Token = "0x4001688")]
	public static readonly StreamWriter Null; //Field offset: 0x0
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4001689")]
	private Stream _stream; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400168A")]
	private Encoding _encoding; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400168B")]
	private Encoder _encoder; //Field offset: 0x40
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x400168C")]
	private Byte[] _byteBuffer; //Field offset: 0x48
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x400168D")]
	private Char[] _charBuffer; //Field offset: 0x50
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x400168E")]
	private int _charPos; //Field offset: 0x58
	[FieldOffset(Offset = "0x5C")]
	[Token(Token = "0x400168F")]
	private int _charLen; //Field offset: 0x5C
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x4001690")]
	private bool _autoFlush; //Field offset: 0x60
	[FieldOffset(Offset = "0x61")]
	[Token(Token = "0x4001691")]
	private bool _haveWrittenPreamble; //Field offset: 0x61
	[FieldOffset(Offset = "0x62")]
	[Token(Token = "0x4001692")]
	private bool _closable; //Field offset: 0x62
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4001693")]
	private Task _asyncWriteTask; //Field offset: 0x68

	[Token(Token = "0x1700062B")]
	public override bool AutoFlush
	{
		[Address(RVA = "0x7332F0C", Offset = "0x7332F0C", Length = "0x40")]
		[Token(Token = "0x6002A12")]
		 set { } //Length: 64
	}

	[Token(Token = "0x1700062C")]
	public override Stream BaseStream
	{
		[Address(RVA = "0x7332F4C", Offset = "0x7332F4C", Length = "0x8")]
		[Token(Token = "0x6002A13")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700062F")]
	private int CharPos_Prop
	{
		[Address(RVA = "0x73364BC", Offset = "0x73364BC", Length = "0x8")]
		[Token(Token = "0x6002A27")]
		private set { } //Length: 8
	}

	[Token(Token = "0x1700062E")]
	public virtual Encoding Encoding
	{
		[Address(RVA = "0x7332F64", Offset = "0x7332F64", Length = "0x8")]
		[Token(Token = "0x6002A15")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000630")]
	private bool HaveWrittenPreamble_Prop
	{
		[Address(RVA = "0x73364C4", Offset = "0x73364C4", Length = "0x8")]
		[Token(Token = "0x6002A28")]
		private set { } //Length: 8
	}

	[Token(Token = "0x1700062D")]
	internal bool LeaveOpen
	{
		[Address(RVA = "0x7332F54", Offset = "0x7332F54", Length = "0x10")]
		[Token(Token = "0x6002A14")]
		internal get { } //Length: 16
	}

	[Token(Token = "0x1700062A")]
	private static Encoding UTF8NoBOM
	{
		[Address(RVA = "0x73322C0", Offset = "0x73322C0", Length = "0x50")]
		[Token(Token = "0x6002A05")]
		private get { } //Length: 80
	}

	[Address(RVA = "0x7336674", Offset = "0x7336674", Length = "0xBC")]
	[Token(Token = "0x6002A2B")]
	private static StreamWriter() { }

	[Address(RVA = "0x7332900", Offset = "0x7332900", Length = "0x258")]
	[Token(Token = "0x6002A0C")]
	public StreamWriter(string path, bool append, Encoding encoding, int bufferSize) { }

	[Address(RVA = "0x7332B58", Offset = "0x7332B58", Length = "0x78")]
	[Token(Token = "0x6002A0B")]
	public StreamWriter(string path, bool append) { }

	[Address(RVA = "0x7332310", Offset = "0x7332310", Length = "0xC4")]
	[Token(Token = "0x6002A06")]
	internal StreamWriter() { }

	[Address(RVA = "0x7332478", Offset = "0x7332478", Length = "0x74")]
	[Token(Token = "0x6002A07")]
	public StreamWriter(Stream stream) { }

	[Address(RVA = "0x7332704", Offset = "0x7332704", Length = "0xC")]
	[Token(Token = "0x6002A08")]
	public StreamWriter(Stream stream, Encoding encoding) { }

	[Address(RVA = "0x73324EC", Offset = "0x73324EC", Length = "0x218")]
	[Token(Token = "0x6002A09")]
	public StreamWriter(Stream stream, Encoding encoding, int bufferSize, bool leaveOpen) { }

	[Address(RVA = "0x733288C", Offset = "0x733288C", Length = "0x74")]
	[Token(Token = "0x6002A0A")]
	public StreamWriter(string path) { }

	[Address(RVA = "0x7332204", Offset = "0x7332204", Length = "0x6C")]
	[Token(Token = "0x6002A03")]
	private void CheckAsyncTaskInProgress() { }

	[Address(RVA = "0x7332C68", Offset = "0x7332C68", Length = "0x6C")]
	[Token(Token = "0x6002A0E")]
	public virtual void Close() { }

	[Address(RVA = "0x7332CD4", Offset = "0x7332CD4", Length = "0x90")]
	[Token(Token = "0x6002A0F")]
	protected virtual void Dispose(bool disposing) { }

	[Address(RVA = "0x7332EEC", Offset = "0x7332EEC", Length = "0x20")]
	[Token(Token = "0x6002A10")]
	public virtual void Flush() { }

	[Address(RVA = "0x7332D64", Offset = "0x7332D64", Length = "0x188")]
	[Token(Token = "0x6002A11")]
	private void Flush(bool flushStream, bool flushEncoder) { }

	[Address(RVA = "0x7335FD8", Offset = "0x7335FD8", Length = "0x148")]
	[Token(Token = "0x6002A26")]
	public virtual Task FlushAsync() { }

	[Address(RVA = "0x733631C", Offset = "0x733631C", Length = "0x1A0")]
	[Token(Token = "0x6002A29")]
	private Task FlushAsyncInternal(bool flushStream, bool flushEncoder, Char[] sCharBuffer, int sCharPos, CancellationToken cancellationToken = null) { }

	[Address(RVA = "0x73364CC", Offset = "0x73364CC", Length = "0x1A8")]
	[AsyncStateMachine(typeof(<FlushAsyncInternal>d__74))]
	[Token(Token = "0x6002A2A")]
	private static Task FlushAsyncInternal(StreamWriter _this, bool flushStream, bool flushEncoder, Char[] charBuffer, int charPos, bool haveWrittenPreamble, Encoding encoding, Encoder encoder, Byte[] byteBuffer, Stream stream, CancellationToken cancellationToken) { }

	[Address(RVA = "0x7332F4C", Offset = "0x7332F4C", Length = "0x8")]
	[Token(Token = "0x6002A13")]
	public override Stream get_BaseStream() { }

	[Address(RVA = "0x7332F64", Offset = "0x7332F64", Length = "0x8")]
	[Token(Token = "0x6002A15")]
	public virtual Encoding get_Encoding() { }

	[Address(RVA = "0x7332F54", Offset = "0x7332F54", Length = "0x10")]
	[Token(Token = "0x6002A14")]
	internal bool get_LeaveOpen() { }

	[Address(RVA = "0x73322C0", Offset = "0x73322C0", Length = "0x50")]
	[Token(Token = "0x6002A05")]
	private static Encoding get_UTF8NoBOM() { }

	[Address(RVA = "0x7332710", Offset = "0x7332710", Length = "0x17C")]
	[Token(Token = "0x6002A0D")]
	private void Init(Stream streamArg, Encoding encodingArg, int bufferSize, bool shouldLeaveOpen) { }

	[Address(RVA = "0x7332F0C", Offset = "0x7332F0C", Length = "0x40")]
	[Token(Token = "0x6002A12")]
	public override void set_AutoFlush(bool value) { }

	[Address(RVA = "0x73364BC", Offset = "0x73364BC", Length = "0x8")]
	[Token(Token = "0x6002A27")]
	private void set_CharPos_Prop(int value) { }

	[Address(RVA = "0x73364C4", Offset = "0x73364C4", Length = "0x8")]
	[Token(Token = "0x6002A28")]
	private void set_HaveWrittenPreamble_Prop(bool value) { }

	[Address(RVA = "0x7332270", Offset = "0x7332270", Length = "0x50")]
	[Token(Token = "0x6002A04")]
	private static void ThrowAsyncIOInProgress() { }

	[Address(RVA = "0x7332FF8", Offset = "0x7332FF8", Length = "0x268")]
	[Token(Token = "0x6002A17")]
	public virtual void Write(Char[] buffer) { }

	[Address(RVA = "0x73338F8", Offset = "0x73338F8", Length = "0x26C")]
	[Token(Token = "0x6002A1A")]
	public virtual void Write(string value) { }

	[Address(RVA = "0x7333260", Offset = "0x7333260", Length = "0x3D8")]
	[Token(Token = "0x6002A18")]
	public virtual void Write(Char[] buffer, int index, int count) { }

	[Address(RVA = "0x7332F6C", Offset = "0x7332F6C", Length = "0x8C")]
	[Token(Token = "0x6002A16")]
	public virtual void Write(char value) { }

	[Address(RVA = "0x73343AC", Offset = "0x73343AC", Length = "0x210")]
	[Token(Token = "0x6002A1E")]
	public virtual Task WriteAsync(string value) { }

	[Address(RVA = "0x7334970", Offset = "0x7334970", Length = "0x318")]
	[Token(Token = "0x6002A20")]
	public virtual Task WriteAsync(Char[] buffer, int index, int count) { }

	[Address(RVA = "0x7333E5C", Offset = "0x7333E5C", Length = "0x1A8")]
	[Token(Token = "0x6002A1C")]
	public virtual Task WriteAsync(char value) { }

	[Address(RVA = "0x733424C", Offset = "0x733424C", Length = "0x160")]
	[AsyncStateMachine(typeof(<WriteAsyncInternal>d__57))]
	[Token(Token = "0x6002A1D")]
	private static Task WriteAsyncInternal(StreamWriter _this, char value, Char[] charBuffer, int charPos, int charLen, Char[] coreNewLine, bool autoFlush, bool appendNewLine) { }

	[Address(RVA = "0x7334804", Offset = "0x7334804", Length = "0x16C")]
	[AsyncStateMachine(typeof(<WriteAsyncInternal>d__59))]
	[Token(Token = "0x6002A1F")]
	private static Task WriteAsyncInternal(StreamWriter _this, string value, Char[] charBuffer, int charPos, int charLen, Char[] coreNewLine, bool autoFlush, bool appendNewLine) { }

	[Address(RVA = "0x7334EE0", Offset = "0x7334EE0", Length = "0x190")]
	[AsyncStateMachine(typeof(<WriteAsyncInternal>d__62))]
	[Token(Token = "0x6002A21")]
	private static Task WriteAsyncInternal(StreamWriter _this, ReadOnlyMemory<Char> source, Char[] charBuffer, int charPos, int charLen, Char[] coreNewLine, bool autoFlush, bool appendNewLine, CancellationToken cancellationToken) { }

	[Address(RVA = "0x7333B64", Offset = "0x7333B64", Length = "0x2F8")]
	[Token(Token = "0x6002A1B")]
	public virtual void WriteLine(string value) { }

	[Address(RVA = "0x7335070", Offset = "0x7335070", Length = "0x1E0")]
	[Token(Token = "0x6002A22")]
	public virtual Task WriteLineAsync() { }

	[Address(RVA = "0x7335258", Offset = "0x7335258", Length = "0x1A8")]
	[Token(Token = "0x6002A23")]
	public virtual Task WriteLineAsync(char value) { }

	[Address(RVA = "0x7335648", Offset = "0x7335648", Length = "0x1D4")]
	[Token(Token = "0x6002A24")]
	public virtual Task WriteLineAsync(string value) { }

	[Address(RVA = "0x7335A64", Offset = "0x7335A64", Length = "0x31C")]
	[Token(Token = "0x6002A25")]
	public virtual Task WriteLineAsync(Char[] buffer, int index, int count) { }

	[Address(RVA = "0x7333638", Offset = "0x7333638", Length = "0x2C0")]
	[Token(Token = "0x6002A19")]
	private void WriteSpan(ReadOnlySpan<Char> buffer, bool appendNewLine) { }

}

