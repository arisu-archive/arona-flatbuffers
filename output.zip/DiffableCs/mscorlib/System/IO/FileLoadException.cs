namespace System.IO;

[Token(Token = "0x200056A")]
public class FileLoadException : IOException
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x400163A")]
	private readonly string <FileName>k__BackingField; //Field offset: 0x90
	[CompilerGenerated]
	[FieldOffset(Offset = "0x98")]
	[Token(Token = "0x400163B")]
	private readonly string <FusionLog>k__BackingField; //Field offset: 0x98

	[Token(Token = "0x17000618")]
	public string FileName
	{
		[Address(RVA = "0x7329F88", Offset = "0x7329F88", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x600297F")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000619")]
	public string FusionLog
	{
		[Address(RVA = "0x7329F90", Offset = "0x7329F90", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6002980")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000617")]
	public virtual string Message
	{
		[Address(RVA = "0x7329ED4", Offset = "0x7329ED4", Length = "0x40")]
		[Token(Token = "0x600297E")]
		 get { } //Length: 64
	}

	[Address(RVA = "0x7329E18", Offset = "0x7329E18", Length = "0x5C")]
	[Token(Token = "0x600297B")]
	public FileLoadException() { }

	[Address(RVA = "0x7329E74", Offset = "0x7329E74", Length = "0x24")]
	[Token(Token = "0x600297C")]
	public FileLoadException(string message) { }

	[Address(RVA = "0x7329E98", Offset = "0x7329E98", Length = "0x3C")]
	[Token(Token = "0x600297D")]
	public FileLoadException(string message, string fileName) { }

	[Address(RVA = "0x732A178", Offset = "0x732A178", Length = "0xC4")]
	[Token(Token = "0x6002982")]
	protected FileLoadException(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x7329F14", Offset = "0x7329F14", Length = "0x74")]
	[Token(Token = "0x6002984")]
	internal static string FormatFileLoadExceptionMessage(string fileName, int hResult) { }

	[Address(RVA = "0x7329F88", Offset = "0x7329F88", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x600297F")]
	public string get_FileName() { }

	[Address(RVA = "0x7329F90", Offset = "0x7329F90", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6002980")]
	public string get_FusionLog() { }

	[Address(RVA = "0x7329ED4", Offset = "0x7329ED4", Length = "0x40")]
	[Token(Token = "0x600297E")]
	public virtual string get_Message() { }

	[Address(RVA = "0x732A23C", Offset = "0x732A23C", Length = "0x118")]
	[Token(Token = "0x6002983")]
	public virtual void GetObjectData(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x7329F98", Offset = "0x7329F98", Length = "0x1E0")]
	[Token(Token = "0x6002981")]
	public virtual string ToString() { }

}

