namespace System.IO.Enumeration;

[IsByRefLike]
[Obsolete("Types with embedded references are not supported in this version of your compiler.", True)]
[Token(Token = "0x20005BB")]
public struct FileSystemEntry
{
	[CompilerGenerated]
	[Token(Token = "0x20005BC")]
	[UnsafeValueType]
	internal struct <_fileNameBuffer>e__FixedBuffer
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40017FB")]
		public char FixedElementField; //Field offset: 0x0

	}

	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40017F1")]
	internal DirectoryEntry _directoryEntry; //Field offset: 0x0
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40017F2")]
	private FileStatus _status; //Field offset: 0x10
	[FieldOffset(Offset = "0x88")]
	[Token(Token = "0x40017F3")]
	private Span<Char> _pathBuffer; //Field offset: 0x88
	[FieldOffset(Offset = "0x98")]
	[Token(Token = "0x40017F4")]
	private ReadOnlySpan<Char> _fullPath; //Field offset: 0x98
	[FieldOffset(Offset = "0xA8")]
	[Token(Token = "0x40017F5")]
	private ReadOnlySpan<Char> _fileName; //Field offset: 0xA8
	[FieldOffset(Offset = "0xB8")]
	[FixedBuffer(typeof(char, 256)]
	[Token(Token = "0x40017F6")]
	private <_fileNameBuffer>e__FixedBuffer _fileNameBuffer; //Field offset: 0xB8
	[FieldOffset(Offset = "0x2B8")]
	[Token(Token = "0x40017F7")]
	private FileAttributes _initialAttributes; //Field offset: 0x2B8
	[CompilerGenerated]
	[FieldOffset(Offset = "0x2C0")]
	[Token(Token = "0x40017F8")]
	private ReadOnlySpan<Char> <Directory>k__BackingField; //Field offset: 0x2C0
	[CompilerGenerated]
	[FieldOffset(Offset = "0x2D0")]
	[Token(Token = "0x40017F9")]
	private ReadOnlySpan<Char> <RootDirectory>k__BackingField; //Field offset: 0x2D0
	[CompilerGenerated]
	[FieldOffset(Offset = "0x2E0")]
	[Token(Token = "0x40017FA")]
	private ReadOnlySpan<Char> <OriginalRootDirectory>k__BackingField; //Field offset: 0x2E0

	[Token(Token = "0x17000684")]
	public FileAttributes Attributes
	{
		[Address(RVA = "0x737D1BC", Offset = "0x737D1BC", Length = "0x48")]
		[Token(Token = "0x6002CE6")]
		 get { } //Length: 72
	}

	[Token(Token = "0x17000681")]
	public private ReadOnlySpan<Char> Directory
	{
		[Address(RVA = "0x737D168", Offset = "0x737D168", Length = "0x10")]
		[CompilerGenerated]
		[IsReadOnly]
		[Token(Token = "0x6002CE0")]
		 get { } //Length: 16
		[Address(RVA = "0x737D178", Offset = "0x737D178", Length = "0xC")]
		[CompilerGenerated]
		[Token(Token = "0x6002CE1")]
		private set { } //Length: 12
	}

	[Token(Token = "0x17000680")]
	public ReadOnlySpan<Char> FileName
	{
		[Address(RVA = "0x737D0D4", Offset = "0x737D0D4", Length = "0x94")]
		[Token(Token = "0x6002CDF")]
		 get { } //Length: 148
	}

	[Token(Token = "0x1700067F")]
	private ReadOnlySpan<Char> FullPath
	{
		[Address(RVA = "0x737CFA0", Offset = "0x737CFA0", Length = "0x134")]
		[Token(Token = "0x6002CDE")]
		private get { } //Length: 308
	}

	[Token(Token = "0x17000685")]
	public bool IsDirectory
	{
		[Address(RVA = "0x737D204", Offset = "0x737D204", Length = "0x8")]
		[Token(Token = "0x6002CE7")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000683")]
	public private ReadOnlySpan<Char> OriginalRootDirectory
	{
		[Address(RVA = "0x737D1A0", Offset = "0x737D1A0", Length = "0x10")]
		[CompilerGenerated]
		[IsReadOnly]
		[Token(Token = "0x6002CE4")]
		 get { } //Length: 16
		[Address(RVA = "0x737D1B0", Offset = "0x737D1B0", Length = "0xC")]
		[CompilerGenerated]
		[Token(Token = "0x6002CE5")]
		private set { } //Length: 12
	}

	[Token(Token = "0x17000682")]
	public private ReadOnlySpan<Char> RootDirectory
	{
		[Address(RVA = "0x737D184", Offset = "0x737D184", Length = "0x10")]
		[CompilerGenerated]
		[IsReadOnly]
		[Token(Token = "0x6002CE2")]
		 get { } //Length: 16
		[Address(RVA = "0x737D194", Offset = "0x737D194", Length = "0xC")]
		[CompilerGenerated]
		[Token(Token = "0x6002CE3")]
		private set { } //Length: 12
	}

	[Address(RVA = "0x737D1BC", Offset = "0x737D1BC", Length = "0x48")]
	[Token(Token = "0x6002CE6")]
	public FileAttributes get_Attributes() { }

	[Address(RVA = "0x737D168", Offset = "0x737D168", Length = "0x10")]
	[CompilerGenerated]
	[IsReadOnly]
	[Token(Token = "0x6002CE0")]
	public ReadOnlySpan<Char> get_Directory() { }

	[Address(RVA = "0x737D0D4", Offset = "0x737D0D4", Length = "0x94")]
	[Token(Token = "0x6002CDF")]
	public ReadOnlySpan<Char> get_FileName() { }

	[Address(RVA = "0x737CFA0", Offset = "0x737CFA0", Length = "0x134")]
	[Token(Token = "0x6002CDE")]
	private ReadOnlySpan<Char> get_FullPath() { }

	[Address(RVA = "0x737D204", Offset = "0x737D204", Length = "0x8")]
	[Token(Token = "0x6002CE7")]
	public bool get_IsDirectory() { }

	[Address(RVA = "0x737D1A0", Offset = "0x737D1A0", Length = "0x10")]
	[CompilerGenerated]
	[IsReadOnly]
	[Token(Token = "0x6002CE4")]
	public ReadOnlySpan<Char> get_OriginalRootDirectory() { }

	[Address(RVA = "0x737D184", Offset = "0x737D184", Length = "0x10")]
	[CompilerGenerated]
	[IsReadOnly]
	[Token(Token = "0x6002CE2")]
	public ReadOnlySpan<Char> get_RootDirectory() { }

	[Address(RVA = "0x737CCCC", Offset = "0x737CCCC", Length = "0x2D4")]
	[Token(Token = "0x6002CDD")]
	internal static FileAttributes Initialize(ref FileSystemEntry entry, DirectoryEntry directoryEntry, ReadOnlySpan<Char> directory, ReadOnlySpan<Char> rootDirectory, ReadOnlySpan<Char> originalRootDirectory, Span<Char> pathBuffer) { }

	[Address(RVA = "0x737D178", Offset = "0x737D178", Length = "0xC")]
	[CompilerGenerated]
	[Token(Token = "0x6002CE1")]
	private void set_Directory(ReadOnlySpan<Char> value) { }

	[Address(RVA = "0x737D1B0", Offset = "0x737D1B0", Length = "0xC")]
	[CompilerGenerated]
	[Token(Token = "0x6002CE5")]
	private void set_OriginalRootDirectory(ReadOnlySpan<Char> value) { }

	[Address(RVA = "0x737D194", Offset = "0x737D194", Length = "0xC")]
	[CompilerGenerated]
	[Token(Token = "0x6002CE3")]
	private void set_RootDirectory(ReadOnlySpan<Char> value) { }

	[Address(RVA = "0x737D20C", Offset = "0x737D20C", Length = "0x70")]
	[Token(Token = "0x6002CE8")]
	public FileSystemInfo ToFileSystemInfo() { }

	[Address(RVA = "0x737D27C", Offset = "0x737D27C", Length = "0x28")]
	[Token(Token = "0x6002CE9")]
	public string ToFullPath() { }

	[Address(RVA = "0x737D2A4", Offset = "0x737D2A4", Length = "0x18C")]
	[Token(Token = "0x6002CEA")]
	public string ToSpecifiedFullPath() { }

}

