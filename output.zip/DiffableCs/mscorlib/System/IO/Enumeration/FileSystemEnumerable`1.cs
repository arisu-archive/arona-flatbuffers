namespace System.IO.Enumeration;

[Token(Token = "0x20005BD")]
public class FileSystemEnumerable : IEnumerable<TResult>, IEnumerable
{
	[Token(Token = "0x20005C0")]
	private sealed class DelegateEnumerator : FileSystemEnumerator<TResult>
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001802")]
		private readonly FileSystemEnumerable<TResult> _enumerable; //Field offset: 0x0

		[Address(RVA = "0x6E341E8", Offset = "0x6E341E8", Length = "0x4C")]
		[Token(Token = "0x6002CF5")]
		public DelegateEnumerator(FileSystemEnumerable<TResult> enumerable) { }

		[Address(RVA = "0x6E342C8", Offset = "0x6E342C8", Length = "0x64")]
		[Token(Token = "0x6002CF8")]
		protected virtual bool ShouldIncludeEntry(ref FileSystemEntry entry) { }

		[Address(RVA = "0x6E34264", Offset = "0x6E34264", Length = "0x64")]
		[Token(Token = "0x6002CF7")]
		protected virtual bool ShouldRecurseIntoEntry(ref FileSystemEntry entry) { }

		[Address(RVA = "0x6E34234", Offset = "0x6E34234", Length = "0x30")]
		[Token(Token = "0x6002CF6")]
		protected virtual TResult TransformEntry(ref FileSystemEntry entry) { }

	}

	[Token(Token = "0x20005BE")]
	internal sealed class FindPredicate : MulticastDelegate
	{

		[Address(RVA = "0x4D4DD34", Offset = "0x4D4DD34", Length = "0xE8")]
		[Token(Token = "0x6002CF1")]
		public FindPredicate(object object, IntPtr method) { }

		[Address(RVA = "0x4D4DE1C", Offset = "0x4D4DE1C", Length = "0x14")]
		[Token(Token = "0x6002CF2")]
		public override bool Invoke(ref FileSystemEntry entry) { }

	}

	[Token(Token = "0x20005BF")]
	internal sealed class FindTransform : MulticastDelegate
	{

		[Address(RVA = "0x4D4DE30", Offset = "0x4D4DE30", Length = "0xE8")]
		[Token(Token = "0x6002CF3")]
		public FindTransform(object object, IntPtr method) { }

		[Address(RVA = "0x4D4DF18", Offset = "0x4D4DF18", Length = "0x14")]
		[Token(Token = "0x6002CF4")]
		public override TResult Invoke(ref FileSystemEntry entry) { }

	}

	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40017FC")]
	private DelegateEnumerator<TResult> _enumerator; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40017FD")]
	private readonly FindTransform<TResult> _transform; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40017FE")]
	private readonly EnumerationOptions _options; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40017FF")]
	private readonly string _directory; //Field offset: 0x0
	[CompilerGenerated]
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001800")]
	private FindPredicate<TResult> <ShouldIncludePredicate>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001801")]
	private FindPredicate<TResult> <ShouldRecursePredicate>k__BackingField; //Field offset: 0x0

	[Token(Token = "0x17000686")]
	public FindPredicate<TResult> ShouldIncludePredicate
	{
		[Address(RVA = "0x4D47700", Offset = "0x4D47700", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6002CEC")]
		 get { } //Length: 8
		[Address(RVA = "0x4D47708", Offset = "0x4D47708", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6002CED")]
		 set { } //Length: 8
	}

	[Token(Token = "0x17000687")]
	public FindPredicate<TResult> ShouldRecursePredicate
	{
		[Address(RVA = "0x4D47710", Offset = "0x4D47710", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6002CEE")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x4D4753C", Offset = "0x4D4753C", Length = "0x1C4")]
	[Token(Token = "0x6002CEB")]
	public FileSystemEnumerable`1(string directory, FindTransform<TResult> transform, EnumerationOptions options = null) { }

	[Address(RVA = "0x4D47700", Offset = "0x4D47700", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6002CEC")]
	public FindPredicate<TResult> get_ShouldIncludePredicate() { }

	[Address(RVA = "0x4D47710", Offset = "0x4D47710", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6002CEE")]
	public FindPredicate<TResult> get_ShouldRecursePredicate() { }

	[Address(RVA = "0x4D47718", Offset = "0x4D47718", Length = "0x74")]
	[Token(Token = "0x6002CEF")]
	public override IEnumerator<TResult> GetEnumerator() { }

	[Address(RVA = "0x4D47708", Offset = "0x4D47708", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6002CED")]
	public void set_ShouldIncludePredicate(FindPredicate<TResult> value) { }

	[Address(RVA = "0x4D4778C", Offset = "0x4D4778C", Length = "0x14")]
	[Token(Token = "0x6002CF0")]
	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

