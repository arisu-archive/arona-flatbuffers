namespace System.IO.Enumeration;

[Token(Token = "0x20005C1")]
internal static class FileSystemEnumerableFactory
{
	[CompilerGenerated]
	[Token(Token = "0x20005C3")]
	private sealed class <>c
	{
		[Token(Token = "0x4001806")]
		public static readonly <>c <>9; //Field offset: 0x0
		[Token(Token = "0x4001807")]
		public static FindTransform<String> <>9__3_0; //Field offset: 0x8
		[Token(Token = "0x4001808")]
		public static FindTransform<String> <>9__4_0; //Field offset: 0x10
		[Token(Token = "0x4001809")]
		public static FindTransform<String> <>9__5_0; //Field offset: 0x18
		[Token(Token = "0x400180A")]
		public static FindTransform<FileInfo> <>9__6_0; //Field offset: 0x20
		[Token(Token = "0x400180B")]
		public static FindTransform<DirectoryInfo> <>9__7_0; //Field offset: 0x28
		[Token(Token = "0x400180C")]
		public static FindTransform<FileSystemInfo> <>9__8_0; //Field offset: 0x30

		[Address(RVA = "0x737ED34", Offset = "0x737ED34", Length = "0x70")]
		[Token(Token = "0x6002D04")]
		private static <>c() { }

		[Address(RVA = "0x737EDA4", Offset = "0x737EDA4", Length = "0x8")]
		[Token(Token = "0x6002D05")]
		public <>c() { }

		[Address(RVA = "0x737EE24", Offset = "0x737EE24", Length = "0x60")]
		[Token(Token = "0x6002D0A")]
		internal DirectoryInfo <DirectoryInfos>b__7_0(ref FileSystemEntry entry) { }

		[Address(RVA = "0x737EDC4", Offset = "0x737EDC4", Length = "0x60")]
		[Token(Token = "0x6002D09")]
		internal FileInfo <FileInfos>b__6_0(ref FileSystemEntry entry) { }

		[Address(RVA = "0x737EE84", Offset = "0x737EE84", Length = "0x8")]
		[Token(Token = "0x6002D0B")]
		internal FileSystemInfo <FileSystemInfos>b__8_0(ref FileSystemEntry entry) { }

		[Address(RVA = "0x737EDB4", Offset = "0x737EDB4", Length = "0x8")]
		[Token(Token = "0x6002D07")]
		internal string <UserDirectories>b__4_0(ref FileSystemEntry entry) { }

		[Address(RVA = "0x737EDBC", Offset = "0x737EDBC", Length = "0x8")]
		[Token(Token = "0x6002D08")]
		internal string <UserEntries>b__5_0(ref FileSystemEntry entry) { }

		[Address(RVA = "0x737EDAC", Offset = "0x737EDAC", Length = "0x8")]
		[Token(Token = "0x6002D06")]
		internal string <UserFiles>b__3_0(ref FileSystemEntry entry) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x20005C2")]
	private sealed class <>c__DisplayClass3_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001804")]
		public string expression; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4001805")]
		public EnumerationOptions options; //Field offset: 0x18

		[Address(RVA = "0x737E1EC", Offset = "0x737E1EC", Length = "0x8")]
		[Token(Token = "0x6002D02")]
		public <>c__DisplayClass3_0() { }

		[Address(RVA = "0x737EC94", Offset = "0x737EC94", Length = "0xA0")]
		[Token(Token = "0x6002D03")]
		internal bool <UserFiles>b__1(ref FileSystemEntry entry) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x20005C4")]
	private sealed class <>c__DisplayClass4_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x400180D")]
		public string expression; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x400180E")]
		public EnumerationOptions options; //Field offset: 0x18

		[Address(RVA = "0x737E3EC", Offset = "0x737E3EC", Length = "0x8")]
		[Token(Token = "0x6002D0C")]
		public <>c__DisplayClass4_0() { }

		[Address(RVA = "0x737EE8C", Offset = "0x737EE8C", Length = "0xA0")]
		[Token(Token = "0x6002D0D")]
		internal bool <UserDirectories>b__1(ref FileSystemEntry entry) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x20005C5")]
	private sealed class <>c__DisplayClass5_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x400180F")]
		public string expression; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4001810")]
		public EnumerationOptions options; //Field offset: 0x18

		[Address(RVA = "0x737E5EC", Offset = "0x737E5EC", Length = "0x8")]
		[Token(Token = "0x6002D0E")]
		public <>c__DisplayClass5_0() { }

		[Address(RVA = "0x737EF2C", Offset = "0x737EF2C", Length = "0x84")]
		[Token(Token = "0x6002D0F")]
		internal bool <UserEntries>b__1(ref FileSystemEntry entry) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x20005C6")]
	private sealed class <>c__DisplayClass6_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001811")]
		public string expression; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4001812")]
		public EnumerationOptions options; //Field offset: 0x18

		[Address(RVA = "0x737E7EC", Offset = "0x737E7EC", Length = "0x8")]
		[Token(Token = "0x6002D10")]
		public <>c__DisplayClass6_0() { }

		[Address(RVA = "0x737EFB0", Offset = "0x737EFB0", Length = "0xA0")]
		[Token(Token = "0x6002D11")]
		internal bool <FileInfos>b__1(ref FileSystemEntry entry) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x20005C7")]
	private sealed class <>c__DisplayClass7_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001813")]
		public string expression; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4001814")]
		public EnumerationOptions options; //Field offset: 0x18

		[Address(RVA = "0x737E9EC", Offset = "0x737E9EC", Length = "0x8")]
		[Token(Token = "0x6002D12")]
		public <>c__DisplayClass7_0() { }

		[Address(RVA = "0x737F050", Offset = "0x737F050", Length = "0xA0")]
		[Token(Token = "0x6002D13")]
		internal bool <DirectoryInfos>b__1(ref FileSystemEntry entry) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x20005C8")]
	private sealed class <>c__DisplayClass8_0
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001815")]
		public string expression; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4001816")]
		public EnumerationOptions options; //Field offset: 0x18

		[Address(RVA = "0x737EBEC", Offset = "0x737EBEC", Length = "0x8")]
		[Token(Token = "0x6002D14")]
		public <>c__DisplayClass8_0() { }

		[Address(RVA = "0x737F0F0", Offset = "0x737F0F0", Length = "0x84")]
		[Token(Token = "0x6002D15")]
		internal bool <FileSystemInfos>b__1(ref FileSystemEntry entry) { }

	}

	[Token(Token = "0x4001803")]
	private static readonly Char[] s_unixEscapeChars; //Field offset: 0x0

	[Address(RVA = "0x737EBF4", Offset = "0x737EBF4", Length = "0xA0")]
	[Token(Token = "0x6002D01")]
	private static FileSystemEnumerableFactory() { }

	[Address(RVA = "0x737E7F4", Offset = "0x737E7F4", Length = "0x1F8")]
	[Token(Token = "0x6002CFF")]
	internal static IEnumerable<DirectoryInfo> DirectoryInfos(string directory, string expression, EnumerationOptions options) { }

	[Address(RVA = "0x737E5F4", Offset = "0x737E5F4", Length = "0x1F8")]
	[Token(Token = "0x6002CFE")]
	internal static IEnumerable<FileInfo> FileInfos(string directory, string expression, EnumerationOptions options) { }

	[Address(RVA = "0x737E9F4", Offset = "0x737E9F4", Length = "0x1F8")]
	[Token(Token = "0x6002D00")]
	internal static IEnumerable<FileSystemInfo> FileSystemInfos(string directory, string expression, EnumerationOptions options) { }

	[Address(RVA = "0x737DCB8", Offset = "0x737DCB8", Length = "0x22C")]
	[Token(Token = "0x6002CFA")]
	private static bool MatchesPattern(string expression, ReadOnlySpan<Char> name, EnumerationOptions options) { }

	[Address(RVA = "0x737D430", Offset = "0x737D430", Length = "0x4E0")]
	[Token(Token = "0x6002CF9")]
	internal static void NormalizeInputs(ref string directory, ref string expression, EnumerationOptions options) { }

	[Address(RVA = "0x737E1F4", Offset = "0x737E1F4", Length = "0x1F8")]
	[Token(Token = "0x6002CFC")]
	internal static IEnumerable<String> UserDirectories(string directory, string expression, EnumerationOptions options) { }

	[Address(RVA = "0x737E3F4", Offset = "0x737E3F4", Length = "0x1F8")]
	[Token(Token = "0x6002CFD")]
	internal static IEnumerable<String> UserEntries(string directory, string expression, EnumerationOptions options) { }

	[Address(RVA = "0x737DFF4", Offset = "0x737DFF4", Length = "0x1F8")]
	[Token(Token = "0x6002CFB")]
	internal static IEnumerable<String> UserFiles(string directory, string expression, EnumerationOptions options) { }

}

