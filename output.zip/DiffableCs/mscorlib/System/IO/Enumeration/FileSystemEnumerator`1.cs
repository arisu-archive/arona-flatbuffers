namespace System.IO.Enumeration;

[Token(Token = "0x20005C9")]
public abstract class FileSystemEnumerator : CriticalFinalizerObject, IEnumerator<TResult>, IDisposable, IEnumerator
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001817")]
	private readonly string _originalRootDirectory; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001818")]
	private readonly string _rootDirectory; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001819")]
	private readonly EnumerationOptions _options; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x400181A")]
	private readonly object _lock; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x400181B")]
	private string _currentPath; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x400181C")]
	private IntPtr _directoryHandle; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x400181D")]
	private bool _lastEntryFound; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x400181E")]
	private Queue<String> _pending; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x400181F")]
	private DirectoryEntry _entry; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001820")]
	private TResult _current; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001821")]
	private Char[] _pathBuffer; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001822")]
	private Byte[] _entryBuffer; //Field offset: 0x0

	[Token(Token = "0x17000688")]
	public override TResult Current
	{
		[Address(RVA = "0x4D48A2C", Offset = "0x4D48A2C", Length = "0x8")]
		[Token(Token = "0x6002D26")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000689")]
	private override object System.Collections.IEnumerator.Current
	{
		[Address(RVA = "0x4D48A34", Offset = "0x4D48A34", Length = "0x14")]
		[Token(Token = "0x6002D27")]
		private get { } //Length: 20
	}

	[Address(RVA = "0x4D477A0", Offset = "0x4D477A0", Length = "0x4B8")]
	[Token(Token = "0x6002D16")]
	public FileSystemEnumerator`1(string directory, EnumerationOptions options = null) { }

	[Address(RVA = "0x4D47E84", Offset = "0x4D47E84", Length = "0xAC")]
	[Token(Token = "0x6002D1B")]
	private void CloseDirectoryHandle() { }

	[Address(RVA = "0x4D48A24", Offset = "0x4D48A24", Length = "0x8")]
	[Token(Token = "0x6002D25")]
	protected override bool ContinueOnError(int error) { }

	[Address(RVA = "0x4D47D5C", Offset = "0x4D47D5C", Length = "0x128")]
	[Token(Token = "0x6002D1A")]
	private IntPtr CreateDirectoryHandle(string path, bool ignoreNotFound = false) { }

	[Address(RVA = "0x4D4862C", Offset = "0x4D4862C", Length = "0x114")]
	[Token(Token = "0x6002D1F")]
	private bool DequeueNextDirectory() { }

	[Address(RVA = "0x4D48A48", Offset = "0x4D48A48", Length = "0xE0")]
	[Token(Token = "0x6002D28")]
	private void DirectoryFinished() { }

	[Address(RVA = "0x4D48B68", Offset = "0x4D48B68", Length = "0x80")]
	[Token(Token = "0x6002D2A")]
	public override void Dispose() { }

	[Address(RVA = "0x4D48BE8", Offset = "0x4D48BE8", Length = "0x4")]
	[Token(Token = "0x6002D2B")]
	protected override void Dispose(bool disposing) { }

	[Address(RVA = "0x4D48BEC", Offset = "0x4D48BEC", Length = "0x98")]
	[Token(Token = "0x6002D2C")]
	protected virtual void Finalize() { }

	[Address(RVA = "0x4D4849C", Offset = "0x4D4849C", Length = "0x38")]
	[Token(Token = "0x6002D1D")]
	private void FindNextEntry() { }

	[Address(RVA = "0x4D484D4", Offset = "0x4D484D4", Length = "0x158")]
	[Token(Token = "0x6002D1E")]
	private void FindNextEntry(Byte* entryBufferPtr, int bufferLength) { }

	[Address(RVA = "0x4D48A2C", Offset = "0x4D48A2C", Length = "0x8")]
	[Token(Token = "0x6002D26")]
	public override TResult get_Current() { }

	[Address(RVA = "0x4D47C58", Offset = "0x4D47C58", Length = "0xAC")]
	[Token(Token = "0x6002D17")]
	private bool InternalContinueOnError(ErrorInfo info, bool ignoreNotFound = false) { }

	[Address(RVA = "0x4D48740", Offset = "0x4D48740", Length = "0x2D0")]
	[Token(Token = "0x6002D20")]
	private void InternalDispose(bool disposing) { }

	[Address(RVA = "0x4D47D20", Offset = "0x4D47D20", Length = "0x3C")]
	[Token(Token = "0x6002D19")]
	private static bool IsAccessError(ErrorInfo info) { }

	[Address(RVA = "0x4D47D04", Offset = "0x4D47D04", Length = "0x1C")]
	[Token(Token = "0x6002D18")]
	private static bool IsDirectoryNotFound(ErrorInfo info) { }

	[Address(RVA = "0x4D47F30", Offset = "0x4D47F30", Length = "0x56C")]
	[Token(Token = "0x6002D1C")]
	public override bool MoveNext() { }

	[Address(RVA = "0x4D48A20", Offset = "0x4D48A20", Length = "0x4")]
	[Token(Token = "0x6002D24")]
	protected override void OnDirectoryFinished(ReadOnlySpan<Char> directory) { }

	[Address(RVA = "0x4D48B28", Offset = "0x4D48B28", Length = "0x40")]
	[Token(Token = "0x6002D29")]
	public override void Reset() { }

	[Address(RVA = "0x4D48A10", Offset = "0x4D48A10", Length = "0x8")]
	[Token(Token = "0x6002D21")]
	protected override bool ShouldIncludeEntry(ref FileSystemEntry entry) { }

	[Address(RVA = "0x4D48A18", Offset = "0x4D48A18", Length = "0x8")]
	[Token(Token = "0x6002D22")]
	protected override bool ShouldRecurseIntoEntry(ref FileSystemEntry entry) { }

	[Address(RVA = "0x4D48A34", Offset = "0x4D48A34", Length = "0x14")]
	[Token(Token = "0x6002D27")]
	private override object System.Collections.IEnumerator.get_Current() { }

	[Token(Token = "0x6002D23")]
	protected abstract TResult TransformEntry(ref FileSystemEntry entry) { }

}

