namespace System.IO.Enumeration;

[Token(Token = "0x20005CA")]
public static class FileSystemName
{
	[Token(Token = "0x4001823")]
	private static readonly Char[] s_wildcardChars; //Field offset: 0x0
	[Token(Token = "0x4001824")]
	private static readonly Char[] s_simpleWildcardChars; //Field offset: 0x8

	[Address(RVA = "0x737F8FC", Offset = "0x737F8FC", Length = "0xEC")]
	[Token(Token = "0x6002D31")]
	private static FileSystemName() { }

	[Address(RVA = "0x737DEE4", Offset = "0x737DEE4", Length = "0x88")]
	[Token(Token = "0x6002D2F")]
	public static bool MatchesSimpleExpression(ReadOnlySpan<Char> expression, ReadOnlySpan<Char> name, bool ignoreCase = true) { }

	[Address(RVA = "0x737DF6C", Offset = "0x737DF6C", Length = "0x88")]
	[Token(Token = "0x6002D2E")]
	public static bool MatchesWin32Expression(ReadOnlySpan<Char> expression, ReadOnlySpan<Char> name, bool ignoreCase = true) { }

	[Address(RVA = "0x737F174", Offset = "0x737F174", Length = "0x788")]
	[Token(Token = "0x6002D30")]
	private static bool MatchPattern(ReadOnlySpan<Char> expression, ReadOnlySpan<Char> name, bool ignoreCase, bool useExtendedWildcards) { }

	[Address(RVA = "0x737D910", Offset = "0x737D910", Length = "0x3A8")]
	[Token(Token = "0x6002D2D")]
	public static string TranslateWin32Expression(string expression) { }

}

