namespace System.IO;

[Token(Token = "0x20005B8")]
internal class CStreamReader : StreamReader
{
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x40017EF")]
	private TermInfoDriver driver; //Field offset: 0x60

	[Address(RVA = "0x737BE98", Offset = "0x737BE98", Length = "0x120")]
	[Token(Token = "0x6002CCD")]
	public CStreamReader(Stream stream, Encoding encoding) { }

	[Address(RVA = "0x737BFB8", Offset = "0x737BFB8", Length = "0x88")]
	[Token(Token = "0x6002CCE")]
	public virtual int Peek() { }

	[Address(RVA = "0x737C040", Offset = "0x737C040", Length = "0xD0")]
	[Token(Token = "0x6002CCF")]
	public virtual int Read() { }

	[Address(RVA = "0x737C110", Offset = "0x737C110", Length = "0x1B0")]
	[Token(Token = "0x6002CD0")]
	public virtual int Read(out Char[] dest, int index, int count) { }

	[Address(RVA = "0x737C2C0", Offset = "0x737C2C0", Length = "0x98")]
	[Token(Token = "0x6002CD1")]
	public virtual string ReadLine() { }

	[Address(RVA = "0x737C358", Offset = "0x737C358", Length = "0x98")]
	[Token(Token = "0x6002CD2")]
	public virtual string ReadToEnd() { }

}

