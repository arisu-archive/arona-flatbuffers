namespace System.IO;

[ComVisible(True)]
[Token(Token = "0x20005AA")]
public class StringReader : TextReader
{
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001797")]
	private string _s; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4001798")]
	private int _pos; //Field offset: 0x20
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x4001799")]
	private int _length; //Field offset: 0x24

	[Address(RVA = "0x7372228", Offset = "0x7372228", Length = "0xD0")]
	[Token(Token = "0x6002C26")]
	public StringReader(string s) { }

	[Address(RVA = "0x73722F8", Offset = "0x73722F8", Length = "0x10")]
	[Token(Token = "0x6002C27")]
	public virtual void Close() { }

	[Address(RVA = "0x7372308", Offset = "0x7372308", Length = "0x38")]
	[Token(Token = "0x6002C28")]
	protected virtual void Dispose(bool disposing) { }

	[Address(RVA = "0x7372340", Offset = "0x7372340", Length = "0x3C")]
	[Token(Token = "0x6002C29")]
	public virtual int Peek() { }

	[Address(RVA = "0x737237C", Offset = "0x737237C", Length = "0x44")]
	[Token(Token = "0x6002C2A")]
	public virtual int Read() { }

	[Address(RVA = "0x73723C0", Offset = "0x73723C0", Length = "0x1BC")]
	[Token(Token = "0x6002C2B")]
	public virtual int Read(out Char[] buffer, int index, int count) { }

	[Address(RVA = "0x73726CC", Offset = "0x73726CC", Length = "0x1F0")]
	[ComVisible(False)]
	[Token(Token = "0x6002C2E")]
	public virtual Task<Int32> ReadAsync(Char[] buffer, int index, int count) { }

	[Address(RVA = "0x73725B8", Offset = "0x73725B8", Length = "0x114")]
	[Token(Token = "0x6002C2D")]
	public virtual string ReadLine() { }

	[Address(RVA = "0x737257C", Offset = "0x737257C", Length = "0x3C")]
	[Token(Token = "0x6002C2C")]
	public virtual string ReadToEnd() { }

}

