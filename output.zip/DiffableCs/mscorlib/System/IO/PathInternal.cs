namespace System.IO;

[Token(Token = "0x2000571")]
internal static class PathInternal
{
	[Token(Token = "0x400165E")]
	private static readonly bool s_isCaseSensitive; //Field offset: 0x0

	[Token(Token = "0x17000623")]
	internal static bool IsCaseSensitive
	{
		[Address(RVA = "0x732D518", Offset = "0x732D518", Length = "0x58")]
		[Token(Token = "0x60029C4")]
		internal get { } //Length: 88
	}

	[Address(RVA = "0x732D9F8", Offset = "0x732D9F8", Length = "0x50")]
	[Token(Token = "0x60029C7")]
	private static PathInternal() { }

	[Address(RVA = "0x732D180", Offset = "0x732D180", Length = "0x80")]
	[Token(Token = "0x60029BF")]
	internal static bool EndsInDirectorySeparator(ReadOnlySpan<Char> path) { }

	[Address(RVA = "0x732D518", Offset = "0x732D518", Length = "0x58")]
	[Token(Token = "0x60029C4")]
	internal static bool get_IsCaseSensitive() { }

	[Address(RVA = "0x732D570", Offset = "0x732D570", Length = "0x2C0")]
	[Token(Token = "0x60029C5")]
	private static bool GetIsCaseSensitive() { }

	[Address(RVA = "0x732D0F4", Offset = "0x732D0F4", Length = "0x7C")]
	[Token(Token = "0x60029BD")]
	internal static int GetRootLength(ReadOnlySpan<Char> path) { }

	[Address(RVA = "0x732D170", Offset = "0x732D170", Length = "0x10")]
	[Token(Token = "0x60029BE")]
	internal static bool IsDirectorySeparator(char c) { }

	[Address(RVA = "0x732D9F0", Offset = "0x732D9F0", Length = "0x8")]
	[Token(Token = "0x60029C6")]
	public static bool IsPartiallyQualified(string path) { }

	[Address(RVA = "0x732D3BC", Offset = "0x732D3BC", Length = "0x7C")]
	[Token(Token = "0x60029C3")]
	internal static bool IsRoot(ReadOnlySpan<Char> path) { }

	[Address(RVA = "0x732D200", Offset = "0x732D200", Length = "0x7C")]
	[Token(Token = "0x60029C0")]
	internal static bool StartsWithDirectorySeparator(ReadOnlySpan<Char> path) { }

	[Address(RVA = "0x732D27C", Offset = "0x732D27C", Length = "0x140")]
	[Token(Token = "0x60029C1")]
	internal static string TrimEndingDirectorySeparator(string path) { }

	[Address(RVA = "0x732D438", Offset = "0x732D438", Length = "0xE0")]
	[Token(Token = "0x60029C2")]
	internal static ReadOnlySpan<Char> TrimEndingDirectorySeparator(ReadOnlySpan<Char> path) { }

}

