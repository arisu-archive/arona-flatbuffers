namespace System.IO;

[ComVisible(True)]
[Token(Token = "0x20005A8")]
public class BinaryReader : IDisposable
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001785")]
	private Stream m_stream; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001786")]
	private Byte[] m_buffer; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4001787")]
	private Decoder m_decoder; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4001788")]
	private Byte[] m_charBytes; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4001789")]
	private Char[] m_singleChar; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400178A")]
	private Char[] m_charBuffer; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400178B")]
	private int m_maxCharsSize; //Field offset: 0x40
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x400178C")]
	private bool m_2BytesPerChar; //Field offset: 0x44
	[FieldOffset(Offset = "0x45")]
	[Token(Token = "0x400178D")]
	private bool m_isMemoryStream; //Field offset: 0x45
	[FieldOffset(Offset = "0x46")]
	[Token(Token = "0x400178E")]
	private bool m_leaveOpen; //Field offset: 0x46

	[Token(Token = "0x1700066B")]
	public override Stream BaseStream
	{
		[Address(RVA = "0x736FC9C", Offset = "0x736FC9C", Length = "0x8")]
		[Token(Token = "0x6002BF2")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x736F978", Offset = "0x736F978", Length = "0x78")]
	[Token(Token = "0x6002BEF")]
	public BinaryReader(Stream input) { }

	[Address(RVA = "0x736FC94", Offset = "0x736FC94", Length = "0x8")]
	[Token(Token = "0x6002BF0")]
	public BinaryReader(Stream input, Encoding encoding) { }

	[Address(RVA = "0x736F9F0", Offset = "0x736F9F0", Length = "0x2A4")]
	[Token(Token = "0x6002BF1")]
	public BinaryReader(Stream input, Encoding encoding, bool leaveOpen) { }

	[Address(RVA = "0x736FCA4", Offset = "0x736FCA4", Length = "0x10")]
	[Token(Token = "0x6002BF3")]
	public override void Close() { }

	[Address(RVA = "0x736FCB4", Offset = "0x736FCB4", Length = "0xAC")]
	[Token(Token = "0x6002BF4")]
	protected override void Dispose(bool disposing) { }

	[Address(RVA = "0x736FD60", Offset = "0x736FD60", Length = "0x10")]
	[Token(Token = "0x6002BF5")]
	public override void Dispose() { }

	[Address(RVA = "0x73711D0", Offset = "0x73711D0", Length = "0x120")]
	[Token(Token = "0x6002C0A")]
	protected override void FillBuffer(int numBytes) { }

	[Address(RVA = "0x736FC9C", Offset = "0x736FC9C", Length = "0x8")]
	[Token(Token = "0x6002BF2")]
	public override Stream get_BaseStream() { }

	[Address(RVA = "0x7370A38", Offset = "0x7370A38", Length = "0x324")]
	[Token(Token = "0x6002C05")]
	private int InternalReadChars(Char[] buffer, int index, int count) { }

	[Address(RVA = "0x736FD88", Offset = "0x736FD88", Length = "0x294")]
	[Token(Token = "0x6002C06")]
	private int InternalReadOneChar() { }

	[Address(RVA = "0x736FD70", Offset = "0x736FD70", Length = "0x18")]
	[Token(Token = "0x6002BF6")]
	public override int Read() { }

	[Address(RVA = "0x7370EBC", Offset = "0x7370EBC", Length = "0x184")]
	[Token(Token = "0x6002C08")]
	public override int Read(Byte[] buffer, int index, int count) { }

	[Address(RVA = "0x7370990", Offset = "0x7370990", Length = "0xA8")]
	[Token(Token = "0x6002C0B")]
	protected private int Read7BitEncodedInt() { }

	[Address(RVA = "0x737001C", Offset = "0x737001C", Length = "0x48")]
	[Token(Token = "0x6002BF7")]
	public override bool ReadBoolean() { }

	[Address(RVA = "0x7370064", Offset = "0x7370064", Length = "0x34")]
	[Token(Token = "0x6002BF8")]
	public override byte ReadByte() { }

	[Address(RVA = "0x7371040", Offset = "0x7371040", Length = "0x190")]
	[Token(Token = "0x6002C09")]
	public override Byte[] ReadBytes(int count) { }

	[Address(RVA = "0x73700D8", Offset = "0x73700D8", Length = "0x24")]
	[Token(Token = "0x6002BFA")]
	public override char ReadChar() { }

	[Address(RVA = "0x7370D5C", Offset = "0x7370D5C", Length = "0x160")]
	[Token(Token = "0x6002C07")]
	public override Char[] ReadChars(int count) { }

	[Address(RVA = "0x73704B0", Offset = "0x73704B0", Length = "0x218")]
	[Token(Token = "0x6002C03")]
	public override decimal ReadDecimal() { }

	[Address(RVA = "0x7370480", Offset = "0x7370480", Length = "0x30")]
	[Token(Token = "0x6002C02")]
	public override double ReadDouble() { }

	[Address(RVA = "0x73700FC", Offset = "0x73700FC", Length = "0x48")]
	[Token(Token = "0x6002BFB")]
	public override short ReadInt16() { }

	[Address(RVA = "0x737018C", Offset = "0x737018C", Length = "0xF4")]
	[Token(Token = "0x6002BFD")]
	public override int ReadInt32() { }

	[Address(RVA = "0x73702F0", Offset = "0x73702F0", Length = "0xB0")]
	[Token(Token = "0x6002BFF")]
	public override long ReadInt64() { }

	[Address(RVA = "0x7370098", Offset = "0x7370098", Length = "0x40")]
	[CLSCompliant(False)]
	[Token(Token = "0x6002BF9")]
	public override sbyte ReadSByte() { }

	[Address(RVA = "0x7370450", Offset = "0x7370450", Length = "0x30")]
	[Token(Token = "0x6002C01")]
	public override float ReadSingle() { }

	[Address(RVA = "0x73706C8", Offset = "0x73706C8", Length = "0x2C8")]
	[Token(Token = "0x6002C04")]
	public override string ReadString() { }

	[Address(RVA = "0x7370144", Offset = "0x7370144", Length = "0x48")]
	[CLSCompliant(False)]
	[Token(Token = "0x6002BFC")]
	public override ushort ReadUInt16() { }

	[Address(RVA = "0x7370280", Offset = "0x7370280", Length = "0x70")]
	[CLSCompliant(False)]
	[Token(Token = "0x6002BFE")]
	public override uint ReadUInt32() { }

	[Address(RVA = "0x73703A0", Offset = "0x73703A0", Length = "0xB0")]
	[CLSCompliant(False)]
	[Token(Token = "0x6002C00")]
	public override ulong ReadUInt64() { }

}

