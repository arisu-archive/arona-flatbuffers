namespace System.IO;

[Extension]
[Token(Token = "0x20005BA")]
internal static class MonoLinqHelper
{

	[Address(RVA = "0x43E8E8C", Offset = "0x43E8E8C", Length = "0x10")]
	[Extension]
	[Token(Token = "0x6002CDC")]
	public static T[] ToArray(IEnumerable<T> source) { }

}

