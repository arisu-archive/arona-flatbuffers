namespace System.IO;

[Token(Token = "0x200058B")]
public static class File
{
	[CompilerGenerated]
	[Token(Token = "0x200058C")]
	private struct <InternalReadAllBytesAsync>d__71 : IAsyncStateMachine
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40016EF")]
		public int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x40016F0")]
		public AsyncTaskMethodBuilder<Byte[]> <>t__builder; //Field offset: 0x8
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40016F1")]
		public FileStream fs; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x40016F2")]
		public int count; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x40016F3")]
		public CancellationToken cancellationToken; //Field offset: 0x30
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x40016F4")]
		private FileStream <>7__wrap1; //Field offset: 0x38
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x40016F5")]
		private int <index>5__3; //Field offset: 0x40
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x40016F6")]
		private Byte[] <bytes>5__4; //Field offset: 0x48
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x40016F7")]
		private ConfiguredValueTaskAwaiter<Int32> <>u__1; //Field offset: 0x50

		[Address(RVA = "0x733FE04", Offset = "0x733FE04", Length = "0x5C8")]
		[Token(Token = "0x6002B08")]
		private override void MoveNext() { }

		[Address(RVA = "0x73403CC", Offset = "0x73403CC", Length = "0x7C")]
		[DebuggerHidden]
		[Token(Token = "0x6002B09")]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x200058D")]
	private struct <InternalReadAllBytesUnknownLengthAsync>d__72 : IAsyncStateMachine
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40016F8")]
		public int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x40016F9")]
		public AsyncTaskMethodBuilder<Byte[]> <>t__builder; //Field offset: 0x8
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x40016FA")]
		public FileStream fs; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x40016FB")]
		public CancellationToken cancellationToken; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x40016FC")]
		private Byte[] <rentedArray>5__2; //Field offset: 0x30
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x40016FD")]
		private int <bytesRead>5__3; //Field offset: 0x38
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x40016FE")]
		private ConfiguredValueTaskAwaiter<Int32> <>u__1; //Field offset: 0x40

		[Address(RVA = "0x7361184", Offset = "0x7361184", Length = "0x7F0")]
		[Token(Token = "0x6002B0A")]
		private override void MoveNext() { }

		[Address(RVA = "0x7361974", Offset = "0x7361974", Length = "0x7C")]
		[DebuggerHidden]
		[Token(Token = "0x6002B0B")]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x200058E")]
	private struct <InternalWriteAllBytesAsync>d__74 : IAsyncStateMachine
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x40016FF")]
		public int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x4001700")]
		public AsyncTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4001701")]
		public string path; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4001702")]
		public Byte[] bytes; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4001703")]
		public CancellationToken cancellationToken; //Field offset: 0x30
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4001704")]
		private FileStream <fs>5__2; //Field offset: 0x38
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4001705")]
		private ConfiguredValueTaskAwaiter <>u__1; //Field offset: 0x40
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x4001706")]
		private ConfiguredTaskAwaiter <>u__2; //Field offset: 0x50

		[Address(RVA = "0x73619F0", Offset = "0x73619F0", Length = "0x758")]
		[Token(Token = "0x6002B0C")]
		private override void MoveNext() { }

		[Address(RVA = "0x7362168", Offset = "0x7362168", Length = "0x68")]
		[DebuggerHidden]
		[Token(Token = "0x6002B0D")]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}


	[Address(RVA = "0x733E010", Offset = "0x733E010", Length = "0x8")]
	[Token(Token = "0x6002AEE")]
	public static void Copy(string sourceFileName, string destFileName) { }

	[Address(RVA = "0x733E018", Offset = "0x733E018", Length = "0x1A8")]
	[Token(Token = "0x6002AEF")]
	public static void Copy(string sourceFileName, string destFileName, bool overwrite) { }

	[Address(RVA = "0x733E1C0", Offset = "0x733E1C0", Length = "0x8")]
	[Token(Token = "0x6002AF0")]
	public static FileStream Create(string path) { }

	[Address(RVA = "0x733E1C8", Offset = "0x733E1C8", Length = "0x80")]
	[Token(Token = "0x6002AF1")]
	public static FileStream Create(string path, int bufferSize) { }

	[Address(RVA = "0x733E248", Offset = "0x733E248", Length = "0xB0")]
	[Token(Token = "0x6002AF2")]
	public static void Delete(string path) { }

	[Address(RVA = "0x732D830", Offset = "0x732D830", Length = "0x1C0")]
	[Token(Token = "0x6002AF3")]
	public static bool Exists(string path) { }

	[Address(RVA = "0x733E398", Offset = "0x733E398", Length = "0x60")]
	[Token(Token = "0x6002AF6")]
	public static FileAttributes GetAttributes(string path) { }

	[Address(RVA = "0x733F9FC", Offset = "0x733F9FC", Length = "0x140")]
	[AsyncStateMachine(typeof(<InternalReadAllBytesAsync>d__71))]
	[Token(Token = "0x6002B04")]
	private static Task<Byte[]> InternalReadAllBytesAsync(FileStream fs, int count, CancellationToken cancellationToken) { }

	[Address(RVA = "0x733F8D0", Offset = "0x733F8D0", Length = "0x12C")]
	[AsyncStateMachine(typeof(<InternalReadAllBytesUnknownLengthAsync>d__72))]
	[Token(Token = "0x6002B05")]
	private static Task<Byte[]> InternalReadAllBytesUnknownLengthAsync(FileStream fs, CancellationToken cancellationToken) { }

	[Address(RVA = "0x733F408", Offset = "0x733F408", Length = "0x254")]
	[Token(Token = "0x6002B02")]
	private static String[] InternalReadAllLines(string path, Encoding encoding) { }

	[Address(RVA = "0x733E5A4", Offset = "0x733E5A4", Length = "0x168")]
	[Token(Token = "0x6002AFB")]
	private static string InternalReadAllText(string path, Encoding encoding) { }

	[Address(RVA = "0x733F1C8", Offset = "0x733F1C8", Length = "0x174")]
	[Token(Token = "0x6002B00")]
	private static void InternalWriteAllBytes(string path, Byte[] bytes) { }

	[Address(RVA = "0x733FCE8", Offset = "0x733FCE8", Length = "0x11C")]
	[AsyncStateMachine(typeof(<InternalWriteAllBytesAsync>d__74))]
	[Token(Token = "0x6002B07")]
	private static Task InternalWriteAllBytesAsync(string path, Byte[] bytes, CancellationToken cancellationToken) { }

	[Address(RVA = "0x733E2F8", Offset = "0x733E2F8", Length = "0x14")]
	[Token(Token = "0x6002AF4")]
	public static FileStream Open(string path, FileMode mode) { }

	[Address(RVA = "0x733E30C", Offset = "0x733E30C", Length = "0x8C")]
	[Token(Token = "0x6002AF5")]
	public static FileStream Open(string path, FileMode mode, FileAccess access, FileShare share) { }

	[Address(RVA = "0x733E3F8", Offset = "0x733E3F8", Length = "0x70")]
	[Token(Token = "0x6002AF7")]
	public static FileStream OpenRead(string path) { }

	[Address(RVA = "0x733DF48", Offset = "0x733DF48", Length = "0xC8")]
	[Token(Token = "0x6002AED")]
	public static StreamReader OpenText(string path) { }

	[Address(RVA = "0x733E468", Offset = "0x733E468", Length = "0x70")]
	[Token(Token = "0x6002AF8")]
	public static FileStream OpenWrite(string path) { }

	[Address(RVA = "0x733E9DC", Offset = "0x733E9DC", Length = "0x280")]
	[Token(Token = "0x6002AFD")]
	public static Byte[] ReadAllBytes(string path) { }

	[Address(RVA = "0x733F65C", Offset = "0x733F65C", Length = "0x274")]
	[Token(Token = "0x6002B03")]
	public static Task<Byte[]> ReadAllBytesAsync(string path, CancellationToken cancellationToken = null) { }

	[Address(RVA = "0x733EC5C", Offset = "0x733EC5C", Length = "0x464")]
	[Token(Token = "0x6002AFE")]
	private static Byte[] ReadAllBytesUnknownLength(FileStream fs) { }

	[Address(RVA = "0x733F33C", Offset = "0x733F33C", Length = "0xCC")]
	[Token(Token = "0x6002B01")]
	public static String[] ReadAllLines(string path) { }

	[Address(RVA = "0x733E4D8", Offset = "0x733E4D8", Length = "0xCC")]
	[Token(Token = "0x6002AF9")]
	public static string ReadAllText(string path) { }

	[Address(RVA = "0x733E70C", Offset = "0x733E70C", Length = "0xE0")]
	[Token(Token = "0x6002AFA")]
	public static string ReadAllText(string path, Encoding encoding) { }

	[Address(RVA = "0x733F0C0", Offset = "0x733F0C0", Length = "0x108")]
	[Token(Token = "0x6002AFF")]
	public static void WriteAllBytes(string path, Byte[] bytes) { }

	[Address(RVA = "0x733FB3C", Offset = "0x733FB3C", Length = "0x1AC")]
	[Token(Token = "0x6002B06")]
	public static Task WriteAllBytesAsync(string path, Byte[] bytes, CancellationToken cancellationToken = null) { }

	[Address(RVA = "0x733E7EC", Offset = "0x733E7EC", Length = "0x1F0")]
	[Token(Token = "0x6002AFC")]
	public static void WriteAllText(string path, string contents) { }

}

