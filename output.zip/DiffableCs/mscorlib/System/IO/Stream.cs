namespace System.IO;

[Token(Token = "0x200059E")]
public abstract class Stream : MarshalByRefObject, IDisposable
{
	[CompilerGenerated]
	[Token(Token = "0x20005A6")]
	private struct <<ReadAsync>g__FinishReadAsync|44_0>d : IAsyncStateMachine
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x400177F")]
		public int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x4001780")]
		public AsyncValueTaskMethodBuilder<Int32> <>t__builder; //Field offset: 0x8
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4001781")]
		public Task<Int32> readTask; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4001782")]
		public Byte[] localBuffer; //Field offset: 0x30
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4001783")]
		public Memory<Byte> localDestination; //Field offset: 0x38
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4001784")]
		private ConfiguredTaskAwaiter<Int32> <>u__1; //Field offset: 0x48

		[Address(RVA = "0x736EC94", Offset = "0x736EC94", Length = "0x390")]
		[Token(Token = "0x6002BE7")]
		private override void MoveNext() { }

		[Address(RVA = "0x736F024", Offset = "0x736F024", Length = "0x58")]
		[DebuggerHidden]
		[Token(Token = "0x6002BE8")]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x20005A4")]
	private sealed class <>c
	{
		[Token(Token = "0x4001770")]
		public static readonly <>c <>9; //Field offset: 0x0
		[Token(Token = "0x4001771")]
		public static Func<SemaphoreSlim> <>9__4_0; //Field offset: 0x8
		[Token(Token = "0x4001772")]
		public static Action<Object> <>9__37_0; //Field offset: 0x10
		[Token(Token = "0x4001773")]
		public static Func<Object, Int32> <>9__40_0; //Field offset: 0x18
		[Token(Token = "0x4001774")]
		public static Func<Stream, ReadWriteParameters, AsyncCallback, Object, IAsyncResult> <>9__45_0; //Field offset: 0x20
		[Token(Token = "0x4001775")]
		public static Func<Stream, IAsyncResult, Int32> <>9__45_1; //Field offset: 0x28
		[Token(Token = "0x4001776")]
		public static Func<Object, Int32> <>9__48_0; //Field offset: 0x30
		[Token(Token = "0x4001777")]
		public static Action<Task, Object> <>9__49_0; //Field offset: 0x38
		[Token(Token = "0x4001778")]
		public static Func<Stream, ReadWriteParameters, AsyncCallback, Object, IAsyncResult> <>9__58_0; //Field offset: 0x40
		[Token(Token = "0x4001779")]
		public static Func<Stream, IAsyncResult, VoidTaskResult> <>9__58_1; //Field offset: 0x48

		[Address(RVA = "0x736E3BC", Offset = "0x736E3BC", Length = "0x70")]
		[Token(Token = "0x6002BDA")]
		private static <>c() { }

		[Address(RVA = "0x736E42C", Offset = "0x736E42C", Length = "0x8")]
		[Token(Token = "0x6002BDB")]
		public <>c() { }

		[Address(RVA = "0x736E6D0", Offset = "0x736E6D0", Length = "0x34")]
		[Token(Token = "0x6002BDF")]
		internal IAsyncResult <BeginEndReadAsync>b__45_0(Stream stream, ReadWriteParameters args, AsyncCallback callback, object state) { }

		[Address(RVA = "0x736E704", Offset = "0x736E704", Length = "0x2C")]
		[Token(Token = "0x6002BE0")]
		internal int <BeginEndReadAsync>b__45_1(Stream stream, IAsyncResult asyncResult) { }

		[Address(RVA = "0x736E938", Offset = "0x736E938", Length = "0x34")]
		[Token(Token = "0x6002BE3")]
		internal IAsyncResult <BeginEndWriteAsync>b__58_0(Stream stream, ReadWriteParameters args, AsyncCallback callback, object state) { }

		[Address(RVA = "0x736E96C", Offset = "0x736E96C", Length = "0x34")]
		[Token(Token = "0x6002BE4")]
		internal VoidTaskResult <BeginEndWriteAsync>b__58_1(Stream stream, IAsyncResult asyncResult) { }

		[Address(RVA = "0x736E520", Offset = "0x736E520", Length = "0x1B0")]
		[Token(Token = "0x6002BDE")]
		internal int <BeginReadInternal>b__40_0(object <p0>) { }

		[Address(RVA = "0x736E730", Offset = "0x736E730", Length = "0x19C")]
		[Token(Token = "0x6002BE1")]
		internal int <BeginWriteInternal>b__48_0(object <p0>) { }

		[Address(RVA = "0x736E434", Offset = "0x736E434", Length = "0x64")]
		[Token(Token = "0x6002BDC")]
		internal SemaphoreSlim <EnsureAsyncActiveSemaphoreInitialized>b__4_0() { }

		[Address(RVA = "0x736E498", Offset = "0x736E498", Length = "0x88")]
		[Token(Token = "0x6002BDD")]
		internal void <FlushAsync>b__37_0(object state) { }

		[Address(RVA = "0x736E8CC", Offset = "0x736E8CC", Length = "0x6C")]
		[Token(Token = "0x6002BE2")]
		internal void <RunReadWriteTaskWhenReady>b__49_0(Task t, object state) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x20005A5")]
	private struct <FinishWriteAsync>d__57 : IAsyncStateMachine
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x400177A")]
		public int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x400177B")]
		public AsyncTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400177C")]
		public Task writeTask; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x400177D")]
		public Byte[] localBuffer; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x400177E")]
		private ConfiguredTaskAwaiter <>u__1; //Field offset: 0x30

		[Address(RVA = "0x736E9A0", Offset = "0x736E9A0", Length = "0x28C")]
		[Token(Token = "0x6002BE5")]
		private override void MoveNext() { }

		[Address(RVA = "0x736EC2C", Offset = "0x736EC2C", Length = "0x68")]
		[DebuggerHidden]
		[Token(Token = "0x6002BE6")]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[Token(Token = "0x20005A1")]
	private sealed class NullStream : Stream
	{
		[Token(Token = "0x4001767")]
		private static readonly Task<Int32> s_zeroTask; //Field offset: 0x0

		[Token(Token = "0x17000662")]
		public virtual bool CanRead
		{
			[Address(RVA = "0x736DB14", Offset = "0x736DB14", Length = "0x8")]
			[Token(Token = "0x6002BB3")]
			 get { } //Length: 8
		}

		[Token(Token = "0x17000664")]
		public virtual bool CanSeek
		{
			[Address(RVA = "0x736DB24", Offset = "0x736DB24", Length = "0x8")]
			[Token(Token = "0x6002BB5")]
			 get { } //Length: 8
		}

		[Token(Token = "0x17000663")]
		public virtual bool CanWrite
		{
			[Address(RVA = "0x736DB1C", Offset = "0x736DB1C", Length = "0x8")]
			[Token(Token = "0x6002BB4")]
			 get { } //Length: 8
		}

		[Token(Token = "0x17000665")]
		public virtual long Length
		{
			[Address(RVA = "0x736DB2C", Offset = "0x736DB2C", Length = "0x8")]
			[Token(Token = "0x6002BB6")]
			 get { } //Length: 8
		}

		[Token(Token = "0x17000666")]
		public virtual long Position
		{
			[Address(RVA = "0x736DB34", Offset = "0x736DB34", Length = "0x8")]
			[Token(Token = "0x6002BB7")]
			 get { } //Length: 8
			[Address(RVA = "0x736DB3C", Offset = "0x736DB3C", Length = "0x4")]
			[Token(Token = "0x6002BB8")]
			 set { } //Length: 4
		}

		[Address(RVA = "0x736E120", Offset = "0x736E120", Length = "0x98")]
		[Token(Token = "0x6002BCC")]
		private static NullStream() { }

		[Address(RVA = "0x736D8BC", Offset = "0x736D8BC", Length = "0x58")]
		[Token(Token = "0x6002BB2")]
		internal NullStream() { }

		[Address(RVA = "0x736DC2C", Offset = "0x736DC2C", Length = "0x88")]
		[Token(Token = "0x6002BBC")]
		public virtual IAsyncResult BeginRead(Byte[] buffer, int offset, int count, AsyncCallback callback, object state) { }

		[Address(RVA = "0x736DD58", Offset = "0x736DD58", Length = "0x88")]
		[Token(Token = "0x6002BBE")]
		public virtual IAsyncResult BeginWrite(Byte[] buffer, int offset, int count, AsyncCallback callback, object state) { }

		[Address(RVA = "0x736DB40", Offset = "0x736DB40", Length = "0x4")]
		[Token(Token = "0x6002BB9")]
		protected virtual void Dispose(bool disposing) { }

		[Address(RVA = "0x736DCB4", Offset = "0x736DCB4", Length = "0xA4")]
		[Token(Token = "0x6002BBD")]
		public virtual int EndRead(IAsyncResult asyncResult) { }

		[Address(RVA = "0x736DDE0", Offset = "0x736DDE0", Length = "0xA4")]
		[Token(Token = "0x6002BBF")]
		public virtual void EndWrite(IAsyncResult asyncResult) { }

		[Address(RVA = "0x736DB44", Offset = "0x736DB44", Length = "0x4")]
		[Token(Token = "0x6002BBA")]
		public virtual void Flush() { }

		[Address(RVA = "0x736DB48", Offset = "0x736DB48", Length = "0xE4")]
		[Token(Token = "0x6002BBB")]
		public virtual Task FlushAsync(CancellationToken cancellationToken) { }

		[Address(RVA = "0x736DB14", Offset = "0x736DB14", Length = "0x8")]
		[Token(Token = "0x6002BB3")]
		public virtual bool get_CanRead() { }

		[Address(RVA = "0x736DB24", Offset = "0x736DB24", Length = "0x8")]
		[Token(Token = "0x6002BB5")]
		public virtual bool get_CanSeek() { }

		[Address(RVA = "0x736DB1C", Offset = "0x736DB1C", Length = "0x8")]
		[Token(Token = "0x6002BB4")]
		public virtual bool get_CanWrite() { }

		[Address(RVA = "0x736DB2C", Offset = "0x736DB2C", Length = "0x8")]
		[Token(Token = "0x6002BB6")]
		public virtual long get_Length() { }

		[Address(RVA = "0x736DB34", Offset = "0x736DB34", Length = "0x8")]
		[Token(Token = "0x6002BB7")]
		public virtual long get_Position() { }

		[Address(RVA = "0x736DE8C", Offset = "0x736DE8C", Length = "0x8")]
		[Token(Token = "0x6002BC1")]
		public virtual int Read(Span<Byte> buffer) { }

		[Address(RVA = "0x736DE84", Offset = "0x736DE84", Length = "0x8")]
		[Token(Token = "0x6002BC0")]
		public virtual int Read(Byte[] buffer, int offset, int count) { }

		[Address(RVA = "0x736DE94", Offset = "0x736DE94", Length = "0x58")]
		[Token(Token = "0x6002BC2")]
		public virtual Task<Int32> ReadAsync(Byte[] buffer, int offset, int count, CancellationToken cancellationToken) { }

		[Address(RVA = "0x736DEEC", Offset = "0x736DEEC", Length = "0x54")]
		[Token(Token = "0x6002BC3")]
		public virtual ValueTask<Int32> ReadAsync(Memory<Byte> buffer, CancellationToken cancellationToken = null) { }

		[Address(RVA = "0x736DF40", Offset = "0x736DF40", Length = "0x8")]
		[Token(Token = "0x6002BC4")]
		public virtual int ReadByte() { }

		[Address(RVA = "0x736E114", Offset = "0x736E114", Length = "0x8")]
		[Token(Token = "0x6002BCA")]
		public virtual long Seek(long offset, SeekOrigin origin) { }

		[Address(RVA = "0x736DB3C", Offset = "0x736DB3C", Length = "0x4")]
		[Token(Token = "0x6002BB8")]
		public virtual void set_Position(long value) { }

		[Address(RVA = "0x736E11C", Offset = "0x736E11C", Length = "0x4")]
		[Token(Token = "0x6002BCB")]
		public virtual void SetLength(long length) { }

		[Address(RVA = "0x736DF48", Offset = "0x736DF48", Length = "0x4")]
		[Token(Token = "0x6002BC5")]
		public virtual void Write(Byte[] buffer, int offset, int count) { }

		[Address(RVA = "0x736DF4C", Offset = "0x736DF4C", Length = "0x4")]
		[Token(Token = "0x6002BC6")]
		public virtual void Write(ReadOnlySpan<Byte> buffer) { }

		[Address(RVA = "0x736DF50", Offset = "0x736DF50", Length = "0xE4")]
		[Token(Token = "0x6002BC7")]
		public virtual Task WriteAsync(Byte[] buffer, int offset, int count, CancellationToken cancellationToken) { }

		[Address(RVA = "0x736E034", Offset = "0x736E034", Length = "0xDC")]
		[Token(Token = "0x6002BC8")]
		public virtual ValueTask WriteAsync(ReadOnlyMemory<Byte> buffer, CancellationToken cancellationToken = null) { }

		[Address(RVA = "0x736E110", Offset = "0x736E110", Length = "0x4")]
		[Token(Token = "0x6002BC9")]
		public virtual void WriteByte(byte value) { }

	}

	[Token(Token = "0x200059F")]
	private struct ReadWriteParameters
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x400175B")]
		internal Byte[] Buffer; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x400175C")]
		internal int Offset; //Field offset: 0x8
		[FieldOffset(Offset = "0xC")]
		[Token(Token = "0x400175D")]
		internal int Count; //Field offset: 0xC

	}

	[Token(Token = "0x20005A0")]
	private sealed class ReadWriteTask : Task<Int32>, ITaskCompletionAction
	{
		[Token(Token = "0x4001766")]
		private static ContextCallback s_invokeAsyncCallback; //Field offset: 0x0
		[FieldOffset(Offset = "0x54")]
		[Token(Token = "0x400175E")]
		internal readonly bool _isRead; //Field offset: 0x54
		[FieldOffset(Offset = "0x55")]
		[Token(Token = "0x400175F")]
		internal readonly bool _apm; //Field offset: 0x55
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x4001760")]
		internal Stream _stream; //Field offset: 0x58
		[FieldOffset(Offset = "0x60")]
		[Token(Token = "0x4001761")]
		internal Byte[] _buffer; //Field offset: 0x60
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x4001762")]
		internal readonly int _offset; //Field offset: 0x68
		[FieldOffset(Offset = "0x6C")]
		[Token(Token = "0x4001763")]
		internal readonly int _count; //Field offset: 0x6C
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x4001764")]
		private AsyncCallback _callback; //Field offset: 0x70
		[FieldOffset(Offset = "0x78")]
		[Token(Token = "0x4001765")]
		private ExecutionContext _context; //Field offset: 0x78

		[Token(Token = "0x17000661")]
		private override bool System.Threading.Tasks.ITaskCompletionAction.InvokeMayRunArbitraryCode
		{
			[Address(RVA = "0x736DB0C", Offset = "0x736DB0C", Length = "0x8")]
			[Token(Token = "0x6002BB1")]
			private get { } //Length: 8
		}

		[Address(RVA = "0x736B514", Offset = "0x736B514", Length = "0x184")]
		[Token(Token = "0x6002BAE")]
		public ReadWriteTask(bool isRead, bool apm, Func<Object, Int32> function, object state, Stream stream, Byte[] buffer, int offset, int count, AsyncCallback callback) { }

		[Address(RVA = "0x736D914", Offset = "0x736D914", Length = "0x28")]
		[Token(Token = "0x6002BAD")]
		internal void ClearBeginState() { }

		[Address(RVA = "0x736D93C", Offset = "0x736D93C", Length = "0x88")]
		[Token(Token = "0x6002BAF")]
		private static void InvokeAsyncCallback(object completedTask) { }

		[Address(RVA = "0x736DB0C", Offset = "0x736DB0C", Length = "0x8")]
		[Token(Token = "0x6002BB1")]
		private override bool System.Threading.Tasks.ITaskCompletionAction.get_InvokeMayRunArbitraryCode() { }

		[Address(RVA = "0x736D9C4", Offset = "0x736D9C4", Length = "0x148")]
		[Token(Token = "0x6002BB0")]
		private override void System.Threading.Tasks.ITaskCompletionAction.Invoke(Task completingTask) { }

	}

	[Token(Token = "0x20005A2")]
	private sealed class SynchronousAsyncResult : IAsyncResult
	{
		[CompilerGenerated]
		[Token(Token = "0x20005A3")]
		private sealed class <>c
		{
			[Token(Token = "0x400176E")]
			public static readonly <>c <>9; //Field offset: 0x0
			[Token(Token = "0x400176F")]
			public static Func<ManualResetEvent> <>9__12_0; //Field offset: 0x8

			[Address(RVA = "0x736E2E4", Offset = "0x736E2E4", Length = "0x70")]
			[Token(Token = "0x6002BD7")]
			private static <>c() { }

			[Address(RVA = "0x736E354", Offset = "0x736E354", Length = "0x8")]
			[Token(Token = "0x6002BD8")]
			public <>c() { }

			[Address(RVA = "0x736E35C", Offset = "0x736E35C", Length = "0x60")]
			[Token(Token = "0x6002BD9")]
			internal ManualResetEvent <get_AsyncWaitHandle>b__12_0() { }

		}

		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001768")]
		private readonly object _stateObject; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4001769")]
		private readonly bool _isWrite; //Field offset: 0x18
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400176A")]
		private ManualResetEvent _waitHandle; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x400176B")]
		private ExceptionDispatchInfo _exceptionInfo; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x400176C")]
		private bool _endXxxCalled; //Field offset: 0x30
		[FieldOffset(Offset = "0x34")]
		[Token(Token = "0x400176D")]
		private int _bytesRead; //Field offset: 0x34

		[Token(Token = "0x17000669")]
		public override object AsyncState
		{
			[Address(RVA = "0x736E2C0", Offset = "0x736E2C0", Length = "0x8")]
			[Token(Token = "0x6002BD2")]
			 get { } //Length: 8
		}

		[Token(Token = "0x17000668")]
		public override WaitHandle AsyncWaitHandle
		{
			[Address(RVA = "0x736E1C0", Offset = "0x736E1C0", Length = "0x100")]
			[Token(Token = "0x6002BD1")]
			 get { } //Length: 256
		}

		[Token(Token = "0x1700066A")]
		public override bool CompletedSynchronously
		{
			[Address(RVA = "0x736E2C8", Offset = "0x736E2C8", Length = "0x8")]
			[Token(Token = "0x6002BD3")]
			 get { } //Length: 8
		}

		[Token(Token = "0x17000667")]
		public override bool IsCompleted
		{
			[Address(RVA = "0x736E1B8", Offset = "0x736E1B8", Length = "0x8")]
			[Token(Token = "0x6002BD0")]
			 get { } //Length: 8
		}

		[Address(RVA = "0x736D3F8", Offset = "0x736D3F8", Length = "0x38")]
		[Token(Token = "0x6002BCD")]
		internal SynchronousAsyncResult(int bytesRead, object asyncStateObject) { }

		[Address(RVA = "0x736D708", Offset = "0x736D708", Length = "0x3C")]
		[Token(Token = "0x6002BCE")]
		internal SynchronousAsyncResult(object asyncStateObject) { }

		[Address(RVA = "0x736D430", Offset = "0x736D430", Length = "0x64")]
		[Token(Token = "0x6002BCF")]
		internal SynchronousAsyncResult(Exception ex, object asyncStateObject, bool isWrite) { }

		[Address(RVA = "0x736D498", Offset = "0x736D498", Length = "0xF0")]
		[Token(Token = "0x6002BD5")]
		internal static int EndRead(IAsyncResult asyncResult) { }

		[Address(RVA = "0x736D748", Offset = "0x736D748", Length = "0xF4")]
		[Token(Token = "0x6002BD6")]
		internal static void EndWrite(IAsyncResult asyncResult) { }

		[Address(RVA = "0x736E2C0", Offset = "0x736E2C0", Length = "0x8")]
		[Token(Token = "0x6002BD2")]
		public override object get_AsyncState() { }

		[Address(RVA = "0x736E1C0", Offset = "0x736E1C0", Length = "0x100")]
		[Token(Token = "0x6002BD1")]
		public override WaitHandle get_AsyncWaitHandle() { }

		[Address(RVA = "0x736E2C8", Offset = "0x736E2C8", Length = "0x8")]
		[Token(Token = "0x6002BD3")]
		public override bool get_CompletedSynchronously() { }

		[Address(RVA = "0x736E1B8", Offset = "0x736E1B8", Length = "0x8")]
		[Token(Token = "0x6002BD0")]
		public override bool get_IsCompleted() { }

		[Address(RVA = "0x736E2D0", Offset = "0x736E2D0", Length = "0x14")]
		[Token(Token = "0x6002BD4")]
		internal void ThrowIfError() { }

	}

	[Token(Token = "0x4001757")]
	public static readonly Stream Null; //Field offset: 0x0
	[Token(Token = "0x4001758")]
	private const int DefaultCopyBufferSize = 81920; //Field offset: 0x0
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001759")]
	private ReadWriteTask _activeReadWriteTask; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400175A")]
	private SemaphoreSlim _asyncActiveSemaphore; //Field offset: 0x20

	[Token(Token = "0x17000659")]
	public abstract bool CanRead
	{
		[Token(Token = "0x6002B7A")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700065A")]
	public abstract bool CanSeek
	{
		[Token(Token = "0x6002B7B")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700065B")]
	public override bool CanTimeout
	{
		[Address(RVA = "0x736AF68", Offset = "0x736AF68", Length = "0x8")]
		[Token(Token = "0x6002B7C")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700065C")]
	public abstract bool CanWrite
	{
		[Token(Token = "0x6002B7D")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700065D")]
	public abstract long Length
	{
		[Token(Token = "0x6002B7E")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700065E")]
	public abstract long Position
	{
		[Token(Token = "0x6002B7F")]
		 get { } //Length: 0
		[Token(Token = "0x6002B80")]
		 set { } //Length: 0
	}

	[Token(Token = "0x1700065F")]
	public override int ReadTimeout
	{
		[Address(RVA = "0x736AF70", Offset = "0x736AF70", Length = "0x50")]
		[Token(Token = "0x6002B81")]
		 get { } //Length: 80
		[Address(RVA = "0x736AFC0", Offset = "0x736AFC0", Length = "0x50")]
		[Token(Token = "0x6002B82")]
		 set { } //Length: 80
	}

	[Token(Token = "0x17000660")]
	public override int WriteTimeout
	{
		[Address(RVA = "0x736B010", Offset = "0x736B010", Length = "0x50")]
		[Token(Token = "0x6002B83")]
		 get { } //Length: 80
		[Address(RVA = "0x736B060", Offset = "0x736B060", Length = "0x50")]
		[Token(Token = "0x6002B84")]
		 set { } //Length: 80
	}

	[Address(RVA = "0x736D83C", Offset = "0x736D83C", Length = "0x80")]
	[Token(Token = "0x6002BAB")]
	private static Stream() { }

	[Address(RVA = "0x736542C", Offset = "0x736542C", Length = "0x8")]
	[Token(Token = "0x6002BAA")]
	protected Stream() { }

	[Address(RVA = "0x736C0A4", Offset = "0x736C0A4", Length = "0x164")]
	[AsyncStateMachine(typeof(<<ReadAsync>g__FinishReadAsync|44_0>d))]
	[CompilerGenerated]
	[Token(Token = "0x6002BAC")]
	internal static ValueTask<Int32> <ReadAsync>g__FinishReadAsync|44_0(Task<Int32> readTask, Byte[] localBuffer, Memory<Byte> localDestination) { }

	[Address(RVA = "0x736BC24", Offset = "0x736BC24", Length = "0x1E4")]
	[Token(Token = "0x6002B90")]
	private Task<Int32> BeginEndReadAsync(Byte[] buffer, int offset, int count) { }

	[Address(RVA = "0x736C770", Offset = "0x736C770", Length = "0x1E4")]
	[Token(Token = "0x6002B9B")]
	private Task BeginEndWriteAsync(Byte[] buffer, int offset, int count) { }

	[Address(RVA = "0x736B300", Offset = "0x736B300", Length = "0x20")]
	[Token(Token = "0x6002B8A")]
	public override IAsyncResult BeginRead(Byte[] buffer, int offset, int count, AsyncCallback callback, object state) { }

	[Address(RVA = "0x736B320", Offset = "0x736B320", Length = "0x1F4")]
	[Token(Token = "0x6002B8B")]
	internal IAsyncResult BeginReadInternal(Byte[] buffer, int offset, int count, AsyncCallback callback, object state, bool serializeAsynchronously, bool apm) { }

	[Address(RVA = "0x736C210", Offset = "0x736C210", Length = "0x20")]
	[Token(Token = "0x6002B91")]
	public override IAsyncResult BeginWrite(Byte[] buffer, int offset, int count, AsyncCallback callback, object state) { }

	[Address(RVA = "0x736C230", Offset = "0x736C230", Length = "0x1F4")]
	[Token(Token = "0x6002B92")]
	internal IAsyncResult BeginWriteInternal(Byte[] buffer, int offset, int count, AsyncCallback callback, object state, bool serializeAsynchronously, bool apm) { }

	[Address(RVA = "0x736D278", Offset = "0x736D278", Length = "0x180")]
	[Token(Token = "0x6002BA4")]
	internal IAsyncResult BlockingBeginRead(Byte[] buffer, int offset, int count, AsyncCallback callback, object state) { }

	[Address(RVA = "0x736D588", Offset = "0x736D588", Length = "0x180")]
	[Token(Token = "0x6002BA6")]
	internal IAsyncResult BlockingBeginWrite(Byte[] buffer, int offset, int count, AsyncCallback callback, object state) { }

	[Address(RVA = "0x736D494", Offset = "0x736D494", Length = "0x4")]
	[Token(Token = "0x6002BA5")]
	internal static int BlockingEndRead(IAsyncResult asyncResult) { }

	[Address(RVA = "0x736D744", Offset = "0x736D744", Length = "0x4")]
	[Token(Token = "0x6002BA7")]
	internal static void BlockingEndWrite(IAsyncResult asyncResult) { }

	[Address(RVA = "0x736B0B0", Offset = "0x736B0B0", Length = "0x70")]
	[Token(Token = "0x6002B85")]
	public override void Close() { }

	[Address(RVA = "0x736B120", Offset = "0x736B120", Length = "0x10")]
	[Token(Token = "0x6002B86")]
	public override void Dispose() { }

	[Address(RVA = "0x736B130", Offset = "0x736B130", Length = "0x4")]
	[Token(Token = "0x6002B87")]
	protected override void Dispose(bool disposing) { }

	[Address(RVA = "0x736B8EC", Offset = "0x736B8EC", Length = "0x1C4")]
	[Token(Token = "0x6002B8C")]
	public override int EndRead(IAsyncResult asyncResult) { }

	[Address(RVA = "0x736C454", Offset = "0x736C454", Length = "0x1BC")]
	[Token(Token = "0x6002B96")]
	public override void EndWrite(IAsyncResult asyncResult) { }

	[Address(RVA = "0x736AE68", Offset = "0x736AE68", Length = "0x100")]
	[Token(Token = "0x6002B79")]
	internal SemaphoreSlim EnsureAsyncActiveSemaphoreInitialized() { }

	[Address(RVA = "0x736C424", Offset = "0x736C424", Length = "0x30")]
	[Token(Token = "0x6002B95")]
	private void FinishTrackingAsyncOperation() { }

	[Address(RVA = "0x736CC0C", Offset = "0x736CC0C", Length = "0xF8")]
	[AsyncStateMachine(typeof(<FinishWriteAsync>d__57))]
	[Token(Token = "0x6002B9A")]
	private Task FinishWriteAsync(Task writeTask, Byte[] localBuffer) { }

	[Token(Token = "0x6002B88")]
	public abstract void Flush() { }

	[Address(RVA = "0x736B134", Offset = "0x736B134", Length = "0x1CC")]
	[Token(Token = "0x6002B89")]
	public override Task FlushAsync(CancellationToken cancellationToken) { }

	[Token(Token = "0x6002B7A")]
	public abstract bool get_CanRead() { }

	[Token(Token = "0x6002B7B")]
	public abstract bool get_CanSeek() { }

	[Address(RVA = "0x736AF68", Offset = "0x736AF68", Length = "0x8")]
	[Token(Token = "0x6002B7C")]
	public override bool get_CanTimeout() { }

	[Token(Token = "0x6002B7D")]
	public abstract bool get_CanWrite() { }

	[Token(Token = "0x6002B7E")]
	public abstract long get_Length() { }

	[Token(Token = "0x6002B7F")]
	public abstract long get_Position() { }

	[Address(RVA = "0x736AF70", Offset = "0x736AF70", Length = "0x50")]
	[Token(Token = "0x6002B81")]
	public override int get_ReadTimeout() { }

	[Address(RVA = "0x736B010", Offset = "0x736B010", Length = "0x50")]
	[Token(Token = "0x6002B83")]
	public override int get_WriteTimeout() { }

	[Address(RVA = "0x736C208", Offset = "0x736C208", Length = "0x8")]
	[Token(Token = "0x6002BA8")]
	private bool HasOverriddenBeginEndRead() { }

	[Address(RVA = "0x736CD04", Offset = "0x736CD04", Length = "0x8")]
	[Token(Token = "0x6002BA9")]
	private bool HasOverriddenBeginEndWrite() { }

	[Token(Token = "0x6002B9E")]
	public abstract int Read(Byte[] buffer, int offset, int count) { }

	[Address(RVA = "0x736CD0C", Offset = "0x736CD0C", Length = "0x288")]
	[Token(Token = "0x6002B9F")]
	public override int Read(Span<Byte> buffer) { }

	[Address(RVA = "0x736BE08", Offset = "0x736BE08", Length = "0x29C")]
	[Token(Token = "0x6002B8F")]
	public override ValueTask<Int32> ReadAsync(Memory<Byte> buffer, CancellationToken cancellationToken = null) { }

	[Address(RVA = "0x736BB44", Offset = "0x736BB44", Length = "0xE0")]
	[Token(Token = "0x6002B8E")]
	public override Task<Int32> ReadAsync(Byte[] buffer, int offset, int count, CancellationToken cancellationToken) { }

	[Address(RVA = "0x736BAB0", Offset = "0x736BAB0", Length = "0x94")]
	[Token(Token = "0x6002B8D")]
	public Task<Int32> ReadAsync(Byte[] buffer, int offset, int count) { }

	[Address(RVA = "0x736CF94", Offset = "0x736CF94", Length = "0x94")]
	[Token(Token = "0x6002BA0")]
	public override int ReadByte() { }

	[Address(RVA = "0x736B824", Offset = "0x736B824", Length = "0xC8")]
	[Token(Token = "0x6002B94")]
	private void RunReadWriteTask(ReadWriteTask readWriteTask) { }

	[Address(RVA = "0x736B698", Offset = "0x736B698", Length = "0x18C")]
	[Token(Token = "0x6002B93")]
	private void RunReadWriteTaskWhenReady(Task asyncWaiter, ReadWriteTask readWriteTask) { }

	[Token(Token = "0x6002B9C")]
	public abstract long Seek(long offset, SeekOrigin origin) { }

	[Token(Token = "0x6002B80")]
	public abstract void set_Position(long value) { }

	[Address(RVA = "0x736AFC0", Offset = "0x736AFC0", Length = "0x50")]
	[Token(Token = "0x6002B82")]
	public override void set_ReadTimeout(int value) { }

	[Address(RVA = "0x736B060", Offset = "0x736B060", Length = "0x50")]
	[Token(Token = "0x6002B84")]
	public override void set_WriteTimeout(int value) { }

	[Token(Token = "0x6002B9D")]
	public abstract void SetLength(long value) { }

	[Address(RVA = "0x736D028", Offset = "0x736D028", Length = "0x1C4")]
	[Token(Token = "0x6002BA2")]
	public override void Write(ReadOnlySpan<Byte> buffer) { }

	[Token(Token = "0x6002BA1")]
	public abstract void Write(Byte[] buffer, int offset, int count) { }

	[Address(RVA = "0x736C954", Offset = "0x736C954", Length = "0x2B8")]
	[Token(Token = "0x6002B99")]
	public override ValueTask WriteAsync(ReadOnlyMemory<Byte> buffer, CancellationToken cancellationToken = null) { }

	[Address(RVA = "0x736C6A4", Offset = "0x736C6A4", Length = "0xCC")]
	[Token(Token = "0x6002B98")]
	public override Task WriteAsync(Byte[] buffer, int offset, int count, CancellationToken cancellationToken) { }

	[Address(RVA = "0x736C610", Offset = "0x736C610", Length = "0x94")]
	[Token(Token = "0x6002B97")]
	public Task WriteAsync(Byte[] buffer, int offset, int count) { }

	[Address(RVA = "0x736D1EC", Offset = "0x736D1EC", Length = "0x8C")]
	[Token(Token = "0x6002BA3")]
	public override void WriteByte(byte value) { }

}

