namespace System.IO;

[Token(Token = "0x2000570")]
public class MemoryStream : Stream
{
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4001654")]
	private Byte[] _buffer; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4001655")]
	private int _origin; //Field offset: 0x30
	[FieldOffset(Offset = "0x34")]
	[Token(Token = "0x4001656")]
	private int _position; //Field offset: 0x34
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4001657")]
	private int _length; //Field offset: 0x38
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x4001658")]
	private int _capacity; //Field offset: 0x3C
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4001659")]
	private bool _expandable; //Field offset: 0x40
	[FieldOffset(Offset = "0x41")]
	[Token(Token = "0x400165A")]
	private bool _writable; //Field offset: 0x41
	[FieldOffset(Offset = "0x42")]
	[Token(Token = "0x400165B")]
	private bool _exposable; //Field offset: 0x42
	[FieldOffset(Offset = "0x43")]
	[Token(Token = "0x400165C")]
	private bool _isOpen; //Field offset: 0x43
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x400165D")]
	private Task<Int32> _lastReadTask; //Field offset: 0x48

	[Token(Token = "0x1700061D")]
	public virtual bool CanRead
	{
		[Address(RVA = "0x732AD98", Offset = "0x732AD98", Length = "0x8")]
		[Token(Token = "0x600299B")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700061E")]
	public virtual bool CanSeek
	{
		[Address(RVA = "0x732ADA0", Offset = "0x732ADA0", Length = "0x8")]
		[Token(Token = "0x600299C")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700061F")]
	public virtual bool CanWrite
	{
		[Address(RVA = "0x732ADA8", Offset = "0x732ADA8", Length = "0x8")]
		[Token(Token = "0x600299D")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000620")]
	public override int Capacity
	{
		[Address(RVA = "0x732B324", Offset = "0x732B324", Length = "0x20")]
		[Token(Token = "0x60029AA")]
		 get { } //Length: 32
		[Address(RVA = "0x732B344", Offset = "0x732B344", Length = "0x194")]
		[Token(Token = "0x60029AB")]
		 set { } //Length: 404
	}

	[Token(Token = "0x17000621")]
	public virtual long Length
	{
		[Address(RVA = "0x732B4D8", Offset = "0x732B4D8", Length = "0x24")]
		[Token(Token = "0x60029AC")]
		 get { } //Length: 36
	}

	[Token(Token = "0x17000622")]
	public virtual long Position
	{
		[Address(RVA = "0x732B4FC", Offset = "0x732B4FC", Length = "0x20")]
		[Token(Token = "0x60029AD")]
		 get { } //Length: 32
		[Address(RVA = "0x732B51C", Offset = "0x732B51C", Length = "0xCC")]
		[Token(Token = "0x60029AE")]
		 set { } //Length: 204
	}

	[Address(RVA = "0x732A928", Offset = "0x732A928", Length = "0x8")]
	[Token(Token = "0x6002994")]
	public MemoryStream() { }

	[Address(RVA = "0x732A930", Offset = "0x732A930", Length = "0x16C")]
	[Token(Token = "0x6002995")]
	public MemoryStream(int capacity) { }

	[Address(RVA = "0x732AA9C", Offset = "0x732AA9C", Length = "0x8")]
	[Token(Token = "0x6002996")]
	public MemoryStream(Byte[] buffer) { }

	[Address(RVA = "0x732AAA4", Offset = "0x732AAA4", Length = "0xFC")]
	[Token(Token = "0x6002997")]
	public MemoryStream(Byte[] buffer, bool writable) { }

	[Address(RVA = "0x732ABA0", Offset = "0x732ABA0", Length = "0xC")]
	[Token(Token = "0x6002998")]
	public MemoryStream(Byte[] buffer, int index, int count) { }

	[Address(RVA = "0x732AD90", Offset = "0x732AD90", Length = "0x8")]
	[Token(Token = "0x6002999")]
	public MemoryStream(Byte[] buffer, int index, int count, bool writable) { }

	[Address(RVA = "0x732ABAC", Offset = "0x732ABAC", Length = "0x1E4")]
	[Token(Token = "0x600299A")]
	public MemoryStream(Byte[] buffer, int index, int count, bool writable, bool publiclyVisible) { }

	[Address(RVA = "0x732AE20", Offset = "0x732AE20", Length = "0xA4")]
	[Token(Token = "0x60029A0")]
	protected virtual void Dispose(bool disposing) { }

	[Address(RVA = "0x732AEC4", Offset = "0x732AEC4", Length = "0xB8")]
	[Token(Token = "0x60029A1")]
	private bool EnsureCapacity(int value) { }

	[Address(RVA = "0x732ADB0", Offset = "0x732ADB0", Length = "0x34")]
	[Token(Token = "0x600299E")]
	private void EnsureNotClosed() { }

	[Address(RVA = "0x732ADE4", Offset = "0x732ADE4", Length = "0x3C")]
	[Token(Token = "0x600299F")]
	private void EnsureWriteable() { }

	[Address(RVA = "0x732AF7C", Offset = "0x732AF7C", Length = "0x4")]
	[Token(Token = "0x60029A2")]
	public virtual void Flush() { }

	[Address(RVA = "0x732AF80", Offset = "0x732AF80", Length = "0x1A0")]
	[Token(Token = "0x60029A3")]
	public virtual Task FlushAsync(CancellationToken cancellationToken) { }

	[Address(RVA = "0x732AD98", Offset = "0x732AD98", Length = "0x8")]
	[Token(Token = "0x600299B")]
	public virtual bool get_CanRead() { }

	[Address(RVA = "0x732ADA0", Offset = "0x732ADA0", Length = "0x8")]
	[Token(Token = "0x600299C")]
	public virtual bool get_CanSeek() { }

	[Address(RVA = "0x732ADA8", Offset = "0x732ADA8", Length = "0x8")]
	[Token(Token = "0x600299D")]
	public virtual bool get_CanWrite() { }

	[Address(RVA = "0x732B324", Offset = "0x732B324", Length = "0x20")]
	[Token(Token = "0x60029AA")]
	public override int get_Capacity() { }

	[Address(RVA = "0x732B4D8", Offset = "0x732B4D8", Length = "0x24")]
	[Token(Token = "0x60029AC")]
	public virtual long get_Length() { }

	[Address(RVA = "0x732B4FC", Offset = "0x732B4FC", Length = "0x20")]
	[Token(Token = "0x60029AD")]
	public virtual long get_Position() { }

	[Address(RVA = "0x732B120", Offset = "0x732B120", Length = "0x64")]
	[Token(Token = "0x60029A4")]
	public override Byte[] GetBuffer() { }

	[Address(RVA = "0x732B2E4", Offset = "0x732B2E4", Length = "0x40")]
	[Token(Token = "0x60029A9")]
	internal int InternalEmulateRead(int count) { }

	[Address(RVA = "0x732B21C", Offset = "0x732B21C", Length = "0x8")]
	[Token(Token = "0x60029A6")]
	internal Byte[] InternalGetBuffer() { }

	[Address(RVA = "0x732B224", Offset = "0x732B224", Length = "0x8")]
	[Token(Token = "0x60029A7")]
	internal int InternalGetPosition() { }

	[Address(RVA = "0x732B22C", Offset = "0x732B22C", Length = "0xB8")]
	[Token(Token = "0x60029A8")]
	internal int InternalReadInt32() { }

	[Address(RVA = "0x732B5E8", Offset = "0x732B5E8", Length = "0x1F4")]
	[Token(Token = "0x60029AF")]
	public virtual int Read(Byte[] buffer, int offset, int count) { }

	[Address(RVA = "0x732B7DC", Offset = "0x732B7DC", Length = "0x1FC")]
	[Token(Token = "0x60029B0")]
	public virtual int Read(Span<Byte> buffer) { }

	[Address(RVA = "0x732B9D8", Offset = "0x732B9D8", Length = "0x3A4")]
	[Token(Token = "0x60029B1")]
	public virtual Task<Int32> ReadAsync(Byte[] buffer, int offset, int count, CancellationToken cancellationToken) { }

	[Address(RVA = "0x732BD7C", Offset = "0x732BD7C", Length = "0x384")]
	[Token(Token = "0x60029B2")]
	public virtual ValueTask<Int32> ReadAsync(Memory<Byte> buffer, CancellationToken cancellationToken = null) { }

	[Address(RVA = "0x732C100", Offset = "0x732C100", Length = "0x58")]
	[Token(Token = "0x60029B3")]
	public virtual int ReadByte() { }

	[Address(RVA = "0x732C158", Offset = "0x732C158", Length = "0x158")]
	[Token(Token = "0x60029B4")]
	public virtual long Seek(long offset, SeekOrigin loc) { }

	[Address(RVA = "0x732B344", Offset = "0x732B344", Length = "0x194")]
	[Token(Token = "0x60029AB")]
	public override void set_Capacity(int value) { }

	[Address(RVA = "0x732B51C", Offset = "0x732B51C", Length = "0xCC")]
	[Token(Token = "0x60029AE")]
	public virtual void set_Position(long value) { }

	[Address(RVA = "0x732C2B0", Offset = "0x732C2B0", Length = "0xDC")]
	[Token(Token = "0x60029B5")]
	public virtual void SetLength(long value) { }

	[Address(RVA = "0x732C38C", Offset = "0x732C38C", Length = "0xD8")]
	[Token(Token = "0x60029B6")]
	public override Byte[] ToArray() { }

	[Address(RVA = "0x732B184", Offset = "0x732B184", Length = "0x98")]
	[Token(Token = "0x60029A5")]
	public override bool TryGetBuffer(out ArraySegment<Byte>& buffer) { }

	[Address(RVA = "0x732C464", Offset = "0x732C464", Length = "0x288")]
	[Token(Token = "0x60029B7")]
	public virtual void Write(Byte[] buffer, int offset, int count) { }

	[Address(RVA = "0x732C6EC", Offset = "0x732C6EC", Length = "0x250")]
	[Token(Token = "0x60029B8")]
	public virtual void Write(ReadOnlySpan<Byte> buffer) { }

	[Address(RVA = "0x732C93C", Offset = "0x732C93C", Length = "0x344")]
	[Token(Token = "0x60029B9")]
	public virtual Task WriteAsync(Byte[] buffer, int offset, int count, CancellationToken cancellationToken) { }

	[Address(RVA = "0x732CC80", Offset = "0x732CC80", Length = "0x314")]
	[Token(Token = "0x60029BA")]
	public virtual ValueTask WriteAsync(ReadOnlyMemory<Byte> buffer, CancellationToken cancellationToken = null) { }

	[Address(RVA = "0x732CF94", Offset = "0x732CF94", Length = "0xBC")]
	[Token(Token = "0x60029BB")]
	public virtual void WriteByte(byte value) { }

	[Address(RVA = "0x732D050", Offset = "0x732D050", Length = "0xA4")]
	[Token(Token = "0x60029BC")]
	public override void WriteTo(Stream stream) { }

}

