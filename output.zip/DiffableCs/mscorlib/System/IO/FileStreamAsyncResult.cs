namespace System.IO;

[Token(Token = "0x20005AF")]
internal class FileStreamAsyncResult : IAsyncResult
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40017AE")]
	private object state; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40017AF")]
	private bool completed; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40017B0")]
	private ManualResetEvent wh; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40017B1")]
	private AsyncCallback cb; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40017B2")]
	private bool completedSynch; //Field offset: 0x30
	[FieldOffset(Offset = "0x34")]
	[Token(Token = "0x40017B3")]
	public int Count; //Field offset: 0x34
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40017B4")]
	public int OriginalCount; //Field offset: 0x38
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x40017B5")]
	public int BytesRead; //Field offset: 0x3C
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40017B6")]
	private AsyncCallback realcb; //Field offset: 0x40

	[Token(Token = "0x17000674")]
	public override object AsyncState
	{
		[Address(RVA = "0x7378294", Offset = "0x7378294", Length = "0x8")]
		[Token(Token = "0x6002C7A")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000676")]
	public override WaitHandle AsyncWaitHandle
	{
		[Address(RVA = "0x73782A4", Offset = "0x73782A4", Length = "0x8")]
		[Token(Token = "0x6002C7C")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000675")]
	public override bool CompletedSynchronously
	{
		[Address(RVA = "0x737829C", Offset = "0x737829C", Length = "0x8")]
		[Token(Token = "0x6002C7B")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000677")]
	public override bool IsCompleted
	{
		[Address(RVA = "0x73782AC", Offset = "0x73782AC", Length = "0x8")]
		[Token(Token = "0x6002C7D")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x7377160", Offset = "0x7377160", Length = "0x10C")]
	[Token(Token = "0x6002C78")]
	public FileStreamAsyncResult(AsyncCallback cb, object state) { }

	[Address(RVA = "0x7378200", Offset = "0x7378200", Length = "0x94")]
	[Token(Token = "0x6002C79")]
	private static void CBWrapper(IAsyncResult ares) { }

	[Address(RVA = "0x7378294", Offset = "0x7378294", Length = "0x8")]
	[Token(Token = "0x6002C7A")]
	public override object get_AsyncState() { }

	[Address(RVA = "0x73782A4", Offset = "0x73782A4", Length = "0x8")]
	[Token(Token = "0x6002C7C")]
	public override WaitHandle get_AsyncWaitHandle() { }

	[Address(RVA = "0x737829C", Offset = "0x737829C", Length = "0x8")]
	[Token(Token = "0x6002C7B")]
	public override bool get_CompletedSynchronously() { }

	[Address(RVA = "0x73782AC", Offset = "0x73782AC", Length = "0x8")]
	[Token(Token = "0x6002C7D")]
	public override bool get_IsCompleted() { }

}

