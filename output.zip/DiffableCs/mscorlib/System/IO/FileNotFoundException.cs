namespace System.IO;

[Token(Token = "0x200056C")]
public class FileNotFoundException : IOException
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x4001643")]
	private readonly string <FileName>k__BackingField; //Field offset: 0x90
	[CompilerGenerated]
	[FieldOffset(Offset = "0x98")]
	[Token(Token = "0x4001644")]
	private readonly string <FusionLog>k__BackingField; //Field offset: 0x98

	[Token(Token = "0x1700061B")]
	public string FileName
	{
		[Address(RVA = "0x732A4B4", Offset = "0x732A4B4", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x600298A")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700061C")]
	public string FusionLog
	{
		[Address(RVA = "0x732A4BC", Offset = "0x732A4BC", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x600298B")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700061A")]
	public virtual string Message
	{
		[Address(RVA = "0x732A410", Offset = "0x732A410", Length = "0x18")]
		[Token(Token = "0x6002988")]
		 get { } //Length: 24
	}

	[Address(RVA = "0x732A354", Offset = "0x732A354", Length = "0x5C")]
	[Token(Token = "0x6002985")]
	public FileNotFoundException() { }

	[Address(RVA = "0x732A3B0", Offset = "0x732A3B0", Length = "0x24")]
	[Token(Token = "0x6002986")]
	public FileNotFoundException(string message) { }

	[Address(RVA = "0x732A3D4", Offset = "0x732A3D4", Length = "0x3C")]
	[Token(Token = "0x6002987")]
	public FileNotFoundException(string message, string fileName) { }

	[Address(RVA = "0x732A6A4", Offset = "0x732A6A4", Length = "0xC4")]
	[Token(Token = "0x600298D")]
	protected FileNotFoundException(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x732A4B4", Offset = "0x732A4B4", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x600298A")]
	public string get_FileName() { }

	[Address(RVA = "0x732A4BC", Offset = "0x732A4BC", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x600298B")]
	public string get_FusionLog() { }

	[Address(RVA = "0x732A410", Offset = "0x732A410", Length = "0x18")]
	[Token(Token = "0x6002988")]
	public virtual string get_Message() { }

	[Address(RVA = "0x732A768", Offset = "0x732A768", Length = "0x118")]
	[Token(Token = "0x600298E")]
	public virtual void GetObjectData(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x732A428", Offset = "0x732A428", Length = "0x8C")]
	[Token(Token = "0x6002989")]
	private void SetMessageField() { }

	[Address(RVA = "0x732A4C4", Offset = "0x732A4C4", Length = "0x1E0")]
	[Token(Token = "0x600298C")]
	public virtual string ToString() { }

}

