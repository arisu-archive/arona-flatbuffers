namespace System.IO;

[Token(Token = "0x2000589")]
public sealed class DirectoryInfo : FileSystemInfo
{

	[Address(RVA = "0x733C618", Offset = "0x733C618", Length = "0x88")]
	[Token(Token = "0x6002ACC")]
	public DirectoryInfo(string path) { }

	[Address(RVA = "0x733DCC8", Offset = "0x733DCC8", Length = "0x8")]
	[Token(Token = "0x6002ADC")]
	private DirectoryInfo(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x733C7F8", Offset = "0x733C7F8", Length = "0x4C")]
	[Token(Token = "0x6002ACD")]
	internal DirectoryInfo(string originalPath, string fullPath = null, string fileName = null, bool isNormalized = false) { }

	[Address(RVA = "0x733DCBC", Offset = "0x733DCBC", Length = "0xC")]
	[Token(Token = "0x6002ADB")]
	public void Delete(bool recursive) { }

	[Address(RVA = "0x733DCAC", Offset = "0x733DCAC", Length = "0x10")]
	[Token(Token = "0x6002ADA")]
	public virtual void Delete() { }

	[Address(RVA = "0x733DA80", Offset = "0x733DA80", Length = "0x88")]
	[Token(Token = "0x6002AD5")]
	public IEnumerable<DirectoryInfo> EnumerateDirectories(string searchPattern, EnumerationOptions enumerationOptions) { }

	[Address(RVA = "0x733D9D8", Offset = "0x733D9D8", Length = "0xA8")]
	[Token(Token = "0x6002AD4")]
	public IEnumerable<DirectoryInfo> EnumerateDirectories() { }

	[Address(RVA = "0x733DB08", Offset = "0x733DB08", Length = "0xA8")]
	[Token(Token = "0x6002AD6")]
	public IEnumerable<FileInfo> EnumerateFiles() { }

	[Address(RVA = "0x733DC38", Offset = "0x733DC38", Length = "0x74")]
	[Token(Token = "0x6002AD7")]
	public IEnumerable<FileInfo> EnumerateFiles(string searchPattern, SearchOption searchOption) { }

	[Address(RVA = "0x733DBB0", Offset = "0x733DBB0", Length = "0x88")]
	[Token(Token = "0x6002AD8")]
	public IEnumerable<FileInfo> EnumerateFiles(string searchPattern, EnumerationOptions enumerationOptions) { }

	[Address(RVA = "0x733D890", Offset = "0x733D890", Length = "0xA8")]
	[Token(Token = "0x6002AD2")]
	public DirectoryInfo[] GetDirectories() { }

	[Address(RVA = "0x733D938", Offset = "0x733D938", Length = "0xA0")]
	[Token(Token = "0x6002AD3")]
	public DirectoryInfo[] GetDirectories(string searchPattern, EnumerationOptions enumerationOptions) { }

	[Address(RVA = "0x733D4E8", Offset = "0x733D4E8", Length = "0xA8")]
	[Token(Token = "0x6002ACF")]
	public FileInfo[] GetFiles() { }

	[Address(RVA = "0x733D630", Offset = "0x733D630", Length = "0xA0")]
	[Token(Token = "0x6002AD0")]
	public FileInfo[] GetFiles(string searchPattern) { }

	[Address(RVA = "0x733D590", Offset = "0x733D590", Length = "0xA0")]
	[Token(Token = "0x6002AD1")]
	public FileInfo[] GetFiles(string searchPattern, EnumerationOptions enumerationOptions) { }

	[Address(RVA = "0x733D234", Offset = "0x733D234", Length = "0x2B4")]
	[Token(Token = "0x6002ACE")]
	private void Init(string originalPath, string fullPath = null, string fileName = null, bool isNormalized = false) { }

	[Address(RVA = "0x733D6D0", Offset = "0x733D6D0", Length = "0x1C0")]
	[Token(Token = "0x6002AD9")]
	internal static IEnumerable<FileSystemInfo> InternalEnumerateInfos(string path, string searchPattern, SearchTarget searchTarget, EnumerationOptions options) { }

}

