namespace System.IO;

[Token(Token = "0x2000572")]
public class PathTooLongException : IOException
{

	[Address(RVA = "0x732DA48", Offset = "0x732DA48", Length = "0x5C")]
	[Token(Token = "0x60029C8")]
	public PathTooLongException() { }

	[Address(RVA = "0x732DAA4", Offset = "0x732DAA4", Length = "0x24")]
	[Token(Token = "0x60029C9")]
	public PathTooLongException(string message) { }

	[Address(RVA = "0x732DAC8", Offset = "0x732DAC8", Length = "0x8")]
	[Token(Token = "0x60029CA")]
	protected PathTooLongException(SerializationInfo info, StreamingContext context) { }

}

