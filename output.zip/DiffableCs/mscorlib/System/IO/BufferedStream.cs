namespace System.IO;

[Token(Token = "0x2000597")]
public sealed class BufferedStream : Stream
{
	[CompilerGenerated]
	[Token(Token = "0x2000598")]
	private sealed class <>c
	{
		[Token(Token = "0x4001726")]
		public static readonly <>c <>9; //Field offset: 0x0
		[Token(Token = "0x4001727")]
		public static Func<SemaphoreSlim> <>9__10_0; //Field offset: 0x8

		[Address(RVA = "0x73681C4", Offset = "0x73681C4", Length = "0x70")]
		[Token(Token = "0x6002B6E")]
		private static <>c() { }

		[Address(RVA = "0x7368234", Offset = "0x7368234", Length = "0x8")]
		[Token(Token = "0x6002B6F")]
		public <>c() { }

		[Address(RVA = "0x736823C", Offset = "0x736823C", Length = "0x64")]
		[Token(Token = "0x6002B70")]
		internal SemaphoreSlim <LazyEnsureAsyncActiveSemaphoreInitialized>b__10_0() { }

	}

	[CompilerGenerated]
	[Token(Token = "0x2000599")]
	private struct <FlushAsyncInternal>d__38 : IAsyncStateMachine
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001728")]
		public int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x4001729")]
		public AsyncTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x400172A")]
		public BufferedStream <>4__this; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x400172B")]
		public CancellationToken cancellationToken; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x400172C")]
		private SemaphoreSlim <sem>5__2; //Field offset: 0x30
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x400172D")]
		private ConfiguredTaskAwaiter <>u__1; //Field offset: 0x38

		[Address(RVA = "0x73682A0", Offset = "0x73682A0", Length = "0x658")]
		[Token(Token = "0x6002B71")]
		private override void MoveNext() { }

		[Address(RVA = "0x73688F8", Offset = "0x73688F8", Length = "0x68")]
		[DebuggerHidden]
		[Token(Token = "0x6002B72")]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x200059A")]
	private struct <FlushWriteAsync>d__42 : IAsyncStateMachine
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x400172E")]
		public int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x400172F")]
		public AsyncTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4001730")]
		public BufferedStream <>4__this; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4001731")]
		public CancellationToken cancellationToken; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4001732")]
		private ConfiguredValueTaskAwaiter <>u__1; //Field offset: 0x30
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4001733")]
		private ConfiguredTaskAwaiter <>u__2; //Field offset: 0x40

		[Address(RVA = "0x7368960", Offset = "0x7368960", Length = "0x5D4")]
		[Token(Token = "0x6002B73")]
		private override void MoveNext() { }

		[Address(RVA = "0x7368F34", Offset = "0x7368F34", Length = "0x68")]
		[DebuggerHidden]
		[Token(Token = "0x6002B74")]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x200059B")]
	private struct <ReadFromUnderlyingStreamAsync>d__51 : IAsyncStateMachine
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x4001734")]
		public int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x4001735")]
		public AsyncValueTaskMethodBuilder<Int32> <>t__builder; //Field offset: 0x8
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4001736")]
		public Task semaphoreLockTask; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4001737")]
		public BufferedStream <>4__this; //Field offset: 0x30
		[FieldOffset(Offset = "0x38")]
		[Token(Token = "0x4001738")]
		public Memory<Byte> buffer; //Field offset: 0x38
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4001739")]
		public int bytesAlreadySatisfied; //Field offset: 0x48
		[FieldOffset(Offset = "0x50")]
		[Token(Token = "0x400173A")]
		public CancellationToken cancellationToken; //Field offset: 0x50
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x400173B")]
		private ConfiguredTaskAwaiter <>u__1; //Field offset: 0x58
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x400173C")]
		private int <>7__wrap1; //Field offset: 0x68
		[FieldOffset(Offset = "0x70")]
		[Token(Token = "0x400173D")]
		private ConfiguredValueTaskAwaiter<Int32> <>u__2; //Field offset: 0x70

		[Address(RVA = "0x7368F9C", Offset = "0x7368F9C", Length = "0x974")]
		[Token(Token = "0x6002B75")]
		private override void MoveNext() { }

		[Address(RVA = "0x7369910", Offset = "0x7369910", Length = "0x58")]
		[DebuggerHidden]
		[Token(Token = "0x6002B76")]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[CompilerGenerated]
	[Token(Token = "0x200059C")]
	private struct <WriteToUnderlyingStreamAsync>d__63 : IAsyncStateMachine
	{
		[FieldOffset(Offset = "0x0")]
		[Token(Token = "0x400173E")]
		public int <>1__state; //Field offset: 0x0
		[FieldOffset(Offset = "0x8")]
		[Token(Token = "0x400173F")]
		public AsyncTaskMethodBuilder <>t__builder; //Field offset: 0x8
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4001740")]
		public Task semaphoreLockTask; //Field offset: 0x20
		[FieldOffset(Offset = "0x28")]
		[Token(Token = "0x4001741")]
		public BufferedStream <>4__this; //Field offset: 0x28
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x4001742")]
		public ReadOnlyMemory<Byte> buffer; //Field offset: 0x30
		[FieldOffset(Offset = "0x40")]
		[Token(Token = "0x4001743")]
		public CancellationToken cancellationToken; //Field offset: 0x40
		[FieldOffset(Offset = "0x48")]
		[Token(Token = "0x4001744")]
		private ConfiguredTaskAwaiter <>u__1; //Field offset: 0x48
		[FieldOffset(Offset = "0x58")]
		[Token(Token = "0x4001745")]
		private ConfiguredValueTaskAwaiter <>u__2; //Field offset: 0x58

		[Address(RVA = "0x7369968", Offset = "0x7369968", Length = "0x1498")]
		[Token(Token = "0x6002B77")]
		private override void MoveNext() { }

		[Address(RVA = "0x736AE00", Offset = "0x736AE00", Length = "0x68")]
		[DebuggerHidden]
		[Token(Token = "0x6002B78")]
		private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

	}

	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400171E")]
	private Stream _stream; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400171F")]
	private Byte[] _buffer; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4001720")]
	private readonly int _bufferSize; //Field offset: 0x38
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x4001721")]
	private int _readPos; //Field offset: 0x3C
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4001722")]
	private int _readLen; //Field offset: 0x40
	[FieldOffset(Offset = "0x44")]
	[Token(Token = "0x4001723")]
	private int _writePos; //Field offset: 0x44
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x4001724")]
	private Task<Int32> _lastSyncCompletedReadTask; //Field offset: 0x48
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x4001725")]
	private SemaphoreSlim _asyncActiveSemaphore; //Field offset: 0x50

	[Token(Token = "0x17000654")]
	public virtual bool CanRead
	{
		[Address(RVA = "0x7365748", Offset = "0x7365748", Length = "0x18")]
		[Token(Token = "0x6002B47")]
		 get { } //Length: 24
	}

	[Token(Token = "0x17000656")]
	public virtual bool CanSeek
	{
		[Address(RVA = "0x7365778", Offset = "0x7365778", Length = "0x18")]
		[Token(Token = "0x6002B49")]
		 get { } //Length: 24
	}

	[Token(Token = "0x17000655")]
	public virtual bool CanWrite
	{
		[Address(RVA = "0x7365760", Offset = "0x7365760", Length = "0x18")]
		[Token(Token = "0x6002B48")]
		 get { } //Length: 24
	}

	[Token(Token = "0x17000657")]
	public virtual long Length
	{
		[Address(RVA = "0x7365790", Offset = "0x7365790", Length = "0x3C")]
		[Token(Token = "0x6002B4A")]
		 get { } //Length: 60
	}

	[Token(Token = "0x17000658")]
	public virtual long Position
	{
		[Address(RVA = "0x736581C", Offset = "0x736581C", Length = "0x48")]
		[Token(Token = "0x6002B4B")]
		 get { } //Length: 72
		[Address(RVA = "0x7365864", Offset = "0x7365864", Length = "0xC4")]
		[Token(Token = "0x6002B4C")]
		 set { } //Length: 196
	}

	[Address(RVA = "0x7365234", Offset = "0x7365234", Length = "0x8")]
	[Token(Token = "0x6002B3F")]
	public BufferedStream(Stream stream) { }

	[Address(RVA = "0x736523C", Offset = "0x736523C", Length = "0x1F0")]
	[Token(Token = "0x6002B40")]
	public BufferedStream(Stream stream, int bufferSize) { }

	[Address(RVA = "0x7366E74", Offset = "0x7366E74", Length = "0xB4")]
	[Token(Token = "0x6002B5E")]
	public virtual IAsyncResult BeginRead(Byte[] buffer, int offset, int count, AsyncCallback callback, object state) { }

	[Address(RVA = "0x7367E94", Offset = "0x7367E94", Length = "0xB4")]
	[Token(Token = "0x6002B69")]
	public virtual IAsyncResult BeginWrite(Byte[] buffer, int offset, int count, AsyncCallback callback, object state) { }

	[Address(RVA = "0x7365D2C", Offset = "0x7365D2C", Length = "0x94")]
	[Token(Token = "0x6002B52")]
	private void ClearReadBufferBeforeWrite() { }

	[Address(RVA = "0x7365928", Offset = "0x7365928", Length = "0x134")]
	[Token(Token = "0x6002B4D")]
	protected virtual void Dispose(bool disposing) { }

	[Address(RVA = "0x7366F28", Offset = "0x7366F28", Length = "0x48")]
	[Token(Token = "0x6002B5F")]
	public virtual int EndRead(IAsyncResult asyncResult) { }

	[Address(RVA = "0x7367F48", Offset = "0x7367F48", Length = "0xC")]
	[Token(Token = "0x6002B6A")]
	public virtual void EndWrite(IAsyncResult asyncResult) { }

	[Address(RVA = "0x73656D8", Offset = "0x73656D8", Length = "0x70")]
	[Token(Token = "0x6002B46")]
	private void EnsureBufferAllocated() { }

	[Address(RVA = "0x736550C", Offset = "0x736550C", Length = "0x74")]
	[Token(Token = "0x6002B43")]
	private void EnsureCanRead() { }

	[Address(RVA = "0x7365498", Offset = "0x7365498", Length = "0x74")]
	[Token(Token = "0x6002B42")]
	private void EnsureCanSeek() { }

	[Address(RVA = "0x7365580", Offset = "0x7365580", Length = "0x74")]
	[Token(Token = "0x6002B44")]
	private void EnsureCanWrite() { }

	[Address(RVA = "0x7365434", Offset = "0x7365434", Length = "0x64")]
	[Token(Token = "0x6002B41")]
	private void EnsureNotClosed() { }

	[Address(RVA = "0x73655F4", Offset = "0x73655F4", Length = "0xE4")]
	[Token(Token = "0x6002B45")]
	private void EnsureShadowBufferAllocated() { }

	[Address(RVA = "0x7365A5C", Offset = "0x7365A5C", Length = "0xC4")]
	[Token(Token = "0x6002B4E")]
	public virtual void Flush() { }

	[Address(RVA = "0x7365B64", Offset = "0x7365B64", Length = "0xCC")]
	[Token(Token = "0x6002B4F")]
	public virtual Task FlushAsync(CancellationToken cancellationToken) { }

	[Address(RVA = "0x7365C30", Offset = "0x7365C30", Length = "0xFC")]
	[AsyncStateMachine(typeof(<FlushAsyncInternal>d__38))]
	[Token(Token = "0x6002B50")]
	private Task FlushAsyncInternal(CancellationToken cancellationToken) { }

	[Address(RVA = "0x7365B20", Offset = "0x7365B20", Length = "0x44")]
	[Token(Token = "0x6002B51")]
	private void FlushRead() { }

	[Address(RVA = "0x73657CC", Offset = "0x73657CC", Length = "0x50")]
	[Token(Token = "0x6002B53")]
	private void FlushWrite() { }

	[Address(RVA = "0x7365DC0", Offset = "0x7365DC0", Length = "0xFC")]
	[AsyncStateMachine(typeof(<FlushWriteAsync>d__42))]
	[Token(Token = "0x6002B54")]
	private Task FlushWriteAsync(CancellationToken cancellationToken) { }

	[Address(RVA = "0x7365748", Offset = "0x7365748", Length = "0x18")]
	[Token(Token = "0x6002B47")]
	public virtual bool get_CanRead() { }

	[Address(RVA = "0x7365778", Offset = "0x7365778", Length = "0x18")]
	[Token(Token = "0x6002B49")]
	public virtual bool get_CanSeek() { }

	[Address(RVA = "0x7365760", Offset = "0x7365760", Length = "0x18")]
	[Token(Token = "0x6002B48")]
	public virtual bool get_CanWrite() { }

	[Address(RVA = "0x7365790", Offset = "0x7365790", Length = "0x3C")]
	[Token(Token = "0x6002B4A")]
	public virtual long get_Length() { }

	[Address(RVA = "0x736581C", Offset = "0x736581C", Length = "0x48")]
	[Token(Token = "0x6002B4B")]
	public virtual long get_Position() { }

	[Address(RVA = "0x73664B8", Offset = "0x73664B8", Length = "0xBC")]
	[Token(Token = "0x6002B5A")]
	private Task<Int32> LastSyncCompletedReadTask(int val) { }

	[Address(RVA = "0x7365134", Offset = "0x7365134", Length = "0x100")]
	[Token(Token = "0x6002B3E")]
	internal SemaphoreSlim LazyEnsureAsyncActiveSemaphoreInitialized() { }

	[Address(RVA = "0x736612C", Offset = "0x736612C", Length = "0x228")]
	[Token(Token = "0x6002B58")]
	public virtual int Read(Byte[] array, int offset, int count) { }

	[Address(RVA = "0x7366354", Offset = "0x7366354", Length = "0x164")]
	[Token(Token = "0x6002B59")]
	public virtual int Read(Span<Byte> destination) { }

	[Address(RVA = "0x7366574", Offset = "0x7366574", Length = "0x428")]
	[Token(Token = "0x6002B5B")]
	public virtual Task<Int32> ReadAsync(Byte[] buffer, int offset, int count, CancellationToken cancellationToken) { }

	[Address(RVA = "0x7366B24", Offset = "0x7366B24", Length = "0x350")]
	[Token(Token = "0x6002B5C")]
	public virtual ValueTask<Int32> ReadAsync(Memory<Byte> buffer, CancellationToken cancellationToken = null) { }

	[Address(RVA = "0x7366F70", Offset = "0x7366F70", Length = "0x50")]
	[Token(Token = "0x6002B60")]
	public virtual int ReadByte() { }

	[Address(RVA = "0x7366FC0", Offset = "0x7366FC0", Length = "0x90")]
	[Token(Token = "0x6002B61")]
	private int ReadByteSlow() { }

	[Address(RVA = "0x7365EBC", Offset = "0x7365EBC", Length = "0x60")]
	[Token(Token = "0x6002B55")]
	private int ReadFromBuffer(Byte[] array, int offset, int count) { }

	[Address(RVA = "0x736604C", Offset = "0x736604C", Length = "0xE0")]
	[Token(Token = "0x6002B57")]
	private int ReadFromBuffer(Byte[] array, int offset, int count, out Exception error) { }

	[Address(RVA = "0x7365F1C", Offset = "0x7365F1C", Length = "0x130")]
	[Token(Token = "0x6002B56")]
	private int ReadFromBuffer(Span<Byte> destination) { }

	[Address(RVA = "0x736699C", Offset = "0x736699C", Length = "0x188")]
	[AsyncStateMachine(typeof(<ReadFromUnderlyingStreamAsync>d__51))]
	[Token(Token = "0x6002B5D")]
	private ValueTask<Int32> ReadFromUnderlyingStreamAsync(Memory<Byte> buffer, CancellationToken cancellationToken, int bytesAlreadySatisfied, Task semaphoreLockTask) { }

	[Address(RVA = "0x7367FE0", Offset = "0x7367FE0", Length = "0x120")]
	[Token(Token = "0x6002B6C")]
	public virtual long Seek(long offset, SeekOrigin origin) { }

	[Address(RVA = "0x7365864", Offset = "0x7365864", Length = "0xC4")]
	[Token(Token = "0x6002B4C")]
	public virtual void set_Position(long value) { }

	[Address(RVA = "0x7368100", Offset = "0x7368100", Length = "0xC4")]
	[Token(Token = "0x6002B6D")]
	public virtual void SetLength(long value) { }

	[Address(RVA = "0x73672B8", Offset = "0x73672B8", Length = "0x320")]
	[Token(Token = "0x6002B64")]
	public virtual void Write(Byte[] array, int offset, int count) { }

	[Address(RVA = "0x73675D8", Offset = "0x73675D8", Length = "0x2DC")]
	[Token(Token = "0x6002B65")]
	public virtual void Write(ReadOnlySpan<Byte> buffer) { }

	[Address(RVA = "0x73678B4", Offset = "0x73678B4", Length = "0x208")]
	[Token(Token = "0x6002B66")]
	public virtual Task WriteAsync(Byte[] buffer, int offset, int count, CancellationToken cancellationToken) { }

	[Address(RVA = "0x7367ABC", Offset = "0x7367ABC", Length = "0x288")]
	[Token(Token = "0x6002B67")]
	public virtual ValueTask WriteAsync(ReadOnlyMemory<Byte> buffer, CancellationToken cancellationToken = null) { }

	[Address(RVA = "0x7367F54", Offset = "0x7367F54", Length = "0x8C")]
	[Token(Token = "0x6002B6B")]
	public virtual void WriteByte(byte value) { }

	[Address(RVA = "0x7367050", Offset = "0x7367050", Length = "0xDC")]
	[Token(Token = "0x6002B62")]
	private void WriteToBuffer(Byte[] array, ref int offset, ref int count) { }

	[Address(RVA = "0x736712C", Offset = "0x736712C", Length = "0x18C")]
	[Token(Token = "0x6002B63")]
	private int WriteToBuffer(ReadOnlySpan<Byte> buffer) { }

	[Address(RVA = "0x7367D44", Offset = "0x7367D44", Length = "0x150")]
	[AsyncStateMachine(typeof(<WriteToUnderlyingStreamAsync>d__63))]
	[Token(Token = "0x6002B68")]
	private Task WriteToUnderlyingStreamAsync(ReadOnlyMemory<Byte> buffer, CancellationToken cancellationToken, Task semaphoreLockTask) { }

}

