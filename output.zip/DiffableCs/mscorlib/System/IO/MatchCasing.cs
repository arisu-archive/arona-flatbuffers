namespace System.IO;

[Token(Token = "0x2000593")]
public enum MatchCasing
{
	PlatformDefault = 0,
	CaseSensitive = 1,
	CaseInsensitive = 2,
}

