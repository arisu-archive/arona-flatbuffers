namespace System.IO;

[Token(Token = "0x2000574")]
public enum SeekOrigin
{
	Begin = 0,
	Current = 1,
	End = 2,
}

