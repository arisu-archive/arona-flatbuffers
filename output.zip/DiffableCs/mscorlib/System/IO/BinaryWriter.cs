namespace System.IO;

[ComVisible(True)]
[Token(Token = "0x20005A9")]
public class BinaryWriter : IDisposable
{
	[Token(Token = "0x400178F")]
	public static readonly BinaryWriter Null; //Field offset: 0x0
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001790")]
	protected Stream OutStream; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001791")]
	private Byte[] _buffer; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4001792")]
	private Encoding _encoding; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4001793")]
	private Encoder _encoder; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[OptionalField]
	[Token(Token = "0x4001794")]
	private bool _leaveOpen; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4001795")]
	private Byte[] _largeByteBuffer; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x4001796")]
	private int _maxChars; //Field offset: 0x40

	[Address(RVA = "0x73721BC", Offset = "0x73721BC", Length = "0x6C")]
	[Token(Token = "0x6002C25")]
	private static BinaryWriter() { }

	[Address(RVA = "0x737148C", Offset = "0x737148C", Length = "0x1B8")]
	[Token(Token = "0x6002C0F")]
	public BinaryWriter(Stream output, Encoding encoding, bool leaveOpen) { }

	[Address(RVA = "0x73712F0", Offset = "0x73712F0", Length = "0x11C")]
	[Token(Token = "0x6002C0C")]
	protected BinaryWriter() { }

	[Address(RVA = "0x737140C", Offset = "0x737140C", Length = "0x80")]
	[Token(Token = "0x6002C0D")]
	public BinaryWriter(Stream output) { }

	[Address(RVA = "0x7371644", Offset = "0x7371644", Length = "0x8")]
	[Token(Token = "0x6002C0E")]
	public BinaryWriter(Stream output, Encoding encoding) { }

	[Address(RVA = "0x737164C", Offset = "0x737164C", Length = "0x10")]
	[Token(Token = "0x6002C10")]
	public override void Close() { }

	[Address(RVA = "0x737165C", Offset = "0x737165C", Length = "0x54")]
	[Token(Token = "0x6002C11")]
	protected override void Dispose(bool disposing) { }

	[Address(RVA = "0x73716B0", Offset = "0x73716B0", Length = "0x10")]
	[Token(Token = "0x6002C12")]
	public override void Dispose() { }

	[Address(RVA = "0x73716C0", Offset = "0x73716C0", Length = "0x24")]
	[Token(Token = "0x6002C13")]
	public override void Flush() { }

	[Address(RVA = "0x7371E98", Offset = "0x7371E98", Length = "0x2C8")]
	[Token(Token = "0x6002C23")]
	public override void Write(string value) { }

	[Address(RVA = "0x7371E5C", Offset = "0x7371E5C", Length = "0x3C")]
	[Token(Token = "0x6002C22")]
	public override void Write(float value) { }

	[Address(RVA = "0x7371D4C", Offset = "0x7371D4C", Length = "0x110")]
	[CLSCompliant(False)]
	[Token(Token = "0x6002C21")]
	public override void Write(ulong value) { }

	[Address(RVA = "0x7371C3C", Offset = "0x7371C3C", Length = "0x110")]
	[Token(Token = "0x6002C20")]
	public override void Write(long value) { }

	[Address(RVA = "0x7371B9C", Offset = "0x7371B9C", Length = "0xA0")]
	[CLSCompliant(False)]
	[Token(Token = "0x6002C1F")]
	public override void Write(uint value) { }

	[Address(RVA = "0x7371AFC", Offset = "0x7371AFC", Length = "0xA0")]
	[Token(Token = "0x6002C1E")]
	public override void Write(int value) { }

	[Address(RVA = "0x7371A94", Offset = "0x7371A94", Length = "0x68")]
	[CLSCompliant(False)]
	[Token(Token = "0x6002C1D")]
	public override void Write(ushort value) { }

	[Address(RVA = "0x7371948", Offset = "0x7371948", Length = "0xA8")]
	[Token(Token = "0x6002C1A")]
	public override void Write(Char[] chars) { }

	[Address(RVA = "0x73719F0", Offset = "0x73719F0", Length = "0x3C")]
	[Token(Token = "0x6002C1B")]
	public override void Write(double value) { }

	[Address(RVA = "0x737181C", Offset = "0x737181C", Length = "0x12C")]
	[Token(Token = "0x6002C19")]
	public override void Write(char ch) { }

	[Address(RVA = "0x737177C", Offset = "0x737177C", Length = "0x7C")]
	[Token(Token = "0x6002C17")]
	public override void Write(Byte[] buffer) { }

	[Address(RVA = "0x7371758", Offset = "0x7371758", Length = "0x24")]
	[CLSCompliant(False)]
	[Token(Token = "0x6002C16")]
	public override void Write(sbyte value) { }

	[Address(RVA = "0x7371734", Offset = "0x7371734", Length = "0x24")]
	[Token(Token = "0x6002C15")]
	public override void Write(byte value) { }

	[Address(RVA = "0x73716E4", Offset = "0x73716E4", Length = "0x50")]
	[Token(Token = "0x6002C14")]
	public override void Write(bool value) { }

	[Address(RVA = "0x7371A2C", Offset = "0x7371A2C", Length = "0x68")]
	[Token(Token = "0x6002C1C")]
	public override void Write(short value) { }

	[Address(RVA = "0x73717F8", Offset = "0x73717F8", Length = "0x24")]
	[Token(Token = "0x6002C18")]
	public override void Write(Byte[] buffer, int index, int count) { }

	[Address(RVA = "0x7372160", Offset = "0x7372160", Length = "0x5C")]
	[Token(Token = "0x6002C24")]
	protected void Write7BitEncodedInt(int value) { }

}

