namespace System.IO;

[Token(Token = "0x2000591")]
internal static class FileSystem
{

	[Address(RVA = "0x73633E8", Offset = "0x73633E8", Length = "0x168")]
	[Token(Token = "0x6002B22")]
	private static bool CopyDanglingSymlink(string sourceFullPath, string destFullPath) { }

	[Address(RVA = "0x7363550", Offset = "0x7363550", Length = "0x3A0")]
	[Token(Token = "0x6002B23")]
	public static void CopyFile(string sourceFullPath, string destFullPath, bool overwrite) { }

	[Address(RVA = "0x7363C88", Offset = "0x7363C88", Length = "0x5C4")]
	[Token(Token = "0x6002B25")]
	public static void CreateDirectory(string fullPath) { }

	[Address(RVA = "0x7362C30", Offset = "0x7362C30", Length = "0x1AC")]
	[Token(Token = "0x6002B24")]
	public static void DeleteFile(string fullPath) { }

	[Address(RVA = "0x73638F0", Offset = "0x73638F0", Length = "0x1C")]
	[Token(Token = "0x6002B28")]
	public static bool DirectoryExists(ReadOnlySpan<Char> fullPath) { }

	[Address(RVA = "0x73642C8", Offset = "0x73642C8", Length = "0xC")]
	[Token(Token = "0x6002B29")]
	private static bool DirectoryExists(ReadOnlySpan<Char> fullPath, out ErrorInfo errorInfo) { }

	[Address(RVA = "0x736424C", Offset = "0x736424C", Length = "0x7C")]
	[Token(Token = "0x6002B2A")]
	public static bool FileExists(ReadOnlySpan<Char> fullPath) { }

	[Address(RVA = "0x7363B78", Offset = "0x7363B78", Length = "0x110")]
	[Token(Token = "0x6002B2B")]
	private static bool FileExists(ReadOnlySpan<Char> fullPath, int fileType, out ErrorInfo errorInfo) { }

	[Address(RVA = "0x7364A78", Offset = "0x7364A78", Length = "0x80")]
	[Token(Token = "0x6002B2D")]
	public static FileAttributes GetAttributes(string fullPath) { }

	[Address(RVA = "0x73642D4", Offset = "0x73642D4", Length = "0xC8")]
	[Token(Token = "0x6002B26")]
	public static void RemoveDirectory(string fullPath, bool recursive) { }

	[Address(RVA = "0x736439C", Offset = "0x736439C", Length = "0x658")]
	[Token(Token = "0x6002B27")]
	private static void RemoveDirectoryInternal(DirectoryInfo directory, bool recursive, bool throwOnTopLevelDirectoryNotFound) { }

	[Address(RVA = "0x73649F4", Offset = "0x73649F4", Length = "0x84")]
	[Token(Token = "0x6002B2C")]
	private static bool ShouldIgnoreDirectory(string name) { }

}

