namespace System.IO;

[Token(Token = "0x20005B3")]
internal struct MonoIOStat
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40017DB")]
	public FileAttributes fileAttributes; //Field offset: 0x0
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x40017DC")]
	public long Length; //Field offset: 0x8
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40017DD")]
	public long CreationTime; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40017DE")]
	public long LastAccessTime; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40017DF")]
	public long LastWriteTime; //Field offset: 0x20

}

