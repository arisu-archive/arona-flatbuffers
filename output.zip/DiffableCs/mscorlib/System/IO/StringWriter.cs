namespace System.IO;

[ComVisible(True)]
[Token(Token = "0x20005AB")]
public class StringWriter : TextWriter
{
	[Token(Token = "0x400179A")]
	private static UnicodeEncoding m_encoding; //Field offset: 0x0
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x400179B")]
	private StringBuilder _sb; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400179C")]
	private bool _isOpen; //Field offset: 0x38

	[Token(Token = "0x1700066C")]
	public virtual Encoding Encoding
	{
		[Address(RVA = "0x7372B44", Offset = "0x7372B44", Length = "0xBC")]
		[Token(Token = "0x6002C35")]
		 get { } //Length: 188
	}

	[Address(RVA = "0x73728BC", Offset = "0x73728BC", Length = "0x94")]
	[Token(Token = "0x6002C2F")]
	public StringWriter() { }

	[Address(RVA = "0x7372A44", Offset = "0x7372A44", Length = "0x74")]
	[Token(Token = "0x6002C30")]
	public StringWriter(IFormatProvider formatProvider) { }

	[Address(RVA = "0x7372AB8", Offset = "0x7372AB8", Length = "0x70")]
	[Token(Token = "0x6002C31")]
	public StringWriter(StringBuilder sb) { }

	[Address(RVA = "0x7372950", Offset = "0x7372950", Length = "0xF4")]
	[Token(Token = "0x6002C32")]
	public StringWriter(StringBuilder sb, IFormatProvider formatProvider) { }

	[Address(RVA = "0x7372B28", Offset = "0x7372B28", Length = "0x10")]
	[Token(Token = "0x6002C33")]
	public virtual void Close() { }

	[Address(RVA = "0x7372B38", Offset = "0x7372B38", Length = "0xC")]
	[Token(Token = "0x6002C34")]
	protected virtual void Dispose(bool disposing) { }

	[Address(RVA = "0x7373234", Offset = "0x7373234", Length = "0x88")]
	[ComVisible(False)]
	[Token(Token = "0x6002C3F")]
	public virtual Task FlushAsync() { }

	[Address(RVA = "0x7372B44", Offset = "0x7372B44", Length = "0xBC")]
	[Token(Token = "0x6002C35")]
	public virtual Encoding get_Encoding() { }

	[Address(RVA = "0x73732BC", Offset = "0x73732BC", Length = "0x20")]
	[Token(Token = "0x6002C40")]
	public virtual string ToString() { }

	[Address(RVA = "0x7372DB0", Offset = "0x7372DB0", Length = "0x34")]
	[Token(Token = "0x6002C38")]
	public virtual void Write(string value) { }

	[Address(RVA = "0x7372C00", Offset = "0x7372C00", Length = "0x28")]
	[Token(Token = "0x6002C36")]
	public virtual void Write(char value) { }

	[Address(RVA = "0x7372C28", Offset = "0x7372C28", Length = "0x188")]
	[Token(Token = "0x6002C37")]
	public virtual void Write(Char[] buffer, int index, int count) { }

	[Address(RVA = "0x7372DE4", Offset = "0x7372DE4", Length = "0xB0")]
	[ComVisible(False)]
	[Token(Token = "0x6002C39")]
	public virtual Task WriteAsync(char value) { }

	[Address(RVA = "0x7372E94", Offset = "0x7372E94", Length = "0xB0")]
	[ComVisible(False)]
	[Token(Token = "0x6002C3A")]
	public virtual Task WriteAsync(string value) { }

	[Address(RVA = "0x7372F44", Offset = "0x7372F44", Length = "0xC8")]
	[ComVisible(False)]
	[Token(Token = "0x6002C3B")]
	public virtual Task WriteAsync(Char[] buffer, int index, int count) { }

	[Address(RVA = "0x737300C", Offset = "0x737300C", Length = "0xB0")]
	[ComVisible(False)]
	[Token(Token = "0x6002C3C")]
	public virtual Task WriteLineAsync(char value) { }

	[Address(RVA = "0x73730BC", Offset = "0x73730BC", Length = "0xB0")]
	[ComVisible(False)]
	[Token(Token = "0x6002C3D")]
	public virtual Task WriteLineAsync(string value) { }

	[Address(RVA = "0x737316C", Offset = "0x737316C", Length = "0xC8")]
	[ComVisible(False)]
	[Token(Token = "0x6002C3E")]
	public virtual Task WriteLineAsync(Char[] buffer, int index, int count) { }

}

