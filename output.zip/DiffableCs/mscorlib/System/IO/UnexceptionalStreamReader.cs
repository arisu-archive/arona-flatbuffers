namespace System.IO;

[Token(Token = "0x20005B6")]
internal class UnexceptionalStreamReader : StreamReader
{
	[Token(Token = "0x40017ED")]
	private static Boolean[] newline; //Field offset: 0x0
	[Token(Token = "0x40017EE")]
	private static char newlineChar; //Field offset: 0x8

	[Address(RVA = "0x737B428", Offset = "0x737B428", Length = "0xB0")]
	[Token(Token = "0x6002CBF")]
	private static UnexceptionalStreamReader() { }

	[Address(RVA = "0x737B4D8", Offset = "0x737B4D8", Length = "0x70")]
	[Token(Token = "0x6002CC0")]
	public UnexceptionalStreamReader(Stream stream, Encoding encoding) { }

	[Address(RVA = "0x737B8E4", Offset = "0x737B8E4", Length = "0x198")]
	[Token(Token = "0x6002CC4")]
	private bool CheckEOL(char current) { }

	[Address(RVA = "0x737B548", Offset = "0x737B548", Length = "0x88")]
	[Token(Token = "0x6002CC1")]
	public virtual int Peek() { }

	[Address(RVA = "0x737B5D0", Offset = "0x737B5D0", Length = "0x88")]
	[Token(Token = "0x6002CC2")]
	public virtual int Read() { }

	[Address(RVA = "0x737B658", Offset = "0x737B658", Length = "0x28C")]
	[Token(Token = "0x6002CC3")]
	public virtual int Read(out Char[] dest_buffer, int index, int count) { }

	[Address(RVA = "0x737BA7C", Offset = "0x737BA7C", Length = "0x88")]
	[Token(Token = "0x6002CC5")]
	public virtual string ReadLine() { }

	[Address(RVA = "0x737BB04", Offset = "0x737BB04", Length = "0x88")]
	[Token(Token = "0x6002CC6")]
	public virtual string ReadToEnd() { }

}

