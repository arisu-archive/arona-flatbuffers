namespace System.IO;

[Token(Token = "0x2000596")]
internal enum SearchTarget
{
	Files = 1,
	Directories = 2,
	Both = 3,
}

