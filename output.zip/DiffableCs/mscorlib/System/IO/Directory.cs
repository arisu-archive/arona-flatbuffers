namespace System.IO;

[Token(Token = "0x2000588")]
public static class Directory
{

	[Address(RVA = "0x733C6A0", Offset = "0x733C6A0", Length = "0x158")]
	[Token(Token = "0x6002ABD")]
	public static DirectoryInfo CreateDirectory(string path) { }

	[Address(RVA = "0x733D128", Offset = "0x733D128", Length = "0x70")]
	[Token(Token = "0x6002ACA")]
	public static void Delete(string path, bool recursive) { }

	[Address(RVA = "0x733CD34", Offset = "0x733CD34", Length = "0xAC")]
	[Token(Token = "0x6002AC3")]
	public static IEnumerable<String> EnumerateFiles(string path) { }

	[Address(RVA = "0x733CDEC", Offset = "0x733CDEC", Length = "0x78")]
	[Token(Token = "0x6002AC4")]
	public static IEnumerable<String> EnumerateFiles(string path, string searchPattern, SearchOption searchOption) { }

	[Address(RVA = "0x733CDE0", Offset = "0x733CDE0", Length = "0xC")]
	[Token(Token = "0x6002AC5")]
	public static IEnumerable<String> EnumerateFiles(string path, string searchPattern, EnumerationOptions enumerationOptions) { }

	[Address(RVA = "0x733CFB4", Offset = "0x733CFB4", Length = "0xAC")]
	[Token(Token = "0x6002AC6")]
	public static IEnumerable<String> EnumerateFileSystemEntries(string path) { }

	[Address(RVA = "0x733D060", Offset = "0x733D060", Length = "0xC")]
	[Token(Token = "0x6002AC7")]
	public static IEnumerable<String> EnumerateFileSystemEntries(string path, string searchPattern, EnumerationOptions enumerationOptions) { }

	[Address(RVA = "0x733C844", Offset = "0x733C844", Length = "0x174")]
	[Token(Token = "0x6002ABE")]
	public static bool Exists(string path) { }

	[Address(RVA = "0x733D120", Offset = "0x733D120", Length = "0x8")]
	[Token(Token = "0x6002AC9")]
	public static string GetCurrentDirectory() { }

	[Address(RVA = "0x733C9B8", Offset = "0x733C9B8", Length = "0xA8")]
	[Token(Token = "0x6002ABF")]
	public static String[] GetFiles(string path) { }

	[Address(RVA = "0x733CAC8", Offset = "0x733CAC8", Length = "0xA0")]
	[Token(Token = "0x6002AC0")]
	public static String[] GetFiles(string path, string searchPattern) { }

	[Address(RVA = "0x733CA60", Offset = "0x733CA60", Length = "0x68")]
	[Token(Token = "0x6002AC1")]
	public static String[] GetFiles(string path, string searchPattern, EnumerationOptions enumerationOptions) { }

	[Address(RVA = "0x733C4CC", Offset = "0x733C4CC", Length = "0x14C")]
	[Token(Token = "0x6002ABC")]
	public static DirectoryInfo GetParent(string path) { }

	[Address(RVA = "0x733D198", Offset = "0x733D198", Length = "0x9C")]
	[Token(Token = "0x6002ACB")]
	internal static string InsecureGetCurrentDirectory() { }

	[Address(RVA = "0x733CB68", Offset = "0x733CB68", Length = "0x1CC")]
	[Token(Token = "0x6002AC2")]
	internal static IEnumerable<String> InternalEnumeratePaths(string path, string searchPattern, SearchTarget searchTarget, EnumerationOptions options) { }

	[Address(RVA = "0x733D06C", Offset = "0x733D06C", Length = "0xB4")]
	[Token(Token = "0x6002AC8")]
	internal static string InternalGetDirectoryRoot(string path) { }

}

