namespace System.IO;

[Token(Token = "0x2000590")]
internal struct FileStatus
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001707")]
	private FileStatus _fileStatus; //Field offset: 0x0
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x4001708")]
	private int _fileStatusInitialized; //Field offset: 0x70
	[CompilerGenerated]
	[FieldOffset(Offset = "0x74")]
	[Token(Token = "0x4001709")]
	private bool <InitiallyDirectory>k__BackingField; //Field offset: 0x74
	[FieldOffset(Offset = "0x75")]
	[Token(Token = "0x400170A")]
	internal bool _isDirectory; //Field offset: 0x75
	[FieldOffset(Offset = "0x76")]
	[Token(Token = "0x400170B")]
	private bool _exists; //Field offset: 0x76

	[Token(Token = "0x1700064B")]
	internal bool InitiallyDirectory
	{
		[Address(RVA = "0x7362F48", Offset = "0x7362F48", Length = "0x8")]
		[CompilerGenerated]
		[IsReadOnly]
		[Token(Token = "0x6002B19")]
		internal get { } //Length: 8
		[Address(RVA = "0x7362F50", Offset = "0x7362F50", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6002B1A")]
		private set { } //Length: 8
	}

	[Address(RVA = "0x7363058", Offset = "0x7363058", Length = "0xBC")]
	[Token(Token = "0x6002B21")]
	internal void EnsureStatInitialized(ReadOnlySpan<Char> path, bool continueOnError = false) { }

	[Address(RVA = "0x7362F48", Offset = "0x7362F48", Length = "0x8")]
	[CompilerGenerated]
	[IsReadOnly]
	[Token(Token = "0x6002B19")]
	internal bool get_InitiallyDirectory() { }

	[Address(RVA = "0x7363114", Offset = "0x7363114", Length = "0xE8")]
	[Token(Token = "0x6002B1D")]
	public FileAttributes GetAttributes(ReadOnlySpan<Char> path, ReadOnlySpan<Char> fileName) { }

	[Address(RVA = "0x73631FC", Offset = "0x73631FC", Length = "0x44")]
	[Token(Token = "0x6002B1E")]
	internal bool GetExists(ReadOnlySpan<Char> path) { }

	[Address(RVA = "0x73633D0", Offset = "0x73633D0", Length = "0x18")]
	[Token(Token = "0x6002B1F")]
	internal long GetLength(ReadOnlySpan<Char> path, bool continueOnError = false) { }

	[Address(RVA = "0x7362F58", Offset = "0x7362F58", Length = "0x10")]
	[Token(Token = "0x6002B1B")]
	internal static void Initialize(ref FileStatus status, bool isDirectory) { }

	[Address(RVA = "0x7362F68", Offset = "0x7362F68", Length = "0xF0")]
	[Token(Token = "0x6002B1C")]
	internal bool IsReadOnly(ReadOnlySpan<Char> path, bool continueOnError = false) { }

	[Address(RVA = "0x7363240", Offset = "0x7363240", Length = "0x190")]
	[Token(Token = "0x6002B20")]
	public void Refresh(ReadOnlySpan<Char> path) { }

	[Address(RVA = "0x7362F50", Offset = "0x7362F50", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6002B1A")]
	private void set_InitiallyDirectory(bool value) { }

}

