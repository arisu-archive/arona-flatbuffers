namespace System.IO;

[Token(Token = "0x200058A")]
public class EnumerationOptions
{
	[CompilerGenerated]
	[Token(Token = "0x40016E6")]
	private static readonly EnumerationOptions <Compatible>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	[Token(Token = "0x40016E7")]
	private static readonly EnumerationOptions <CompatibleRecursive>k__BackingField; //Field offset: 0x8
	[CompilerGenerated]
	[Token(Token = "0x40016E8")]
	private static readonly EnumerationOptions <Default>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40016E9")]
	private bool <RecurseSubdirectories>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	[FieldOffset(Offset = "0x11")]
	[Token(Token = "0x40016EA")]
	private bool <IgnoreInaccessible>k__BackingField; //Field offset: 0x11
	[CompilerGenerated]
	[FieldOffset(Offset = "0x14")]
	[Token(Token = "0x40016EB")]
	private FileAttributes <AttributesToSkip>k__BackingField; //Field offset: 0x14
	[CompilerGenerated]
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40016EC")]
	private MatchType <MatchType>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x40016ED")]
	private MatchCasing <MatchCasing>k__BackingField; //Field offset: 0x1C
	[CompilerGenerated]
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40016EE")]
	private bool <ReturnSpecialDirectories>k__BackingField; //Field offset: 0x20

	[Token(Token = "0x17000643")]
	public FileAttributes AttributesToSkip
	{
		[Address(RVA = "0x733DE20", Offset = "0x733DE20", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6002AE6")]
		 get { } //Length: 8
		[Address(RVA = "0x733DE28", Offset = "0x733DE28", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6002AE7")]
		 set { } //Length: 8
	}

	[Token(Token = "0x1700063E")]
	internal static EnumerationOptions Compatible
	{
		[Address(RVA = "0x733DCD0", Offset = "0x733DCD0", Length = "0x58")]
		[CompilerGenerated]
		[Token(Token = "0x6002ADD")]
		internal get { } //Length: 88
	}

	[Token(Token = "0x1700063F")]
	private static EnumerationOptions CompatibleRecursive
	{
		[Address(RVA = "0x733DD28", Offset = "0x733DD28", Length = "0x58")]
		[CompilerGenerated]
		[Token(Token = "0x6002ADE")]
		private get { } //Length: 88
	}

	[Token(Token = "0x17000640")]
	internal static EnumerationOptions Default
	{
		[Address(RVA = "0x733DD80", Offset = "0x733DD80", Length = "0x58")]
		[CompilerGenerated]
		[Token(Token = "0x6002ADF")]
		internal get { } //Length: 88
	}

	[Token(Token = "0x17000642")]
	public bool IgnoreInaccessible
	{
		[Address(RVA = "0x733DE10", Offset = "0x733DE10", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6002AE4")]
		 get { } //Length: 8
		[Address(RVA = "0x733DE18", Offset = "0x733DE18", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6002AE5")]
		 set { } //Length: 8
	}

	[Token(Token = "0x17000645")]
	public MatchCasing MatchCasing
	{
		[Address(RVA = "0x733DE40", Offset = "0x733DE40", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6002AEA")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000644")]
	public MatchType MatchType
	{
		[Address(RVA = "0x733DE30", Offset = "0x733DE30", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6002AE8")]
		 get { } //Length: 8
		[Address(RVA = "0x733DE38", Offset = "0x733DE38", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6002AE9")]
		 set { } //Length: 8
	}

	[Token(Token = "0x17000641")]
	public bool RecurseSubdirectories
	{
		[Address(RVA = "0x733DE00", Offset = "0x733DE00", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6002AE2")]
		 get { } //Length: 8
		[Address(RVA = "0x733DE08", Offset = "0x733DE08", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6002AE3")]
		 set { } //Length: 8
	}

	[Token(Token = "0x17000646")]
	public bool ReturnSpecialDirectories
	{
		[Address(RVA = "0x733DE48", Offset = "0x733DE48", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6002AEB")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x733DE50", Offset = "0x733DE50", Length = "0xF8")]
	[Token(Token = "0x6002AEC")]
	private static EnumerationOptions() { }

	[Address(RVA = "0x733DDD8", Offset = "0x733DDD8", Length = "0x28")]
	[Token(Token = "0x6002AE0")]
	public EnumerationOptions() { }

	[Address(RVA = "0x733CE64", Offset = "0x733CE64", Length = "0x150")]
	[Token(Token = "0x6002AE1")]
	internal static EnumerationOptions FromSearchOption(SearchOption searchOption) { }

	[Address(RVA = "0x733DE20", Offset = "0x733DE20", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6002AE6")]
	public FileAttributes get_AttributesToSkip() { }

	[Address(RVA = "0x733DCD0", Offset = "0x733DCD0", Length = "0x58")]
	[CompilerGenerated]
	[Token(Token = "0x6002ADD")]
	internal static EnumerationOptions get_Compatible() { }

	[Address(RVA = "0x733DD28", Offset = "0x733DD28", Length = "0x58")]
	[CompilerGenerated]
	[Token(Token = "0x6002ADE")]
	private static EnumerationOptions get_CompatibleRecursive() { }

	[Address(RVA = "0x733DD80", Offset = "0x733DD80", Length = "0x58")]
	[CompilerGenerated]
	[Token(Token = "0x6002ADF")]
	internal static EnumerationOptions get_Default() { }

	[Address(RVA = "0x733DE10", Offset = "0x733DE10", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6002AE4")]
	public bool get_IgnoreInaccessible() { }

	[Address(RVA = "0x733DE40", Offset = "0x733DE40", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6002AEA")]
	public MatchCasing get_MatchCasing() { }

	[Address(RVA = "0x733DE30", Offset = "0x733DE30", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6002AE8")]
	public MatchType get_MatchType() { }

	[Address(RVA = "0x733DE00", Offset = "0x733DE00", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6002AE2")]
	public bool get_RecurseSubdirectories() { }

	[Address(RVA = "0x733DE48", Offset = "0x733DE48", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6002AEB")]
	public bool get_ReturnSpecialDirectories() { }

	[Address(RVA = "0x733DE28", Offset = "0x733DE28", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6002AE7")]
	public void set_AttributesToSkip(FileAttributes value) { }

	[Address(RVA = "0x733DE18", Offset = "0x733DE18", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6002AE5")]
	public void set_IgnoreInaccessible(bool value) { }

	[Address(RVA = "0x733DE38", Offset = "0x733DE38", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6002AE9")]
	public void set_MatchType(MatchType value) { }

	[Address(RVA = "0x733DE08", Offset = "0x733DE08", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6002AE3")]
	public void set_RecurseSubdirectories(bool value) { }

}

