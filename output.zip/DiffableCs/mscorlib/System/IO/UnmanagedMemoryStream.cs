namespace System.IO;

[Token(Token = "0x2000586")]
public class UnmanagedMemoryStream : Stream
{
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40016DD")]
	private SafeBuffer _buffer; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40016DE")]
	private Byte* _mem; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40016DF")]
	private long _length; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40016E0")]
	private long _capacity; //Field offset: 0x40
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40016E1")]
	private long _position; //Field offset: 0x48
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40016E2")]
	private long _offset; //Field offset: 0x50
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40016E3")]
	private FileAccess _access; //Field offset: 0x58
	[FieldOffset(Offset = "0x5C")]
	[Token(Token = "0x40016E4")]
	internal bool _isOpen; //Field offset: 0x5C
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x40016E5")]
	private Task<Int32> _lastReadTask; //Field offset: 0x60

	[Token(Token = "0x17000638")]
	public virtual bool CanRead
	{
		[Address(RVA = "0x733A850", Offset = "0x733A850", Length = "0x1C")]
		[Token(Token = "0x6002A9E")]
		 get { } //Length: 28
	}

	[Token(Token = "0x17000639")]
	public virtual bool CanSeek
	{
		[Address(RVA = "0x733A86C", Offset = "0x733A86C", Length = "0x8")]
		[Token(Token = "0x6002A9F")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700063A")]
	public virtual bool CanWrite
	{
		[Address(RVA = "0x733A874", Offset = "0x733A874", Length = "0x1C")]
		[Token(Token = "0x6002AA0")]
		 get { } //Length: 28
	}

	[Token(Token = "0x1700063B")]
	public virtual long Length
	{
		[Address(RVA = "0x733AAE0", Offset = "0x733AAE0", Length = "0x1C")]
		[Token(Token = "0x6002AA7")]
		 get { } //Length: 28
	}

	[Token(Token = "0x1700063C")]
	public virtual long Position
	{
		[Address(RVA = "0x733AAFC", Offset = "0x733AAFC", Length = "0x48")]
		[Token(Token = "0x6002AA8")]
		 get { } //Length: 72
		[Address(RVA = "0x733AB44", Offset = "0x733AB44", Length = "0xA8")]
		[Token(Token = "0x6002AA9")]
		 set { } //Length: 168
	}

	[CLSCompliant(False)]
	[Token(Token = "0x1700063D")]
	public Byte* PositionPointer
	{
		[Address(RVA = "0x733ABEC", Offset = "0x733ABEC", Length = "0xC0")]
		[Token(Token = "0x6002AAA")]
		 get { } //Length: 192
	}

	[Address(RVA = "0x732DB94", Offset = "0x732DB94", Length = "0x64")]
	[Token(Token = "0x6002A9A")]
	protected UnmanagedMemoryStream() { }

	[Address(RVA = "0x733A740", Offset = "0x733A740", Length = "0x80")]
	[CLSCompliant(False)]
	[Token(Token = "0x6002A9B")]
	public UnmanagedMemoryStream(Byte* pointer, long length) { }

	[Address(RVA = "0x733A7C0", Offset = "0x733A7C0", Length = "0x90")]
	[CLSCompliant(False)]
	[Token(Token = "0x6002A9C")]
	public UnmanagedMemoryStream(Byte* pointer, long length, long capacity, FileAccess access) { }

	[Address(RVA = "0x732E3F4", Offset = "0x732E3F4", Length = "0x10")]
	[Token(Token = "0x6002AA1")]
	protected virtual void Dispose(bool disposing) { }

	[Address(RVA = "0x733A890", Offset = "0x733A890", Length = "0x34")]
	[Token(Token = "0x6002AA2")]
	private void EnsureNotClosed() { }

	[Address(RVA = "0x733A8C4", Offset = "0x733A8C4", Length = "0x3C")]
	[Token(Token = "0x6002AA3")]
	private void EnsureReadable() { }

	[Address(RVA = "0x733A900", Offset = "0x733A900", Length = "0x3C")]
	[Token(Token = "0x6002AA4")]
	private void EnsureWriteable() { }

	[Address(RVA = "0x733A93C", Offset = "0x733A93C", Length = "0x4")]
	[Token(Token = "0x6002AA5")]
	public virtual void Flush() { }

	[Address(RVA = "0x733A940", Offset = "0x733A940", Length = "0x1A0")]
	[Token(Token = "0x6002AA6")]
	public virtual Task FlushAsync(CancellationToken cancellationToken) { }

	[Address(RVA = "0x733A850", Offset = "0x733A850", Length = "0x1C")]
	[Token(Token = "0x6002A9E")]
	public virtual bool get_CanRead() { }

	[Address(RVA = "0x733A86C", Offset = "0x733A86C", Length = "0x8")]
	[Token(Token = "0x6002A9F")]
	public virtual bool get_CanSeek() { }

	[Address(RVA = "0x733A874", Offset = "0x733A874", Length = "0x1C")]
	[Token(Token = "0x6002AA0")]
	public virtual bool get_CanWrite() { }

	[Address(RVA = "0x733AAE0", Offset = "0x733AAE0", Length = "0x1C")]
	[Token(Token = "0x6002AA7")]
	public virtual long get_Length() { }

	[Address(RVA = "0x733AAFC", Offset = "0x733AAFC", Length = "0x48")]
	[Token(Token = "0x6002AA8")]
	public virtual long get_Position() { }

	[Address(RVA = "0x733ABEC", Offset = "0x733ABEC", Length = "0xC0")]
	[Token(Token = "0x6002AAA")]
	public Byte* get_PositionPointer() { }

	[Address(RVA = "0x732DBF8", Offset = "0x732DBF8", Length = "0x204")]
	[CLSCompliant(False)]
	[Token(Token = "0x6002A9D")]
	protected void Initialize(Byte* pointer, long length, long capacity, FileAccess access) { }

	[Address(RVA = "0x733ACAC", Offset = "0x733ACAC", Length = "0x1C0")]
	[Token(Token = "0x6002AAB")]
	public virtual int Read(Byte[] buffer, int offset, int count) { }

	[Address(RVA = "0x733AE6C", Offset = "0x733AE6C", Length = "0xE0")]
	[Token(Token = "0x6002AAC")]
	public virtual int Read(Span<Byte> buffer) { }

	[Address(RVA = "0x733B298", Offset = "0x733B298", Length = "0x32C")]
	[Token(Token = "0x6002AAF")]
	public virtual ValueTask<Int32> ReadAsync(Memory<Byte> buffer, CancellationToken cancellationToken = null) { }

	[Address(RVA = "0x733AF4C", Offset = "0x733AF4C", Length = "0x34C")]
	[Token(Token = "0x6002AAE")]
	public virtual Task<Int32> ReadAsync(Byte[] buffer, int offset, int count, CancellationToken cancellationToken) { }

	[Address(RVA = "0x733B5C4", Offset = "0x733B5C4", Length = "0x158")]
	[Token(Token = "0x6002AB0")]
	public virtual int ReadByte() { }

	[Address(RVA = "0x732DE00", Offset = "0x732DE00", Length = "0x21C")]
	[Token(Token = "0x6002AAD")]
	internal int ReadCore(Span<Byte> buffer) { }

	[Address(RVA = "0x733B71C", Offset = "0x733B71C", Length = "0x110")]
	[Token(Token = "0x6002AB1")]
	public virtual long Seek(long offset, SeekOrigin loc) { }

	[Address(RVA = "0x733AB44", Offset = "0x733AB44", Length = "0xA8")]
	[Token(Token = "0x6002AA9")]
	public virtual void set_Position(long value) { }

	[Address(RVA = "0x733B82C", Offset = "0x733B82C", Length = "0x190")]
	[Token(Token = "0x6002AB2")]
	public virtual void SetLength(long value) { }

	[Address(RVA = "0x733B9BC", Offset = "0x733B9BC", Length = "0x1EC")]
	[Token(Token = "0x6002AB3")]
	public virtual void Write(Byte[] buffer, int offset, int count) { }

	[Address(RVA = "0x733BBA8", Offset = "0x733BBA8", Length = "0xE0")]
	[Token(Token = "0x6002AB4")]
	public virtual void Write(ReadOnlySpan<Byte> buffer) { }

	[Address(RVA = "0x733BC88", Offset = "0x733BC88", Length = "0x2EC")]
	[Token(Token = "0x6002AB6")]
	public virtual Task WriteAsync(Byte[] buffer, int offset, int count, CancellationToken cancellationToken) { }

	[Address(RVA = "0x733BF74", Offset = "0x733BF74", Length = "0x2BC")]
	[Token(Token = "0x6002AB7")]
	public virtual ValueTask WriteAsync(ReadOnlyMemory<Byte> buffer, CancellationToken cancellationToken = null) { }

	[Address(RVA = "0x733C230", Offset = "0x733C230", Length = "0x214")]
	[Token(Token = "0x6002AB8")]
	public virtual void WriteByte(byte value) { }

	[Address(RVA = "0x732E020", Offset = "0x732E020", Length = "0x2F4")]
	[Token(Token = "0x6002AB5")]
	internal void WriteCore(ReadOnlySpan<Byte> buffer) { }

}

