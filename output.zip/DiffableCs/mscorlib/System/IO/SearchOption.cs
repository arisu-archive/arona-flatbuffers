namespace System.IO;

[Token(Token = "0x2000595")]
public enum SearchOption
{
	TopDirectoryOnly = 0,
	AllDirectories = 1,
}

