namespace System.IO;

[Token(Token = "0x2000566")]
public class DirectoryNotFoundException : IOException
{

	[Address(RVA = "0x7329AFC", Offset = "0x7329AFC", Length = "0x5C")]
	[Token(Token = "0x6002971")]
	public DirectoryNotFoundException() { }

	[Address(RVA = "0x7329B7C", Offset = "0x7329B7C", Length = "0x24")]
	[Token(Token = "0x6002972")]
	public DirectoryNotFoundException(string message) { }

	[Address(RVA = "0x7329BA0", Offset = "0x7329BA0", Length = "0x8")]
	[Token(Token = "0x6002973")]
	protected DirectoryNotFoundException(SerializationInfo info, StreamingContext context) { }

}

