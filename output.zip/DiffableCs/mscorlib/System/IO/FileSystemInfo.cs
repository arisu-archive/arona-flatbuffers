namespace System.IO;

[Token(Token = "0x2000592")]
public abstract class FileSystemInfo : MarshalByRefObject, ISerializable
{
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400170C")]
	private FileStatus _fileStatus; //Field offset: 0x18
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x400170D")]
	protected string FullPath; //Field offset: 0x90
	[FieldOffset(Offset = "0x98")]
	[Token(Token = "0x400170E")]
	protected string OriginalPath; //Field offset: 0x98
	[FieldOffset(Offset = "0xA0")]
	[Token(Token = "0x400170F")]
	internal string _name; //Field offset: 0xA0

	[Token(Token = "0x1700064C")]
	public FileAttributes Attributes
	{
		[Address(RVA = "0x73625A0", Offset = "0x73625A0", Length = "0xCC")]
		[Token(Token = "0x6002B31")]
		 get { } //Length: 204
	}

	[Token(Token = "0x17000653")]
	public override bool Exists
	{
		[Address(RVA = "0x7365058", Offset = "0x7365058", Length = "0x88")]
		[Token(Token = "0x6002B3B")]
		 get { } //Length: 136
	}

	[Token(Token = "0x1700064D")]
	internal bool ExistsCore
	{
		[Address(RVA = "0x7364CE0", Offset = "0x7364CE0", Length = "0x98")]
		[Token(Token = "0x6002B32")]
		internal get { } //Length: 152
	}

	[Token(Token = "0x17000651")]
	public string Extension
	{
		[Address(RVA = "0x7364F20", Offset = "0x7364F20", Length = "0x130")]
		[Token(Token = "0x6002B39")]
		 get { } //Length: 304
	}

	[Token(Token = "0x17000650")]
	public override string FullName
	{
		[Address(RVA = "0x7364F18", Offset = "0x7364F18", Length = "0x8")]
		[Token(Token = "0x6002B38")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700064E")]
	internal long LengthCore
	{
		[Address(RVA = "0x736266C", Offset = "0x736266C", Length = "0x74")]
		[Token(Token = "0x6002B33")]
		internal get { } //Length: 116
	}

	[Token(Token = "0x17000652")]
	public override string Name
	{
		[Address(RVA = "0x7365050", Offset = "0x7365050", Length = "0x8")]
		[Token(Token = "0x6002B3A")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700064F")]
	internal string NormalizedPath
	{
		[Address(RVA = "0x7364D78", Offset = "0x7364D78", Length = "0x8")]
		[Token(Token = "0x6002B35")]
		internal get { } //Length: 8
	}

	[Address(RVA = "0x73621D4", Offset = "0x73621D4", Length = "0x74")]
	[Token(Token = "0x6002B2E")]
	protected FileSystemInfo() { }

	[Address(RVA = "0x7362DE0", Offset = "0x7362DE0", Length = "0x160")]
	[Token(Token = "0x6002B36")]
	protected FileSystemInfo(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x7364B94", Offset = "0x7364B94", Length = "0xD0")]
	[Token(Token = "0x6002B2F")]
	internal static FileSystemInfo Create(string fullPath, string fileName, ref FileStatus fileStatus) { }

	[Token(Token = "0x6002B3C")]
	public abstract void Delete() { }

	[Address(RVA = "0x73625A0", Offset = "0x73625A0", Length = "0xCC")]
	[Token(Token = "0x6002B31")]
	public FileAttributes get_Attributes() { }

	[Address(RVA = "0x7365058", Offset = "0x7365058", Length = "0x88")]
	[Token(Token = "0x6002B3B")]
	public override bool get_Exists() { }

	[Address(RVA = "0x7364CE0", Offset = "0x7364CE0", Length = "0x98")]
	[Token(Token = "0x6002B32")]
	internal bool get_ExistsCore() { }

	[Address(RVA = "0x7364F20", Offset = "0x7364F20", Length = "0x130")]
	[Token(Token = "0x6002B39")]
	public string get_Extension() { }

	[Address(RVA = "0x7364F18", Offset = "0x7364F18", Length = "0x8")]
	[Token(Token = "0x6002B38")]
	public override string get_FullName() { }

	[Address(RVA = "0x736266C", Offset = "0x736266C", Length = "0x74")]
	[Token(Token = "0x6002B33")]
	internal long get_LengthCore() { }

	[Address(RVA = "0x7365050", Offset = "0x7365050", Length = "0x8")]
	[Token(Token = "0x6002B3A")]
	public override string get_Name() { }

	[Address(RVA = "0x7364D78", Offset = "0x7364D78", Length = "0x8")]
	[Token(Token = "0x6002B35")]
	internal string get_NormalizedPath() { }

	[Address(RVA = "0x7364DD4", Offset = "0x7364DD4", Length = "0x144")]
	[ComVisible(False)]
	[Token(Token = "0x6002B37")]
	public override void GetObjectData(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x7364C64", Offset = "0x7364C64", Length = "0x7C")]
	[Token(Token = "0x6002B30")]
	internal void Init(ref FileStatus fileStatus) { }

	[Address(RVA = "0x7364AF8", Offset = "0x7364AF8", Length = "0x9C")]
	[Token(Token = "0x6002B34")]
	internal static void ThrowNotFound(string path) { }

	[Address(RVA = "0x73650E0", Offset = "0x73650E0", Length = "0x54")]
	[Token(Token = "0x6002B3D")]
	public virtual string ToString() { }

}

