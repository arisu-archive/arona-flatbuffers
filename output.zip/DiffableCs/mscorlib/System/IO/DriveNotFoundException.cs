namespace System.IO;

[Token(Token = "0x2000587")]
public class DriveNotFoundException : IOException
{

	[Address(RVA = "0x733C444", Offset = "0x733C444", Length = "0x5C")]
	[Token(Token = "0x6002AB9")]
	public DriveNotFoundException() { }

	[Address(RVA = "0x733C4A0", Offset = "0x733C4A0", Length = "0x24")]
	[Token(Token = "0x6002ABA")]
	public DriveNotFoundException(string message) { }

	[Address(RVA = "0x733C4C4", Offset = "0x733C4C4", Length = "0x8")]
	[Token(Token = "0x6002ABB")]
	protected DriveNotFoundException(SerializationInfo info, StreamingContext context) { }

}

