namespace System.IO;

[Token(Token = "0x2000582")]
public abstract class TextWriter : MarshalByRefObject, IDisposable
{
	[CompilerGenerated]
	[Token(Token = "0x2000585")]
	private sealed class <>c
	{
		[Token(Token = "0x40016D5")]
		public static readonly <>c <>9; //Field offset: 0x0
		[Token(Token = "0x40016D6")]
		public static Action<Object> <>9__56_0; //Field offset: 0x8
		[Token(Token = "0x40016D7")]
		public static Action<Object> <>9__57_0; //Field offset: 0x10
		[Token(Token = "0x40016D8")]
		public static Action<Object> <>9__59_0; //Field offset: 0x18
		[Token(Token = "0x40016D9")]
		public static Action<Object> <>9__61_0; //Field offset: 0x20
		[Token(Token = "0x40016DA")]
		public static Action<Object> <>9__62_0; //Field offset: 0x28
		[Token(Token = "0x40016DB")]
		public static Action<Object> <>9__64_0; //Field offset: 0x30
		[Token(Token = "0x40016DC")]
		public static Action<Object> <>9__67_0; //Field offset: 0x38

		[Address(RVA = "0x733A204", Offset = "0x733A204", Length = "0x70")]
		[Token(Token = "0x6002A91")]
		private static <>c() { }

		[Address(RVA = "0x733A274", Offset = "0x733A274", Length = "0x8")]
		[Token(Token = "0x6002A92")]
		public <>c() { }

		[Address(RVA = "0x733A6BC", Offset = "0x733A6BC", Length = "0x84")]
		[Token(Token = "0x6002A99")]
		internal void <FlushAsync>b__67_0(object state) { }

		[Address(RVA = "0x733A27C", Offset = "0x733A27C", Length = "0xAC")]
		[Token(Token = "0x6002A93")]
		internal void <WriteAsync>b__56_0(object state) { }

		[Address(RVA = "0x733A328", Offset = "0x733A328", Length = "0xAC")]
		[Token(Token = "0x6002A94")]
		internal void <WriteAsync>b__57_0(object state) { }

		[Address(RVA = "0x733A3D4", Offset = "0x733A3D4", Length = "0xC8")]
		[Token(Token = "0x6002A95")]
		internal void <WriteAsync>b__59_0(object state) { }

		[Address(RVA = "0x733A49C", Offset = "0x733A49C", Length = "0xAC")]
		[Token(Token = "0x6002A96")]
		internal void <WriteLineAsync>b__61_0(object state) { }

		[Address(RVA = "0x733A548", Offset = "0x733A548", Length = "0xAC")]
		[Token(Token = "0x6002A97")]
		internal void <WriteLineAsync>b__62_0(object state) { }

		[Address(RVA = "0x733A5F4", Offset = "0x733A5F4", Length = "0xC8")]
		[Token(Token = "0x6002A98")]
		internal void <WriteLineAsync>b__64_0(object state) { }

	}

	[Token(Token = "0x2000583")]
	private sealed class NullTextWriter : TextWriter
	{

		[Token(Token = "0x17000634")]
		public virtual Encoding Encoding
		{
			[Address(RVA = "0x7339A14", Offset = "0x7339A14", Length = "0x8")]
			[Token(Token = "0x6002A71")]
			 get { } //Length: 8
		}

		[Address(RVA = "0x7339988", Offset = "0x7339988", Length = "0x8C")]
		[Token(Token = "0x6002A70")]
		internal NullTextWriter() { }

		[Address(RVA = "0x7339A14", Offset = "0x7339A14", Length = "0x8")]
		[Token(Token = "0x6002A71")]
		public virtual Encoding get_Encoding() { }

		[Address(RVA = "0x7339A1C", Offset = "0x7339A1C", Length = "0x4")]
		[Token(Token = "0x6002A72")]
		public virtual void Write(Char[] buffer, int index, int count) { }

		[Address(RVA = "0x7339A20", Offset = "0x7339A20", Length = "0x4")]
		[Token(Token = "0x6002A73")]
		public virtual void Write(string value) { }

		[Address(RVA = "0x7339A30", Offset = "0x7339A30", Length = "0x4")]
		[Token(Token = "0x6002A77")]
		public virtual void Write(char value) { }

		[Address(RVA = "0x7339A24", Offset = "0x7339A24", Length = "0x4")]
		[Token(Token = "0x6002A74")]
		public virtual void WriteLine() { }

		[Address(RVA = "0x7339A28", Offset = "0x7339A28", Length = "0x4")]
		[Token(Token = "0x6002A75")]
		public virtual void WriteLine(string value) { }

		[Address(RVA = "0x7339A2C", Offset = "0x7339A2C", Length = "0x4")]
		[Token(Token = "0x6002A76")]
		public virtual void WriteLine(object value) { }

	}

	[Token(Token = "0x2000584")]
	public sealed class SyncTextWriter : TextWriter, IDisposable
	{
		[FieldOffset(Offset = "0x30")]
		[Token(Token = "0x40016D4")]
		private readonly TextWriter _out; //Field offset: 0x30

		[Token(Token = "0x17000635")]
		public virtual Encoding Encoding
		{
			[Address(RVA = "0x7339A34", Offset = "0x7339A34", Length = "0x20")]
			[Token(Token = "0x6002A79")]
			 get { } //Length: 32
		}

		[Token(Token = "0x17000636")]
		public virtual IFormatProvider FormatProvider
		{
			[Address(RVA = "0x7339A54", Offset = "0x7339A54", Length = "0x20")]
			[Token(Token = "0x6002A7A")]
			 get { } //Length: 32
		}

		[Token(Token = "0x17000637")]
		public virtual string NewLine
		{
			[Address(RVA = "0x7339A74", Offset = "0x7339A74", Length = "0x20")]
			[Token(Token = "0x6002A7B")]
			 get { } //Length: 32
		}

		[Address(RVA = "0x733985C", Offset = "0x733985C", Length = "0x84")]
		[Token(Token = "0x6002A78")]
		internal SyncTextWriter(TextWriter t) { }

		[Address(RVA = "0x7339A94", Offset = "0x7339A94", Length = "0x20")]
		[Token(Token = "0x6002A7C")]
		public virtual void Close() { }

		[Address(RVA = "0x7339AB4", Offset = "0x7339AB4", Length = "0xB4")]
		[Token(Token = "0x6002A7D")]
		protected virtual void Dispose(bool disposing) { }

		[Address(RVA = "0x7339B68", Offset = "0x7339B68", Length = "0x20")]
		[Token(Token = "0x6002A7E")]
		public virtual void Flush() { }

		[Address(RVA = "0x733A168", Offset = "0x733A168", Length = "0x9C")]
		[Token(Token = "0x6002A90")]
		public virtual Task FlushAsync() { }

		[Address(RVA = "0x7339A34", Offset = "0x7339A34", Length = "0x20")]
		[Token(Token = "0x6002A79")]
		public virtual Encoding get_Encoding() { }

		[Address(RVA = "0x7339A54", Offset = "0x7339A54", Length = "0x20")]
		[Token(Token = "0x6002A7A")]
		public virtual IFormatProvider get_FormatProvider() { }

		[Address(RVA = "0x7339A74", Offset = "0x7339A74", Length = "0x20")]
		[Token(Token = "0x6002A7B")]
		public virtual string get_NewLine() { }

		[Address(RVA = "0x7339C1C", Offset = "0x7339C1C", Length = "0x24")]
		[Token(Token = "0x6002A83")]
		public virtual void Write(decimal value) { }

		[Address(RVA = "0x7339BF4", Offset = "0x7339BF4", Length = "0x28")]
		[Token(Token = "0x6002A82")]
		public virtual void Write(bool value) { }

		[Address(RVA = "0x7339C40", Offset = "0x7339C40", Length = "0x24")]
		[Token(Token = "0x6002A84")]
		public virtual void Write(string value) { }

		[Address(RVA = "0x7339BAC", Offset = "0x7339BAC", Length = "0x24")]
		[Token(Token = "0x6002A80")]
		public virtual void Write(Char[] buffer) { }

		[Address(RVA = "0x7339B88", Offset = "0x7339B88", Length = "0x24")]
		[Token(Token = "0x6002A7F")]
		public virtual void Write(char value) { }

		[Address(RVA = "0x7339BD0", Offset = "0x7339BD0", Length = "0x24")]
		[Token(Token = "0x6002A81")]
		public virtual void Write(Char[] buffer, int index, int count) { }

		[Address(RVA = "0x7339D18", Offset = "0x7339D18", Length = "0xB0")]
		[Token(Token = "0x6002A8A")]
		public virtual Task WriteAsync(char value) { }

		[Address(RVA = "0x7339DC8", Offset = "0x7339DC8", Length = "0xB0")]
		[Token(Token = "0x6002A8B")]
		public virtual Task WriteAsync(string value) { }

		[Address(RVA = "0x7339E78", Offset = "0x7339E78", Length = "0xC8")]
		[Token(Token = "0x6002A8C")]
		public virtual Task WriteAsync(Char[] buffer, int index, int count) { }

		[Address(RVA = "0x7339C64", Offset = "0x7339C64", Length = "0x24")]
		[Token(Token = "0x6002A85")]
		public virtual void WriteLine() { }

		[Address(RVA = "0x7339CAC", Offset = "0x7339CAC", Length = "0x24")]
		[Token(Token = "0x6002A87")]
		public virtual void WriteLine(Char[] buffer, int index, int count) { }

		[Address(RVA = "0x7339CD0", Offset = "0x7339CD0", Length = "0x24")]
		[Token(Token = "0x6002A88")]
		public virtual void WriteLine(string value) { }

		[Address(RVA = "0x7339CF4", Offset = "0x7339CF4", Length = "0x24")]
		[Token(Token = "0x6002A89")]
		public virtual void WriteLine(object value) { }

		[Address(RVA = "0x7339C88", Offset = "0x7339C88", Length = "0x24")]
		[Token(Token = "0x6002A86")]
		public virtual void WriteLine(char value) { }

		[Address(RVA = "0x733A0A0", Offset = "0x733A0A0", Length = "0xC8")]
		[Token(Token = "0x6002A8F")]
		public virtual Task WriteLineAsync(Char[] buffer, int index, int count) { }

		[Address(RVA = "0x7339F40", Offset = "0x7339F40", Length = "0xB0")]
		[Token(Token = "0x6002A8D")]
		public virtual Task WriteLineAsync(char value) { }

		[Address(RVA = "0x7339FF0", Offset = "0x7339FF0", Length = "0xB0")]
		[Token(Token = "0x6002A8E")]
		public virtual Task WriteLineAsync(string value) { }

	}

	[Token(Token = "0x40016CF")]
	public static readonly TextWriter Null; //Field offset: 0x0
	[Token(Token = "0x40016D0")]
	private static readonly Char[] s_coreNewLine; //Field offset: 0x8
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40016D1")]
	protected Char[] CoreNewLine; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40016D2")]
	private string CoreNewLineStr; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40016D3")]
	private IFormatProvider _internalFormatProvider; //Field offset: 0x28

	[Token(Token = "0x17000632")]
	public abstract Encoding Encoding
	{
		[Token(Token = "0x6002A58")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000631")]
	public override IFormatProvider FormatProvider
	{
		[Address(RVA = "0x7339084", Offset = "0x7339084", Length = "0x68")]
		[Token(Token = "0x6002A53")]
		 get { } //Length: 104
	}

	[Token(Token = "0x17000633")]
	public override string NewLine
	{
		[Address(RVA = "0x73391CC", Offset = "0x73391CC", Length = "0x8")]
		[Token(Token = "0x6002A59")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x73398E0", Offset = "0x73398E0", Length = "0xA8")]
	[Token(Token = "0x6002A6F")]
	private static TextWriter() { }

	[Address(RVA = "0x7332BD0", Offset = "0x7332BD0", Length = "0x98")]
	[Token(Token = "0x6002A51")]
	protected TextWriter() { }

	[Address(RVA = "0x73323D4", Offset = "0x73323D4", Length = "0xA4")]
	[Token(Token = "0x6002A52")]
	protected TextWriter(IFormatProvider formatProvider) { }

	[Address(RVA = "0x73390EC", Offset = "0x73390EC", Length = "0x6C")]
	[Token(Token = "0x6002A54")]
	public override void Close() { }

	[Address(RVA = "0x7339158", Offset = "0x7339158", Length = "0x4")]
	[Token(Token = "0x6002A55")]
	protected override void Dispose(bool disposing) { }

	[Address(RVA = "0x733915C", Offset = "0x733915C", Length = "0x6C")]
	[Token(Token = "0x6002A56")]
	public override void Dispose() { }

	[Address(RVA = "0x73391C8", Offset = "0x73391C8", Length = "0x4")]
	[Token(Token = "0x6002A57")]
	public override void Flush() { }

	[Address(RVA = "0x7336120", Offset = "0x7336120", Length = "0x1FC")]
	[Token(Token = "0x6002A6D")]
	public override Task FlushAsync() { }

	[Token(Token = "0x6002A58")]
	public abstract Encoding get_Encoding() { }

	[Address(RVA = "0x7339084", Offset = "0x7339084", Length = "0x68")]
	[Token(Token = "0x6002A53")]
	public override IFormatProvider get_FormatProvider() { }

	[Address(RVA = "0x73391CC", Offset = "0x73391CC", Length = "0x8")]
	[Token(Token = "0x6002A59")]
	public override string get_NewLine() { }

	[Address(RVA = "0x733979C", Offset = "0x733979C", Length = "0xC0")]
	[Token(Token = "0x6002A6E")]
	public static TextWriter Synchronized(TextWriter writer) { }

	[Address(RVA = "0x73394D8", Offset = "0x73394D8", Length = "0x38")]
	[Token(Token = "0x6002A5F")]
	public override void Write(string value) { }

	[Address(RVA = "0x73391F8", Offset = "0x73391F8", Length = "0x1A0")]
	[Token(Token = "0x6002A5C")]
	public override void Write(Char[] buffer, int index, int count) { }

	[Address(RVA = "0x7339398", Offset = "0x7339398", Length = "0x7C")]
	[Token(Token = "0x6002A5D")]
	public override void Write(bool value) { }

	[Address(RVA = "0x73391D8", Offset = "0x73391D8", Length = "0x20")]
	[Token(Token = "0x6002A5B")]
	public override void Write(Char[] buffer) { }

	[Address(RVA = "0x73391D4", Offset = "0x73391D4", Length = "0x4")]
	[Token(Token = "0x6002A5A")]
	public override void Write(char value) { }

	[Address(RVA = "0x7339414", Offset = "0x7339414", Length = "0xC4")]
	[Token(Token = "0x6002A5E")]
	public override void Write(decimal value) { }

	[Address(RVA = "0x7334004", Offset = "0x7334004", Length = "0x248")]
	[Token(Token = "0x6002A65")]
	public override Task WriteAsync(char value) { }

	[Address(RVA = "0x7334C88", Offset = "0x7334C88", Length = "0x258")]
	[Token(Token = "0x6002A68")]
	public override Task WriteAsync(Char[] buffer, int index, int count) { }

	[Address(RVA = "0x73396E0", Offset = "0x73396E0", Length = "0xBC")]
	[Token(Token = "0x6002A67")]
	public Task WriteAsync(Char[] buffer) { }

	[Address(RVA = "0x73345BC", Offset = "0x73345BC", Length = "0x248")]
	[Token(Token = "0x6002A66")]
	public override Task WriteAsync(string value) { }

	[Address(RVA = "0x7339524", Offset = "0x7339524", Length = "0x30")]
	[Token(Token = "0x6002A61")]
	public override void WriteLine(char value) { }

	[Address(RVA = "0x7339584", Offset = "0x7339584", Length = "0x3C")]
	[Token(Token = "0x6002A63")]
	public override void WriteLine(string value) { }

	[Address(RVA = "0x7339554", Offset = "0x7339554", Length = "0x30")]
	[Token(Token = "0x6002A62")]
	public override void WriteLine(Char[] buffer, int index, int count) { }

	[Address(RVA = "0x73395C0", Offset = "0x73395C0", Length = "0x120")]
	[Token(Token = "0x6002A64")]
	public override void WriteLine(object value) { }

	[Address(RVA = "0x7339510", Offset = "0x7339510", Length = "0x14")]
	[Token(Token = "0x6002A60")]
	public override void WriteLine() { }

	[Address(RVA = "0x7335400", Offset = "0x7335400", Length = "0x248")]
	[Token(Token = "0x6002A69")]
	public override Task WriteLineAsync(char value) { }

	[Address(RVA = "0x733581C", Offset = "0x733581C", Length = "0x248")]
	[Token(Token = "0x6002A6A")]
	public override Task WriteLineAsync(string value) { }

	[Address(RVA = "0x7335D80", Offset = "0x7335D80", Length = "0x258")]
	[Token(Token = "0x6002A6B")]
	public override Task WriteLineAsync(Char[] buffer, int index, int count) { }

	[Address(RVA = "0x7335250", Offset = "0x7335250", Length = "0x8")]
	[Token(Token = "0x6002A6C")]
	public override Task WriteLineAsync() { }

}

