namespace System.IO;

[Token(Token = "0x2000573")]
internal sealed class PinnedBufferMemoryStream : UnmanagedMemoryStream
{
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x400165F")]
	private Byte[] _array; //Field offset: 0x68
	[FieldOffset(Offset = "0x70")]
	[Token(Token = "0x4001660")]
	private GCHandle _pinningHandle; //Field offset: 0x70

	[Address(RVA = "0x732DAD0", Offset = "0x732DAD0", Length = "0xC4")]
	[Token(Token = "0x60029CB")]
	internal PinnedBufferMemoryStream(Byte[] array) { }

	[Address(RVA = "0x732E3A4", Offset = "0x732E3A4", Length = "0x50")]
	[Token(Token = "0x60029CF")]
	protected virtual void Dispose(bool disposing) { }

	[Address(RVA = "0x732E314", Offset = "0x732E314", Length = "0x90")]
	[Token(Token = "0x60029CE")]
	protected virtual void Finalize() { }

	[Address(RVA = "0x732DDFC", Offset = "0x732DDFC", Length = "0x4")]
	[Token(Token = "0x60029CC")]
	public virtual int Read(Span<Byte> buffer) { }

	[Address(RVA = "0x732E01C", Offset = "0x732E01C", Length = "0x4")]
	[Token(Token = "0x60029CD")]
	public virtual void Write(ReadOnlySpan<Byte> buffer) { }

}

