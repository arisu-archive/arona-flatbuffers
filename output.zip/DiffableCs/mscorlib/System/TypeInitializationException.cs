namespace System;

[Token(Token = "0x200012B")]
public sealed class TypeInitializationException : SystemException
{
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x400043C")]
	private string _typeName; //Field offset: 0x90

	[Token(Token = "0x1700012D")]
	public string TypeName
	{
		[Address(RVA = "0x741A4EC", Offset = "0x741A4EC", Length = "0x54")]
		[Token(Token = "0x6000BE6")]
		 get { } //Length: 84
	}

	[Address(RVA = "0x741A230", Offset = "0x741A230", Length = "0x58")]
	[Token(Token = "0x6000BE1")]
	private TypeInitializationException() { }

	[Address(RVA = "0x741A288", Offset = "0x741A288", Length = "0x8C")]
	[Token(Token = "0x6000BE2")]
	public TypeInitializationException(string fullTypeName, Exception innerException) { }

	[Address(RVA = "0x741A314", Offset = "0x741A314", Length = "0x44")]
	[Token(Token = "0x6000BE3")]
	internal TypeInitializationException(string fullTypeName, string message, Exception innerException) { }

	[Address(RVA = "0x741A358", Offset = "0x741A358", Length = "0x8C")]
	[Token(Token = "0x6000BE4")]
	internal TypeInitializationException(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x741A4EC", Offset = "0x741A4EC", Length = "0x54")]
	[Token(Token = "0x6000BE6")]
	public string get_TypeName() { }

	[Address(RVA = "0x741A3E4", Offset = "0x741A3E4", Length = "0x108")]
	[Token(Token = "0x6000BE5")]
	public virtual void GetObjectData(SerializationInfo info, StreamingContext context) { }

}

