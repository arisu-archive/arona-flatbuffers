namespace System;

[Token(Token = "0x200017A")]
internal sealed class SharedStatics
{
	[Token(Token = "0x40005C5")]
	private static readonly SharedStatics _sharedStatics; //Field offset: 0x0
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40005C6")]
	private StringMaker _maker; //Field offset: 0x10

	[Address(RVA = "0x7442580", Offset = "0x7442580", Length = "0x64")]
	[Token(Token = "0x6000FBB")]
	private static SharedStatics() { }

	[Address(RVA = "0x7442280", Offset = "0x7442280", Length = "0x4")]
	[Token(Token = "0x6000FB8")]
	private SharedStatics() { }

	[Address(RVA = "0x7442288", Offset = "0x7442288", Length = "0x1C0")]
	[Token(Token = "0x6000FB9")]
	public static StringMaker GetSharedStringMaker() { }

	[Address(RVA = "0x7442448", Offset = "0x7442448", Length = "0x138")]
	[Token(Token = "0x6000FBA")]
	public static void ReleaseSharedStringMaker(ref StringMaker maker) { }

}

