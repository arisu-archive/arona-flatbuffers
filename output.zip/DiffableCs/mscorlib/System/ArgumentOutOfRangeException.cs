namespace System;

[Token(Token = "0x200008E")]
public class ArgumentOutOfRangeException : ArgumentException
{
	[FieldOffset(Offset = "0x98")]
	[Token(Token = "0x40001E4")]
	private object _actualValue; //Field offset: 0x98

	[Token(Token = "0x17000059")]
	public virtual string Message
	{
		[Address(RVA = "0x735133C", Offset = "0x735133C", Length = "0xA8")]
		[Token(Token = "0x6000404")]
		 get { } //Length: 168
	}

	[Address(RVA = "0x735108C", Offset = "0x735108C", Length = "0x5C")]
	[Token(Token = "0x60003FD")]
	public ArgumentOutOfRangeException() { }

	[Address(RVA = "0x73510E8", Offset = "0x73510E8", Length = "0x78")]
	[Token(Token = "0x60003FE")]
	public ArgumentOutOfRangeException(string paramName) { }

	[Address(RVA = "0x734B1E8", Offset = "0x734B1E8", Length = "0x44")]
	[Token(Token = "0x60003FF")]
	public ArgumentOutOfRangeException(string paramName, string message) { }

	[Address(RVA = "0x7351160", Offset = "0x7351160", Length = "0x24")]
	[Token(Token = "0x6000400")]
	public ArgumentOutOfRangeException(string message, Exception innerException) { }

	[Address(RVA = "0x734C4AC", Offset = "0x734C4AC", Length = "0x64")]
	[Token(Token = "0x6000401")]
	public ArgumentOutOfRangeException(string paramName, object actualValue, string message) { }

	[Address(RVA = "0x7351184", Offset = "0x7351184", Length = "0xE0")]
	[Token(Token = "0x6000402")]
	protected ArgumentOutOfRangeException(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x735133C", Offset = "0x735133C", Length = "0xA8")]
	[Token(Token = "0x6000404")]
	public virtual string get_Message() { }

	[Address(RVA = "0x7351264", Offset = "0x7351264", Length = "0xD8")]
	[Token(Token = "0x6000403")]
	public virtual void GetObjectData(SerializationInfo info, StreamingContext context) { }

}

