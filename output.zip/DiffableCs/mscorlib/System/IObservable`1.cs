namespace System;

[Token(Token = "0x20000D6")]
public interface IObservable
{

	[Token(Token = "0x60007DA")]
	public IDisposable Subscribe(IObserver<T> observer) { }

}

