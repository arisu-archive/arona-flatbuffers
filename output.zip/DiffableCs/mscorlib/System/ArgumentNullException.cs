namespace System;

[Token(Token = "0x200008D")]
public class ArgumentNullException : ArgumentException
{

	[Address(RVA = "0x7350FE8", Offset = "0x7350FE8", Length = "0x5C")]
	[Token(Token = "0x60003F9")]
	public ArgumentNullException() { }

	[Address(RVA = "0x7347130", Offset = "0x7347130", Length = "0x78")]
	[Token(Token = "0x60003FA")]
	public ArgumentNullException(string paramName) { }

	[Address(RVA = "0x7351044", Offset = "0x7351044", Length = "0x44")]
	[Token(Token = "0x60003FB")]
	public ArgumentNullException(string paramName, string message) { }

	[Address(RVA = "0x7351088", Offset = "0x7351088", Length = "0x4")]
	[Token(Token = "0x60003FC")]
	protected ArgumentNullException(SerializationInfo info, StreamingContext context) { }

}

