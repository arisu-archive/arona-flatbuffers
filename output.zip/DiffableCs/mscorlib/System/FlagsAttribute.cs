namespace System;

[AttributeUsage(AttributeTargets::Enum (16), Inherited = False)]
[Token(Token = "0x20000B1")]
public class FlagsAttribute : Attribute
{

	[Address(RVA = "0x73E3184", Offset = "0x73E3184", Length = "0x8")]
	[Token(Token = "0x60006D3")]
	public FlagsAttribute() { }

}

