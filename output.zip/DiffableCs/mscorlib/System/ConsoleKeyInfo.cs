namespace System;

[IsReadOnly]
[Token(Token = "0x2000145")]
public struct ConsoleKeyInfo
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000518")]
	private readonly char _keyChar; //Field offset: 0x0
	[FieldOffset(Offset = "0x4")]
	[Token(Token = "0x4000519")]
	private readonly ConsoleKey _key; //Field offset: 0x4
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x400051A")]
	private readonly ConsoleModifiers _mods; //Field offset: 0x8

	[Token(Token = "0x1700014C")]
	public ConsoleKey Key
	{
		[Address(RVA = "0x741EE18", Offset = "0x741EE18", Length = "0x8")]
		[Token(Token = "0x6000D01")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700014B")]
	public char KeyChar
	{
		[Address(RVA = "0x741EE10", Offset = "0x741EE10", Length = "0x8")]
		[Token(Token = "0x6000D00")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x741ED70", Offset = "0x741ED70", Length = "0xA0")]
	[Token(Token = "0x6000CFF")]
	public ConsoleKeyInfo(char keyChar, ConsoleKey key, bool shift, bool alt, bool control) { }

	[Address(RVA = "0x741EE20", Offset = "0x741EE20", Length = "0x98")]
	[Token(Token = "0x6000D02")]
	public virtual bool Equals(object value) { }

	[Address(RVA = "0x741EEB8", Offset = "0x741EEB8", Length = "0x34")]
	[Token(Token = "0x6000D03")]
	public bool Equals(ConsoleKeyInfo obj) { }

	[Address(RVA = "0x741EE18", Offset = "0x741EE18", Length = "0x8")]
	[Token(Token = "0x6000D01")]
	public ConsoleKey get_Key() { }

	[Address(RVA = "0x741EE10", Offset = "0x741EE10", Length = "0x8")]
	[Token(Token = "0x6000D00")]
	public char get_KeyChar() { }

	[Address(RVA = "0x741EEEC", Offset = "0x741EEEC", Length = "0x14")]
	[Token(Token = "0x6000D04")]
	public virtual int GetHashCode() { }

}

