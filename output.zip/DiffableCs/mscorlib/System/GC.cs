namespace System;

[Token(Token = "0x2000173")]
public static class GC
{
	[Token(Token = "0x4000596")]
	internal static readonly object EPHEMERON_TOMBSTONE; //Field offset: 0x0

	[Token(Token = "0x1700016E")]
	public static int MaxGeneration
	{
		[Address(RVA = "0x7438358", Offset = "0x7438358", Length = "0x4C")]
		[Token(Token = "0x6000F15")]
		 get { } //Length: 76
	}

	[Address(RVA = "0x7438514", Offset = "0x7438514", Length = "0x4")]
	[Token(Token = "0x6000F19")]
	private static void _ReRegisterForFinalize(object o) { }

	[Address(RVA = "0x743846C", Offset = "0x743846C", Length = "0x4")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6000F17")]
	private static void _SuppressFinalize(object o) { }

	[Address(RVA = "0x74385C0", Offset = "0x74385C0", Length = "0x58")]
	[Token(Token = "0x6000F1C")]
	private static GC() { }

	[Address(RVA = "0x7438308", Offset = "0x7438308", Length = "0x50")]
	[Token(Token = "0x6000F12")]
	public static void Collect() { }

	[Address(RVA = "0x74383A4", Offset = "0x74383A4", Length = "0xC0")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6000F13")]
	public static int CollectionCount(int generation) { }

	[Address(RVA = "0x743826C", Offset = "0x743826C", Length = "0x4")]
	[Token(Token = "0x6000F10")]
	private static object get_ephemeron_tombstone() { }

	[Address(RVA = "0x7438358", Offset = "0x7438358", Length = "0x4C")]
	[Token(Token = "0x6000F15")]
	public static int get_MaxGeneration() { }

	[Address(RVA = "0x743825C", Offset = "0x743825C", Length = "0x4")]
	[Token(Token = "0x6000F0C")]
	private static int GetCollectionCount(int generation) { }

	[Address(RVA = "0x7438260", Offset = "0x7438260", Length = "0x4")]
	[Token(Token = "0x6000F0D")]
	private static int GetMaxGeneration() { }

	[Address(RVA = "0x7438270", Offset = "0x7438270", Length = "0x98")]
	[Token(Token = "0x6000F11")]
	internal static void GetMemoryInfo(out uint highMemLoadThreshold, out ulong totalPhysicalMem, out uint lastRecordedMemLoad, out UIntPtr lastRecordedHeapSize, out UIntPtr lastRecordedFragmentation) { }

	[Address(RVA = "0x74385BC", Offset = "0x74385BC", Length = "0x4")]
	[Token(Token = "0x6000F1B")]
	public static long GetTotalMemory(bool forceFullCollection) { }

	[Address(RVA = "0x7438264", Offset = "0x7438264", Length = "0x4")]
	[Token(Token = "0x6000F0E")]
	private static void InternalCollect(int generation) { }

	[Address(RVA = "0x7438464", Offset = "0x7438464", Length = "0x4")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6000F14")]
	public static void KeepAlive(object obj) { }

	[Address(RVA = "0x7438268", Offset = "0x7438268", Length = "0x4")]
	[Token(Token = "0x6000F0F")]
	internal static void register_ephemeron_array(Ephemeron[] array) { }

	[Address(RVA = "0x7438518", Offset = "0x7438518", Length = "0xA4")]
	[Token(Token = "0x6000F1A")]
	public static void ReRegisterForFinalize(object obj) { }

	[Address(RVA = "0x7438470", Offset = "0x7438470", Length = "0xA4")]
	[ReliabilityContract(Consistency::WillNotCorruptState (3), Cer::Success (2))]
	[Token(Token = "0x6000F18")]
	public static void SuppressFinalize(object obj) { }

	[Address(RVA = "0x7438468", Offset = "0x7438468", Length = "0x4")]
	[Token(Token = "0x6000F16")]
	public static void WaitForPendingFinalizers() { }

}

