namespace System.Reflection;

[Token(Token = "0x200051E")]
public abstract class PropertyInfo : MemberInfo
{

	[Token(Token = "0x1700052B")]
	public abstract bool CanRead
	{
		[Token(Token = "0x600260A")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700052C")]
	public abstract bool CanWrite
	{
		[Token(Token = "0x600260B")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700052D")]
	public override MethodInfo GetMethod
	{
		[Address(RVA = "0x73151FC", Offset = "0x73151FC", Length = "0x14")]
		[Token(Token = "0x600260C")]
		 get { } //Length: 20
	}

	[Token(Token = "0x17000529")]
	public virtual MemberTypes MemberType
	{
		[Address(RVA = "0x73151F4", Offset = "0x73151F4", Length = "0x8")]
		[Token(Token = "0x6002607")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700052A")]
	public abstract Type PropertyType
	{
		[Token(Token = "0x6002608")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700052E")]
	public override MethodInfo SetMethod
	{
		[Address(RVA = "0x7315224", Offset = "0x7315224", Length = "0x14")]
		[Token(Token = "0x600260F")]
		 get { } //Length: 20
	}

	[Address(RVA = "0x73151EC", Offset = "0x73151EC", Length = "0x8")]
	[Token(Token = "0x6002606")]
	protected PropertyInfo() { }

	[Address(RVA = "0x73152B4", Offset = "0x73152B4", Length = "0x8")]
	[Token(Token = "0x6002618")]
	public virtual bool Equals(object obj) { }

	[Token(Token = "0x600260A")]
	public abstract bool get_CanRead() { }

	[Token(Token = "0x600260B")]
	public abstract bool get_CanWrite() { }

	[Address(RVA = "0x73151FC", Offset = "0x73151FC", Length = "0x14")]
	[Token(Token = "0x600260C")]
	public override MethodInfo get_GetMethod() { }

	[Address(RVA = "0x73151F4", Offset = "0x73151F4", Length = "0x8")]
	[Token(Token = "0x6002607")]
	public virtual MemberTypes get_MemberType() { }

	[Token(Token = "0x6002608")]
	public abstract Type get_PropertyType() { }

	[Address(RVA = "0x7315224", Offset = "0x7315224", Length = "0x14")]
	[Token(Token = "0x600260F")]
	public override MethodInfo get_SetMethod() { }

	[Address(RVA = "0x7315210", Offset = "0x7315210", Length = "0x14")]
	[Token(Token = "0x600260D")]
	public override MethodInfo GetGetMethod() { }

	[Token(Token = "0x600260E")]
	public abstract MethodInfo GetGetMethod(bool nonPublic) { }

	[Address(RVA = "0x73152BC", Offset = "0x73152BC", Length = "0x8")]
	[Token(Token = "0x6002619")]
	public virtual int GetHashCode() { }

	[Token(Token = "0x6002609")]
	public abstract ParameterInfo[] GetIndexParameters() { }

	[Address(RVA = "0x7315238", Offset = "0x7315238", Length = "0x14")]
	[Token(Token = "0x6002610")]
	public override MethodInfo GetSetMethod() { }

	[Token(Token = "0x6002611")]
	public abstract MethodInfo GetSetMethod(bool nonPublic) { }

	[Address(RVA = "0x7315260", Offset = "0x7315260", Length = "0x20")]
	[DebuggerHidden]
	[DebuggerStepThrough]
	[Token(Token = "0x6002613")]
	public override object GetValue(object obj, Object[] index) { }

	[Token(Token = "0x6002614")]
	public abstract object GetValue(object obj, BindingFlags invokeAttr, Binder binder, Object[] index, CultureInfo culture) { }

	[Address(RVA = "0x731524C", Offset = "0x731524C", Length = "0x14")]
	[DebuggerHidden]
	[DebuggerStepThrough]
	[Token(Token = "0x6002612")]
	public object GetValue(object obj) { }

	[Address(RVA = "0x73134A0", Offset = "0x73134A0", Length = "0x2C")]
	[Token(Token = "0x600261A")]
	public static bool op_Equality(PropertyInfo left, PropertyInfo right) { }

	[Address(RVA = "0x7313464", Offset = "0x7313464", Length = "0x3C")]
	[Token(Token = "0x600261B")]
	public static bool op_Inequality(PropertyInfo left, PropertyInfo right) { }

	[Address(RVA = "0x7315280", Offset = "0x7315280", Length = "0x14")]
	[DebuggerHidden]
	[DebuggerStepThrough]
	[Token(Token = "0x6002615")]
	public void SetValue(object obj, object value) { }

	[Address(RVA = "0x7315294", Offset = "0x7315294", Length = "0x20")]
	[DebuggerHidden]
	[DebuggerStepThrough]
	[Token(Token = "0x6002616")]
	public override void SetValue(object obj, object value, Object[] index) { }

	[Token(Token = "0x6002617")]
	public abstract void SetValue(object obj, object value, BindingFlags invokeAttr, Binder binder, Object[] index, CultureInfo culture) { }

}

