namespace System.Reflection;

[ComVisible(True)]
[Token(Token = "0x200053C")]
public class ExceptionHandlingClause
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x400159A")]
	internal Type catch_type; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400159B")]
	internal int filter_offset; //Field offset: 0x18
	[FieldOffset(Offset = "0x1C")]
	[Token(Token = "0x400159C")]
	internal ExceptionHandlingClauseOptions flags; //Field offset: 0x1C
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400159D")]
	internal int try_offset; //Field offset: 0x20
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x400159E")]
	internal int try_length; //Field offset: 0x24
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400159F")]
	internal int handler_offset; //Field offset: 0x28
	[FieldOffset(Offset = "0x2C")]
	[Token(Token = "0x40015A0")]
	internal int handler_length; //Field offset: 0x2C

	[Address(RVA = "0x731EA90", Offset = "0x731EA90", Length = "0x8")]
	[Token(Token = "0x6002795")]
	protected ExceptionHandlingClause() { }

	[Address(RVA = "0x731EA98", Offset = "0x731EA98", Length = "0x300")]
	[Token(Token = "0x6002796")]
	public virtual string ToString() { }

}

