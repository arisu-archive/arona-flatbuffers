namespace System.Reflection;

[ComVisible(True)]
[Token(Token = "0x200053A")]
public class CustomAttributeData
{
	[Token(Token = "0x200053B")]
	private class LazyCAttrData
	{
		[FieldOffset(Offset = "0x10")]
		[Token(Token = "0x4001597")]
		internal Assembly assembly; //Field offset: 0x10
		[FieldOffset(Offset = "0x18")]
		[Token(Token = "0x4001598")]
		internal IntPtr data; //Field offset: 0x18
		[FieldOffset(Offset = "0x20")]
		[Token(Token = "0x4001599")]
		internal uint data_length; //Field offset: 0x20

		[Address(RVA = "0x731D7D0", Offset = "0x731D7D0", Length = "0x8")]
		[Token(Token = "0x6002794")]
		public LazyCAttrData() { }

	}

	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001593")]
	private ConstructorInfo ctorInfo; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001594")]
	private IList<CustomAttributeTypedArgument> ctorArgs; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4001595")]
	private IList<CustomAttributeNamedArgument> namedArgs; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4001596")]
	private LazyCAttrData lazyData; //Field offset: 0x28

	[Token(Token = "0x1700059A")]
	public Type AttributeType
	{
		[Address(RVA = "0x731DBA8", Offset = "0x731DBA8", Length = "0x24")]
		[Token(Token = "0x600278F")]
		 get { } //Length: 36
	}

	[ComVisible(True)]
	[Token(Token = "0x17000597")]
	public override ConstructorInfo Constructor
	{
		[Address(RVA = "0x731D9A4", Offset = "0x731D9A4", Length = "0x8")]
		[Token(Token = "0x6002787")]
		 get { } //Length: 8
	}

	[ComVisible(True)]
	[Token(Token = "0x17000598")]
	public override IList<CustomAttributeTypedArgument> ConstructorArguments
	{
		[Address(RVA = "0x731D9AC", Offset = "0x731D9AC", Length = "0x18")]
		[Token(Token = "0x6002788")]
		 get { } //Length: 24
	}

	[Token(Token = "0x17000599")]
	public override IList<CustomAttributeNamedArgument> NamedArguments
	{
		[Address(RVA = "0x731D9C4", Offset = "0x731D9C4", Length = "0x18")]
		[Token(Token = "0x6002789")]
		 get { } //Length: 24
	}

	[Address(RVA = "0x731D6FC", Offset = "0x731D6FC", Length = "0x8")]
	[Token(Token = "0x6002781")]
	protected CustomAttributeData() { }

	[Address(RVA = "0x731D704", Offset = "0x731D704", Length = "0xCC")]
	[Token(Token = "0x6002782")]
	internal CustomAttributeData(ConstructorInfo ctorInfo, Assembly assembly, IntPtr data, uint data_length) { }

	[Address(RVA = "0x7312528", Offset = "0x7312528", Length = "0xF4")]
	[Token(Token = "0x6002783")]
	internal CustomAttributeData(ConstructorInfo ctorInfo) { }

	[Address(RVA = "0x7312904", Offset = "0x7312904", Length = "0x60")]
	[Token(Token = "0x6002784")]
	internal CustomAttributeData(ConstructorInfo ctorInfo, IList<CustomAttributeTypedArgument> ctorArgs, IList<CustomAttributeNamedArgument> namedArgs) { }

	[Address(RVA = "0x731E13C", Offset = "0x731E13C", Length = "0x66C")]
	[Token(Token = "0x6002792")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x731DBA8", Offset = "0x731DBA8", Length = "0x24")]
	[Token(Token = "0x600278F")]
	public Type get_AttributeType() { }

	[Address(RVA = "0x731D9A4", Offset = "0x731D9A4", Length = "0x8")]
	[Token(Token = "0x6002787")]
	public override ConstructorInfo get_Constructor() { }

	[Address(RVA = "0x731D9AC", Offset = "0x731D9AC", Length = "0x18")]
	[Token(Token = "0x6002788")]
	public override IList<CustomAttributeTypedArgument> get_ConstructorArguments() { }

	[Address(RVA = "0x731D9C4", Offset = "0x731D9C4", Length = "0x18")]
	[Token(Token = "0x6002789")]
	public override IList<CustomAttributeNamedArgument> get_NamedArguments() { }

	[Address(RVA = "0x731DB4C", Offset = "0x731DB4C", Length = "0x5C")]
	[Token(Token = "0x600278E")]
	public static IList<CustomAttributeData> GetCustomAttributes(ParameterInfo target) { }

	[Address(RVA = "0x731DAF0", Offset = "0x731DAF0", Length = "0x5C")]
	[Token(Token = "0x600278D")]
	public static IList<CustomAttributeData> GetCustomAttributes(Module target) { }

	[Address(RVA = "0x731D9DC", Offset = "0x731D9DC", Length = "0x5C")]
	[Token(Token = "0x600278A")]
	public static IList<CustomAttributeData> GetCustomAttributes(Assembly target) { }

	[Address(RVA = "0x731DA38", Offset = "0x731DA38", Length = "0x5C")]
	[Token(Token = "0x600278B")]
	public static IList<CustomAttributeData> GetCustomAttributes(MemberInfo target) { }

	[Address(RVA = "0x731DA94", Offset = "0x731DA94", Length = "0x5C")]
	[Token(Token = "0x600278C")]
	internal static IList<CustomAttributeData> GetCustomAttributesInternal(RuntimeType target) { }

	[Address(RVA = "0x731E7A8", Offset = "0x731E7A8", Length = "0x2E8")]
	[Token(Token = "0x6002793")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x731D7DC", Offset = "0x731D7DC", Length = "0x1C8")]
	[Token(Token = "0x6002786")]
	private void ResolveArguments() { }

	[Address(RVA = "0x731D7D8", Offset = "0x731D7D8", Length = "0x4")]
	[Token(Token = "0x6002785")]
	private static void ResolveArgumentsInternal(ConstructorInfo ctor, Assembly assembly, IntPtr data, uint data_length, out Object[] ctorArgs, out Object[] namedArgs) { }

	[Address(RVA = "0x731DBCC", Offset = "0x731DBCC", Length = "0x570")]
	[Token(Token = "0x6002790")]
	public virtual string ToString() { }

	[Address(RVA = "0x419AEE4", Offset = "0x419AEE4", Length = "0x100")]
	[Token(Token = "0x6002791")]
	private static T[] UnboxValues(Object[] values) { }

}

