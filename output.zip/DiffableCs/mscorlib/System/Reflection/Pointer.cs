namespace System.Reflection;

[CLSCompliant(False)]
[Token(Token = "0x200051B")]
public sealed class Pointer : ISerializable
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40014D6")]
	private readonly Void* _ptr; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40014D7")]
	private readonly Type _ptrType; //Field offset: 0x18

	[Address(RVA = "0x7314FDC", Offset = "0x7314FDC", Length = "0x38")]
	[Token(Token = "0x6002603")]
	private Pointer(Void* ptr, Type ptrType) { }

	[Address(RVA = "0x7315014", Offset = "0x7315014", Length = "0x198")]
	[Token(Token = "0x6002604")]
	public static object Box(Void* ptr, Type type) { }

	[Address(RVA = "0x73151AC", Offset = "0x73151AC", Length = "0x40")]
	[Token(Token = "0x6002605")]
	private override void System.Runtime.Serialization.ISerializable.GetObjectData(SerializationInfo info, StreamingContext context) { }

}

