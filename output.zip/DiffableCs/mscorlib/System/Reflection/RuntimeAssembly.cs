namespace System.Reflection;

[ClassInterface(ClassInterfaceType::None (0))]
[ComDefaultInterface(typeof(_Assembly))]
[ComVisible(True)]
[Token(Token = "0x200053E")]
internal class RuntimeAssembly : Assembly
{
	[Token(Token = "0x200053F")]
	public class UnmanagedMemoryStreamForModule : UnmanagedMemoryStream
	{
		[FieldOffset(Offset = "0x68")]
		[Token(Token = "0x40015AE")]
		private Module module; //Field offset: 0x68

		[Address(RVA = "0x731F930", Offset = "0x731F930", Length = "0x30")]
		[Token(Token = "0x60027B9")]
		public UnmanagedMemoryStreamForModule(Byte* pointer, long length, Module module) { }

		[Address(RVA = "0x731FB9C", Offset = "0x731FB9C", Length = "0x40")]
		[Token(Token = "0x60027BA")]
		protected virtual void Dispose(bool disposing) { }

	}

	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40015A4")]
	internal IntPtr _mono_assembly; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40015A5")]
	private object _evidence; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40015A6")]
	internal ResolveEventHolder resolve_event_holder; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40015A7")]
	private object _minimum; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40015A8")]
	private object _optional; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40015A9")]
	private object _refuse; //Field offset: 0x38
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40015AA")]
	private object _granted; //Field offset: 0x40
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x40015AB")]
	private object _denied; //Field offset: 0x48
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40015AC")]
	internal bool fromByteArray; //Field offset: 0x50
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40015AD")]
	internal string assemblyName; //Field offset: 0x58

	[Token(Token = "0x1700059C")]
	public virtual string CodeBase
	{
		[Address(RVA = "0x731F410", Offset = "0x731F410", Length = "0x8")]
		[Token(Token = "0x60027A8")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700059D")]
	public virtual string EscapedCodeBase
	{
		[Address(RVA = "0x731F418", Offset = "0x731F418", Length = "0x8")]
		[Token(Token = "0x60027A9")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700059E")]
	public virtual string FullName
	{
		[Address(RVA = "0x731F420", Offset = "0x731F420", Length = "0x4")]
		[Token(Token = "0x60027AA")]
		 get { } //Length: 4
	}

	[Token(Token = "0x170005A0")]
	public virtual string Location
	{
		[Address(RVA = "0x731F42C", Offset = "0x731F42C", Length = "0x64")]
		[Token(Token = "0x60027AC")]
		 get { } //Length: 100
	}

	[Token(Token = "0x1700059F")]
	internal virtual IntPtr MonoAssembly
	{
		[Address(RVA = "0x731F424", Offset = "0x731F424", Length = "0x8")]
		[Token(Token = "0x60027AB")]
		internal get { } //Length: 8
	}

	[ComVisible(False)]
	[Token(Token = "0x1700059B")]
	public virtual bool ReflectionOnly
	{
		[Address(RVA = "0x731F408", Offset = "0x731F408", Length = "0x4")]
		[Token(Token = "0x60027A6")]
		 get { } //Length: 4
	}

	[Address(RVA = "0x731EE58", Offset = "0x731EE58", Length = "0x74")]
	[Token(Token = "0x6002799")]
	protected RuntimeAssembly() { }

	[Address(RVA = "0x731FAB4", Offset = "0x731FAB4", Length = "0xA0")]
	[Token(Token = "0x60027B7")]
	public virtual bool Equals(object o) { }

	[Address(RVA = "0x731F3FC", Offset = "0x731F3FC", Length = "0x4")]
	[Token(Token = "0x60027A2")]
	private static string get_code_base(Assembly a, bool escaped) { }

	[Address(RVA = "0x731F410", Offset = "0x731F410", Length = "0x8")]
	[Token(Token = "0x60027A8")]
	public virtual string get_CodeBase() { }

	[Address(RVA = "0x731F418", Offset = "0x731F418", Length = "0x8")]
	[Token(Token = "0x60027A9")]
	public virtual string get_EscapedCodeBase() { }

	[Address(RVA = "0x731F404", Offset = "0x731F404", Length = "0x4")]
	[Token(Token = "0x60027A4")]
	internal static string get_fullname(Assembly a) { }

	[Address(RVA = "0x731F420", Offset = "0x731F420", Length = "0x4")]
	[Token(Token = "0x60027AA")]
	public virtual string get_FullName() { }

	[Address(RVA = "0x731F400", Offset = "0x731F400", Length = "0x4")]
	[Token(Token = "0x60027A3")]
	private string get_location() { }

	[Address(RVA = "0x731F42C", Offset = "0x731F42C", Length = "0x64")]
	[Token(Token = "0x60027AC")]
	public virtual string get_Location() { }

	[Address(RVA = "0x731F424", Offset = "0x731F424", Length = "0x8")]
	[Token(Token = "0x60027AB")]
	internal virtual IntPtr get_MonoAssembly() { }

	[Address(RVA = "0x731F408", Offset = "0x731F408", Length = "0x4")]
	[Token(Token = "0x60027A6")]
	public virtual bool get_ReflectionOnly() { }

	[Address(RVA = "0x731F3A0", Offset = "0x731F3A0", Length = "0x58")]
	[Token(Token = "0x60027A1")]
	internal static Byte[] GetAotId() { }

	[Address(RVA = "0x731F3F8", Offset = "0x731F3F8", Length = "0x4")]
	[Token(Token = "0x60027A5")]
	internal static bool GetAotIdInternal(Byte[] aotid) { }

	[Address(RVA = "0x731F40C", Offset = "0x731F40C", Length = "0x4")]
	[Token(Token = "0x60027A7")]
	internal static string GetCodeBase(Assembly a, bool escaped) { }

	[Address(RVA = "0x731FA38", Offset = "0x731FA38", Length = "0x70")]
	[Token(Token = "0x60027B4")]
	public virtual Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x731F9D0", Offset = "0x731F9D0", Length = "0x68")]
	[Token(Token = "0x60027B3")]
	public virtual Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x731FAAC", Offset = "0x731FAAC", Length = "0x8")]
	[Token(Token = "0x60027B6")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x731F494", Offset = "0x731F494", Length = "0x110")]
	[Token(Token = "0x60027AE")]
	public virtual ManifestResourceInfo GetManifestResourceInfo(string resourceName) { }

	[Address(RVA = "0x731F490", Offset = "0x731F490", Length = "0x4")]
	[Token(Token = "0x60027AD")]
	private bool GetManifestResourceInfoInternal(string name, ManifestResourceInfo info) { }

	[Address(RVA = "0x731F5A8", Offset = "0x731F5A8", Length = "0x4")]
	[Token(Token = "0x60027B0")]
	internal IntPtr GetManifestResourceInternal(string name, out int size, out Module module) { }

	[Address(RVA = "0x731F5A4", Offset = "0x731F5A4", Length = "0x4")]
	[Token(Token = "0x60027AF")]
	public virtual String[] GetManifestResourceNames() { }

	[Address(RVA = "0x731F5AC", Offset = "0x731F5AC", Length = "0x384")]
	[Token(Token = "0x60027B1")]
	public virtual Stream GetManifestResourceStream(string name) { }

	[Address(RVA = "0x731F0D4", Offset = "0x731F0D4", Length = "0x130")]
	[Token(Token = "0x600279F")]
	public virtual Module GetModule(string name) { }

	[Address(RVA = "0x731F204", Offset = "0x731F204", Length = "0x19C")]
	[Token(Token = "0x60027A0")]
	public virtual Module[] GetModules(bool getResourceModules) { }

	[Address(RVA = "0x731FAA8", Offset = "0x731FAA8", Length = "0x4")]
	[Token(Token = "0x60027B5")]
	internal virtual Module[] GetModulesInternal() { }

	[Address(RVA = "0x731F008", Offset = "0x731F008", Length = "0x8")]
	[Token(Token = "0x600279D")]
	public virtual AssemblyName GetName(bool copiedName) { }

	[Address(RVA = "0x731EECC", Offset = "0x731EECC", Length = "0x8C")]
	[Token(Token = "0x600279A")]
	public virtual void GetObjectData(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x731F010", Offset = "0x731F010", Length = "0xC4")]
	[Token(Token = "0x600279E")]
	public virtual Type GetType(string name, bool throwOnError, bool ignoreCase) { }

	[Address(RVA = "0x731F960", Offset = "0x731F960", Length = "0x70")]
	[Token(Token = "0x60027B2")]
	public virtual bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x731EFE0", Offset = "0x731EFE0", Length = "0x28")]
	[Token(Token = "0x600279C")]
	internal static RuntimeAssembly LoadWithPartialNameInternal(AssemblyName an, Evidence securityEvidence, ref StackCrawlMark stackMark) { }

	[Address(RVA = "0x731EF58", Offset = "0x731EF58", Length = "0x88")]
	[Token(Token = "0x600279B")]
	internal static RuntimeAssembly LoadWithPartialNameInternal(string partialName, Evidence securityEvidence, ref StackCrawlMark stackMark) { }

	[Address(RVA = "0x731FB54", Offset = "0x731FB54", Length = "0x48")]
	[Token(Token = "0x60027B8")]
	public virtual string ToString() { }

}

