namespace System.Reflection;

[ComVisible(True)]
[Token(Token = "0x200054F")]
public class StrongNameKeyPair : ISerializable, IDeserializationCallback
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40015E3")]
	private Byte[] _publicKey; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40015E4")]
	private string _keyPairContainer; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40015E5")]
	private bool _keyPairExported; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40015E6")]
	private Byte[] _keyPairArray; //Field offset: 0x28

	[Address(RVA = "0x7326FEC", Offset = "0x7326FEC", Length = "0x230")]
	[Token(Token = "0x60028A1")]
	protected StrongNameKeyPair(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x7327364", Offset = "0x7327364", Length = "0x4")]
	[Token(Token = "0x60028A3")]
	private override void System.Runtime.Serialization.IDeserializationCallback.OnDeserialization(object sender) { }

	[Address(RVA = "0x732721C", Offset = "0x732721C", Length = "0x148")]
	[Token(Token = "0x60028A2")]
	private override void System.Runtime.Serialization.ISerializable.GetObjectData(SerializationInfo info, StreamingContext context) { }

}

