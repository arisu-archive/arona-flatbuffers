namespace System.Reflection;

[AttributeUsage(AttributeTargets::Assembly (1), Inherited = False)]
[Token(Token = "0x20004FB")]
public sealed class AssemblyTitleAttribute : Attribute
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x400143D")]
	private readonly string <Title>k__BackingField; //Field offset: 0x10

	[Address(RVA = "0x7310D94", Offset = "0x7310D94", Length = "0x30")]
	[Token(Token = "0x600253B")]
	public AssemblyTitleAttribute(string title) { }

}

