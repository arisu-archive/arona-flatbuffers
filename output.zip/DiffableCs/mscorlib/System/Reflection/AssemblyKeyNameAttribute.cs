namespace System.Reflection;

[AttributeUsage(AttributeTargets::Assembly (1), Inherited = False)]
[Token(Token = "0x20004F7")]
public sealed class AssemblyKeyNameAttribute : Attribute
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001433")]
	private readonly string <KeyName>k__BackingField; //Field offset: 0x10

	[Address(RVA = "0x7310CF0", Offset = "0x7310CF0", Length = "0x30")]
	[Token(Token = "0x6002538")]
	public AssemblyKeyNameAttribute(string keyName) { }

}

