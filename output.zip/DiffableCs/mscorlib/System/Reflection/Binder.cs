namespace System.Reflection;

[Token(Token = "0x20004FD")]
public abstract class Binder
{

	[Address(RVA = "0x7310DF4", Offset = "0x7310DF4", Length = "0x8")]
	[Token(Token = "0x600253D")]
	protected Binder() { }

	[Token(Token = "0x600253E")]
	public abstract FieldInfo BindToField(BindingFlags bindingAttr, FieldInfo[] match, object value, CultureInfo culture) { }

	[Token(Token = "0x600253F")]
	public abstract MethodBase BindToMethod(BindingFlags bindingAttr, MethodBase[] match, ref Object[] args, ParameterModifier[] modifiers, CultureInfo culture, String[] names, out object state) { }

	[Token(Token = "0x6002540")]
	public abstract object ChangeType(object value, Type type, CultureInfo culture) { }

	[Token(Token = "0x6002541")]
	public abstract void ReorderArgumentArray(ref Object[] args, object state) { }

	[Token(Token = "0x6002542")]
	public abstract MethodBase SelectMethod(BindingFlags bindingAttr, MethodBase[] match, Type[] types, ParameterModifier[] modifiers) { }

	[Token(Token = "0x6002543")]
	public abstract PropertyInfo SelectProperty(BindingFlags bindingAttr, PropertyInfo[] match, Type returnType, Type[] indexes, ParameterModifier[] modifiers) { }

}

