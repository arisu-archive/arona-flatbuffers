namespace System.Reflection;

[Token(Token = "0x2000545")]
internal class RuntimeMethodInfo : MethodInfo, ISerializable
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40015C3")]
	internal IntPtr mhandle; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40015C4")]
	private string name; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40015C5")]
	private Type reftype; //Field offset: 0x20

	[Token(Token = "0x170005B9")]
	public virtual MethodAttributes Attributes
	{
		[Address(RVA = "0x7322024", Offset = "0x7322024", Length = "0x8")]
		[Token(Token = "0x6002824")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005B2")]
	internal BindingFlags BindingFlags
	{
		[Address(RVA = "0x7321240", Offset = "0x7321240", Length = "0x8")]
		[Token(Token = "0x6002805")]
		internal get { } //Length: 8
	}

	[Token(Token = "0x170005BA")]
	public virtual CallingConventions CallingConvention
	{
		[Address(RVA = "0x732202C", Offset = "0x732202C", Length = "0x2C")]
		[Token(Token = "0x6002825")]
		 get { } //Length: 44
	}

	[Token(Token = "0x170005C0")]
	public virtual bool ContainsGenericParameters
	{
		[Address(RVA = "0x7323018", Offset = "0x7323018", Length = "0xD8")]
		[Token(Token = "0x6002837")]
		 get { } //Length: 216
	}

	[Token(Token = "0x170005BC")]
	public virtual Type DeclaringType
	{
		[Address(RVA = "0x7322060", Offset = "0x7322060", Length = "0x2C")]
		[Token(Token = "0x6002827")]
		 get { } //Length: 44
	}

	[Token(Token = "0x170005BF")]
	public virtual bool IsGenericMethod
	{
		[Address(RVA = "0x7323014", Offset = "0x7323014", Length = "0x4")]
		[Token(Token = "0x6002836")]
		 get { } //Length: 4
	}

	[Token(Token = "0x170005BE")]
	public virtual bool IsGenericMethodDefinition
	{
		[Address(RVA = "0x7323010", Offset = "0x7323010", Length = "0x4")]
		[Token(Token = "0x6002835")]
		 get { } //Length: 4
	}

	[Token(Token = "0x170005C1")]
	public virtual bool IsSecurityCritical
	{
		[Address(RVA = "0x73230FC", Offset = "0x73230FC", Length = "0x8")]
		[Token(Token = "0x600283A")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005B7")]
	public virtual int MetadataToken
	{
		[Address(RVA = "0x732194C", Offset = "0x732194C", Length = "0x4")]
		[Token(Token = "0x600281B")]
		 get { } //Length: 4
	}

	[Token(Token = "0x170005B8")]
	public virtual RuntimeMethodHandle MethodHandle
	{
		[Address(RVA = "0x732201C", Offset = "0x732201C", Length = "0x8")]
		[Token(Token = "0x6002823")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005B3")]
	public virtual Module Module
	{
		[Address(RVA = "0x7321248", Offset = "0x7321248", Length = "0x4")]
		[Token(Token = "0x6002806")]
		 get { } //Length: 4
	}

	[Token(Token = "0x170005BD")]
	public virtual string Name
	{
		[Address(RVA = "0x732208C", Offset = "0x732208C", Length = "0x14")]
		[Token(Token = "0x6002828")]
		 get { } //Length: 20
	}

	[Token(Token = "0x170005BB")]
	public virtual Type ReflectedType
	{
		[Address(RVA = "0x7322058", Offset = "0x7322058", Length = "0x8")]
		[Token(Token = "0x6002826")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005B4")]
	private RuntimeType ReflectedTypeInternal
	{
		[Address(RVA = "0x73212DC", Offset = "0x73212DC", Length = "0x88")]
		[Token(Token = "0x6002807")]
		private get { } //Length: 136
	}

	[Token(Token = "0x170005B5")]
	public virtual ParameterInfo ReturnParameter
	{
		[Address(RVA = "0x732191C", Offset = "0x732191C", Length = "0x4")]
		[Token(Token = "0x6002819")]
		 get { } //Length: 4
	}

	[Token(Token = "0x170005B6")]
	public virtual Type ReturnType
	{
		[Address(RVA = "0x7321920", Offset = "0x7321920", Length = "0x2C")]
		[Token(Token = "0x600281A")]
		 get { } //Length: 44
	}

	[Address(RVA = "0x73218F8", Offset = "0x73218F8", Length = "0x8")]
	[Token(Token = "0x6002813")]
	internal RuntimeMethodInfo() { }

	[Address(RVA = "0x7321D38", Offset = "0x7321D38", Length = "0x2E4")]
	[Token(Token = "0x6002822")]
	internal static void ConvertValues(Binder binder, Object[] args, ParameterInfo[] pinfo, CultureInfo culture, BindingFlags invokeAttr) { }

	[Address(RVA = "0x73216B8", Offset = "0x73216B8", Length = "0x14")]
	[Token(Token = "0x6002809")]
	public virtual Delegate CreateDelegate(Type delegateType) { }

	[Address(RVA = "0x73216CC", Offset = "0x73216CC", Length = "0x18")]
	[Token(Token = "0x600280A")]
	public virtual Delegate CreateDelegate(Type delegateType, object target) { }

	[Address(RVA = "0x7321364", Offset = "0x7321364", Length = "0x160")]
	[Token(Token = "0x6002808")]
	internal virtual string FormatNameAndSig(bool serialization) { }

	[Address(RVA = "0x7322024", Offset = "0x7322024", Length = "0x8")]
	[Token(Token = "0x6002824")]
	public virtual MethodAttributes get_Attributes() { }

	[Address(RVA = "0x7321904", Offset = "0x7321904", Length = "0x4")]
	[Token(Token = "0x6002815")]
	internal static RuntimeMethodInfo get_base_method(RuntimeMethodInfo method, bool definition) { }

	[Address(RVA = "0x7321240", Offset = "0x7321240", Length = "0x8")]
	[Token(Token = "0x6002805")]
	internal BindingFlags get_BindingFlags() { }

	[Address(RVA = "0x732202C", Offset = "0x732202C", Length = "0x2C")]
	[Token(Token = "0x6002825")]
	public virtual CallingConventions get_CallingConvention() { }

	[Address(RVA = "0x7323018", Offset = "0x7323018", Length = "0xD8")]
	[Token(Token = "0x6002837")]
	public virtual bool get_ContainsGenericParameters() { }

	[Address(RVA = "0x73230F4", Offset = "0x73230F4", Length = "0x8")]
	[Token(Token = "0x6002839")]
	private static int get_core_clr_security_level() { }

	[Address(RVA = "0x7322060", Offset = "0x7322060", Length = "0x2C")]
	[Token(Token = "0x6002827")]
	public virtual Type get_DeclaringType() { }

	[Address(RVA = "0x7323014", Offset = "0x7323014", Length = "0x4")]
	[Token(Token = "0x6002836")]
	public virtual bool get_IsGenericMethod() { }

	[Address(RVA = "0x7323010", Offset = "0x7323010", Length = "0x4")]
	[Token(Token = "0x6002835")]
	public virtual bool get_IsGenericMethodDefinition() { }

	[Address(RVA = "0x73230FC", Offset = "0x73230FC", Length = "0x8")]
	[Token(Token = "0x600283A")]
	public virtual bool get_IsSecurityCritical() { }

	[Address(RVA = "0x7321908", Offset = "0x7321908", Length = "0x4")]
	[Token(Token = "0x6002816")]
	internal static int get_metadata_token(RuntimeMethodInfo method) { }

	[Address(RVA = "0x732194C", Offset = "0x732194C", Length = "0x4")]
	[Token(Token = "0x600281B")]
	public virtual int get_MetadataToken() { }

	[Address(RVA = "0x732201C", Offset = "0x732201C", Length = "0x8")]
	[Token(Token = "0x6002823")]
	public virtual RuntimeMethodHandle get_MethodHandle() { }

	[Address(RVA = "0x7321248", Offset = "0x7321248", Length = "0x4")]
	[Token(Token = "0x6002806")]
	public virtual Module get_Module() { }

	[Address(RVA = "0x7321900", Offset = "0x7321900", Length = "0x4")]
	[Token(Token = "0x6002814")]
	internal static string get_name(MethodBase method) { }

	[Address(RVA = "0x732208C", Offset = "0x732208C", Length = "0x14")]
	[Token(Token = "0x6002828")]
	public virtual string get_Name() { }

	[Address(RVA = "0x7322058", Offset = "0x7322058", Length = "0x8")]
	[Token(Token = "0x6002826")]
	public virtual Type get_ReflectedType() { }

	[Address(RVA = "0x73212DC", Offset = "0x73212DC", Length = "0x88")]
	[Token(Token = "0x6002807")]
	private RuntimeType get_ReflectedTypeInternal() { }

	[Address(RVA = "0x732191C", Offset = "0x732191C", Length = "0x4")]
	[Token(Token = "0x6002819")]
	public virtual ParameterInfo get_ReturnParameter() { }

	[Address(RVA = "0x7321920", Offset = "0x7321920", Length = "0x2C")]
	[Token(Token = "0x600281A")]
	public virtual Type get_ReturnType() { }

	[Address(RVA = "0x732190C", Offset = "0x732190C", Length = "0x8")]
	[Token(Token = "0x6002817")]
	public virtual MethodInfo GetBaseDefinition() { }

	[Address(RVA = "0x7321914", Offset = "0x7321914", Length = "0x8")]
	[Token(Token = "0x6002818")]
	internal MethodInfo GetBaseMethod() { }

	[Address(RVA = "0x7322178", Offset = "0x7322178", Length = "0x70")]
	[Token(Token = "0x600282B")]
	public virtual Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7322110", Offset = "0x7322110", Length = "0x68")]
	[Token(Token = "0x600282A")]
	public virtual Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x73230F0", Offset = "0x73230F0", Length = "0x4")]
	[Token(Token = "0x6002838")]
	public virtual IList<CustomAttributeData> GetCustomAttributesData() { }

	[Address(RVA = "0x7322550", Offset = "0x7322550", Length = "0x700")]
	[Token(Token = "0x600282F")]
	private CustomAttributeData GetDllImportAttributeData() { }

	[Address(RVA = "0x7322FB8", Offset = "0x7322FB8", Length = "0x4")]
	[Token(Token = "0x6002832")]
	public virtual Type[] GetGenericArguments() { }

	[Address(RVA = "0x7322FC0", Offset = "0x7322FC0", Length = "0x50")]
	[Token(Token = "0x6002834")]
	public virtual MethodInfo GetGenericMethodDefinition() { }

	[Address(RVA = "0x7322FBC", Offset = "0x7322FBC", Length = "0x4")]
	[Token(Token = "0x6002833")]
	private MethodInfo GetGenericMethodDefinition_impl() { }

	[Address(RVA = "0x7313F74", Offset = "0x7313F74", Length = "0x8")]
	[Token(Token = "0x6002811")]
	internal static MethodBase GetMethodFromHandleInternalType(IntPtr method_handle, IntPtr type_handle) { }

	[Address(RVA = "0x73218EC", Offset = "0x73218EC", Length = "0x4")]
	[Token(Token = "0x6002812")]
	private static MethodBase GetMethodFromHandleInternalType_native(IntPtr method_handle, IntPtr type_handle, bool genericCheck) { }

	[Address(RVA = "0x73218F0", Offset = "0x73218F0", Length = "0x8")]
	[Token(Token = "0x6002810")]
	internal static MethodBase GetMethodFromHandleNoGenericCheck(RuntimeMethodHandle handle, RuntimeTypeHandle reflectedType) { }

	[Address(RVA = "0x7321898", Offset = "0x7321898", Length = "0x54")]
	[Token(Token = "0x600280F")]
	internal static MethodBase GetMethodFromHandleNoGenericCheck(RuntimeMethodHandle handle) { }

	[Address(RVA = "0x7321950", Offset = "0x7321950", Length = "0x2C")]
	[Token(Token = "0x600281C")]
	public virtual MethodImplAttributes GetMethodImplementationFlags() { }

	[Address(RVA = "0x7321774", Offset = "0x7321774", Length = "0x124")]
	[Token(Token = "0x600280D")]
	public override void GetObjectData(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x732197C", Offset = "0x732197C", Length = "0x90")]
	[Token(Token = "0x600281D")]
	public virtual ParameterInfo[] GetParameters() { }

	[Address(RVA = "0x7321A18", Offset = "0x7321A18", Length = "0x24")]
	[Token(Token = "0x600281F")]
	internal virtual int GetParametersCount() { }

	[Address(RVA = "0x7321A0C", Offset = "0x7321A0C", Length = "0xC")]
	[Token(Token = "0x600281E")]
	internal virtual ParameterInfo[] GetParametersInternal() { }

	[Address(RVA = "0x73221E8", Offset = "0x73221E8", Length = "0x4")]
	[Token(Token = "0x600282C")]
	internal void GetPInvoke(out PInvokeAttributes flags, out string entryPoint, out string dllName) { }

	[Address(RVA = "0x73221EC", Offset = "0x73221EC", Length = "0x184")]
	[Token(Token = "0x600282D")]
	internal Object[] GetPseudoCustomAttributes() { }

	[Address(RVA = "0x7322370", Offset = "0x7322370", Length = "0x1E0")]
	[Token(Token = "0x600282E")]
	internal CustomAttributeData[] GetPseudoCustomAttributesData() { }

	[Address(RVA = "0x732124C", Offset = "0x732124C", Length = "0x90")]
	[Token(Token = "0x600280C")]
	internal RuntimeModule GetRuntimeModule() { }

	[Address(RVA = "0x7323104", Offset = "0x7323104", Length = "0x58")]
	[Token(Token = "0x600283B")]
	public virtual bool HasSameMetadataDefinitionAs(MemberInfo other) { }

	[Address(RVA = "0x7321A3C", Offset = "0x7321A3C", Length = "0x4")]
	[Token(Token = "0x6002820")]
	internal object InternalInvoke(object obj, Object[] parameters, out Exception exc) { }

	[Address(RVA = "0x7321A40", Offset = "0x7321A40", Length = "0x2F8")]
	[DebuggerHidden]
	[DebuggerStepThrough]
	[Token(Token = "0x6002821")]
	public virtual object Invoke(object obj, BindingFlags invokeAttr, Binder binder, Object[] parameters, CultureInfo culture) { }

	[Address(RVA = "0x73220A0", Offset = "0x73220A0", Length = "0x70")]
	[Token(Token = "0x6002829")]
	public virtual bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7322C50", Offset = "0x7322C50", Length = "0x364")]
	[Token(Token = "0x6002830")]
	public virtual MethodInfo MakeGenericMethod(Type[] methodInstantiation) { }

	[Address(RVA = "0x7322FB4", Offset = "0x7322FB4", Length = "0x4")]
	[Token(Token = "0x6002831")]
	private MethodInfo MakeGenericMethod_impl(Type[] types) { }

	[Address(RVA = "0x731B208", Offset = "0x731B208", Length = "0x9C")]
	[Token(Token = "0x600280E")]
	internal string SerializationToString() { }

	[Address(RVA = "0x73216E4", Offset = "0x73216E4", Length = "0x90")]
	[Token(Token = "0x600280B")]
	public virtual string ToString() { }

}

