namespace System.Reflection;

[Token(Token = "0x2000515")]
public abstract class MethodInfo : MethodBase
{

	[Token(Token = "0x1700051B")]
	internal override int GenericParameterCount
	{
		[Address(RVA = "0x7314270", Offset = "0x7314270", Length = "0x28")]
		[Token(Token = "0x60025DE")]
		internal get { } //Length: 40
	}

	[Token(Token = "0x17000518")]
	public virtual MemberTypes MemberType
	{
		[Address(RVA = "0x7314078", Offset = "0x7314078", Length = "0x8")]
		[Token(Token = "0x60025D1")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000519")]
	public override ParameterInfo ReturnParameter
	{
		[Address(RVA = "0x7314080", Offset = "0x7314080", Length = "0x28")]
		[Token(Token = "0x60025D2")]
		 get { } //Length: 40
	}

	[Token(Token = "0x1700051A")]
	public override Type ReturnType
	{
		[Address(RVA = "0x73140A8", Offset = "0x73140A8", Length = "0x28")]
		[Token(Token = "0x60025D3")]
		 get { } //Length: 40
	}

	[Address(RVA = "0x7314070", Offset = "0x7314070", Length = "0x8")]
	[Token(Token = "0x60025D0")]
	protected MethodInfo() { }

	[Address(RVA = "0x73141C0", Offset = "0x73141C0", Length = "0x50")]
	[Token(Token = "0x60025D8")]
	public override Delegate CreateDelegate(Type delegateType) { }

	[Address(RVA = "0x7314210", Offset = "0x7314210", Length = "0x50")]
	[Token(Token = "0x60025D9")]
	public override Delegate CreateDelegate(Type delegateType, object target) { }

	[Address(RVA = "0x7314260", Offset = "0x7314260", Length = "0x8")]
	[Token(Token = "0x60025DA")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x7314270", Offset = "0x7314270", Length = "0x28")]
	[Token(Token = "0x60025DE")]
	internal override int get_GenericParameterCount() { }

	[Address(RVA = "0x7314078", Offset = "0x7314078", Length = "0x8")]
	[Token(Token = "0x60025D1")]
	public virtual MemberTypes get_MemberType() { }

	[Address(RVA = "0x7314080", Offset = "0x7314080", Length = "0x28")]
	[Token(Token = "0x60025D2")]
	public override ParameterInfo get_ReturnParameter() { }

	[Address(RVA = "0x73140A8", Offset = "0x73140A8", Length = "0x28")]
	[Token(Token = "0x60025D3")]
	public override Type get_ReturnType() { }

	[Token(Token = "0x60025D7")]
	public abstract MethodInfo GetBaseDefinition() { }

	[Address(RVA = "0x73140D0", Offset = "0x73140D0", Length = "0x50")]
	[Token(Token = "0x60025D4")]
	public virtual Type[] GetGenericArguments() { }

	[Address(RVA = "0x7314120", Offset = "0x7314120", Length = "0x50")]
	[Token(Token = "0x60025D5")]
	public override MethodInfo GetGenericMethodDefinition() { }

	[Address(RVA = "0x7314268", Offset = "0x7314268", Length = "0x8")]
	[Token(Token = "0x60025DB")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x7314170", Offset = "0x7314170", Length = "0x50")]
	[Token(Token = "0x60025D6")]
	public override MethodInfo MakeGenericMethod(Type[] typeArguments) { }

	[Address(RVA = "0x7311360", Offset = "0x7311360", Length = "0x2C")]
	[Token(Token = "0x60025DC")]
	public static bool op_Equality(MethodInfo left, MethodInfo right) { }

	[Address(RVA = "0x73138C0", Offset = "0x73138C0", Length = "0x3C")]
	[Token(Token = "0x60025DD")]
	public static bool op_Inequality(MethodInfo left, MethodInfo right) { }

}

