namespace System.Reflection;

[AttributeUsage(AttributeTargets::Assembly (1), Inherited = False)]
[Token(Token = "0x20004F3")]
public sealed class AssemblyDescriptionAttribute : Attribute
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x400142F")]
	private readonly string <Description>k__BackingField; //Field offset: 0x10

	[Address(RVA = "0x7310BE0", Offset = "0x7310BE0", Length = "0x30")]
	[Token(Token = "0x6002534")]
	public AssemblyDescriptionAttribute(string description) { }

}

