namespace System.Reflection;

[Token(Token = "0x200052C")]
public class TypeDelegator : TypeInfo
{
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001514")]
	protected Type typeImpl; //Field offset: 0x18

	[Token(Token = "0x17000575")]
	public virtual Assembly Assembly
	{
		[Address(RVA = "0x7318334", Offset = "0x7318334", Length = "0x24")]
		[Token(Token = "0x60026D2")]
		 get { } //Length: 36
	}

	[Token(Token = "0x1700057A")]
	public virtual string AssemblyQualifiedName
	{
		[Address(RVA = "0x73183E8", Offset = "0x73183E8", Length = "0x24")]
		[Token(Token = "0x60026D7")]
		 get { } //Length: 36
	}

	[Token(Token = "0x1700057B")]
	public virtual Type BaseType
	{
		[Address(RVA = "0x731840C", Offset = "0x731840C", Length = "0x24")]
		[Token(Token = "0x60026D8")]
		 get { } //Length: 36
	}

	[Token(Token = "0x17000578")]
	public virtual string FullName
	{
		[Address(RVA = "0x73183A0", Offset = "0x73183A0", Length = "0x24")]
		[Token(Token = "0x60026D5")]
		 get { } //Length: 36
	}

	[Token(Token = "0x17000572")]
	public virtual Guid GUID
	{
		[Address(RVA = "0x731829C", Offset = "0x731829C", Length = "0x24")]
		[Token(Token = "0x60026CE")]
		 get { } //Length: 36
	}

	[Token(Token = "0x1700057F")]
	public virtual bool IsCollectible
	{
		[Address(RVA = "0x7318824", Offset = "0x7318824", Length = "0x24")]
		[Token(Token = "0x60026F1")]
		 get { } //Length: 36
	}

	[Token(Token = "0x1700057E")]
	public virtual bool IsConstructedGenericType
	{
		[Address(RVA = "0x7318800", Offset = "0x7318800", Length = "0x24")]
		[Token(Token = "0x60026F0")]
		 get { } //Length: 36
	}

	[Token(Token = "0x1700057D")]
	public virtual bool IsGenericMethodParameter
	{
		[Address(RVA = "0x7318788", Offset = "0x7318788", Length = "0x24")]
		[Token(Token = "0x60026EC")]
		 get { } //Length: 36
	}

	[Token(Token = "0x1700057C")]
	public virtual bool IsSZArray
	{
		[Address(RVA = "0x7318710", Offset = "0x7318710", Length = "0x24")]
		[Token(Token = "0x60026E8")]
		 get { } //Length: 36
	}

	[Token(Token = "0x17000573")]
	public virtual int MetadataToken
	{
		[Address(RVA = "0x73182C0", Offset = "0x73182C0", Length = "0x24")]
		[Token(Token = "0x60026CF")]
		 get { } //Length: 36
	}

	[Token(Token = "0x17000574")]
	public virtual Module Module
	{
		[Address(RVA = "0x7318310", Offset = "0x7318310", Length = "0x24")]
		[Token(Token = "0x60026D1")]
		 get { } //Length: 36
	}

	[Token(Token = "0x17000577")]
	public virtual string Name
	{
		[Address(RVA = "0x731837C", Offset = "0x731837C", Length = "0x24")]
		[Token(Token = "0x60026D4")]
		 get { } //Length: 36
	}

	[Token(Token = "0x17000579")]
	public virtual string Namespace
	{
		[Address(RVA = "0x73183C4", Offset = "0x73183C4", Length = "0x24")]
		[Token(Token = "0x60026D6")]
		 get { } //Length: 36
	}

	[Token(Token = "0x17000576")]
	public virtual RuntimeTypeHandle TypeHandle
	{
		[Address(RVA = "0x7318358", Offset = "0x7318358", Length = "0x24")]
		[Token(Token = "0x60026D3")]
		 get { } //Length: 36
	}

	[Token(Token = "0x17000580")]
	public virtual Type UnderlyingSystemType
	{
		[Address(RVA = "0x7318888", Offset = "0x7318888", Length = "0x24")]
		[Token(Token = "0x60026F4")]
		 get { } //Length: 36
	}

	[Address(RVA = "0x7312AD0", Offset = "0x7312AD0", Length = "0xD0")]
	[Token(Token = "0x60026CD")]
	public TypeDelegator(Type delegatingType) { }

	[Address(RVA = "0x7318334", Offset = "0x7318334", Length = "0x24")]
	[Token(Token = "0x60026D2")]
	public virtual Assembly get_Assembly() { }

	[Address(RVA = "0x73183E8", Offset = "0x73183E8", Length = "0x24")]
	[Token(Token = "0x60026D7")]
	public virtual string get_AssemblyQualifiedName() { }

	[Address(RVA = "0x731840C", Offset = "0x731840C", Length = "0x24")]
	[Token(Token = "0x60026D8")]
	public virtual Type get_BaseType() { }

	[Address(RVA = "0x73183A0", Offset = "0x73183A0", Length = "0x24")]
	[Token(Token = "0x60026D5")]
	public virtual string get_FullName() { }

	[Address(RVA = "0x731829C", Offset = "0x731829C", Length = "0x24")]
	[Token(Token = "0x60026CE")]
	public virtual Guid get_GUID() { }

	[Address(RVA = "0x7318824", Offset = "0x7318824", Length = "0x24")]
	[Token(Token = "0x60026F1")]
	public virtual bool get_IsCollectible() { }

	[Address(RVA = "0x7318800", Offset = "0x7318800", Length = "0x24")]
	[Token(Token = "0x60026F0")]
	public virtual bool get_IsConstructedGenericType() { }

	[Address(RVA = "0x7318788", Offset = "0x7318788", Length = "0x24")]
	[Token(Token = "0x60026EC")]
	public virtual bool get_IsGenericMethodParameter() { }

	[Address(RVA = "0x7318710", Offset = "0x7318710", Length = "0x24")]
	[Token(Token = "0x60026E8")]
	public virtual bool get_IsSZArray() { }

	[Address(RVA = "0x73182C0", Offset = "0x73182C0", Length = "0x24")]
	[Token(Token = "0x60026CF")]
	public virtual int get_MetadataToken() { }

	[Address(RVA = "0x7318310", Offset = "0x7318310", Length = "0x24")]
	[Token(Token = "0x60026D1")]
	public virtual Module get_Module() { }

	[Address(RVA = "0x731837C", Offset = "0x731837C", Length = "0x24")]
	[Token(Token = "0x60026D4")]
	public virtual string get_Name() { }

	[Address(RVA = "0x73183C4", Offset = "0x73183C4", Length = "0x24")]
	[Token(Token = "0x60026D6")]
	public virtual string get_Namespace() { }

	[Address(RVA = "0x7318358", Offset = "0x7318358", Length = "0x24")]
	[Token(Token = "0x60026D3")]
	public virtual RuntimeTypeHandle get_TypeHandle() { }

	[Address(RVA = "0x7318888", Offset = "0x7318888", Length = "0x24")]
	[Token(Token = "0x60026F4")]
	public virtual Type get_UnderlyingSystemType() { }

	[Address(RVA = "0x73186F4", Offset = "0x73186F4", Length = "0x1C")]
	[Token(Token = "0x60026E7")]
	protected virtual TypeAttributes GetAttributeFlagsImpl() { }

	[Address(RVA = "0x7318430", Offset = "0x7318430", Length = "0x1C")]
	[Token(Token = "0x60026D9")]
	protected virtual ConstructorInfo GetConstructorImpl(BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers) { }

	[Address(RVA = "0x731844C", Offset = "0x731844C", Length = "0x24")]
	[ComVisible(True)]
	[Token(Token = "0x60026DA")]
	public virtual ConstructorInfo[] GetConstructors(BindingFlags bindingAttr) { }

	[Address(RVA = "0x73188D4", Offset = "0x73188D4", Length = "0x28")]
	[Token(Token = "0x60026F6")]
	public virtual Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x73188AC", Offset = "0x73188AC", Length = "0x28")]
	[Token(Token = "0x60026F5")]
	public virtual Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x7318848", Offset = "0x7318848", Length = "0x24")]
	[Token(Token = "0x60026F2")]
	public virtual Type GetElementType() { }

	[Address(RVA = "0x7318530", Offset = "0x7318530", Length = "0x24")]
	[Token(Token = "0x60026E0")]
	public virtual EventInfo GetEvent(string name, BindingFlags bindingAttr) { }

	[Address(RVA = "0x7318664", Offset = "0x7318664", Length = "0x24")]
	[Token(Token = "0x60026E3")]
	public virtual EventInfo[] GetEvents(BindingFlags bindingAttr) { }

	[Address(RVA = "0x73184C4", Offset = "0x73184C4", Length = "0x24")]
	[Token(Token = "0x60026DD")]
	public virtual FieldInfo GetField(string name, BindingFlags bindingAttr) { }

	[Address(RVA = "0x73184E8", Offset = "0x73184E8", Length = "0x24")]
	[Token(Token = "0x60026DE")]
	public virtual FieldInfo[] GetFields(BindingFlags bindingAttr) { }

	[Address(RVA = "0x731850C", Offset = "0x731850C", Length = "0x24")]
	[Token(Token = "0x60026DF")]
	public virtual Type[] GetInterfaces() { }

	[Address(RVA = "0x73186AC", Offset = "0x73186AC", Length = "0x24")]
	[Token(Token = "0x60026E5")]
	public virtual MemberInfo[] GetMember(string name, MemberTypes type, BindingFlags bindingAttr) { }

	[Address(RVA = "0x73186D0", Offset = "0x73186D0", Length = "0x24")]
	[Token(Token = "0x60026E6")]
	public virtual MemberInfo[] GetMembers(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7318470", Offset = "0x7318470", Length = "0x30")]
	[Token(Token = "0x60026DB")]
	protected virtual MethodInfo GetMethodImpl(string name, BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers) { }

	[Address(RVA = "0x73184A0", Offset = "0x73184A0", Length = "0x24")]
	[Token(Token = "0x60026DC")]
	public virtual MethodInfo[] GetMethods(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7318688", Offset = "0x7318688", Length = "0x24")]
	[Token(Token = "0x60026E4")]
	public virtual Type GetNestedType(string name, BindingFlags bindingAttr) { }

	[Address(RVA = "0x7318640", Offset = "0x7318640", Length = "0x24")]
	[Token(Token = "0x60026E2")]
	public virtual PropertyInfo[] GetProperties(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7318554", Offset = "0x7318554", Length = "0xEC")]
	[Token(Token = "0x60026E1")]
	protected virtual PropertyInfo GetPropertyImpl(string name, BindingFlags bindingAttr, Binder binder, Type returnType, Type[] types, ParameterModifier[] modifiers) { }

	[Address(RVA = "0x731886C", Offset = "0x731886C", Length = "0x1C")]
	[Token(Token = "0x60026F3")]
	protected virtual bool HasElementTypeImpl() { }

	[Address(RVA = "0x73182E4", Offset = "0x73182E4", Length = "0x2C")]
	[Token(Token = "0x60026D0")]
	public virtual object InvokeMember(string name, BindingFlags invokeAttr, Binder binder, object target, Object[] args, ParameterModifier[] modifiers, CultureInfo culture, String[] namedParameters) { }

	[Address(RVA = "0x7318734", Offset = "0x7318734", Length = "0x1C")]
	[Token(Token = "0x60026E9")]
	protected virtual bool IsArrayImpl() { }

	[Address(RVA = "0x731876C", Offset = "0x731876C", Length = "0x1C")]
	[Token(Token = "0x60026EB")]
	protected virtual bool IsByRefImpl() { }

	[Address(RVA = "0x73187E4", Offset = "0x73187E4", Length = "0x1C")]
	[Token(Token = "0x60026EF")]
	protected virtual bool IsCOMObjectImpl() { }

	[Address(RVA = "0x73188FC", Offset = "0x73188FC", Length = "0x28")]
	[Token(Token = "0x60026F7")]
	public virtual bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x73187AC", Offset = "0x73187AC", Length = "0x1C")]
	[Token(Token = "0x60026ED")]
	protected virtual bool IsPointerImpl() { }

	[Address(RVA = "0x7318750", Offset = "0x7318750", Length = "0x1C")]
	[Token(Token = "0x60026EA")]
	protected virtual bool IsPrimitiveImpl() { }

	[Address(RVA = "0x73187C8", Offset = "0x73187C8", Length = "0x1C")]
	[Token(Token = "0x60026EE")]
	protected virtual bool IsValueTypeImpl() { }

}

