namespace System.Reflection;

[Extension]
[Token(Token = "0x200050C")]
public static class IntrospectionExtensions
{

	[Address(RVA = "0x7312964", Offset = "0x7312964", Length = "0x16C")]
	[Extension]
	[Token(Token = "0x6002589")]
	public static TypeInfo GetTypeInfo(Type type) { }

}

