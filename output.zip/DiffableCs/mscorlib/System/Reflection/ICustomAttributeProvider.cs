namespace System.Reflection;

[Token(Token = "0x200050A")]
public interface ICustomAttributeProvider
{

	[Token(Token = "0x6002585")]
	public Object[] GetCustomAttributes(bool inherit) { }

	[Token(Token = "0x6002586")]
	public Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Token(Token = "0x6002587")]
	public bool IsDefined(Type attributeType, bool inherit) { }

}

