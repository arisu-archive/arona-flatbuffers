namespace System.Reflection;

[AttributeUsage(AttributeTargets::Assembly (1), Inherited = False)]
[Token(Token = "0x20004ED")]
public sealed class AssemblyCompanyAttribute : Attribute
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001427")]
	private readonly string <Company>k__BackingField; //Field offset: 0x10

	[Address(RVA = "0x7310AF8", Offset = "0x7310AF8", Length = "0x30")]
	[Token(Token = "0x600252F")]
	public AssemblyCompanyAttribute(string company) { }

}

