namespace System.Reflection;

[Token(Token = "0x200051F")]
public sealed class ReflectionTypeLoadException : SystemException, ISerializable
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x90")]
	[Token(Token = "0x40014E8")]
	private readonly Type[] <Types>k__BackingField; //Field offset: 0x90
	[CompilerGenerated]
	[FieldOffset(Offset = "0x98")]
	[Token(Token = "0x40014E9")]
	private readonly Exception[] <LoaderExceptions>k__BackingField; //Field offset: 0x98

	[Token(Token = "0x1700052F")]
	public Exception[] LoaderExceptions
	{
		[Address(RVA = "0x7315580", Offset = "0x7315580", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x600261F")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000530")]
	public virtual string Message
	{
		[Address(RVA = "0x7315588", Offset = "0x7315588", Length = "0x8")]
		[Token(Token = "0x6002620")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x73152C4", Offset = "0x73152C4", Length = "0x58")]
	[Token(Token = "0x600261C")]
	public ReflectionTypeLoadException(Type[] classes, Exception[] exceptions) { }

	[Address(RVA = "0x731531C", Offset = "0x731531C", Length = "0x13C")]
	[Token(Token = "0x600261D")]
	private ReflectionTypeLoadException(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x7315590", Offset = "0x7315590", Length = "0x164")]
	[Token(Token = "0x6002622")]
	private string CreateString(bool isMessage) { }

	[Address(RVA = "0x7315580", Offset = "0x7315580", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x600261F")]
	public Exception[] get_LoaderExceptions() { }

	[Address(RVA = "0x7315588", Offset = "0x7315588", Length = "0x8")]
	[Token(Token = "0x6002620")]
	public virtual string get_Message() { }

	[Address(RVA = "0x7315458", Offset = "0x7315458", Length = "0x128")]
	[Token(Token = "0x600261E")]
	public virtual void GetObjectData(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x73156F4", Offset = "0x73156F4", Length = "0x8")]
	[Token(Token = "0x6002621")]
	public virtual string ToString() { }

}

