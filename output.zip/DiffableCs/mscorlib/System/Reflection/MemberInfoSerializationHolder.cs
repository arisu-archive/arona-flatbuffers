namespace System.Reflection;

[Token(Token = "0x2000536")]
internal class MemberInfoSerializationHolder : ISerializable, IObjectReference
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x400157D")]
	private string m_memberName; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x400157E")]
	private RuntimeType m_reflectedType; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x400157F")]
	private string m_signature; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4001580")]
	private string m_signature2; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4001581")]
	private MemberTypes m_memberType; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x4001582")]
	private SerializationInfo m_info; //Field offset: 0x38

	[Address(RVA = "0x731A5C0", Offset = "0x731A5C0", Length = "0x3B0")]
	[Token(Token = "0x600272D")]
	internal MemberInfoSerializationHolder(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x731A970", Offset = "0x731A970", Length = "0x60")]
	[Token(Token = "0x600272E")]
	public override void GetObjectData(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x731A9D0", Offset = "0x731A9D0", Length = "0x824")]
	[Token(Token = "0x600272F")]
	public override object GetRealObject(StreamingContext context) { }

	[Address(RVA = "0x731A2A0", Offset = "0x731A2A0", Length = "0x10")]
	[Token(Token = "0x600272B")]
	public static void GetSerializationInfo(SerializationInfo info, string name, RuntimeType reflectedClass, string signature, MemberTypes type) { }

	[Address(RVA = "0x731A2B0", Offset = "0x731A2B0", Length = "0x310")]
	[Token(Token = "0x600272C")]
	public static void GetSerializationInfo(SerializationInfo info, string name, RuntimeType reflectedClass, string signature, string signature2, MemberTypes type, Type[] genericArguments) { }

}

