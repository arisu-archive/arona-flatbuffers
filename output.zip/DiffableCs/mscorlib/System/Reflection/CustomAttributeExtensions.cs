namespace System.Reflection;

[Extension]
[Token(Token = "0x2000533")]
public static class CustomAttributeExtensions
{

	[Address(RVA = "0x731A258", Offset = "0x731A258", Length = "0x8")]
	[Extension]
	[Token(Token = "0x600271C")]
	public static Attribute GetCustomAttribute(Assembly element, Type attributeType) { }

	[Address(RVA = "0x731A260", Offset = "0x731A260", Length = "0x8")]
	[Extension]
	[Token(Token = "0x600271D")]
	public static Attribute GetCustomAttribute(MemberInfo element, Type attributeType) { }

	[Address(RVA = "0x731A268", Offset = "0x731A268", Length = "0x8")]
	[Extension]
	[Token(Token = "0x600271E")]
	public static Attribute GetCustomAttribute(ParameterInfo element, Type attributeType) { }

	[Address(RVA = "0x419B1F0", Offset = "0x419B1F0", Length = "0xC4")]
	[Extension]
	[Token(Token = "0x600271F")]
	public static T GetCustomAttribute(Assembly element) { }

	[Address(RVA = "0x419B2B4", Offset = "0x419B2B4", Length = "0xC4")]
	[Extension]
	[Token(Token = "0x6002720")]
	public static T GetCustomAttribute(MemberInfo element) { }

	[Address(RVA = "0x419B378", Offset = "0x419B378", Length = "0xC4")]
	[Extension]
	[Token(Token = "0x6002721")]
	public static T GetCustomAttribute(ParameterInfo element) { }

	[Address(RVA = "0x731A270", Offset = "0x731A270", Length = "0x8")]
	[Extension]
	[Token(Token = "0x6002722")]
	public static Attribute GetCustomAttribute(ParameterInfo element, Type attributeType, bool inherit) { }

	[Address(RVA = "0x419B43C", Offset = "0x419B43C", Length = "0xCC")]
	[Extension]
	[Token(Token = "0x6002723")]
	public static T GetCustomAttribute(ParameterInfo element, bool inherit) { }

	[Address(RVA = "0x731A278", Offset = "0x731A278", Length = "0x8")]
	[Extension]
	[Token(Token = "0x6002724")]
	public static IEnumerable<Attribute> GetCustomAttributes(Assembly element) { }

	[Address(RVA = "0x731A280", Offset = "0x731A280", Length = "0x8")]
	[Extension]
	[Token(Token = "0x6002725")]
	public static IEnumerable<Attribute> GetCustomAttributes(MemberInfo element) { }

	[Address(RVA = "0x731A288", Offset = "0x731A288", Length = "0x8")]
	[Extension]
	[Token(Token = "0x6002726")]
	public static IEnumerable<Attribute> GetCustomAttributes(MemberInfo element, Type attributeType) { }

	[Address(RVA = "0x419B508", Offset = "0x419B508", Length = "0xC4")]
	[Extension]
	[Token(Token = "0x6002727")]
	public static IEnumerable<T> GetCustomAttributes(MemberInfo element) { }

	[Address(RVA = "0x731A290", Offset = "0x731A290", Length = "0x8")]
	[Extension]
	[Token(Token = "0x6002728")]
	public static IEnumerable<Attribute> GetCustomAttributes(MemberInfo element, Type attributeType, bool inherit) { }

	[Address(RVA = "0x419B5CC", Offset = "0x419B5CC", Length = "0xCC")]
	[Extension]
	[Token(Token = "0x6002729")]
	public static IEnumerable<T> GetCustomAttributes(MemberInfo element, bool inherit) { }

	[Address(RVA = "0x731A298", Offset = "0x731A298", Length = "0x8")]
	[Extension]
	[Token(Token = "0x600272A")]
	public static bool IsDefined(MemberInfo element, Type attributeType) { }

}

