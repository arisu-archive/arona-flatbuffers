namespace System.Reflection;

[ComVisible(True)]
[Token(Token = "0x200053D")]
public class LocalVariableInfo
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40015A1")]
	internal Type type; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40015A2")]
	internal bool is_pinned; //Field offset: 0x18
	[FieldOffset(Offset = "0x1A")]
	[Token(Token = "0x40015A3")]
	internal ushort position; //Field offset: 0x1A

	[Address(RVA = "0x731ED98", Offset = "0x731ED98", Length = "0x8")]
	[Token(Token = "0x6002797")]
	protected LocalVariableInfo() { }

	[Address(RVA = "0x731EDA0", Offset = "0x731EDA0", Length = "0xB8")]
	[Token(Token = "0x6002798")]
	public virtual string ToString() { }

}

