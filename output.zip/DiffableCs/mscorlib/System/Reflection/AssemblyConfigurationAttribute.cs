namespace System.Reflection;

[AttributeUsage(AttributeTargets::Assembly (1), Inherited = False)]
[Token(Token = "0x20004EE")]
public sealed class AssemblyConfigurationAttribute : Attribute
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001428")]
	private readonly string <Configuration>k__BackingField; //Field offset: 0x10

	[Address(RVA = "0x7310B28", Offset = "0x7310B28", Length = "0x30")]
	[Token(Token = "0x6002530")]
	public AssemblyConfigurationAttribute(string configuration) { }

}

