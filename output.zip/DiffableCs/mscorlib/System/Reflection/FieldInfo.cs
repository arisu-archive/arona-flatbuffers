namespace System.Reflection;

[Token(Token = "0x2000508")]
public abstract class FieldInfo : MemberInfo
{

	[Token(Token = "0x170004F0")]
	public abstract FieldAttributes Attributes
	{
		[Token(Token = "0x6002569")]
		 get { } //Length: 0
	}

	[Token(Token = "0x170004FB")]
	public abstract RuntimeFieldHandle FieldHandle
	{
		[Token(Token = "0x6002574")]
		 get { } //Length: 0
	}

	[Token(Token = "0x170004F1")]
	public abstract Type FieldType
	{
		[Token(Token = "0x600256A")]
		 get { } //Length: 0
	}

	[Token(Token = "0x170004F6")]
	public override bool IsAssembly
	{
		[Address(RVA = "0x73118D8", Offset = "0x73118D8", Length = "0x28")]
		[Token(Token = "0x600256F")]
		 get { } //Length: 40
	}

	[Token(Token = "0x170004F7")]
	public override bool IsFamily
	{
		[Address(RVA = "0x7311900", Offset = "0x7311900", Length = "0x28")]
		[Token(Token = "0x6002570")]
		 get { } //Length: 40
	}

	[Token(Token = "0x170004F8")]
	public override bool IsFamilyOrAssembly
	{
		[Address(RVA = "0x7311928", Offset = "0x7311928", Length = "0x28")]
		[Token(Token = "0x6002571")]
		 get { } //Length: 40
	}

	[Token(Token = "0x170004F2")]
	public override bool IsInitOnly
	{
		[Address(RVA = "0x7311858", Offset = "0x7311858", Length = "0x20")]
		[Token(Token = "0x600256B")]
		 get { } //Length: 32
	}

	[Token(Token = "0x170004F3")]
	public override bool IsLiteral
	{
		[Address(RVA = "0x7311878", Offset = "0x7311878", Length = "0x20")]
		[Token(Token = "0x600256C")]
		 get { } //Length: 32
	}

	[Token(Token = "0x170004F4")]
	public override bool IsNotSerialized
	{
		[Address(RVA = "0x7311898", Offset = "0x7311898", Length = "0x20")]
		[Token(Token = "0x600256D")]
		 get { } //Length: 32
	}

	[Token(Token = "0x170004F9")]
	public override bool IsPrivate
	{
		[Address(RVA = "0x7311950", Offset = "0x7311950", Length = "0x28")]
		[Token(Token = "0x6002572")]
		 get { } //Length: 40
	}

	[Token(Token = "0x170004FA")]
	public override bool IsPublic
	{
		[Address(RVA = "0x7311978", Offset = "0x7311978", Length = "0x28")]
		[Token(Token = "0x6002573")]
		 get { } //Length: 40
	}

	[Token(Token = "0x170004F5")]
	public override bool IsStatic
	{
		[Address(RVA = "0x73118B8", Offset = "0x73118B8", Length = "0x20")]
		[Token(Token = "0x600256E")]
		 get { } //Length: 32
	}

	[Token(Token = "0x170004EF")]
	public virtual MemberTypes MemberType
	{
		[Address(RVA = "0x7311850", Offset = "0x7311850", Length = "0x8")]
		[Token(Token = "0x6002568")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x7311848", Offset = "0x7311848", Length = "0x8")]
	[Token(Token = "0x6002567")]
	protected FieldInfo() { }

	[Address(RVA = "0x73119A0", Offset = "0x73119A0", Length = "0x8")]
	[Token(Token = "0x6002575")]
	public virtual bool Equals(object obj) { }

	[Token(Token = "0x6002569")]
	public abstract FieldAttributes get_Attributes() { }

	[Token(Token = "0x6002574")]
	public abstract RuntimeFieldHandle get_FieldHandle() { }

	[Token(Token = "0x600256A")]
	public abstract Type get_FieldType() { }

	[Address(RVA = "0x73118D8", Offset = "0x73118D8", Length = "0x28")]
	[Token(Token = "0x600256F")]
	public override bool get_IsAssembly() { }

	[Address(RVA = "0x7311900", Offset = "0x7311900", Length = "0x28")]
	[Token(Token = "0x6002570")]
	public override bool get_IsFamily() { }

	[Address(RVA = "0x7311928", Offset = "0x7311928", Length = "0x28")]
	[Token(Token = "0x6002571")]
	public override bool get_IsFamilyOrAssembly() { }

	[Address(RVA = "0x7311858", Offset = "0x7311858", Length = "0x20")]
	[Token(Token = "0x600256B")]
	public override bool get_IsInitOnly() { }

	[Address(RVA = "0x7311878", Offset = "0x7311878", Length = "0x20")]
	[Token(Token = "0x600256C")]
	public override bool get_IsLiteral() { }

	[Address(RVA = "0x7311898", Offset = "0x7311898", Length = "0x20")]
	[Token(Token = "0x600256D")]
	public override bool get_IsNotSerialized() { }

	[Address(RVA = "0x7311950", Offset = "0x7311950", Length = "0x28")]
	[Token(Token = "0x6002572")]
	public override bool get_IsPrivate() { }

	[Address(RVA = "0x7311978", Offset = "0x7311978", Length = "0x28")]
	[Token(Token = "0x6002573")]
	public override bool get_IsPublic() { }

	[Address(RVA = "0x73118B8", Offset = "0x73118B8", Length = "0x20")]
	[Token(Token = "0x600256E")]
	public override bool get_IsStatic() { }

	[Address(RVA = "0x7311D38", Offset = "0x7311D38", Length = "0x4")]
	[Token(Token = "0x6002582")]
	private MarshalAsAttribute get_marshal_info() { }

	[Address(RVA = "0x7311850", Offset = "0x7311850", Length = "0x8")]
	[Token(Token = "0x6002568")]
	public virtual MemberTypes get_MemberType() { }

	[Address(RVA = "0x7311C00", Offset = "0x7311C00", Length = "0xE8")]
	[ComVisible(False)]
	[Token(Token = "0x6002580")]
	public static FieldInfo GetFieldFromHandle(RuntimeFieldHandle handle, RuntimeTypeHandle declaringType) { }

	[Address(RVA = "0x7311B48", Offset = "0x7311B48", Length = "0xB8")]
	[Token(Token = "0x600257F")]
	public static FieldInfo GetFieldFromHandle(RuntimeFieldHandle handle) { }

	[Address(RVA = "0x7311CE8", Offset = "0x7311CE8", Length = "0x50")]
	[Token(Token = "0x6002581")]
	internal override int GetFieldOffset() { }

	[Address(RVA = "0x73119A8", Offset = "0x73119A8", Length = "0x8")]
	[Token(Token = "0x6002576")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x7311D3C", Offset = "0x7311D3C", Length = "0x234")]
	[Token(Token = "0x6002583")]
	internal Object[] GetPseudoCustomAttributes() { }

	[Address(RVA = "0x7311F70", Offset = "0x7311F70", Length = "0x5B8")]
	[Token(Token = "0x6002584")]
	internal CustomAttributeData[] GetPseudoCustomAttributesData() { }

	[Address(RVA = "0x7311AF4", Offset = "0x7311AF4", Length = "0x50")]
	[Token(Token = "0x600257D")]
	public override object GetRawConstantValue() { }

	[Token(Token = "0x6002579")]
	public abstract object GetValue(object obj) { }

	[Address(RVA = "0x7311B44", Offset = "0x7311B44", Length = "0x4")]
	[Token(Token = "0x600257E")]
	private static FieldInfo internal_from_handle_type(IntPtr field_handle, IntPtr type_handle) { }

	[Address(RVA = "0x73119B0", Offset = "0x73119B0", Length = "0x2C")]
	[Token(Token = "0x6002577")]
	public static bool op_Equality(FieldInfo left, FieldInfo right) { }

	[Address(RVA = "0x73119DC", Offset = "0x73119DC", Length = "0x3C")]
	[Token(Token = "0x6002578")]
	public static bool op_Inequality(FieldInfo left, FieldInfo right) { }

	[Token(Token = "0x600257B")]
	public abstract void SetValue(object obj, object value, BindingFlags invokeAttr, Binder binder, CultureInfo culture) { }

	[Address(RVA = "0x7311A18", Offset = "0x7311A18", Length = "0x8C")]
	[DebuggerHidden]
	[DebuggerStepThrough]
	[Token(Token = "0x600257A")]
	public override void SetValue(object obj, object value) { }

	[Address(RVA = "0x7311AA4", Offset = "0x7311AA4", Length = "0x50")]
	[CLSCompliant(False)]
	[Token(Token = "0x600257C")]
	public override void SetValueDirect(TypedReference obj, object value) { }

}

