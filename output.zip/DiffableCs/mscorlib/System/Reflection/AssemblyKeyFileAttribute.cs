namespace System.Reflection;

[AttributeUsage(AttributeTargets::Assembly (1), Inherited = False)]
[Token(Token = "0x20004F6")]
public sealed class AssemblyKeyFileAttribute : Attribute
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001432")]
	private readonly string <KeyFile>k__BackingField; //Field offset: 0x10

	[Address(RVA = "0x7310CC0", Offset = "0x7310CC0", Length = "0x30")]
	[Token(Token = "0x6002537")]
	public AssemblyKeyFileAttribute(string keyFile) { }

}

