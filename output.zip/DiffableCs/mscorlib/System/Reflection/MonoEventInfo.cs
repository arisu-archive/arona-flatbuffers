namespace System.Reflection;

[Token(Token = "0x2000540")]
internal struct MonoEventInfo
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40015AF")]
	public Type declaring_type; //Field offset: 0x0
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x40015B0")]
	public Type reflected_type; //Field offset: 0x8
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40015B1")]
	public string name; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40015B2")]
	public MethodInfo add_method; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40015B3")]
	public MethodInfo remove_method; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40015B4")]
	public MethodInfo raise_method; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40015B5")]
	public EventAttributes attrs; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40015B6")]
	public MethodInfo[] other_methods; //Field offset: 0x38

}

