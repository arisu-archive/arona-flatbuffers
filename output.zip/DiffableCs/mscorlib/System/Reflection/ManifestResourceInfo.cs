namespace System.Reflection;

[Token(Token = "0x200050E")]
public class ManifestResourceInfo
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001486")]
	private readonly Assembly <ReferencedAssembly>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001487")]
	private readonly string <FileName>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4001488")]
	private readonly ResourceLocation <ResourceLocation>k__BackingField; //Field offset: 0x20

	[Token(Token = "0x170004FD")]
	public override string FileName
	{
		[Address(RVA = "0x7312CB4", Offset = "0x7312CB4", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6002590")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170004FC")]
	public override Assembly ReferencedAssembly
	{
		[Address(RVA = "0x7312CAC", Offset = "0x7312CAC", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x600258F")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170004FE")]
	public override ResourceLocation ResourceLocation
	{
		[Address(RVA = "0x7312CBC", Offset = "0x7312CBC", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6002591")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x7312C54", Offset = "0x7312C54", Length = "0x58")]
	[Token(Token = "0x600258E")]
	public ManifestResourceInfo(Assembly containingAssembly, string containingFileName, ResourceLocation resourceLocation) { }

	[Address(RVA = "0x7312CB4", Offset = "0x7312CB4", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6002590")]
	public override string get_FileName() { }

	[Address(RVA = "0x7312CAC", Offset = "0x7312CAC", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x600258F")]
	public override Assembly get_ReferencedAssembly() { }

	[Address(RVA = "0x7312CBC", Offset = "0x7312CBC", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6002591")]
	public override ResourceLocation get_ResourceLocation() { }

}

