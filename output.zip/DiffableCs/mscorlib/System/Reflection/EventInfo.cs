namespace System.Reflection;

[Token(Token = "0x2000504")]
public abstract class EventInfo : MemberInfo
{
	[Token(Token = "0x2000505")]
	private sealed class AddEventAdapter : MulticastDelegate
	{

		[Address(RVA = "0x73116F0", Offset = "0x73116F0", Length = "0x144")]
		[Token(Token = "0x6002565")]
		public AddEventAdapter(object object, IntPtr method) { }

		[Address(RVA = "0x7311834", Offset = "0x7311834", Length = "0x14")]
		[Token(Token = "0x6002566")]
		public override void Invoke(object _this, Delegate dele) { }

	}

	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001463")]
	private AddEventAdapter cached_add_event; //Field offset: 0x10

	[Token(Token = "0x170004EC")]
	public override MethodInfo AddMethod
	{
		[Address(RVA = "0x73110B4", Offset = "0x73110B4", Length = "0x14")]
		[Token(Token = "0x6002555")]
		 get { } //Length: 20
	}

	[Token(Token = "0x170004EE")]
	public override Type EventHandlerType
	{
		[Address(RVA = "0x7311104", Offset = "0x7311104", Length = "0x124")]
		[Token(Token = "0x600255C")]
		 get { } //Length: 292
	}

	[Token(Token = "0x170004EB")]
	public virtual MemberTypes MemberType
	{
		[Address(RVA = "0x73110AC", Offset = "0x73110AC", Length = "0x8")]
		[Token(Token = "0x6002554")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170004ED")]
	public override MethodInfo RemoveMethod
	{
		[Address(RVA = "0x73110C8", Offset = "0x73110C8", Length = "0x14")]
		[Token(Token = "0x6002556")]
		 get { } //Length: 20
	}

	[Address(RVA = "0x731109C", Offset = "0x731109C", Length = "0x8")]
	[Token(Token = "0x6002553")]
	protected EventInfo() { }

	[Address(RVA = "0x7311434", Offset = "0x7311434", Length = "0x188")]
	[DebuggerHidden]
	[DebuggerStepThrough]
	[Token(Token = "0x6002562")]
	public override void AddEventHandler(object target, Delegate handler) { }

	[Address(RVA = "0x73113AC", Offset = "0x73113AC", Length = "0x8")]
	[Token(Token = "0x600255E")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x73110B4", Offset = "0x73110B4", Length = "0x14")]
	[Token(Token = "0x6002555")]
	public override MethodInfo get_AddMethod() { }

	[Address(RVA = "0x7311104", Offset = "0x7311104", Length = "0x124")]
	[Token(Token = "0x600255C")]
	public override Type get_EventHandlerType() { }

	[Address(RVA = "0x73110AC", Offset = "0x73110AC", Length = "0x8")]
	[Token(Token = "0x6002554")]
	public virtual MemberTypes get_MemberType() { }

	[Address(RVA = "0x73110C8", Offset = "0x73110C8", Length = "0x14")]
	[Token(Token = "0x6002556")]
	public override MethodInfo get_RemoveMethod() { }

	[Address(RVA = "0x73110DC", Offset = "0x73110DC", Length = "0x14")]
	[Token(Token = "0x6002557")]
	public override MethodInfo GetAddMethod() { }

	[Token(Token = "0x6002559")]
	public abstract MethodInfo GetAddMethod(bool nonPublic) { }

	[Address(RVA = "0x7311608", Offset = "0x7311608", Length = "0xE8")]
	[Token(Token = "0x6002564")]
	internal static EventInfo GetEventFromHandle(RuntimeEventHandle handle, RuntimeTypeHandle reflectedType) { }

	[Address(RVA = "0x73113BC", Offset = "0x73113BC", Length = "0x8")]
	[Token(Token = "0x600255F")]
	public virtual int GetHashCode() { }

	[Token(Token = "0x600255B")]
	public abstract MethodInfo GetRaiseMethod(bool nonPublic) { }

	[Token(Token = "0x600255A")]
	public abstract MethodInfo GetRemoveMethod(bool nonPublic) { }

	[Address(RVA = "0x73110F0", Offset = "0x73110F0", Length = "0x14")]
	[Token(Token = "0x6002558")]
	public override MethodInfo GetRemoveMethod() { }

	[Address(RVA = "0x7311604", Offset = "0x7311604", Length = "0x4")]
	[Token(Token = "0x6002563")]
	private static EventInfo internal_from_handle_type(IntPtr event_handle, IntPtr type_handle) { }

	[Address(RVA = "0x73113CC", Offset = "0x73113CC", Length = "0x2C")]
	[Token(Token = "0x6002560")]
	public static bool op_Equality(EventInfo left, EventInfo right) { }

	[Address(RVA = "0x73113F8", Offset = "0x73113F8", Length = "0x3C")]
	[Token(Token = "0x6002561")]
	public static bool op_Inequality(EventInfo left, EventInfo right) { }

	[Address(RVA = "0x7311228", Offset = "0x7311228", Length = "0x138")]
	[DebuggerHidden]
	[DebuggerStepThrough]
	[Token(Token = "0x600255D")]
	public override void RemoveEventHandler(object target, Delegate handler) { }

}

