namespace System.Reflection;

[Token(Token = "0x2000528")]
public class TargetException : ApplicationException
{

	[Address(RVA = "0x73180CC", Offset = "0x73180CC", Length = "0x2C")]
	[Token(Token = "0x60026C3")]
	public TargetException() { }

	[Address(RVA = "0x73115DC", Offset = "0x73115DC", Length = "0x28")]
	[Token(Token = "0x60026C4")]
	public TargetException(string message) { }

	[Address(RVA = "0x73180F8", Offset = "0x73180F8", Length = "0x24")]
	[Token(Token = "0x60026C5")]
	public TargetException(string message, Exception inner) { }

	[Address(RVA = "0x731811C", Offset = "0x731811C", Length = "0x8")]
	[Token(Token = "0x60026C6")]
	protected TargetException(SerializationInfo info, StreamingContext context) { }

}

