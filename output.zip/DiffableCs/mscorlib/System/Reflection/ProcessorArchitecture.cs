namespace System.Reflection;

[Token(Token = "0x200051C")]
public enum ProcessorArchitecture
{
	None = 0,
	MSIL = 1,
	X86 = 2,
	IA64 = 3,
	Amd64 = 4,
	Arm = 5,
}

