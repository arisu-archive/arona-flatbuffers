namespace System.Reflection;

[Token(Token = "0x200050B")]
public interface IReflectableType
{

	[Token(Token = "0x6002588")]
	public TypeInfo GetTypeInfo() { }

}

