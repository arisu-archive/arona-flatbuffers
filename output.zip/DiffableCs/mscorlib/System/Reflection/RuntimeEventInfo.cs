namespace System.Reflection;

[Token(Token = "0x2000541")]
internal sealed class RuntimeEventInfo : EventInfo, ISerializable
{
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40015B7")]
	private IntPtr klass; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40015B8")]
	private IntPtr handle; //Field offset: 0x20

	[Token(Token = "0x170005A2")]
	internal BindingFlags BindingFlags
	{
		[Address(RVA = "0x731FC3C", Offset = "0x731FC3C", Length = "0x4")]
		[Token(Token = "0x60027BE")]
		internal get { } //Length: 4
	}

	[Token(Token = "0x170005A4")]
	public virtual Type DeclaringType
	{
		[Address(RVA = "0x732008C", Offset = "0x732008C", Length = "0x2C")]
		[Token(Token = "0x60027C7")]
		 get { } //Length: 44
	}

	[Token(Token = "0x170005A7")]
	public virtual int MetadataToken
	{
		[Address(RVA = "0x73202F0", Offset = "0x73202F0", Length = "0x4")]
		[Token(Token = "0x60027CF")]
		 get { } //Length: 4
	}

	[Token(Token = "0x170005A1")]
	public virtual Module Module
	{
		[Address(RVA = "0x731FC1C", Offset = "0x731FC1C", Length = "0x4")]
		[Token(Token = "0x60027BD")]
		 get { } //Length: 4
	}

	[Token(Token = "0x170005A6")]
	public virtual string Name
	{
		[Address(RVA = "0x73200E4", Offset = "0x73200E4", Length = "0x2C")]
		[Token(Token = "0x60027C9")]
		 get { } //Length: 44
	}

	[Token(Token = "0x170005A5")]
	public virtual Type ReflectedType
	{
		[Address(RVA = "0x73200B8", Offset = "0x73200B8", Length = "0x2C")]
		[Token(Token = "0x60027C8")]
		 get { } //Length: 44
	}

	[Token(Token = "0x170005A3")]
	private RuntimeType ReflectedTypeInternal
	{
		[Address(RVA = "0x731FE28", Offset = "0x731FE28", Length = "0x88")]
		[Token(Token = "0x60027C0")]
		private get { } //Length: 136
	}

	[Address(RVA = "0x7320350", Offset = "0x7320350", Length = "0x8")]
	[Token(Token = "0x60027D2")]
	public RuntimeEventInfo() { }

	[Address(RVA = "0x731FC3C", Offset = "0x731FC3C", Length = "0x4")]
	[Token(Token = "0x60027BE")]
	internal BindingFlags get_BindingFlags() { }

	[Address(RVA = "0x732008C", Offset = "0x732008C", Length = "0x2C")]
	[Token(Token = "0x60027C7")]
	public virtual Type get_DeclaringType() { }

	[Address(RVA = "0x731FBDC", Offset = "0x731FBDC", Length = "0x4")]
	[Token(Token = "0x60027BB")]
	private static void get_event_info(RuntimeEventInfo ev, out MonoEventInfo info) { }

	[Address(RVA = "0x73202F4", Offset = "0x73202F4", Length = "0x4")]
	[Token(Token = "0x60027D1")]
	internal static int get_metadata_token(RuntimeEventInfo monoEvent) { }

	[Address(RVA = "0x73202F0", Offset = "0x73202F0", Length = "0x4")]
	[Token(Token = "0x60027CF")]
	public virtual int get_MetadataToken() { }

	[Address(RVA = "0x731FC1C", Offset = "0x731FC1C", Length = "0x4")]
	[Token(Token = "0x60027BD")]
	public virtual Module get_Module() { }

	[Address(RVA = "0x73200E4", Offset = "0x73200E4", Length = "0x2C")]
	[Token(Token = "0x60027C9")]
	public virtual string get_Name() { }

	[Address(RVA = "0x73200B8", Offset = "0x73200B8", Length = "0x2C")]
	[Token(Token = "0x60027C8")]
	public virtual Type get_ReflectedType() { }

	[Address(RVA = "0x731FE28", Offset = "0x731FE28", Length = "0x88")]
	[Token(Token = "0x60027C0")]
	private RuntimeType get_ReflectedTypeInternal() { }

	[Address(RVA = "0x731FF54", Offset = "0x731FF54", Length = "0x68")]
	[Token(Token = "0x60027C4")]
	public virtual MethodInfo GetAddMethod(bool nonPublic) { }

	[Address(RVA = "0x731FC40", Offset = "0x731FC40", Length = "0x160")]
	[Token(Token = "0x60027C3")]
	internal BindingFlags GetBindingFlags() { }

	[Address(RVA = "0x732027C", Offset = "0x732027C", Length = "0x70")]
	[Token(Token = "0x60027CD")]
	public virtual Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7320214", Offset = "0x7320214", Length = "0x68")]
	[Token(Token = "0x60027CC")]
	public virtual Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x73202EC", Offset = "0x73202EC", Length = "0x4")]
	[Token(Token = "0x60027CE")]
	public virtual IList<CustomAttributeData> GetCustomAttributesData() { }

	[Address(RVA = "0x731FDA0", Offset = "0x731FDA0", Length = "0x88")]
	[Token(Token = "0x60027BF")]
	internal RuntimeType GetDeclaringTypeInternal() { }

	[Address(RVA = "0x731FBE0", Offset = "0x731FBE0", Length = "0x3C")]
	[Token(Token = "0x60027BC")]
	internal static MonoEventInfo GetEventInfo(RuntimeEventInfo ev) { }

	[Address(RVA = "0x731FEB0", Offset = "0x731FEB0", Length = "0xA4")]
	[Token(Token = "0x60027C2")]
	public override void GetObjectData(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x731FFBC", Offset = "0x731FFBC", Length = "0x68")]
	[Token(Token = "0x60027C5")]
	public virtual MethodInfo GetRaiseMethod(bool nonPublic) { }

	[Address(RVA = "0x7320024", Offset = "0x7320024", Length = "0x68")]
	[Token(Token = "0x60027C6")]
	public virtual MethodInfo GetRemoveMethod(bool nonPublic) { }

	[Address(RVA = "0x731FC20", Offset = "0x731FC20", Length = "0x1C")]
	[Token(Token = "0x60027C1")]
	internal RuntimeModule GetRuntimeModule() { }

	[Address(RVA = "0x73202F8", Offset = "0x73202F8", Length = "0x58")]
	[Token(Token = "0x60027D0")]
	public virtual bool HasSameMetadataDefinitionAs(MemberInfo other) { }

	[Address(RVA = "0x73201A4", Offset = "0x73201A4", Length = "0x70")]
	[Token(Token = "0x60027CB")]
	public virtual bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7320110", Offset = "0x7320110", Length = "0x94")]
	[Token(Token = "0x60027CA")]
	public virtual string ToString() { }

}

