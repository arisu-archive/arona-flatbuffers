namespace System.Reflection;

[Token(Token = "0x2000531")]
public struct CustomAttributeTypedArgument
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x400151B")]
	private readonly Type <ArgumentType>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x400151C")]
	private readonly object <Value>k__BackingField; //Field offset: 0x8

	[Token(Token = "0x17000587")]
	public Type ArgumentType
	{
		[Address(RVA = "0x731A070", Offset = "0x731A070", Length = "0x8")]
		[CompilerGenerated]
		[IsReadOnly]
		[Token(Token = "0x6002712")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000588")]
	public object Value
	{
		[Address(RVA = "0x731A078", Offset = "0x731A078", Length = "0x8")]
		[CompilerGenerated]
		[IsReadOnly]
		[Token(Token = "0x6002713")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x7319F1C", Offset = "0x7319F1C", Length = "0x9C")]
	[Token(Token = "0x6002710")]
	public CustomAttributeTypedArgument(object value) { }

	[Address(RVA = "0x731261C", Offset = "0x731261C", Length = "0x2E8")]
	[Token(Token = "0x6002711")]
	public CustomAttributeTypedArgument(Type argumentType, object value) { }

	[Address(RVA = "0x7319FB8", Offset = "0x7319FB8", Length = "0xB8")]
	[Token(Token = "0x600271A")]
	private static object CanonicalizeValue(object value) { }

	[Address(RVA = "0x731A080", Offset = "0x731A080", Length = "0x70")]
	[Token(Token = "0x6002714")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x731A070", Offset = "0x731A070", Length = "0x8")]
	[CompilerGenerated]
	[IsReadOnly]
	[Token(Token = "0x6002712")]
	public Type get_ArgumentType() { }

	[Address(RVA = "0x731A078", Offset = "0x731A078", Length = "0x8")]
	[CompilerGenerated]
	[IsReadOnly]
	[Token(Token = "0x6002713")]
	public object get_Value() { }

	[Address(RVA = "0x731A0F0", Offset = "0x731A0F0", Length = "0x64")]
	[Token(Token = "0x6002715")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x731A154", Offset = "0x731A154", Length = "0x78")]
	[Token(Token = "0x6002716")]
	public static bool op_Equality(CustomAttributeTypedArgument left, CustomAttributeTypedArgument right) { }

	[Address(RVA = "0x731A1CC", Offset = "0x731A1CC", Length = "0x7C")]
	[Token(Token = "0x6002717")]
	public static bool op_Inequality(CustomAttributeTypedArgument left, CustomAttributeTypedArgument right) { }

	[Address(RVA = "0x731A248", Offset = "0x731A248", Length = "0x8")]
	[Token(Token = "0x6002718")]
	public virtual string ToString() { }

	[Address(RVA = "0x7319634", Offset = "0x7319634", Length = "0x8E8")]
	[Token(Token = "0x6002719")]
	internal string ToString(bool typed) { }

}

