namespace System.Reflection;

[AttributeUsage(AttributeTargets::Assembly (1), Inherited = False)]
[Token(Token = "0x20004F4")]
public sealed class AssemblyFileVersionAttribute : Attribute
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001430")]
	private readonly string <Version>k__BackingField; //Field offset: 0x10

	[Address(RVA = "0x7310C10", Offset = "0x7310C10", Length = "0x80")]
	[Token(Token = "0x6002535")]
	public AssemblyFileVersionAttribute(string version) { }

}

