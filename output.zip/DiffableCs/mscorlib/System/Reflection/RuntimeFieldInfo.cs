namespace System.Reflection;

[Token(Token = "0x2000543")]
internal class RuntimeFieldInfo : RtFieldInfo, ISerializable
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40015B9")]
	internal IntPtr klass; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40015BA")]
	internal RuntimeFieldHandle fhandle; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40015BB")]
	private string name; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40015BC")]
	private Type type; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40015BD")]
	private FieldAttributes attrs; //Field offset: 0x30

	[Token(Token = "0x170005AB")]
	public virtual FieldAttributes Attributes
	{
		[Address(RVA = "0x73208AC", Offset = "0x73208AC", Length = "0x8")]
		[Token(Token = "0x60027E1")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005A8")]
	internal BindingFlags BindingFlags
	{
		[Address(RVA = "0x7320360", Offset = "0x7320360", Length = "0x8")]
		[Token(Token = "0x60027D7")]
		internal get { } //Length: 8
	}

	[Token(Token = "0x170005AF")]
	public virtual Type DeclaringType
	{
		[Address(RVA = "0x7320954", Offset = "0x7320954", Length = "0x8")]
		[Token(Token = "0x60027E7")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005AC")]
	public virtual RuntimeFieldHandle FieldHandle
	{
		[Address(RVA = "0x73208B4", Offset = "0x73208B4", Length = "0x8")]
		[Token(Token = "0x60027E2")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005AD")]
	public virtual Type FieldType
	{
		[Address(RVA = "0x73208C0", Offset = "0x73208C0", Length = "0x88")]
		[Token(Token = "0x60027E4")]
		 get { } //Length: 136
	}

	[Token(Token = "0x170005B1")]
	public virtual int MetadataToken
	{
		[Address(RVA = "0x7321078", Offset = "0x7321078", Length = "0x4")]
		[Token(Token = "0x60027F6")]
		 get { } //Length: 4
	}

	[Token(Token = "0x170005A9")]
	public virtual Module Module
	{
		[Address(RVA = "0x7320368", Offset = "0x7320368", Length = "0x4")]
		[Token(Token = "0x60027D8")]
		 get { } //Length: 4
	}

	[Token(Token = "0x170005B0")]
	public virtual string Name
	{
		[Address(RVA = "0x732095C", Offset = "0x732095C", Length = "0x8")]
		[Token(Token = "0x60027E8")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005AE")]
	public virtual Type ReflectedType
	{
		[Address(RVA = "0x732094C", Offset = "0x732094C", Length = "0x8")]
		[Token(Token = "0x60027E6")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005AA")]
	private RuntimeType ReflectedTypeInternal
	{
		[Address(RVA = "0x7320410", Offset = "0x7320410", Length = "0x88")]
		[Token(Token = "0x60027DA")]
		private get { } //Length: 136
	}

	[Address(RVA = "0x7321080", Offset = "0x7321080", Length = "0x8")]
	[Token(Token = "0x60027F8")]
	public RuntimeFieldInfo() { }

	[Address(RVA = "0x732055C", Offset = "0x732055C", Length = "0x188")]
	[Token(Token = "0x60027DE")]
	internal virtual void CheckConsistency(object target) { }

	[Address(RVA = "0x7320C5C", Offset = "0x7320C5C", Length = "0x84")]
	[Token(Token = "0x60027F4")]
	private void CheckGeneric() { }

	[Address(RVA = "0x73208AC", Offset = "0x73208AC", Length = "0x8")]
	[Token(Token = "0x60027E1")]
	public virtual FieldAttributes get_Attributes() { }

	[Address(RVA = "0x7320360", Offset = "0x7320360", Length = "0x8")]
	[Token(Token = "0x60027D7")]
	internal BindingFlags get_BindingFlags() { }

	[Address(RVA = "0x7320954", Offset = "0x7320954", Length = "0x8")]
	[Token(Token = "0x60027E7")]
	public virtual Type get_DeclaringType() { }

	[Address(RVA = "0x73208B4", Offset = "0x73208B4", Length = "0x8")]
	[Token(Token = "0x60027E2")]
	public virtual RuntimeFieldHandle get_FieldHandle() { }

	[Address(RVA = "0x73208C0", Offset = "0x73208C0", Length = "0x88")]
	[Token(Token = "0x60027E4")]
	public virtual Type get_FieldType() { }

	[Address(RVA = "0x732107C", Offset = "0x732107C", Length = "0x4")]
	[Token(Token = "0x60027F7")]
	internal static int get_metadata_token(RuntimeFieldInfo monoField) { }

	[Address(RVA = "0x7321078", Offset = "0x7321078", Length = "0x4")]
	[Token(Token = "0x60027F6")]
	public virtual int get_MetadataToken() { }

	[Address(RVA = "0x7320368", Offset = "0x7320368", Length = "0x4")]
	[Token(Token = "0x60027D8")]
	public virtual Module get_Module() { }

	[Address(RVA = "0x732095C", Offset = "0x732095C", Length = "0x8")]
	[Token(Token = "0x60027E8")]
	public virtual string get_Name() { }

	[Address(RVA = "0x732094C", Offset = "0x732094C", Length = "0x8")]
	[Token(Token = "0x60027E6")]
	public virtual Type get_ReflectedType() { }

	[Address(RVA = "0x7320410", Offset = "0x7320410", Length = "0x88")]
	[Token(Token = "0x60027DA")]
	private RuntimeType get_ReflectedTypeInternal() { }

	[Address(RVA = "0x7320A3C", Offset = "0x7320A3C", Length = "0x70")]
	[Token(Token = "0x60027EB")]
	public virtual Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x73209D4", Offset = "0x73209D4", Length = "0x68")]
	[Token(Token = "0x60027EA")]
	public virtual Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x732101C", Offset = "0x732101C", Length = "0x4")]
	[Token(Token = "0x60027F3")]
	public virtual IList<CustomAttributeData> GetCustomAttributesData() { }

	[Address(RVA = "0x7320388", Offset = "0x7320388", Length = "0x88")]
	[Token(Token = "0x60027D9")]
	internal RuntimeType GetDeclaringTypeInternal() { }

	[Address(RVA = "0x7320AAC", Offset = "0x7320AAC", Length = "0x4")]
	[Token(Token = "0x60027EC")]
	internal virtual int GetFieldOffset() { }

	[Address(RVA = "0x7320498", Offset = "0x7320498", Length = "0xC0")]
	[Token(Token = "0x60027DC")]
	public override void GetObjectData(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x7320948", Offset = "0x7320948", Length = "0x4")]
	[Token(Token = "0x60027E5")]
	private Type GetParentType(bool declaring) { }

	[Address(RVA = "0x7321018", Offset = "0x7321018", Length = "0x4")]
	[Token(Token = "0x60027F2")]
	public virtual object GetRawConstantValue() { }

	[Address(RVA = "0x732036C", Offset = "0x732036C", Length = "0x1C")]
	[Token(Token = "0x60027DB")]
	internal RuntimeModule GetRuntimeModule() { }

	[Address(RVA = "0x7320AB4", Offset = "0x7320AB4", Length = "0x1A8")]
	[Token(Token = "0x60027EE")]
	public virtual object GetValue(object obj) { }

	[Address(RVA = "0x7320AB0", Offset = "0x7320AB0", Length = "0x4")]
	[Token(Token = "0x60027ED")]
	private object GetValueInternal(object obj) { }

	[Address(RVA = "0x7321020", Offset = "0x7321020", Length = "0x58")]
	[Token(Token = "0x60027F5")]
	public virtual bool HasSameMetadataDefinitionAs(MemberInfo other) { }

	[Address(RVA = "0x7320964", Offset = "0x7320964", Length = "0x70")]
	[Token(Token = "0x60027E9")]
	public virtual bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x73208BC", Offset = "0x73208BC", Length = "0x4")]
	[Token(Token = "0x60027E3")]
	private Type ResolveType() { }

	[Address(RVA = "0x7320D48", Offset = "0x7320D48", Length = "0x2D0")]
	[Token(Token = "0x60027F1")]
	public virtual void SetValue(object obj, object val, BindingFlags invokeAttr, Binder binder, CultureInfo culture) { }

	[Address(RVA = "0x7320744", Offset = "0x7320744", Length = "0x168")]
	[DebuggerHidden]
	[DebuggerStepThrough]
	[Token(Token = "0x60027E0")]
	public virtual void SetValueDirect(TypedReference obj, object value) { }

	[Address(RVA = "0x7320D44", Offset = "0x7320D44", Length = "0x4")]
	[Token(Token = "0x60027F0")]
	private static void SetValueInternal(FieldInfo fi, object obj, object value) { }

	[Address(RVA = "0x7320CE0", Offset = "0x7320CE0", Length = "0x64")]
	[Token(Token = "0x60027EF")]
	public virtual string ToString() { }

	[Address(RVA = "0x7320558", Offset = "0x7320558", Length = "0x4")]
	[Token(Token = "0x60027DD")]
	internal virtual object UnsafeGetValue(object obj) { }

	[Address(RVA = "0x73206E4", Offset = "0x73206E4", Length = "0x60")]
	[DebuggerHidden]
	[DebuggerStepThrough]
	[Token(Token = "0x60027DF")]
	internal virtual void UnsafeSetValue(object obj, object value, BindingFlags invokeAttr, Binder binder, CultureInfo culture) { }

}

