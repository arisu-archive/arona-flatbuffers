namespace System.Reflection;

[Token(Token = "0x2000524")]
internal abstract class SignatureHasElementType : SignatureType
{
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40014F2")]
	private readonly SignatureType _elementType; //Field offset: 0x18

	[Token(Token = "0x17000549")]
	public virtual bool ContainsGenericParameters
	{
		[Address(RVA = "0x7315EF8", Offset = "0x7315EF8", Length = "0x24")]
		[Token(Token = "0x6002653")]
		 get { } //Length: 36
	}

	[Token(Token = "0x1700054A")]
	internal virtual SignatureType ElementType
	{
		[Address(RVA = "0x7315F1C", Offset = "0x7315F1C", Length = "0x8")]
		[Token(Token = "0x6002654")]
		internal get { } //Length: 8
	}

	[Token(Token = "0x1700054C")]
	public virtual int GenericParameterPosition
	{
		[Address(RVA = "0x731606C", Offset = "0x731606C", Length = "0x50")]
		[Token(Token = "0x6002659")]
		 get { } //Length: 80
	}

	[Token(Token = "0x1700054B")]
	public virtual Type[] GenericTypeArguments
	{
		[Address(RVA = "0x7315FF0", Offset = "0x7315FF0", Length = "0x7C")]
		[Token(Token = "0x6002658")]
		 get { } //Length: 124
	}

	[Token(Token = "0x17000546")]
	public virtual bool IsConstructedGenericType
	{
		[Address(RVA = "0x7315EE0", Offset = "0x7315EE0", Length = "0x8")]
		[Token(Token = "0x6002650")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000548")]
	public virtual bool IsGenericMethodParameter
	{
		[Address(RVA = "0x7315EF0", Offset = "0x7315EF0", Length = "0x8")]
		[Token(Token = "0x6002652")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000547")]
	public virtual bool IsGenericParameter
	{
		[Address(RVA = "0x7315EE8", Offset = "0x7315EE8", Length = "0x8")]
		[Token(Token = "0x6002651")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000543")]
	public virtual bool IsGenericTypeDefinition
	{
		[Address(RVA = "0x7315ED0", Offset = "0x7315ED0", Length = "0x8")]
		[Token(Token = "0x6002649")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000544")]
	public abstract bool IsSZArray
	{
		[Token(Token = "0x600264E")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000545")]
	public abstract bool IsVariableBoundArray
	{
		[Token(Token = "0x600264F")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700054D")]
	public virtual string Name
	{
		[Address(RVA = "0x73160BC", Offset = "0x73160BC", Length = "0x58")]
		[Token(Token = "0x600265A")]
		 get { } //Length: 88
	}

	[Token(Token = "0x1700054E")]
	public virtual string Namespace
	{
		[Address(RVA = "0x7316114", Offset = "0x7316114", Length = "0x24")]
		[Token(Token = "0x600265B")]
		 get { } //Length: 36
	}

	[Token(Token = "0x1700054F")]
	protected abstract string Suffix
	{
		[Token(Token = "0x600265D")]
		 get { } //Length: 0
	}

	[Address(RVA = "0x7315744", Offset = "0x7315744", Length = "0x2C")]
	[Token(Token = "0x6002648")]
	protected SignatureHasElementType(SignatureType elementType) { }

	[Address(RVA = "0x7315EF8", Offset = "0x7315EF8", Length = "0x24")]
	[Token(Token = "0x6002653")]
	public virtual bool get_ContainsGenericParameters() { }

	[Address(RVA = "0x7315F1C", Offset = "0x7315F1C", Length = "0x8")]
	[Token(Token = "0x6002654")]
	internal virtual SignatureType get_ElementType() { }

	[Address(RVA = "0x731606C", Offset = "0x731606C", Length = "0x50")]
	[Token(Token = "0x6002659")]
	public virtual int get_GenericParameterPosition() { }

	[Address(RVA = "0x7315FF0", Offset = "0x7315FF0", Length = "0x7C")]
	[Token(Token = "0x6002658")]
	public virtual Type[] get_GenericTypeArguments() { }

	[Address(RVA = "0x7315EE0", Offset = "0x7315EE0", Length = "0x8")]
	[Token(Token = "0x6002650")]
	public virtual bool get_IsConstructedGenericType() { }

	[Address(RVA = "0x7315EF0", Offset = "0x7315EF0", Length = "0x8")]
	[Token(Token = "0x6002652")]
	public virtual bool get_IsGenericMethodParameter() { }

	[Address(RVA = "0x7315EE8", Offset = "0x7315EE8", Length = "0x8")]
	[Token(Token = "0x6002651")]
	public virtual bool get_IsGenericParameter() { }

	[Address(RVA = "0x7315ED0", Offset = "0x7315ED0", Length = "0x8")]
	[Token(Token = "0x6002649")]
	public virtual bool get_IsGenericTypeDefinition() { }

	[Token(Token = "0x600264E")]
	public abstract bool get_IsSZArray() { }

	[Token(Token = "0x600264F")]
	public abstract bool get_IsVariableBoundArray() { }

	[Address(RVA = "0x73160BC", Offset = "0x73160BC", Length = "0x58")]
	[Token(Token = "0x600265A")]
	public virtual string get_Name() { }

	[Address(RVA = "0x7316114", Offset = "0x7316114", Length = "0x24")]
	[Token(Token = "0x600265B")]
	public virtual string get_Namespace() { }

	[Token(Token = "0x600265D")]
	protected abstract string get_Suffix() { }

	[Token(Token = "0x6002655")]
	public abstract int GetArrayRank() { }

	[Address(RVA = "0x7315F74", Offset = "0x7315F74", Length = "0x7C")]
	[Token(Token = "0x6002657")]
	public virtual Type[] GetGenericArguments() { }

	[Address(RVA = "0x7315F24", Offset = "0x7315F24", Length = "0x50")]
	[Token(Token = "0x6002656")]
	public virtual Type GetGenericTypeDefinition() { }

	[Address(RVA = "0x7315ED8", Offset = "0x7315ED8", Length = "0x8")]
	[Token(Token = "0x600264A")]
	protected virtual bool HasElementTypeImpl() { }

	[Token(Token = "0x600264B")]
	protected abstract bool IsArrayImpl() { }

	[Token(Token = "0x600264C")]
	protected abstract bool IsByRefImpl() { }

	[Token(Token = "0x600264D")]
	protected abstract bool IsPointerImpl() { }

	[Address(RVA = "0x7316138", Offset = "0x7316138", Length = "0x54")]
	[Token(Token = "0x600265C")]
	public virtual string ToString() { }

}

