namespace System.Reflection;

[Token(Token = "0x2000525")]
internal sealed class SignaturePointerType : SignatureHasElementType
{

	[Token(Token = "0x17000550")]
	public virtual bool IsSZArray
	{
		[Address(RVA = "0x73161D0", Offset = "0x73161D0", Length = "0x8")]
		[Token(Token = "0x6002662")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000551")]
	public virtual bool IsVariableBoundArray
	{
		[Address(RVA = "0x73161D8", Offset = "0x73161D8", Length = "0x8")]
		[Token(Token = "0x6002663")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000552")]
	protected virtual string Suffix
	{
		[Address(RVA = "0x7316230", Offset = "0x7316230", Length = "0x40")]
		[Token(Token = "0x6002665")]
		 get { } //Length: 64
	}

	[Address(RVA = "0x731618C", Offset = "0x731618C", Length = "0x2C")]
	[Token(Token = "0x600265E")]
	internal SignaturePointerType(SignatureType elementType) { }

	[Address(RVA = "0x73161D0", Offset = "0x73161D0", Length = "0x8")]
	[Token(Token = "0x6002662")]
	public virtual bool get_IsSZArray() { }

	[Address(RVA = "0x73161D8", Offset = "0x73161D8", Length = "0x8")]
	[Token(Token = "0x6002663")]
	public virtual bool get_IsVariableBoundArray() { }

	[Address(RVA = "0x7316230", Offset = "0x7316230", Length = "0x40")]
	[Token(Token = "0x6002665")]
	protected virtual string get_Suffix() { }

	[Address(RVA = "0x73161E0", Offset = "0x73161E0", Length = "0x50")]
	[Token(Token = "0x6002664")]
	public virtual int GetArrayRank() { }

	[Address(RVA = "0x73161B8", Offset = "0x73161B8", Length = "0x8")]
	[Token(Token = "0x600265F")]
	protected virtual bool IsArrayImpl() { }

	[Address(RVA = "0x73161C0", Offset = "0x73161C0", Length = "0x8")]
	[Token(Token = "0x6002660")]
	protected virtual bool IsByRefImpl() { }

	[Address(RVA = "0x73161C8", Offset = "0x73161C8", Length = "0x8")]
	[Token(Token = "0x6002661")]
	protected virtual bool IsPointerImpl() { }

}

