namespace System.Reflection;

[AttributeUsage(AttributeTargets::Assembly (1), AllowMultiple = True, Inherited = False)]
[Token(Token = "0x20004F8")]
public sealed class AssemblyMetadataAttribute : Attribute
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001434")]
	private readonly string <Key>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001435")]
	private readonly string <Value>k__BackingField; //Field offset: 0x18

	[Address(RVA = "0x7310D20", Offset = "0x7310D20", Length = "0x44")]
	[Token(Token = "0x6002539")]
	public AssemblyMetadataAttribute(string key, string value) { }

}

