namespace System.Reflection;

[Token(Token = "0x2000516")]
public sealed class Missing : ISerializable
{
	[Token(Token = "0x40014BE")]
	public static readonly Missing Value; //Field offset: 0x0

	[Address(RVA = "0x73142E0", Offset = "0x73142E0", Length = "0x70")]
	[Token(Token = "0x60025E1")]
	private static Missing() { }

	[Address(RVA = "0x7314298", Offset = "0x7314298", Length = "0x8")]
	[Token(Token = "0x60025DF")]
	private Missing() { }

	[Address(RVA = "0x73142A0", Offset = "0x73142A0", Length = "0x40")]
	[Token(Token = "0x60025E0")]
	private override void System.Runtime.Serialization.ISerializable.GetObjectData(SerializationInfo info, StreamingContext context) { }

}

