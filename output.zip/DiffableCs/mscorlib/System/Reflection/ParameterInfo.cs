namespace System.Reflection;

[Token(Token = "0x2000519")]
public class ParameterInfo : ICustomAttributeProvider, IObjectReference, _ParameterInfo
{
	[Token(Token = "0x40014D4")]
	private const int MetadataToken_ParamDef = 134217728; //Field offset: 0x0
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40014CE")]
	protected ParameterAttributes AttrsImpl; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40014CF")]
	protected Type ClassImpl; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40014D0")]
	protected object DefaultValueImpl; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40014D1")]
	protected MemberInfo MemberImpl; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40014D2")]
	protected string NameImpl; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40014D3")]
	protected int PositionImpl; //Field offset: 0x38

	[Token(Token = "0x17000520")]
	public override ParameterAttributes Attributes
	{
		[Address(RVA = "0x7314A1C", Offset = "0x7314A1C", Length = "0x8")]
		[Token(Token = "0x60025F5")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000528")]
	public override object DefaultValue
	{
		[Address(RVA = "0x7314A98", Offset = "0x7314A98", Length = "0x28")]
		[Token(Token = "0x60025FD")]
		 get { } //Length: 40
	}

	[Token(Token = "0x17000525")]
	public bool IsIn
	{
		[Address(RVA = "0x7314A44", Offset = "0x7314A44", Length = "0x1C")]
		[Token(Token = "0x60025FA")]
		 get { } //Length: 28
	}

	[Token(Token = "0x17000526")]
	public bool IsOptional
	{
		[Address(RVA = "0x7314A60", Offset = "0x7314A60", Length = "0x1C")]
		[Token(Token = "0x60025FB")]
		 get { } //Length: 28
	}

	[Token(Token = "0x17000527")]
	public bool IsOut
	{
		[Address(RVA = "0x7314A7C", Offset = "0x7314A7C", Length = "0x1C")]
		[Token(Token = "0x60025FC")]
		 get { } //Length: 28
	}

	[Token(Token = "0x17000521")]
	public override MemberInfo Member
	{
		[Address(RVA = "0x7314A24", Offset = "0x7314A24", Length = "0x8")]
		[Token(Token = "0x60025F6")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000522")]
	public override string Name
	{
		[Address(RVA = "0x7314A2C", Offset = "0x7314A2C", Length = "0x8")]
		[Token(Token = "0x60025F7")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000523")]
	public override Type ParameterType
	{
		[Address(RVA = "0x7314A34", Offset = "0x7314A34", Length = "0x8")]
		[Token(Token = "0x60025F8")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000524")]
	public override int Position
	{
		[Address(RVA = "0x7314A3C", Offset = "0x7314A3C", Length = "0x8")]
		[Token(Token = "0x60025F9")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x7314A14", Offset = "0x7314A14", Length = "0x8")]
	[Token(Token = "0x60025F4")]
	protected ParameterInfo() { }

	[Address(RVA = "0x7314A1C", Offset = "0x7314A1C", Length = "0x8")]
	[Token(Token = "0x60025F5")]
	public override ParameterAttributes get_Attributes() { }

	[Address(RVA = "0x7314A98", Offset = "0x7314A98", Length = "0x28")]
	[Token(Token = "0x60025FD")]
	public override object get_DefaultValue() { }

	[Address(RVA = "0x7314A44", Offset = "0x7314A44", Length = "0x1C")]
	[Token(Token = "0x60025FA")]
	public bool get_IsIn() { }

	[Address(RVA = "0x7314A60", Offset = "0x7314A60", Length = "0x1C")]
	[Token(Token = "0x60025FB")]
	public bool get_IsOptional() { }

	[Address(RVA = "0x7314A7C", Offset = "0x7314A7C", Length = "0x1C")]
	[Token(Token = "0x60025FC")]
	public bool get_IsOut() { }

	[Address(RVA = "0x7314A24", Offset = "0x7314A24", Length = "0x8")]
	[Token(Token = "0x60025F6")]
	public override MemberInfo get_Member() { }

	[Address(RVA = "0x7314A2C", Offset = "0x7314A2C", Length = "0x8")]
	[Token(Token = "0x60025F7")]
	public override string get_Name() { }

	[Address(RVA = "0x7314A34", Offset = "0x7314A34", Length = "0x8")]
	[Token(Token = "0x60025F8")]
	public override Type get_ParameterType() { }

	[Address(RVA = "0x7314A3C", Offset = "0x7314A3C", Length = "0x8")]
	[Token(Token = "0x60025F9")]
	public override int get_Position() { }

	[Address(RVA = "0x7314B74", Offset = "0x7314B74", Length = "0x7C")]
	[Token(Token = "0x60025FF")]
	public override Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x7314BF0", Offset = "0x7314BF0", Length = "0x104")]
	[Token(Token = "0x6002600")]
	public override Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7314CF4", Offset = "0x7314CF4", Length = "0x264")]
	[Token(Token = "0x6002601")]
	public override object GetRealObject(StreamingContext context) { }

	[Address(RVA = "0x7314AC0", Offset = "0x7314AC0", Length = "0xB4")]
	[Token(Token = "0x60025FE")]
	public override bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7314F58", Offset = "0x7314F58", Length = "0x84")]
	[Token(Token = "0x6002602")]
	public virtual string ToString() { }

}

