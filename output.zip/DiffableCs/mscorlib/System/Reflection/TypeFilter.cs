namespace System.Reflection;

[Token(Token = "0x200052D")]
public sealed class TypeFilter : MulticastDelegate
{

	[Address(RVA = "0x73148D0", Offset = "0x73148D0", Length = "0x144")]
	[Token(Token = "0x60026F8")]
	public TypeFilter(object object, IntPtr method) { }

	[Address(RVA = "0x7318924", Offset = "0x7318924", Length = "0x14")]
	[Token(Token = "0x60026F9")]
	public override bool Invoke(Type m, object filterCriteria) { }

}

