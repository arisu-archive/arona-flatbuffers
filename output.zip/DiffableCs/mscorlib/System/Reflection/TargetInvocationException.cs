namespace System.Reflection;

[Token(Token = "0x2000529")]
public sealed class TargetInvocationException : ApplicationException
{

	[Address(RVA = "0x7318124", Offset = "0x7318124", Length = "0x6C")]
	[Token(Token = "0x60026C7")]
	public TargetInvocationException(Exception inner) { }

	[Address(RVA = "0x7318190", Offset = "0x7318190", Length = "0x24")]
	[Token(Token = "0x60026C8")]
	public TargetInvocationException(string message, Exception inner) { }

	[Address(RVA = "0x73181B4", Offset = "0x73181B4", Length = "0x8")]
	[Token(Token = "0x60026C9")]
	internal TargetInvocationException(SerializationInfo info, StreamingContext context) { }

}

