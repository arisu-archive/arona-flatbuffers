namespace System.Reflection;

[Token(Token = "0x2000546")]
internal class RuntimeConstructorInfo : ConstructorInfo, ISerializable
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40015C6")]
	internal IntPtr mhandle; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40015C7")]
	private string name; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40015C8")]
	private Type reftype; //Field offset: 0x20

	[Token(Token = "0x170005C6")]
	public virtual MethodAttributes Attributes
	{
		[Address(RVA = "0x7323994", Offset = "0x7323994", Length = "0x8")]
		[Token(Token = "0x600284D")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005C3")]
	internal BindingFlags BindingFlags
	{
		[Address(RVA = "0x73231EC", Offset = "0x73231EC", Length = "0x8")]
		[Token(Token = "0x600283E")]
		internal get { } //Length: 8
	}

	[Token(Token = "0x170005C7")]
	public virtual CallingConventions CallingConvention
	{
		[Address(RVA = "0x732399C", Offset = "0x732399C", Length = "0x2C")]
		[Token(Token = "0x600284E")]
		 get { } //Length: 44
	}

	[Token(Token = "0x170005C8")]
	public virtual bool ContainsGenericParameters
	{
		[Address(RVA = "0x73239C8", Offset = "0x73239C8", Length = "0x30")]
		[Token(Token = "0x600284F")]
		 get { } //Length: 48
	}

	[Token(Token = "0x170005CA")]
	public virtual Type DeclaringType
	{
		[Address(RVA = "0x7323A00", Offset = "0x7323A00", Length = "0x2C")]
		[Token(Token = "0x6002851")]
		 get { } //Length: 44
	}

	[Token(Token = "0x170005CC")]
	public virtual bool IsSecurityCritical
	{
		[Address(RVA = "0x7323C54", Offset = "0x7323C54", Length = "0x8")]
		[Token(Token = "0x600285A")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005CD")]
	public virtual int MetadataToken
	{
		[Address(RVA = "0x7323C5C", Offset = "0x7323C5C", Length = "0x4")]
		[Token(Token = "0x600285B")]
		 get { } //Length: 4
	}

	[Token(Token = "0x170005C5")]
	public virtual RuntimeMethodHandle MethodHandle
	{
		[Address(RVA = "0x732398C", Offset = "0x732398C", Length = "0x8")]
		[Token(Token = "0x600284C")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005C2")]
	public virtual Module Module
	{
		[Address(RVA = "0x732315C", Offset = "0x732315C", Length = "0x4")]
		[Token(Token = "0x600283C")]
		 get { } //Length: 4
	}

	[Token(Token = "0x170005CB")]
	public virtual string Name
	{
		[Address(RVA = "0x7323A2C", Offset = "0x7323A2C", Length = "0x14")]
		[Token(Token = "0x6002852")]
		 get { } //Length: 20
	}

	[Token(Token = "0x170005C9")]
	public virtual Type ReflectedType
	{
		[Address(RVA = "0x73239F8", Offset = "0x73239F8", Length = "0x8")]
		[Token(Token = "0x6002850")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005C4")]
	private RuntimeType ReflectedTypeInternal
	{
		[Address(RVA = "0x73231F4", Offset = "0x73231F4", Length = "0x88")]
		[Token(Token = "0x600283F")]
		private get { } //Length: 136
	}

	[Address(RVA = "0x7323C64", Offset = "0x7323C64", Length = "0x58")]
	[Token(Token = "0x600285D")]
	public RuntimeConstructorInfo() { }

	[Address(RVA = "0x7323610", Offset = "0x7323610", Length = "0x204")]
	[Token(Token = "0x6002849")]
	private object DoInvoke(object obj, BindingFlags invokeAttr, Binder binder, Object[] parameters, CultureInfo culture) { }

	[Address(RVA = "0x7323994", Offset = "0x7323994", Length = "0x8")]
	[Token(Token = "0x600284D")]
	public virtual MethodAttributes get_Attributes() { }

	[Address(RVA = "0x73231EC", Offset = "0x73231EC", Length = "0x8")]
	[Token(Token = "0x600283E")]
	internal BindingFlags get_BindingFlags() { }

	[Address(RVA = "0x732399C", Offset = "0x732399C", Length = "0x2C")]
	[Token(Token = "0x600284E")]
	public virtual CallingConventions get_CallingConvention() { }

	[Address(RVA = "0x73239C8", Offset = "0x73239C8", Length = "0x30")]
	[Token(Token = "0x600284F")]
	public virtual bool get_ContainsGenericParameters() { }

	[Address(RVA = "0x7323BF4", Offset = "0x7323BF4", Length = "0x8")]
	[Token(Token = "0x6002858")]
	private static int get_core_clr_security_level() { }

	[Address(RVA = "0x7323A00", Offset = "0x7323A00", Length = "0x2C")]
	[Token(Token = "0x6002851")]
	public virtual Type get_DeclaringType() { }

	[Address(RVA = "0x7323C54", Offset = "0x7323C54", Length = "0x8")]
	[Token(Token = "0x600285A")]
	public virtual bool get_IsSecurityCritical() { }

	[Address(RVA = "0x7323C60", Offset = "0x7323C60", Length = "0x4")]
	[Token(Token = "0x600285C")]
	internal static int get_metadata_token(RuntimeConstructorInfo method) { }

	[Address(RVA = "0x7323C5C", Offset = "0x7323C5C", Length = "0x4")]
	[Token(Token = "0x600285B")]
	public virtual int get_MetadataToken() { }

	[Address(RVA = "0x732398C", Offset = "0x732398C", Length = "0x8")]
	[Token(Token = "0x600284C")]
	public virtual RuntimeMethodHandle get_MethodHandle() { }

	[Address(RVA = "0x732315C", Offset = "0x732315C", Length = "0x4")]
	[Token(Token = "0x600283C")]
	public virtual Module get_Module() { }

	[Address(RVA = "0x7323A2C", Offset = "0x7323A2C", Length = "0x14")]
	[Token(Token = "0x6002852")]
	public virtual string get_Name() { }

	[Address(RVA = "0x73239F8", Offset = "0x73239F8", Length = "0x8")]
	[Token(Token = "0x6002850")]
	public virtual Type get_ReflectedType() { }

	[Address(RVA = "0x73231F4", Offset = "0x73231F4", Length = "0x88")]
	[Token(Token = "0x600283F")]
	private RuntimeType get_ReflectedTypeInternal() { }

	[Address(RVA = "0x7323AB0", Offset = "0x7323AB0", Length = "0x68")]
	[Token(Token = "0x6002854")]
	public virtual Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x7323B18", Offset = "0x7323B18", Length = "0x70")]
	[Token(Token = "0x6002855")]
	public virtual Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7323BF0", Offset = "0x7323BF0", Length = "0x4")]
	[Token(Token = "0x6002857")]
	public virtual IList<CustomAttributeData> GetCustomAttributesData() { }

	[Address(RVA = "0x732349C", Offset = "0x732349C", Length = "0x2C")]
	[Token(Token = "0x6002843")]
	public virtual MethodImplAttributes GetMethodImplementationFlags() { }

	[Address(RVA = "0x732327C", Offset = "0x732327C", Length = "0xDC")]
	[Token(Token = "0x6002840")]
	public override void GetObjectData(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x73234C8", Offset = "0x73234C8", Length = "0xC")]
	[Token(Token = "0x6002844")]
	public virtual ParameterInfo[] GetParameters() { }

	[Address(RVA = "0x73234E0", Offset = "0x73234E0", Length = "0x20")]
	[Token(Token = "0x6002846")]
	internal virtual int GetParametersCount() { }

	[Address(RVA = "0x73234D4", Offset = "0x73234D4", Length = "0xC")]
	[Token(Token = "0x6002845")]
	internal virtual ParameterInfo[] GetParametersInternal() { }

	[Address(RVA = "0x7323160", Offset = "0x7323160", Length = "0x8C")]
	[Token(Token = "0x600283D")]
	internal RuntimeModule GetRuntimeModule() { }

	[Address(RVA = "0x7323BFC", Offset = "0x7323BFC", Length = "0x58")]
	[Token(Token = "0x6002859")]
	public virtual bool HasSameMetadataDefinitionAs(MemberInfo other) { }

	[Address(RVA = "0x7323814", Offset = "0x7323814", Length = "0x15C")]
	[Token(Token = "0x600284A")]
	public object InternalInvoke(object obj, Object[] parameters, bool wrapExceptions) { }

	[Address(RVA = "0x7323500", Offset = "0x7323500", Length = "0x4")]
	[Token(Token = "0x6002847")]
	internal object InternalInvoke(object obj, Object[] parameters, out Exception exc) { }

	[Address(RVA = "0x7323504", Offset = "0x7323504", Length = "0x10C")]
	[DebuggerHidden]
	[DebuggerStepThrough]
	[Token(Token = "0x6002848")]
	public virtual object Invoke(object obj, BindingFlags invokeAttr, Binder binder, Object[] parameters, CultureInfo culture) { }

	[Address(RVA = "0x7323970", Offset = "0x7323970", Length = "0x1C")]
	[DebuggerHidden]
	[DebuggerStepThrough]
	[Token(Token = "0x600284B")]
	public virtual object Invoke(BindingFlags invokeAttr, Binder binder, Object[] parameters, CultureInfo culture) { }

	[Address(RVA = "0x7323A40", Offset = "0x7323A40", Length = "0x70")]
	[Token(Token = "0x6002853")]
	public virtual bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7323358", Offset = "0x7323358", Length = "0x144")]
	[Token(Token = "0x6002842")]
	internal void SerializationInvoke(object target, SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x731B1F4", Offset = "0x731B1F4", Length = "0x14")]
	[Token(Token = "0x6002841")]
	internal string SerializationToString() { }

	[Address(RVA = "0x7323B88", Offset = "0x7323B88", Length = "0x68")]
	[Token(Token = "0x6002856")]
	public virtual string ToString() { }

}

