namespace System.Reflection;

[ClassInterface(ClassInterfaceType::None (0))]
[ComDefaultInterface(typeof(_Module))]
[ComVisible(True)]
[Token(Token = "0x2000547")]
internal class RuntimeModule : Module
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40015C9")]
	internal IntPtr _impl; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40015CA")]
	internal Assembly assembly; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40015CB")]
	internal string fqname; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40015CC")]
	internal string name; //Field offset: 0x28
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x40015CD")]
	internal string scopename; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x40015CE")]
	internal bool is_resource; //Field offset: 0x38
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x40015CF")]
	internal int token; //Field offset: 0x3C

	[Token(Token = "0x170005CE")]
	public virtual Assembly Assembly
	{
		[Address(RVA = "0x7323CBC", Offset = "0x7323CBC", Length = "0x8")]
		[Token(Token = "0x600285E")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005D1")]
	public virtual string FullyQualifiedName
	{
		[Address(RVA = "0x7323CDC", Offset = "0x7323CDC", Length = "0x8")]
		[Token(Token = "0x6002861")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005D0")]
	public virtual Guid ModuleVersionId
	{
		[Address(RVA = "0x7323CCC", Offset = "0x7323CCC", Length = "0x10")]
		[Token(Token = "0x6002860")]
		 get { } //Length: 16
	}

	[Token(Token = "0x170005CF")]
	public virtual string ScopeName
	{
		[Address(RVA = "0x7323CC4", Offset = "0x7323CC4", Length = "0x8")]
		[Token(Token = "0x600285F")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x7323FC4", Offset = "0x7323FC4", Length = "0x58")]
	[Token(Token = "0x600286A")]
	public RuntimeModule() { }

	[Address(RVA = "0x7323CBC", Offset = "0x7323CBC", Length = "0x8")]
	[Token(Token = "0x600285E")]
	public virtual Assembly get_Assembly() { }

	[Address(RVA = "0x7323CDC", Offset = "0x7323CDC", Length = "0x8")]
	[Token(Token = "0x6002861")]
	public virtual string get_FullyQualifiedName() { }

	[Address(RVA = "0x7323CCC", Offset = "0x7323CCC", Length = "0x10")]
	[Token(Token = "0x6002860")]
	public virtual Guid get_ModuleVersionId() { }

	[Address(RVA = "0x7323CC4", Offset = "0x7323CC4", Length = "0x8")]
	[Token(Token = "0x600285F")]
	public virtual string get_ScopeName() { }

	[Address(RVA = "0x7323CEC", Offset = "0x7323CEC", Length = "0x68")]
	[Token(Token = "0x6002863")]
	public virtual Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x7323D54", Offset = "0x7323D54", Length = "0x70")]
	[Token(Token = "0x6002864")]
	public virtual Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7323FC0", Offset = "0x7323FC0", Length = "0x4")]
	[Token(Token = "0x6002869")]
	private static void GetGuidInternal(IntPtr module, Byte[] guid) { }

	[Address(RVA = "0x7323F44", Offset = "0x7323F44", Length = "0x7C")]
	[Token(Token = "0x6002868")]
	internal virtual Guid GetModuleVersionId() { }

	[Address(RVA = "0x7323E34", Offset = "0x7323E34", Length = "0x98")]
	[Token(Token = "0x6002866")]
	public virtual void GetObjectData(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x7323ECC", Offset = "0x7323ECC", Length = "0x78")]
	[Token(Token = "0x6002867")]
	internal RuntimeAssembly GetRuntimeAssembly() { }

	[Address(RVA = "0x7323DC4", Offset = "0x7323DC4", Length = "0x70")]
	[Token(Token = "0x6002865")]
	public virtual bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7323CE4", Offset = "0x7323CE4", Length = "0x8")]
	[Token(Token = "0x6002862")]
	public virtual bool IsResource() { }

}

