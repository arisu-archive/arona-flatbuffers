namespace System.Reflection;

[Token(Token = "0x2000501")]
public class CustomAttributeFormatException : FormatException
{

	[Address(RVA = "0x7310FB0", Offset = "0x7310FB0", Length = "0x60")]
	[Token(Token = "0x600254D")]
	public CustomAttributeFormatException() { }

	[Address(RVA = "0x7311010", Offset = "0x7311010", Length = "0x28")]
	[Token(Token = "0x600254E")]
	public CustomAttributeFormatException(string message) { }

	[Address(RVA = "0x7311038", Offset = "0x7311038", Length = "0x24")]
	[Token(Token = "0x600254F")]
	public CustomAttributeFormatException(string message, Exception inner) { }

	[Address(RVA = "0x731105C", Offset = "0x731105C", Length = "0x8")]
	[Token(Token = "0x6002550")]
	protected CustomAttributeFormatException(SerializationInfo info, StreamingContext context) { }

}

