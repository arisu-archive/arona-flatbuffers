namespace System.Reflection;

[Token(Token = "0x20004EF")]
public enum AssemblyContentType
{
	Default = 0,
	WindowsRuntime = 1,
}

