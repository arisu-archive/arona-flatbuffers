namespace System.Reflection;

[Token(Token = "0x2000517")]
public abstract class Module : ICustomAttributeProvider, ISerializable, _Module
{
	[Token(Token = "0x40014BF")]
	public static readonly TypeFilter FilterTypeName; //Field offset: 0x0
	[Token(Token = "0x40014C1")]
	private const BindingFlags DefaultLookup = 28; //Field offset: 0x0
	[Token(Token = "0x40014C0")]
	public static readonly TypeFilter FilterTypeNameIgnoreCase; //Field offset: 0x8

	[Token(Token = "0x1700051C")]
	public override Assembly Assembly
	{
		[Address(RVA = "0x7314358", Offset = "0x7314358", Length = "0x28")]
		[Token(Token = "0x60025E3")]
		 get { } //Length: 40
	}

	[Token(Token = "0x1700051D")]
	public override string FullyQualifiedName
	{
		[Address(RVA = "0x7314380", Offset = "0x7314380", Length = "0x28")]
		[Token(Token = "0x60025E4")]
		 get { } //Length: 40
	}

	[Token(Token = "0x1700051E")]
	public override Guid ModuleVersionId
	{
		[Address(RVA = "0x73143A8", Offset = "0x73143A8", Length = "0x28")]
		[Token(Token = "0x60025E5")]
		 get { } //Length: 40
	}

	[Token(Token = "0x1700051F")]
	public override string ScopeName
	{
		[Address(RVA = "0x73143D0", Offset = "0x73143D0", Length = "0x28")]
		[Token(Token = "0x60025E6")]
		 get { } //Length: 40
	}

	[Address(RVA = "0x73147F0", Offset = "0x73147F0", Length = "0xE0")]
	[Token(Token = "0x60025F3")]
	private static Module() { }

	[Address(RVA = "0x7314350", Offset = "0x7314350", Length = "0x8")]
	[Token(Token = "0x60025E2")]
	protected Module() { }

	[Address(RVA = "0x73144C0", Offset = "0x73144C0", Length = "0x8")]
	[Token(Token = "0x60025EC")]
	public virtual bool Equals(object o) { }

	[Address(RVA = "0x7314644", Offset = "0x7314644", Length = "0x16C")]
	[Token(Token = "0x60025F1")]
	private static bool FilterTypeNameIgnoreCaseImpl(Type cls, object filterCriteria) { }

	[Address(RVA = "0x7314508", Offset = "0x7314508", Length = "0x13C")]
	[Token(Token = "0x60025F0")]
	private static bool FilterTypeNameImpl(Type cls, object filterCriteria) { }

	[Address(RVA = "0x7314358", Offset = "0x7314358", Length = "0x28")]
	[Token(Token = "0x60025E3")]
	public override Assembly get_Assembly() { }

	[Address(RVA = "0x7314380", Offset = "0x7314380", Length = "0x28")]
	[Token(Token = "0x60025E4")]
	public override string get_FullyQualifiedName() { }

	[Address(RVA = "0x73143A8", Offset = "0x73143A8", Length = "0x28")]
	[Token(Token = "0x60025E5")]
	public override Guid get_ModuleVersionId() { }

	[Address(RVA = "0x73143D0", Offset = "0x73143D0", Length = "0x28")]
	[Token(Token = "0x60025E6")]
	public override string get_ScopeName() { }

	[Address(RVA = "0x7314448", Offset = "0x7314448", Length = "0x28")]
	[Token(Token = "0x60025E9")]
	public override Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x7314470", Offset = "0x7314470", Length = "0x28")]
	[Token(Token = "0x60025EA")]
	public override Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x73144C8", Offset = "0x73144C8", Length = "0x8")]
	[Token(Token = "0x60025ED")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x73147B0", Offset = "0x73147B0", Length = "0x40")]
	[Token(Token = "0x60025F2")]
	internal override Guid GetModuleVersionId() { }

	[Address(RVA = "0x7314498", Offset = "0x7314498", Length = "0x28")]
	[Token(Token = "0x60025EB")]
	public override void GetObjectData(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x7314420", Offset = "0x7314420", Length = "0x28")]
	[Token(Token = "0x60025E8")]
	public override bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x73143F8", Offset = "0x73143F8", Length = "0x28")]
	[Token(Token = "0x60025E7")]
	public override bool IsResource() { }

	[Address(RVA = "0x73144D0", Offset = "0x73144D0", Length = "0x2C")]
	[Token(Token = "0x60025EE")]
	public static bool op_Equality(Module left, Module right) { }

	[Address(RVA = "0x73144FC", Offset = "0x73144FC", Length = "0xC")]
	[Token(Token = "0x60025EF")]
	public virtual string ToString() { }

}

