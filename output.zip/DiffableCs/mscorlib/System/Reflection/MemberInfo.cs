namespace System.Reflection;

[Token(Token = "0x2000510")]
public abstract class MemberInfo : ICustomAttributeProvider, _MemberInfo
{

	[Token(Token = "0x17000504")]
	public override IEnumerable<CustomAttributeData> CustomAttributes
	{
		[Address(RVA = "0x7312F18", Offset = "0x7312F18", Length = "0x10")]
		[Token(Token = "0x600259E")]
		 get { } //Length: 16
	}

	[Token(Token = "0x17000501")]
	public abstract Type DeclaringType
	{
		[Token(Token = "0x6002597")]
		 get { } //Length: 0
	}

	[Token(Token = "0x170004FF")]
	public abstract MemberTypes MemberType
	{
		[Token(Token = "0x6002595")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000505")]
	public override int MetadataToken
	{
		[Address(RVA = "0x7312F50", Offset = "0x7312F50", Length = "0x40")]
		[Token(Token = "0x60025A0")]
		 get { } //Length: 64
	}

	[Token(Token = "0x17000503")]
	public override Module Module
	{
		[Address(RVA = "0x7312E1C", Offset = "0x7312E1C", Length = "0xD4")]
		[Token(Token = "0x6002599")]
		 get { } //Length: 212
	}

	[Token(Token = "0x17000500")]
	public abstract string Name
	{
		[Token(Token = "0x6002596")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000502")]
	public abstract Type ReflectedType
	{
		[Token(Token = "0x6002598")]
		 get { } //Length: 0
	}

	[Address(RVA = "0x73110A4", Offset = "0x73110A4", Length = "0x8")]
	[Token(Token = "0x6002594")]
	protected MemberInfo() { }

	[Address(RVA = "0x73134E4", Offset = "0x73134E4", Length = "0x40")]
	[Token(Token = "0x60025A5")]
	internal override bool CacheEquals(object o) { }

	[Address(RVA = "0x73113B4", Offset = "0x73113B4", Length = "0x8")]
	[Token(Token = "0x60025A1")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x7312F18", Offset = "0x7312F18", Length = "0x10")]
	[Token(Token = "0x600259E")]
	public override IEnumerable<CustomAttributeData> get_CustomAttributes() { }

	[Token(Token = "0x6002597")]
	public abstract Type get_DeclaringType() { }

	[Token(Token = "0x6002595")]
	public abstract MemberTypes get_MemberType() { }

	[Address(RVA = "0x7312F50", Offset = "0x7312F50", Length = "0x40")]
	[Token(Token = "0x60025A0")]
	public override int get_MetadataToken() { }

	[Address(RVA = "0x7312E1C", Offset = "0x7312E1C", Length = "0xD4")]
	[Token(Token = "0x6002599")]
	public override Module get_Module() { }

	[Token(Token = "0x6002596")]
	public abstract string get_Name() { }

	[Token(Token = "0x6002598")]
	public abstract Type get_ReflectedType() { }

	[Token(Token = "0x600259C")]
	public abstract Object[] GetCustomAttributes(bool inherit) { }

	[Token(Token = "0x600259D")]
	public abstract Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7312F28", Offset = "0x7312F28", Length = "0x28")]
	[Token(Token = "0x600259F")]
	public override IList<CustomAttributeData> GetCustomAttributesData() { }

	[Address(RVA = "0x73113C4", Offset = "0x73113C4", Length = "0x8")]
	[Token(Token = "0x60025A2")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x7312EF0", Offset = "0x7312EF0", Length = "0x28")]
	[Token(Token = "0x600259A")]
	public override bool HasSameMetadataDefinitionAs(MemberInfo other) { }

	[Address(RVA = "0x437A044", Offset = "0x437A044", Length = "0x134")]
	[Token(Token = "0x60025A6")]
	internal bool HasSameMetadataDefinitionAsCore(MemberInfo other) { }

	[Token(Token = "0x600259B")]
	public abstract bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7312F90", Offset = "0x7312F90", Length = "0x320")]
	[Token(Token = "0x60025A3")]
	public static bool op_Equality(MemberInfo left, MemberInfo right) { }

	[Address(RVA = "0x73134CC", Offset = "0x73134CC", Length = "0x18")]
	[Token(Token = "0x60025A4")]
	public static bool op_Inequality(MemberInfo left, MemberInfo right) { }

	[Address(RVA = "0x7313524", Offset = "0x7313524", Length = "0x38")]
	[Token(Token = "0x60025A7")]
	private override void System.Runtime.InteropServices._MemberInfo.GetIDsOfNames(in Guid riid, IntPtr rgszNames, uint cNames, uint lcid, IntPtr rgDispId) { }

	[Address(RVA = "0x731355C", Offset = "0x731355C", Length = "0x38")]
	[Token(Token = "0x60025A8")]
	private override Type System.Runtime.InteropServices._MemberInfo.GetType() { }

	[Address(RVA = "0x7313594", Offset = "0x7313594", Length = "0x38")]
	[Token(Token = "0x60025A9")]
	private override void System.Runtime.InteropServices._MemberInfo.GetTypeInfo(uint iTInfo, uint lcid, IntPtr ppTInfo) { }

	[Address(RVA = "0x73135CC", Offset = "0x73135CC", Length = "0x38")]
	[Token(Token = "0x60025AA")]
	private override void System.Runtime.InteropServices._MemberInfo.GetTypeInfoCount(out uint pcTInfo) { }

	[Address(RVA = "0x7313604", Offset = "0x7313604", Length = "0x38")]
	[Token(Token = "0x60025AB")]
	private override void System.Runtime.InteropServices._MemberInfo.Invoke(uint dispIdMember, in Guid riid, uint lcid, short wFlags, IntPtr pDispParams, IntPtr pVarResult, IntPtr pExcepInfo, IntPtr puArgErr) { }

}

