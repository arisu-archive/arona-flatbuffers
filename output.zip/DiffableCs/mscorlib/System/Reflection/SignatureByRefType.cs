namespace System.Reflection;

[Token(Token = "0x2000522")]
internal sealed class SignatureByRefType : SignatureHasElementType
{

	[Token(Token = "0x17000534")]
	public virtual bool IsSZArray
	{
		[Address(RVA = "0x73158B4", Offset = "0x73158B4", Length = "0x8")]
		[Token(Token = "0x600262F")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000535")]
	public virtual bool IsVariableBoundArray
	{
		[Address(RVA = "0x73158BC", Offset = "0x73158BC", Length = "0x8")]
		[Token(Token = "0x6002630")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000536")]
	protected virtual string Suffix
	{
		[Address(RVA = "0x7315914", Offset = "0x7315914", Length = "0x40")]
		[Token(Token = "0x6002632")]
		 get { } //Length: 64
	}

	[Address(RVA = "0x7315870", Offset = "0x7315870", Length = "0x2C")]
	[Token(Token = "0x600262B")]
	internal SignatureByRefType(SignatureType elementType) { }

	[Address(RVA = "0x73158B4", Offset = "0x73158B4", Length = "0x8")]
	[Token(Token = "0x600262F")]
	public virtual bool get_IsSZArray() { }

	[Address(RVA = "0x73158BC", Offset = "0x73158BC", Length = "0x8")]
	[Token(Token = "0x6002630")]
	public virtual bool get_IsVariableBoundArray() { }

	[Address(RVA = "0x7315914", Offset = "0x7315914", Length = "0x40")]
	[Token(Token = "0x6002632")]
	protected virtual string get_Suffix() { }

	[Address(RVA = "0x73158C4", Offset = "0x73158C4", Length = "0x50")]
	[Token(Token = "0x6002631")]
	public virtual int GetArrayRank() { }

	[Address(RVA = "0x731589C", Offset = "0x731589C", Length = "0x8")]
	[Token(Token = "0x600262C")]
	protected virtual bool IsArrayImpl() { }

	[Address(RVA = "0x73158A4", Offset = "0x73158A4", Length = "0x8")]
	[Token(Token = "0x600262D")]
	protected virtual bool IsByRefImpl() { }

	[Address(RVA = "0x73158AC", Offset = "0x73158AC", Length = "0x8")]
	[Token(Token = "0x600262E")]
	protected virtual bool IsPointerImpl() { }

}

