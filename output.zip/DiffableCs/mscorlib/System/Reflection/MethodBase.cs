namespace System.Reflection;

[Token(Token = "0x2000513")]
public abstract class MethodBase : MemberInfo
{

	[Token(Token = "0x17000506")]
	public abstract MethodAttributes Attributes
	{
		[Token(Token = "0x60025AE")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000507")]
	public override CallingConventions CallingConvention
	{
		[Address(RVA = "0x731363C", Offset = "0x731363C", Length = "0x8")]
		[Token(Token = "0x60025B0")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000515")]
	public override bool ContainsGenericParameters
	{
		[Address(RVA = "0x7313890", Offset = "0x7313890", Length = "0x8")]
		[Token(Token = "0x60025BF")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000508")]
	public override bool IsAbstract
	{
		[Address(RVA = "0x7313644", Offset = "0x7313644", Length = "0x20")]
		[Token(Token = "0x60025B1")]
		 get { } //Length: 32
	}

	[Token(Token = "0x1700050E")]
	public override bool IsAssembly
	{
		[Address(RVA = "0x7313768", Offset = "0x7313768", Length = "0x28")]
		[Token(Token = "0x60025B7")]
		 get { } //Length: 40
	}

	[Token(Token = "0x17000509")]
	public override bool IsConstructor
	{
		[Address(RVA = "0x7313664", Offset = "0x7313664", Length = "0xA4")]
		[Token(Token = "0x60025B2")]
		 get { } //Length: 164
	}

	[Token(Token = "0x1700050F")]
	public override bool IsFamily
	{
		[Address(RVA = "0x7313790", Offset = "0x7313790", Length = "0x28")]
		[Token(Token = "0x60025B8")]
		 get { } //Length: 40
	}

	[Token(Token = "0x17000510")]
	public override bool IsFamilyOrAssembly
	{
		[Address(RVA = "0x73137B8", Offset = "0x73137B8", Length = "0x28")]
		[Token(Token = "0x60025B9")]
		 get { } //Length: 40
	}

	[Token(Token = "0x17000513")]
	public override bool IsGenericMethod
	{
		[Address(RVA = "0x7313830", Offset = "0x7313830", Length = "0x8")]
		[Token(Token = "0x60025BC")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000514")]
	public override bool IsGenericMethodDefinition
	{
		[Address(RVA = "0x7313838", Offset = "0x7313838", Length = "0x8")]
		[Token(Token = "0x60025BD")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700050A")]
	public override bool IsHideBySig
	{
		[Address(RVA = "0x7313708", Offset = "0x7313708", Length = "0x20")]
		[Token(Token = "0x60025B3")]
		 get { } //Length: 32
	}

	[Token(Token = "0x17000511")]
	public override bool IsPrivate
	{
		[Address(RVA = "0x73137E0", Offset = "0x73137E0", Length = "0x28")]
		[Token(Token = "0x60025BA")]
		 get { } //Length: 40
	}

	[Token(Token = "0x17000512")]
	public override bool IsPublic
	{
		[Address(RVA = "0x7313808", Offset = "0x7313808", Length = "0x28")]
		[Token(Token = "0x60025BB")]
		 get { } //Length: 40
	}

	[Token(Token = "0x17000517")]
	public override bool IsSecurityCritical
	{
		[Address(RVA = "0x7313898", Offset = "0x7313898", Length = "0x28")]
		[Token(Token = "0x60025C3")]
		 get { } //Length: 40
	}

	[Token(Token = "0x1700050B")]
	public override bool IsSpecialName
	{
		[Address(RVA = "0x7313728", Offset = "0x7313728", Length = "0x20")]
		[Token(Token = "0x60025B4")]
		 get { } //Length: 32
	}

	[Token(Token = "0x1700050C")]
	public override bool IsStatic
	{
		[Address(RVA = "0x73115BC", Offset = "0x73115BC", Length = "0x20")]
		[Token(Token = "0x60025B5")]
		 get { } //Length: 32
	}

	[Token(Token = "0x1700050D")]
	public override bool IsVirtual
	{
		[Address(RVA = "0x7313748", Offset = "0x7313748", Length = "0x20")]
		[Token(Token = "0x60025B6")]
		 get { } //Length: 32
	}

	[Token(Token = "0x17000516")]
	public abstract RuntimeMethodHandle MethodHandle
	{
		[Token(Token = "0x60025C2")]
		 get { } //Length: 0
	}

	[Address(RVA = "0x7310E04", Offset = "0x7310E04", Length = "0x8")]
	[Token(Token = "0x60025AC")]
	protected MethodBase() { }

	[Address(RVA = "0x7313A60", Offset = "0x7313A60", Length = "0x1EC")]
	[Token(Token = "0x60025CF")]
	internal static string ConstructParameters(Type[] parameterTypes, CallingConventions callingConvention, bool serialization) { }

	[Address(RVA = "0x7310E3C", Offset = "0x7310E3C", Length = "0x8")]
	[Token(Token = "0x60025C4")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x7313934", Offset = "0x7313934", Length = "0x12C")]
	[Token(Token = "0x60025CA")]
	internal override string FormatNameAndSig(bool serialization) { }

	[Token(Token = "0x60025AE")]
	public abstract MethodAttributes get_Attributes() { }

	[Address(RVA = "0x731363C", Offset = "0x731363C", Length = "0x8")]
	[Token(Token = "0x60025B0")]
	public override CallingConventions get_CallingConvention() { }

	[Address(RVA = "0x7313890", Offset = "0x7313890", Length = "0x8")]
	[Token(Token = "0x60025BF")]
	public override bool get_ContainsGenericParameters() { }

	[Address(RVA = "0x7313644", Offset = "0x7313644", Length = "0x20")]
	[Token(Token = "0x60025B1")]
	public override bool get_IsAbstract() { }

	[Address(RVA = "0x7313768", Offset = "0x7313768", Length = "0x28")]
	[Token(Token = "0x60025B7")]
	public override bool get_IsAssembly() { }

	[Address(RVA = "0x7313664", Offset = "0x7313664", Length = "0xA4")]
	[Token(Token = "0x60025B2")]
	public override bool get_IsConstructor() { }

	[Address(RVA = "0x7313790", Offset = "0x7313790", Length = "0x28")]
	[Token(Token = "0x60025B8")]
	public override bool get_IsFamily() { }

	[Address(RVA = "0x73137B8", Offset = "0x73137B8", Length = "0x28")]
	[Token(Token = "0x60025B9")]
	public override bool get_IsFamilyOrAssembly() { }

	[Address(RVA = "0x7313830", Offset = "0x7313830", Length = "0x8")]
	[Token(Token = "0x60025BC")]
	public override bool get_IsGenericMethod() { }

	[Address(RVA = "0x7313838", Offset = "0x7313838", Length = "0x8")]
	[Token(Token = "0x60025BD")]
	public override bool get_IsGenericMethodDefinition() { }

	[Address(RVA = "0x7313708", Offset = "0x7313708", Length = "0x20")]
	[Token(Token = "0x60025B3")]
	public override bool get_IsHideBySig() { }

	[Address(RVA = "0x73137E0", Offset = "0x73137E0", Length = "0x28")]
	[Token(Token = "0x60025BA")]
	public override bool get_IsPrivate() { }

	[Address(RVA = "0x7313808", Offset = "0x7313808", Length = "0x28")]
	[Token(Token = "0x60025BB")]
	public override bool get_IsPublic() { }

	[Address(RVA = "0x7313898", Offset = "0x7313898", Length = "0x28")]
	[Token(Token = "0x60025C3")]
	public override bool get_IsSecurityCritical() { }

	[Address(RVA = "0x7313728", Offset = "0x7313728", Length = "0x20")]
	[Token(Token = "0x60025B4")]
	public override bool get_IsSpecialName() { }

	[Address(RVA = "0x73115BC", Offset = "0x73115BC", Length = "0x20")]
	[Token(Token = "0x60025B5")]
	public override bool get_IsStatic() { }

	[Address(RVA = "0x7313748", Offset = "0x7313748", Length = "0x20")]
	[Token(Token = "0x60025B6")]
	public override bool get_IsVirtual() { }

	[Token(Token = "0x60025C2")]
	public abstract RuntimeMethodHandle get_MethodHandle() { }

	[Address(RVA = "0x7313840", Offset = "0x7313840", Length = "0x50")]
	[Token(Token = "0x60025BE")]
	public override Type[] GetGenericArguments() { }

	[Address(RVA = "0x7310E4C", Offset = "0x7310E4C", Length = "0x8")]
	[Token(Token = "0x60025C5")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x7313F7C", Offset = "0x7313F7C", Length = "0xF4")]
	[ComVisible(False)]
	[Token(Token = "0x60025CE")]
	public static MethodBase GetMethodFromHandle(RuntimeMethodHandle handle, RuntimeTypeHandle declaringType) { }

	[Address(RVA = "0x7313D68", Offset = "0x7313D68", Length = "0x20C")]
	[Token(Token = "0x60025CD")]
	public static MethodBase GetMethodFromHandle(RuntimeMethodHandle handle) { }

	[Token(Token = "0x60025AF")]
	public abstract MethodImplAttributes GetMethodImplementationFlags() { }

	[Token(Token = "0x60025AD")]
	public abstract ParameterInfo[] GetParameters() { }

	[Address(RVA = "0x731390C", Offset = "0x731390C", Length = "0x28")]
	[Token(Token = "0x60025C9")]
	internal override int GetParametersCount() { }

	[Address(RVA = "0x73138FC", Offset = "0x73138FC", Length = "0x10")]
	[Token(Token = "0x60025C8")]
	internal override ParameterInfo[] GetParametersInternal() { }

	[Address(RVA = "0x7313D58", Offset = "0x7313D58", Length = "0x10")]
	[Token(Token = "0x60025CC")]
	internal override ParameterInfo[] GetParametersNoCopy() { }

	[Address(RVA = "0x7313C4C", Offset = "0x7313C4C", Length = "0x10C")]
	[Token(Token = "0x60025CB")]
	internal override Type[] GetParameterTypes() { }

	[Address(RVA = "0x731138C", Offset = "0x731138C", Length = "0x20")]
	[DebuggerHidden]
	[DebuggerStepThrough]
	[Token(Token = "0x60025C0")]
	public override object Invoke(object obj, Object[] parameters) { }

	[Token(Token = "0x60025C1")]
	public abstract object Invoke(object obj, BindingFlags invokeAttr, Binder binder, Object[] parameters, CultureInfo culture) { }

	[Address(RVA = "0x73132C8", Offset = "0x73132C8", Length = "0x19C")]
	[Token(Token = "0x60025C6")]
	public static bool op_Equality(MethodBase left, MethodBase right) { }

	[Address(RVA = "0x73132B0", Offset = "0x73132B0", Length = "0x18")]
	[Token(Token = "0x60025C7")]
	public static bool op_Inequality(MethodBase left, MethodBase right) { }

}

