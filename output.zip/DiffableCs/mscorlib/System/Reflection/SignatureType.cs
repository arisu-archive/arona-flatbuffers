namespace System.Reflection;

[Token(Token = "0x2000526")]
internal abstract class SignatureType : Type
{

	[Token(Token = "0x17000565")]
	public virtual Assembly Assembly
	{
		[Address(RVA = "0x7316544", Offset = "0x7316544", Length = "0x50")]
		[Token(Token = "0x6002686")]
		 get { } //Length: 80
	}

	[Token(Token = "0x17000564")]
	public virtual string AssemblyQualifiedName
	{
		[Address(RVA = "0x731653C", Offset = "0x731653C", Length = "0x8")]
		[Token(Token = "0x6002684")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000568")]
	public virtual Type BaseType
	{
		[Address(RVA = "0x7316634", Offset = "0x7316634", Length = "0x50")]
		[Token(Token = "0x6002689")]
		 get { } //Length: 80
	}

	[Token(Token = "0x1700055B")]
	public abstract bool ContainsGenericParameters
	{
		[Token(Token = "0x6002672")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700056E")]
	public virtual IEnumerable<CustomAttributeData> CustomAttributes
	{
		[Address(RVA = "0x7317214", Offset = "0x7317214", Length = "0x50")]
		[Token(Token = "0x60026AF")]
		 get { } //Length: 80
	}

	[Token(Token = "0x1700056B")]
	public virtual MethodBase DeclaringMethod
	{
		[Address(RVA = "0x7316814", Offset = "0x7316814", Length = "0x50")]
		[Token(Token = "0x600268F")]
		 get { } //Length: 80
	}

	[Token(Token = "0x1700056A")]
	public virtual Type DeclaringType
	{
		[Address(RVA = "0x73167C4", Offset = "0x73167C4", Length = "0x50")]
		[Token(Token = "0x600268E")]
		 get { } //Length: 80
	}

	[Token(Token = "0x1700055F")]
	internal abstract SignatureType ElementType
	{
		[Token(Token = "0x600267F")]
		internal get { } //Length: 0
	}

	[Token(Token = "0x17000563")]
	public virtual string FullName
	{
		[Address(RVA = "0x7316534", Offset = "0x7316534", Length = "0x8")]
		[Token(Token = "0x6002683")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700056C")]
	public virtual GenericParameterAttributes GenericParameterAttributes
	{
		[Address(RVA = "0x73168B4", Offset = "0x73168B4", Length = "0x50")]
		[Token(Token = "0x6002691")]
		 get { } //Length: 80
	}

	[Token(Token = "0x1700055E")]
	public abstract int GenericParameterPosition
	{
		[Token(Token = "0x600267E")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700055D")]
	public abstract Type[] GenericTypeArguments
	{
		[Token(Token = "0x600267C")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700056D")]
	public virtual Guid GUID
	{
		[Address(RVA = "0x7316A94", Offset = "0x7316A94", Length = "0x50")]
		[Token(Token = "0x6002697")]
		 get { } //Length: 80
	}

	[Token(Token = "0x17000558")]
	public abstract bool IsConstructedGenericType
	{
		[Token(Token = "0x600266F")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700056F")]
	public virtual bool IsEnum
	{
		[Address(RVA = "0x73172B4", Offset = "0x73172B4", Length = "0x50")]
		[Token(Token = "0x60026B1")]
		 get { } //Length: 80
	}

	[Token(Token = "0x1700055A")]
	public abstract bool IsGenericMethodParameter
	{
		[Token(Token = "0x6002671")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000559")]
	public abstract bool IsGenericParameter
	{
		[Token(Token = "0x6002670")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000556")]
	public virtual bool IsGenericType
	{
		[Address(RVA = "0x7316278", Offset = "0x7316278", Length = "0x40")]
		[Token(Token = "0x600266D")]
		 get { } //Length: 64
	}

	[Token(Token = "0x17000557")]
	public abstract bool IsGenericTypeDefinition
	{
		[Token(Token = "0x600266E")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000570")]
	public virtual bool IsSerializable
	{
		[Address(RVA = "0x73173F4", Offset = "0x73173F4", Length = "0x50")]
		[Token(Token = "0x60026B5")]
		 get { } //Length: 80
	}

	[Token(Token = "0x17000553")]
	public virtual bool IsSignatureType
	{
		[Address(RVA = "0x7316270", Offset = "0x7316270", Length = "0x8")]
		[Token(Token = "0x6002666")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000554")]
	public abstract bool IsSZArray
	{
		[Token(Token = "0x6002669")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000555")]
	public abstract bool IsVariableBoundArray
	{
		[Token(Token = "0x600266A")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700055C")]
	public virtual MemberTypes MemberType
	{
		[Address(RVA = "0x73162B8", Offset = "0x73162B8", Length = "0x8")]
		[Token(Token = "0x6002673")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000569")]
	public virtual int MetadataToken
	{
		[Address(RVA = "0x7316724", Offset = "0x7316724", Length = "0x50")]
		[Token(Token = "0x600268C")]
		 get { } //Length: 80
	}

	[Token(Token = "0x17000566")]
	public virtual Module Module
	{
		[Address(RVA = "0x7316594", Offset = "0x7316594", Length = "0x50")]
		[Token(Token = "0x6002687")]
		 get { } //Length: 80
	}

	[Token(Token = "0x17000561")]
	public abstract string Name
	{
		[Token(Token = "0x6002681")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000562")]
	public abstract string Namespace
	{
		[Token(Token = "0x6002682")]
		 get { } //Length: 0
	}

	[Token(Token = "0x17000567")]
	public virtual Type ReflectedType
	{
		[Address(RVA = "0x73165E4", Offset = "0x73165E4", Length = "0x50")]
		[Token(Token = "0x6002688")]
		 get { } //Length: 80
	}

	[Token(Token = "0x17000571")]
	public virtual RuntimeTypeHandle TypeHandle
	{
		[Address(RVA = "0x73174E4", Offset = "0x73174E4", Length = "0x50")]
		[Token(Token = "0x60026B8")]
		 get { } //Length: 80
	}

	[Token(Token = "0x17000560")]
	public virtual Type UnderlyingSystemType
	{
		[Address(RVA = "0x7316530", Offset = "0x7316530", Length = "0x4")]
		[Token(Token = "0x6002680")]
		 get { } //Length: 4
	}

	[Address(RVA = "0x7315B10", Offset = "0x7315B10", Length = "0x58")]
	[Token(Token = "0x60026B9")]
	protected SignatureType() { }

	[Address(RVA = "0x7316544", Offset = "0x7316544", Length = "0x50")]
	[Token(Token = "0x6002686")]
	public virtual Assembly get_Assembly() { }

	[Address(RVA = "0x731653C", Offset = "0x731653C", Length = "0x8")]
	[Token(Token = "0x6002684")]
	public virtual string get_AssemblyQualifiedName() { }

	[Address(RVA = "0x7316634", Offset = "0x7316634", Length = "0x50")]
	[Token(Token = "0x6002689")]
	public virtual Type get_BaseType() { }

	[Token(Token = "0x6002672")]
	public abstract bool get_ContainsGenericParameters() { }

	[Address(RVA = "0x7317214", Offset = "0x7317214", Length = "0x50")]
	[Token(Token = "0x60026AF")]
	public virtual IEnumerable<CustomAttributeData> get_CustomAttributes() { }

	[Address(RVA = "0x7316814", Offset = "0x7316814", Length = "0x50")]
	[Token(Token = "0x600268F")]
	public virtual MethodBase get_DeclaringMethod() { }

	[Address(RVA = "0x73167C4", Offset = "0x73167C4", Length = "0x50")]
	[Token(Token = "0x600268E")]
	public virtual Type get_DeclaringType() { }

	[Token(Token = "0x600267F")]
	internal abstract SignatureType get_ElementType() { }

	[Address(RVA = "0x7316534", Offset = "0x7316534", Length = "0x8")]
	[Token(Token = "0x6002683")]
	public virtual string get_FullName() { }

	[Address(RVA = "0x73168B4", Offset = "0x73168B4", Length = "0x50")]
	[Token(Token = "0x6002691")]
	public virtual GenericParameterAttributes get_GenericParameterAttributes() { }

	[Token(Token = "0x600267E")]
	public abstract int get_GenericParameterPosition() { }

	[Token(Token = "0x600267C")]
	public abstract Type[] get_GenericTypeArguments() { }

	[Address(RVA = "0x7316A94", Offset = "0x7316A94", Length = "0x50")]
	[Token(Token = "0x6002697")]
	public virtual Guid get_GUID() { }

	[Token(Token = "0x600266F")]
	public abstract bool get_IsConstructedGenericType() { }

	[Address(RVA = "0x73172B4", Offset = "0x73172B4", Length = "0x50")]
	[Token(Token = "0x60026B1")]
	public virtual bool get_IsEnum() { }

	[Token(Token = "0x6002671")]
	public abstract bool get_IsGenericMethodParameter() { }

	[Token(Token = "0x6002670")]
	public abstract bool get_IsGenericParameter() { }

	[Address(RVA = "0x7316278", Offset = "0x7316278", Length = "0x40")]
	[Token(Token = "0x600266D")]
	public virtual bool get_IsGenericType() { }

	[Token(Token = "0x600266E")]
	public abstract bool get_IsGenericTypeDefinition() { }

	[Address(RVA = "0x73173F4", Offset = "0x73173F4", Length = "0x50")]
	[Token(Token = "0x60026B5")]
	public virtual bool get_IsSerializable() { }

	[Address(RVA = "0x7316270", Offset = "0x7316270", Length = "0x8")]
	[Token(Token = "0x6002666")]
	public virtual bool get_IsSignatureType() { }

	[Token(Token = "0x6002669")]
	public abstract bool get_IsSZArray() { }

	[Token(Token = "0x600266A")]
	public abstract bool get_IsVariableBoundArray() { }

	[Address(RVA = "0x73162B8", Offset = "0x73162B8", Length = "0x8")]
	[Token(Token = "0x6002673")]
	public virtual MemberTypes get_MemberType() { }

	[Address(RVA = "0x7316724", Offset = "0x7316724", Length = "0x50")]
	[Token(Token = "0x600268C")]
	public virtual int get_MetadataToken() { }

	[Address(RVA = "0x7316594", Offset = "0x7316594", Length = "0x50")]
	[Token(Token = "0x6002687")]
	public virtual Module get_Module() { }

	[Token(Token = "0x6002681")]
	public abstract string get_Name() { }

	[Token(Token = "0x6002682")]
	public abstract string get_Namespace() { }

	[Address(RVA = "0x73165E4", Offset = "0x73165E4", Length = "0x50")]
	[Token(Token = "0x6002688")]
	public virtual Type get_ReflectedType() { }

	[Address(RVA = "0x73174E4", Offset = "0x73174E4", Length = "0x50")]
	[Token(Token = "0x60026B8")]
	public virtual RuntimeTypeHandle get_TypeHandle() { }

	[Address(RVA = "0x7316530", Offset = "0x7316530", Length = "0x4")]
	[Token(Token = "0x6002680")]
	public virtual Type get_UnderlyingSystemType() { }

	[Token(Token = "0x600267A")]
	public abstract int GetArrayRank() { }

	[Address(RVA = "0x7316B34", Offset = "0x7316B34", Length = "0x50")]
	[Token(Token = "0x6002699")]
	protected virtual TypeAttributes GetAttributeFlagsImpl() { }

	[Address(RVA = "0x7317124", Offset = "0x7317124", Length = "0x50")]
	[Token(Token = "0x60026AC")]
	protected virtual ConstructorInfo GetConstructorImpl(BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers) { }

	[Address(RVA = "0x7316B84", Offset = "0x7316B84", Length = "0x50")]
	[Token(Token = "0x600269A")]
	public virtual ConstructorInfo[] GetConstructors(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7317034", Offset = "0x7317034", Length = "0x50")]
	[Token(Token = "0x60026A9")]
	public virtual Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7316FE4", Offset = "0x7316FE4", Length = "0x50")]
	[Token(Token = "0x60026A8")]
	public virtual Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x73170D4", Offset = "0x73170D4", Length = "0x50")]
	[Token(Token = "0x60026AB")]
	public virtual IList<CustomAttributeData> GetCustomAttributesData() { }

	[Address(RVA = "0x7316520", Offset = "0x7316520", Length = "0x10")]
	[Token(Token = "0x6002679")]
	public virtual Type GetElementType() { }

	[Address(RVA = "0x7316954", Offset = "0x7316954", Length = "0x50")]
	[Token(Token = "0x6002693")]
	public virtual string GetEnumName(object value) { }

	[Address(RVA = "0x73169A4", Offset = "0x73169A4", Length = "0x50")]
	[Token(Token = "0x6002694")]
	public virtual String[] GetEnumNames() { }

	[Address(RVA = "0x73169F4", Offset = "0x73169F4", Length = "0x50")]
	[Token(Token = "0x6002695")]
	public virtual Type GetEnumUnderlyingType() { }

	[Address(RVA = "0x7316A44", Offset = "0x7316A44", Length = "0x50")]
	[Token(Token = "0x6002696")]
	public virtual Array GetEnumValues() { }

	[Address(RVA = "0x7316BD4", Offset = "0x7316BD4", Length = "0x50")]
	[Token(Token = "0x600269B")]
	public virtual EventInfo GetEvent(string name, BindingFlags bindingAttr) { }

	[Address(RVA = "0x7316C24", Offset = "0x7316C24", Length = "0x50")]
	[Token(Token = "0x600269C")]
	public virtual EventInfo[] GetEvents(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7316C74", Offset = "0x7316C74", Length = "0x50")]
	[Token(Token = "0x600269D")]
	public virtual FieldInfo GetField(string name, BindingFlags bindingAttr) { }

	[Address(RVA = "0x7316CC4", Offset = "0x7316CC4", Length = "0x50")]
	[Token(Token = "0x600269E")]
	public virtual FieldInfo[] GetFields(BindingFlags bindingAttr) { }

	[Token(Token = "0x600267D")]
	public abstract Type[] GetGenericArguments() { }

	[Address(RVA = "0x7316864", Offset = "0x7316864", Length = "0x50")]
	[Token(Token = "0x6002690")]
	public virtual Type[] GetGenericParameterConstraints() { }

	[Token(Token = "0x600267B")]
	public abstract Type GetGenericTypeDefinition() { }

	[Address(RVA = "0x7316684", Offset = "0x7316684", Length = "0x50")]
	[Token(Token = "0x600268A")]
	public virtual Type[] GetInterfaces() { }

	[Address(RVA = "0x7316F94", Offset = "0x7316F94", Length = "0x50")]
	[Token(Token = "0x60026A7")]
	public virtual MemberInfo[] GetMember(string name, MemberTypes type, BindingFlags bindingAttr) { }

	[Address(RVA = "0x7316F44", Offset = "0x7316F44", Length = "0x50")]
	[Token(Token = "0x60026A6")]
	public virtual MemberInfo[] GetMember(string name, BindingFlags bindingAttr) { }

	[Address(RVA = "0x7316D14", Offset = "0x7316D14", Length = "0x50")]
	[Token(Token = "0x600269F")]
	public virtual MemberInfo[] GetMembers(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7316EA4", Offset = "0x7316EA4", Length = "0x50")]
	[Token(Token = "0x60026A4")]
	protected virtual MethodInfo GetMethodImpl(string name, BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers) { }

	[Address(RVA = "0x7316D64", Offset = "0x7316D64", Length = "0x50")]
	[Token(Token = "0x60026A0")]
	public virtual MethodInfo[] GetMethods(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7316DB4", Offset = "0x7316DB4", Length = "0x50")]
	[Token(Token = "0x60026A1")]
	public virtual Type GetNestedType(string name, BindingFlags bindingAttr) { }

	[Address(RVA = "0x7316E04", Offset = "0x7316E04", Length = "0x50")]
	[Token(Token = "0x60026A2")]
	public virtual PropertyInfo[] GetProperties(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7316EF4", Offset = "0x7316EF4", Length = "0x50")]
	[Token(Token = "0x60026A5")]
	protected virtual PropertyInfo GetPropertyImpl(string name, BindingFlags bindingAttr, Binder binder, Type returnType, Type[] types, ParameterModifier[] modifiers) { }

	[Address(RVA = "0x7316AE4", Offset = "0x7316AE4", Length = "0x50")]
	[Token(Token = "0x6002698")]
	protected virtual TypeCode GetTypeCodeImpl() { }

	[Token(Token = "0x6002667")]
	protected abstract bool HasElementTypeImpl() { }

	[Address(RVA = "0x7316774", Offset = "0x7316774", Length = "0x50")]
	[Token(Token = "0x600268D")]
	public virtual bool HasSameMetadataDefinitionAs(MemberInfo other) { }

	[Address(RVA = "0x7316E54", Offset = "0x7316E54", Length = "0x50")]
	[Token(Token = "0x60026A3")]
	public virtual object InvokeMember(string name, BindingFlags invokeAttr, Binder binder, object target, Object[] args, ParameterModifier[] modifiers, CultureInfo culture, String[] namedParameters) { }

	[Token(Token = "0x6002668")]
	protected abstract bool IsArrayImpl() { }

	[Address(RVA = "0x73166D4", Offset = "0x73166D4", Length = "0x50")]
	[Token(Token = "0x600268B")]
	public virtual bool IsAssignableFrom(Type c) { }

	[Token(Token = "0x600266B")]
	protected abstract bool IsByRefImpl() { }

	[Address(RVA = "0x7317174", Offset = "0x7317174", Length = "0x50")]
	[Token(Token = "0x60026AD")]
	protected virtual bool IsCOMObjectImpl() { }

	[Address(RVA = "0x7317264", Offset = "0x7317264", Length = "0x50")]
	[Token(Token = "0x60026B0")]
	protected virtual bool IsContextfulImpl() { }

	[Address(RVA = "0x7317084", Offset = "0x7317084", Length = "0x50")]
	[Token(Token = "0x60026AA")]
	public virtual bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7316904", Offset = "0x7316904", Length = "0x50")]
	[Token(Token = "0x6002692")]
	public virtual bool IsEnumDefined(object value) { }

	[Address(RVA = "0x7317304", Offset = "0x7317304", Length = "0x50")]
	[Token(Token = "0x60026B2")]
	public virtual bool IsEquivalentTo(Type other) { }

	[Address(RVA = "0x7317354", Offset = "0x7317354", Length = "0x50")]
	[Token(Token = "0x60026B3")]
	public virtual bool IsInstanceOfType(object o) { }

	[Address(RVA = "0x73173A4", Offset = "0x73173A4", Length = "0x50")]
	[Token(Token = "0x60026B4")]
	protected virtual bool IsMarshalByRefImpl() { }

	[Token(Token = "0x600266C")]
	protected abstract bool IsPointerImpl() { }

	[Address(RVA = "0x73171C4", Offset = "0x73171C4", Length = "0x50")]
	[Token(Token = "0x60026AE")]
	protected virtual bool IsPrimitiveImpl() { }

	[Address(RVA = "0x7317444", Offset = "0x7317444", Length = "0x50")]
	[Token(Token = "0x60026B6")]
	public virtual bool IsSubclassOf(Type c) { }

	[Address(RVA = "0x7317494", Offset = "0x7317494", Length = "0x50")]
	[Token(Token = "0x60026B7")]
	protected virtual bool IsValueTypeImpl() { }

	[Address(RVA = "0x73162C0", Offset = "0x73162C0", Length = "0x78")]
	[Token(Token = "0x6002674")]
	public virtual Type MakeArrayType() { }

	[Address(RVA = "0x7316338", Offset = "0x7316338", Length = "0xC0")]
	[Token(Token = "0x6002675")]
	public virtual Type MakeArrayType(int rank) { }

	[Address(RVA = "0x73163F8", Offset = "0x73163F8", Length = "0x6C")]
	[Token(Token = "0x6002676")]
	public virtual Type MakeByRefType() { }

	[Address(RVA = "0x73164D0", Offset = "0x73164D0", Length = "0x50")]
	[Token(Token = "0x6002678")]
	public virtual Type MakeGenericType(Type[] typeArguments) { }

	[Address(RVA = "0x7316464", Offset = "0x7316464", Length = "0x6C")]
	[Token(Token = "0x6002677")]
	public virtual Type MakePointerType() { }

	[Token(Token = "0x6002685")]
	public abstract string ToString() { }

}

