namespace System.Reflection;

[Token(Token = "0x2000523")]
internal sealed class SignatureConstructedGenericType : SignatureType
{
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40014F0")]
	private readonly Type _genericTypeDefinition; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40014F1")]
	private readonly Type[] _genericTypeArguments; //Field offset: 0x20

	[Token(Token = "0x1700053D")]
	public virtual bool ContainsGenericParameters
	{
		[Address(RVA = "0x7315BB8", Offset = "0x7315BB8", Length = "0x74")]
		[Token(Token = "0x600263E")]
		 get { } //Length: 116
	}

	[Token(Token = "0x1700053E")]
	internal virtual SignatureType ElementType
	{
		[Address(RVA = "0x7315C2C", Offset = "0x7315C2C", Length = "0x8")]
		[Token(Token = "0x600263F")]
		internal get { } //Length: 8
	}

	[Token(Token = "0x17000540")]
	public virtual int GenericParameterPosition
	{
		[Address(RVA = "0x7315D14", Offset = "0x7315D14", Length = "0x50")]
		[Token(Token = "0x6002644")]
		 get { } //Length: 80
	}

	[Token(Token = "0x1700053F")]
	public virtual Type[] GenericTypeArguments
	{
		[Address(RVA = "0x7315C9C", Offset = "0x7315C9C", Length = "0x78")]
		[Token(Token = "0x6002643")]
		 get { } //Length: 120
	}

	[Token(Token = "0x1700053A")]
	public virtual bool IsConstructedGenericType
	{
		[Address(RVA = "0x7315BA0", Offset = "0x7315BA0", Length = "0x8")]
		[Token(Token = "0x600263B")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700053C")]
	public virtual bool IsGenericMethodParameter
	{
		[Address(RVA = "0x7315BB0", Offset = "0x7315BB0", Length = "0x8")]
		[Token(Token = "0x600263D")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700053B")]
	public virtual bool IsGenericParameter
	{
		[Address(RVA = "0x7315BA8", Offset = "0x7315BA8", Length = "0x8")]
		[Token(Token = "0x600263C")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000537")]
	public virtual bool IsGenericTypeDefinition
	{
		[Address(RVA = "0x7315B68", Offset = "0x7315B68", Length = "0x8")]
		[Token(Token = "0x6002634")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000538")]
	public virtual bool IsSZArray
	{
		[Address(RVA = "0x7315B90", Offset = "0x7315B90", Length = "0x8")]
		[Token(Token = "0x6002639")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000539")]
	public virtual bool IsVariableBoundArray
	{
		[Address(RVA = "0x7315B98", Offset = "0x7315B98", Length = "0x8")]
		[Token(Token = "0x600263A")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000541")]
	public virtual string Name
	{
		[Address(RVA = "0x7315D64", Offset = "0x7315D64", Length = "0x24")]
		[Token(Token = "0x6002645")]
		 get { } //Length: 36
	}

	[Token(Token = "0x17000542")]
	public virtual string Namespace
	{
		[Address(RVA = "0x7315D88", Offset = "0x7315D88", Length = "0x24")]
		[Token(Token = "0x6002646")]
		 get { } //Length: 36
	}

	[Address(RVA = "0x7315954", Offset = "0x7315954", Length = "0x1BC")]
	[Token(Token = "0x6002633")]
	internal SignatureConstructedGenericType(Type genericTypeDefinition, Type[] typeArguments) { }

	[Address(RVA = "0x7315BB8", Offset = "0x7315BB8", Length = "0x74")]
	[Token(Token = "0x600263E")]
	public virtual bool get_ContainsGenericParameters() { }

	[Address(RVA = "0x7315C2C", Offset = "0x7315C2C", Length = "0x8")]
	[Token(Token = "0x600263F")]
	internal virtual SignatureType get_ElementType() { }

	[Address(RVA = "0x7315D14", Offset = "0x7315D14", Length = "0x50")]
	[Token(Token = "0x6002644")]
	public virtual int get_GenericParameterPosition() { }

	[Address(RVA = "0x7315C9C", Offset = "0x7315C9C", Length = "0x78")]
	[Token(Token = "0x6002643")]
	public virtual Type[] get_GenericTypeArguments() { }

	[Address(RVA = "0x7315BA0", Offset = "0x7315BA0", Length = "0x8")]
	[Token(Token = "0x600263B")]
	public virtual bool get_IsConstructedGenericType() { }

	[Address(RVA = "0x7315BB0", Offset = "0x7315BB0", Length = "0x8")]
	[Token(Token = "0x600263D")]
	public virtual bool get_IsGenericMethodParameter() { }

	[Address(RVA = "0x7315BA8", Offset = "0x7315BA8", Length = "0x8")]
	[Token(Token = "0x600263C")]
	public virtual bool get_IsGenericParameter() { }

	[Address(RVA = "0x7315B68", Offset = "0x7315B68", Length = "0x8")]
	[Token(Token = "0x6002634")]
	public virtual bool get_IsGenericTypeDefinition() { }

	[Address(RVA = "0x7315B90", Offset = "0x7315B90", Length = "0x8")]
	[Token(Token = "0x6002639")]
	public virtual bool get_IsSZArray() { }

	[Address(RVA = "0x7315B98", Offset = "0x7315B98", Length = "0x8")]
	[Token(Token = "0x600263A")]
	public virtual bool get_IsVariableBoundArray() { }

	[Address(RVA = "0x7315D64", Offset = "0x7315D64", Length = "0x24")]
	[Token(Token = "0x6002645")]
	public virtual string get_Name() { }

	[Address(RVA = "0x7315D88", Offset = "0x7315D88", Length = "0x24")]
	[Token(Token = "0x6002646")]
	public virtual string get_Namespace() { }

	[Address(RVA = "0x7315C34", Offset = "0x7315C34", Length = "0x50")]
	[Token(Token = "0x6002640")]
	public virtual int GetArrayRank() { }

	[Address(RVA = "0x7315C8C", Offset = "0x7315C8C", Length = "0x10")]
	[Token(Token = "0x6002642")]
	public virtual Type[] GetGenericArguments() { }

	[Address(RVA = "0x7315C84", Offset = "0x7315C84", Length = "0x8")]
	[Token(Token = "0x6002641")]
	public virtual Type GetGenericTypeDefinition() { }

	[Address(RVA = "0x7315B70", Offset = "0x7315B70", Length = "0x8")]
	[Token(Token = "0x6002635")]
	protected virtual bool HasElementTypeImpl() { }

	[Address(RVA = "0x7315B78", Offset = "0x7315B78", Length = "0x8")]
	[Token(Token = "0x6002636")]
	protected virtual bool IsArrayImpl() { }

	[Address(RVA = "0x7315B80", Offset = "0x7315B80", Length = "0x8")]
	[Token(Token = "0x6002637")]
	protected virtual bool IsByRefImpl() { }

	[Address(RVA = "0x7315B88", Offset = "0x7315B88", Length = "0x8")]
	[Token(Token = "0x6002638")]
	protected virtual bool IsPointerImpl() { }

	[Address(RVA = "0x7315DAC", Offset = "0x7315DAC", Length = "0x124")]
	[Token(Token = "0x6002647")]
	public virtual string ToString() { }

}

