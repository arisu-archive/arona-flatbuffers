namespace System.Reflection;

[Token(Token = "0x2000532")]
public sealed class MissingMetadataException : TypeAccessException
{

	[Address(RVA = "0x731A250", Offset = "0x731A250", Length = "0x8")]
	[Token(Token = "0x600271B")]
	public MissingMetadataException() { }

}

