namespace System.Reflection;

[Token(Token = "0x2000500")]
public abstract class ConstructorInfo : MethodBase
{
	[Token(Token = "0x400145B")]
	public static readonly string ConstructorName; //Field offset: 0x0
	[Token(Token = "0x400145C")]
	public static readonly string TypeConstructorName; //Field offset: 0x8

	[Token(Token = "0x170004E9")]
	public virtual MemberTypes MemberType
	{
		[Address(RVA = "0x7310E0C", Offset = "0x7310E0C", Length = "0x8")]
		[Token(Token = "0x6002545")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x7310F14", Offset = "0x7310F14", Length = "0x9C")]
	[Token(Token = "0x600254C")]
	private static ConstructorInfo() { }

	[Address(RVA = "0x7310DFC", Offset = "0x7310DFC", Length = "0x8")]
	[Token(Token = "0x6002544")]
	protected ConstructorInfo() { }

	[Address(RVA = "0x7310E34", Offset = "0x7310E34", Length = "0x8")]
	[Token(Token = "0x6002548")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x7310E0C", Offset = "0x7310E0C", Length = "0x8")]
	[Token(Token = "0x6002545")]
	public virtual MemberTypes get_MemberType() { }

	[Address(RVA = "0x7310E44", Offset = "0x7310E44", Length = "0x8")]
	[Token(Token = "0x6002549")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x7310E14", Offset = "0x7310E14", Length = "0x20")]
	[DebuggerHidden]
	[DebuggerStepThrough]
	[Token(Token = "0x6002546")]
	public object Invoke(Object[] parameters) { }

	[Token(Token = "0x6002547")]
	public abstract object Invoke(BindingFlags invokeAttr, Binder binder, Object[] parameters, CultureInfo culture) { }

	[Address(RVA = "0x7310E54", Offset = "0x7310E54", Length = "0x2C")]
	[Token(Token = "0x600254A")]
	public static bool op_Equality(ConstructorInfo left, ConstructorInfo right) { }

	[Address(RVA = "0x7310E80", Offset = "0x7310E80", Length = "0x94")]
	[Token(Token = "0x600254B")]
	public static bool op_Inequality(ConstructorInfo left, ConstructorInfo right) { }

}

