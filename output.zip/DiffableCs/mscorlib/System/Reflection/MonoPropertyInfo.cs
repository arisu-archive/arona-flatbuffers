namespace System.Reflection;

[Token(Token = "0x2000549")]
internal struct MonoPropertyInfo
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40015D1")]
	public Type parent; //Field offset: 0x0
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x40015D2")]
	public Type declaring_type; //Field offset: 0x8
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40015D3")]
	public string name; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40015D4")]
	public MethodInfo get_method; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40015D5")]
	public MethodInfo set_method; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x40015D6")]
	public PropertyAttributes attrs; //Field offset: 0x28

}

