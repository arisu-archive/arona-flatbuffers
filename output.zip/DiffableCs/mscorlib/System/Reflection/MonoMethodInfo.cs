namespace System.Reflection;

[Token(Token = "0x2000544")]
internal struct MonoMethodInfo
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40015BE")]
	private Type parent; //Field offset: 0x0
	[FieldOffset(Offset = "0x8")]
	[Token(Token = "0x40015BF")]
	private Type ret; //Field offset: 0x8
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40015C0")]
	internal MethodAttributes attrs; //Field offset: 0x10
	[FieldOffset(Offset = "0x14")]
	[Token(Token = "0x40015C1")]
	internal MethodImplAttributes iattrs; //Field offset: 0x14
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40015C2")]
	private CallingConventions callconv; //Field offset: 0x18

	[Address(RVA = "0x732108C", Offset = "0x732108C", Length = "0x4")]
	[Token(Token = "0x60027FA")]
	private static int get_method_attributes(IntPtr handle) { }

	[Address(RVA = "0x7321088", Offset = "0x7321088", Length = "0x4")]
	[Token(Token = "0x60027F9")]
	private static void get_method_info(IntPtr handle, out MonoMethodInfo info) { }

	[Address(RVA = "0x7321164", Offset = "0x7321164", Length = "0x4")]
	[Token(Token = "0x6002801")]
	private static ParameterInfo[] get_parameter_info(IntPtr handle, MemberInfo member) { }

	[Address(RVA = "0x732116C", Offset = "0x732116C", Length = "0x4")]
	[Token(Token = "0x6002803")]
	private static MarshalAsAttribute get_retval_marshal(IntPtr handle) { }

	[Address(RVA = "0x7321110", Offset = "0x7321110", Length = "0x4")]
	[Token(Token = "0x60027FE")]
	internal static MethodAttributes GetAttributes(IntPtr handle) { }

	[Address(RVA = "0x7321114", Offset = "0x7321114", Length = "0x28")]
	[Token(Token = "0x60027FF")]
	internal static CallingConventions GetCallingConvention(IntPtr handle) { }

	[Address(RVA = "0x73210C0", Offset = "0x73210C0", Length = "0x28")]
	[Token(Token = "0x60027FC")]
	internal static Type GetDeclaringType(IntPtr handle) { }

	[Address(RVA = "0x732113C", Offset = "0x732113C", Length = "0x28")]
	[Token(Token = "0x6002800")]
	internal static MethodImplAttributes GetMethodImplementationFlags(IntPtr handle) { }

	[Address(RVA = "0x7321090", Offset = "0x7321090", Length = "0x30")]
	[Token(Token = "0x60027FB")]
	internal static MonoMethodInfo GetMethodInfo(IntPtr handle) { }

	[Address(RVA = "0x7321168", Offset = "0x7321168", Length = "0x4")]
	[Token(Token = "0x6002802")]
	internal static ParameterInfo[] GetParametersInfo(IntPtr handle, MemberInfo member) { }

	[Address(RVA = "0x7321170", Offset = "0x7321170", Length = "0x58")]
	[Token(Token = "0x6002804")]
	internal static ParameterInfo GetReturnParameterInfo(RuntimeMethodInfo method) { }

	[Address(RVA = "0x73210E8", Offset = "0x73210E8", Length = "0x28")]
	[Token(Token = "0x60027FD")]
	internal static Type GetReturnType(IntPtr handle) { }

}

