namespace System.Reflection;

[Token(Token = "0x2000530")]
public struct CustomAttributeNamedArgument
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4001516")]
	private readonly CustomAttributeTypedArgument <TypedValue>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001517")]
	private readonly bool <IsField>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001518")]
	private readonly string <MemberName>k__BackingField; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4001519")]
	private readonly Type _attributeType; //Field offset: 0x20
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x400151A")]
	private MemberInfo _lazyMemberInfo; //Field offset: 0x28

	[Token(Token = "0x17000584")]
	public bool IsField
	{
		[Address(RVA = "0x7318FE4", Offset = "0x7318FE4", Length = "0x8")]
		[CompilerGenerated]
		[IsReadOnly]
		[Token(Token = "0x6002708")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000586")]
	public MemberInfo MemberInfo
	{
		[Address(RVA = "0x7318FF4", Offset = "0x7318FF4", Length = "0x130")]
		[Token(Token = "0x600270A")]
		 get { } //Length: 304
	}

	[Token(Token = "0x17000585")]
	public string MemberName
	{
		[Address(RVA = "0x7318FEC", Offset = "0x7318FEC", Length = "0x8")]
		[CompilerGenerated]
		[IsReadOnly]
		[Token(Token = "0x6002709")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000583")]
	public CustomAttributeTypedArgument TypedValue
	{
		[Address(RVA = "0x7318FD8", Offset = "0x7318FD8", Length = "0xC")]
		[CompilerGenerated]
		[IsReadOnly]
		[Token(Token = "0x6002707")]
		 get { } //Length: 12
	}

	[Address(RVA = "0x7318B84", Offset = "0x7318B84", Length = "0x6C")]
	[Token(Token = "0x6002704")]
	internal CustomAttributeNamedArgument(Type attributeType, string memberName, bool isField, CustomAttributeTypedArgument typedValue) { }

	[Address(RVA = "0x7318BF0", Offset = "0x7318BF0", Length = "0x290")]
	[Token(Token = "0x6002705")]
	public CustomAttributeNamedArgument(MemberInfo memberInfo, object value) { }

	[Address(RVA = "0x7318E80", Offset = "0x7318E80", Length = "0x158")]
	[Token(Token = "0x6002706")]
	public CustomAttributeNamedArgument(MemberInfo memberInfo, CustomAttributeTypedArgument typedArgument) { }

	[Address(RVA = "0x7319124", Offset = "0x7319124", Length = "0x78")]
	[Token(Token = "0x600270B")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x7318FE4", Offset = "0x7318FE4", Length = "0x8")]
	[CompilerGenerated]
	[IsReadOnly]
	[Token(Token = "0x6002708")]
	public bool get_IsField() { }

	[Address(RVA = "0x7318FF4", Offset = "0x7318FF4", Length = "0x130")]
	[Token(Token = "0x600270A")]
	public MemberInfo get_MemberInfo() { }

	[Address(RVA = "0x7318FEC", Offset = "0x7318FEC", Length = "0x8")]
	[CompilerGenerated]
	[IsReadOnly]
	[Token(Token = "0x6002709")]
	public string get_MemberName() { }

	[Address(RVA = "0x7318FD8", Offset = "0x7318FD8", Length = "0xC")]
	[CompilerGenerated]
	[IsReadOnly]
	[Token(Token = "0x6002707")]
	public CustomAttributeTypedArgument get_TypedValue() { }

	[Address(RVA = "0x731919C", Offset = "0x731919C", Length = "0x6C")]
	[Token(Token = "0x600270C")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x7319208", Offset = "0x7319208", Length = "0x80")]
	[Token(Token = "0x600270D")]
	public static bool op_Equality(CustomAttributeNamedArgument left, CustomAttributeNamedArgument right) { }

	[Address(RVA = "0x7319288", Offset = "0x7319288", Length = "0x84")]
	[Token(Token = "0x600270E")]
	public static bool op_Inequality(CustomAttributeNamedArgument left, CustomAttributeNamedArgument right) { }

	[Address(RVA = "0x731930C", Offset = "0x731930C", Length = "0x328")]
	[Token(Token = "0x600270F")]
	public virtual string ToString() { }

}

