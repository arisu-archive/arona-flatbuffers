namespace System.Reflection;

[AttributeUsage(1036)]
[Token(Token = "0x2000502")]
public sealed class DefaultMemberAttribute : Attribute
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x400145D")]
	private readonly string <MemberName>k__BackingField; //Field offset: 0x10

	[Token(Token = "0x170004EA")]
	public string MemberName
	{
		[Address(RVA = "0x7311094", Offset = "0x7311094", Length = "0x8")]
		[CompilerGenerated]
		[Token(Token = "0x6002552")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x7311064", Offset = "0x7311064", Length = "0x30")]
	[Token(Token = "0x6002551")]
	public DefaultMemberAttribute(string memberName) { }

	[Address(RVA = "0x7311094", Offset = "0x7311094", Length = "0x8")]
	[CompilerGenerated]
	[Token(Token = "0x6002552")]
	public string get_MemberName() { }

}

