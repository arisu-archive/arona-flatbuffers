namespace System.Reflection;

[Token(Token = "0x200054B")]
internal class RuntimePropertyInfo : PropertyInfo, ISerializable
{
	[Token(Token = "0x200054D")]
	private sealed class Getter : MulticastDelegate
	{

		[Address(RVA = "0x4E5C68C", Offset = "0x4E5C68C", Length = "0x140")]
		[Token(Token = "0x600289D")]
		public Getter`2(object object, IntPtr method) { }

		[Address(RVA = "0x4E5C7CC", Offset = "0x4E5C7CC", Length = "0x14")]
		[Token(Token = "0x600289E")]
		public override R Invoke(T _this) { }

	}

	[Token(Token = "0x200054C")]
	private sealed class GetterAdapter : MulticastDelegate
	{

		[Address(RVA = "0x7326E98", Offset = "0x7326E98", Length = "0x140")]
		[Token(Token = "0x600289B")]
		public GetterAdapter(object object, IntPtr method) { }

		[Address(RVA = "0x7326FD8", Offset = "0x7326FD8", Length = "0x14")]
		[Token(Token = "0x600289C")]
		public override object Invoke(object _this) { }

	}

	[Token(Token = "0x200054E")]
	private sealed class StaticGetter : MulticastDelegate
	{

		[Address(RVA = "0x5F268CC", Offset = "0x5F268CC", Length = "0xD0")]
		[Token(Token = "0x600289F")]
		public StaticGetter`1(object object, IntPtr method) { }

		[Address(RVA = "0x5F2699C", Offset = "0x5F2699C", Length = "0x14")]
		[Token(Token = "0x60028A0")]
		public override R Invoke() { }

	}

	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x40015DE")]
	internal IntPtr klass; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x40015DF")]
	internal IntPtr prop; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40015E0")]
	private MonoPropertyInfo info; //Field offset: 0x20
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x40015E1")]
	private PInfo cached; //Field offset: 0x50
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x40015E2")]
	private GetterAdapter cached_getter; //Field offset: 0x58

	[Token(Token = "0x170005D3")]
	internal BindingFlags BindingFlags
	{
		[Address(RVA = "0x7325F44", Offset = "0x7325F44", Length = "0x8")]
		[Token(Token = "0x6002879")]
		internal get { } //Length: 8
	}

	[Token(Token = "0x170005D6")]
	public virtual bool CanRead
	{
		[Address(RVA = "0x7326314", Offset = "0x7326314", Length = "0x40")]
		[Token(Token = "0x6002883")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005D7")]
	public virtual bool CanWrite
	{
		[Address(RVA = "0x7326354", Offset = "0x7326354", Length = "0x40")]
		[Token(Token = "0x6002884")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005DA")]
	public virtual Type DeclaringType
	{
		[Address(RVA = "0x732647C", Offset = "0x732647C", Length = "0x38")]
		[Token(Token = "0x6002887")]
		 get { } //Length: 56
	}

	[Token(Token = "0x170005DC")]
	public virtual int MetadataToken
	{
		[Address(RVA = "0x7326D88", Offset = "0x7326D88", Length = "0x4")]
		[Token(Token = "0x6002896")]
		 get { } //Length: 4
	}

	[Token(Token = "0x170005D4")]
	public virtual Module Module
	{
		[Address(RVA = "0x7325F4C", Offset = "0x7325F4C", Length = "0x4")]
		[Token(Token = "0x600287A")]
		 get { } //Length: 4
	}

	[Token(Token = "0x170005DB")]
	public virtual string Name
	{
		[Address(RVA = "0x73264B4", Offset = "0x73264B4", Length = "0x38")]
		[Token(Token = "0x6002888")]
		 get { } //Length: 56
	}

	[Token(Token = "0x170005D8")]
	public virtual Type PropertyType
	{
		[Address(RVA = "0x7326394", Offset = "0x7326394", Length = "0xB0")]
		[Token(Token = "0x6002885")]
		 get { } //Length: 176
	}

	[Token(Token = "0x170005D9")]
	public virtual Type ReflectedType
	{
		[Address(RVA = "0x7326444", Offset = "0x7326444", Length = "0x38")]
		[Token(Token = "0x6002886")]
		 get { } //Length: 56
	}

	[Token(Token = "0x170005D5")]
	private RuntimeType ReflectedTypeInternal
	{
		[Address(RVA = "0x7325FF4", Offset = "0x7325FF4", Length = "0x88")]
		[Token(Token = "0x600287C")]
		private get { } //Length: 136
	}

	[Address(RVA = "0x7326E90", Offset = "0x7326E90", Length = "0x8")]
	[Token(Token = "0x600289A")]
	public RuntimePropertyInfo() { }

	[Address(RVA = "0x73262D4", Offset = "0x73262D4", Length = "0x40")]
	[Token(Token = "0x6002882")]
	private void CachePropertyInfo(PInfo flags) { }

	[Address(RVA = "0x7326084", Offset = "0x7326084", Length = "0x174")]
	[Token(Token = "0x600287F")]
	private string FormatNameAndSig(bool serialization) { }

	[Address(RVA = "0x7325F44", Offset = "0x7325F44", Length = "0x8")]
	[Token(Token = "0x6002879")]
	internal BindingFlags get_BindingFlags() { }

	[Address(RVA = "0x7326314", Offset = "0x7326314", Length = "0x40")]
	[Token(Token = "0x6002883")]
	public virtual bool get_CanRead() { }

	[Address(RVA = "0x7326354", Offset = "0x7326354", Length = "0x40")]
	[Token(Token = "0x6002884")]
	public virtual bool get_CanWrite() { }

	[Address(RVA = "0x732647C", Offset = "0x732647C", Length = "0x38")]
	[Token(Token = "0x6002887")]
	public virtual Type get_DeclaringType() { }

	[Address(RVA = "0x7326D8C", Offset = "0x7326D8C", Length = "0x4")]
	[Token(Token = "0x6002897")]
	internal static int get_metadata_token(RuntimePropertyInfo monoProperty) { }

	[Address(RVA = "0x7326D88", Offset = "0x7326D88", Length = "0x4")]
	[Token(Token = "0x6002896")]
	public virtual int get_MetadataToken() { }

	[Address(RVA = "0x7325F4C", Offset = "0x7325F4C", Length = "0x4")]
	[Token(Token = "0x600287A")]
	public virtual Module get_Module() { }

	[Address(RVA = "0x73264B4", Offset = "0x73264B4", Length = "0x38")]
	[Token(Token = "0x6002888")]
	public virtual string get_Name() { }

	[Address(RVA = "0x7325F40", Offset = "0x7325F40", Length = "0x4")]
	[Token(Token = "0x6002878")]
	internal static void get_property_info(RuntimePropertyInfo prop, ref MonoPropertyInfo info, PInfo req_info) { }

	[Address(RVA = "0x7326394", Offset = "0x7326394", Length = "0xB0")]
	[Token(Token = "0x6002885")]
	public virtual Type get_PropertyType() { }

	[Address(RVA = "0x7326444", Offset = "0x7326444", Length = "0x38")]
	[Token(Token = "0x6002886")]
	public virtual Type get_ReflectedType() { }

	[Address(RVA = "0x7325FF4", Offset = "0x7325FF4", Length = "0x88")]
	[Token(Token = "0x600287C")]
	private RuntimeType get_ReflectedTypeInternal() { }

	[Address(RVA = "0x7326888", Offset = "0x7326888", Length = "0x6C")]
	[Token(Token = "0x600288E")]
	public virtual Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x732682C", Offset = "0x732682C", Length = "0x5C")]
	[Token(Token = "0x600288D")]
	public virtual Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x7326D28", Offset = "0x7326D28", Length = "0x8")]
	[Token(Token = "0x6002894")]
	public virtual IList<CustomAttributeData> GetCustomAttributesData() { }

	[Address(RVA = "0x7325F6C", Offset = "0x7325F6C", Length = "0x88")]
	[Token(Token = "0x600287B")]
	internal RuntimeType GetDeclaringTypeInternal() { }

	[Address(RVA = "0x73264EC", Offset = "0x73264EC", Length = "0x84")]
	[Token(Token = "0x6002889")]
	public virtual MethodInfo GetGetMethod(bool nonPublic) { }

	[Address(RVA = "0x7326570", Offset = "0x7326570", Length = "0x1CC")]
	[Token(Token = "0x600288A")]
	public virtual ParameterInfo[] GetIndexParameters() { }

	[Address(RVA = "0x73261F8", Offset = "0x73261F8", Length = "0xD4")]
	[Token(Token = "0x6002880")]
	public override void GetObjectData(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x7326D94", Offset = "0x7326D94", Length = "0xFC")]
	[Token(Token = "0x6002899")]
	internal static PropertyInfo GetPropertyFromHandle(RuntimePropertyHandle handle, RuntimeTypeHandle reflectedType) { }

	[Address(RVA = "0x7325F50", Offset = "0x7325F50", Length = "0x1C")]
	[Token(Token = "0x600287D")]
	internal RuntimeModule GetRuntimeModule() { }

	[Address(RVA = "0x732673C", Offset = "0x732673C", Length = "0x84")]
	[Token(Token = "0x600288B")]
	public virtual MethodInfo GetSetMethod(bool nonPublic) { }

	[Address(RVA = "0x4447264", Offset = "0x4447264", Length = "0x90")]
	[Token(Token = "0x600288F")]
	private static object GetterAdapterFrame(Getter<T, R> getter, object obj) { }

	[Address(RVA = "0x73268F4", Offset = "0x73268F4", Length = "0x20")]
	[Token(Token = "0x6002891")]
	public virtual object GetValue(object obj, Object[] index) { }

	[Address(RVA = "0x7326914", Offset = "0x7326914", Length = "0x208")]
	[Token(Token = "0x6002892")]
	public virtual object GetValue(object obj, BindingFlags invokeAttr, Binder binder, Object[] index, CultureInfo culture) { }

	[Address(RVA = "0x7326D30", Offset = "0x7326D30", Length = "0x58")]
	[Token(Token = "0x6002895")]
	public virtual bool HasSameMetadataDefinitionAs(MemberInfo other) { }

	[Address(RVA = "0x7326D90", Offset = "0x7326D90", Length = "0x4")]
	[Token(Token = "0x6002898")]
	private static PropertyInfo internal_from_handle_type(IntPtr event_handle, IntPtr type_handle) { }

	[Address(RVA = "0x73267C0", Offset = "0x73267C0", Length = "0x6C")]
	[Token(Token = "0x600288C")]
	public virtual bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x73262CC", Offset = "0x73262CC", Length = "0x8")]
	[Token(Token = "0x6002881")]
	internal string SerializationToString() { }

	[Address(RVA = "0x7326B1C", Offset = "0x7326B1C", Length = "0x20C")]
	[Token(Token = "0x6002893")]
	public virtual void SetValue(object obj, object value, BindingFlags invokeAttr, Binder binder, Object[] index, CultureInfo culture) { }

	[Address(RVA = "0x44472F4", Offset = "0x44472F4", Length = "0x20")]
	[Token(Token = "0x6002890")]
	private static object StaticGetterAdapterFrame(StaticGetter<R> getter, object obj) { }

	[Address(RVA = "0x732607C", Offset = "0x732607C", Length = "0x8")]
	[Token(Token = "0x600287E")]
	public virtual string ToString() { }

}

