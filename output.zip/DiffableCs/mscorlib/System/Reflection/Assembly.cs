namespace System.Reflection;

[ClassInterface(ClassInterfaceType::None (0))]
[ComDefaultInterface(typeof(_Assembly))]
[ComVisible(True)]
[Token(Token = "0x2000537")]
public class Assembly : ICustomAttributeProvider, ISerializable, _Assembly
{
	[Token(Token = "0x2000538")]
	public class ResolveEventHolder
	{

		[Address(RVA = "0x731C180", Offset = "0x731C180", Length = "0x8")]
		[Token(Token = "0x6002764")]
		public ResolveEventHolder() { }

	}


	[Token(Token = "0x17000589")]
	public override string CodeBase
	{
		[Address(RVA = "0x731B2A4", Offset = "0x731B2A4", Length = "0x40")]
		[Token(Token = "0x6002730")]
		 get { } //Length: 64
	}

	[Token(Token = "0x1700058A")]
	public override string EscapedCodeBase
	{
		[Address(RVA = "0x731B2E4", Offset = "0x731B2E4", Length = "0x40")]
		[Token(Token = "0x6002731")]
		 get { } //Length: 64
	}

	[Token(Token = "0x1700058B")]
	public override string FullName
	{
		[Address(RVA = "0x731B324", Offset = "0x731B324", Length = "0x40")]
		[Token(Token = "0x6002732")]
		 get { } //Length: 64
	}

	[Token(Token = "0x17000590")]
	public override bool IsDynamic
	{
		[Address(RVA = "0x731C120", Offset = "0x731C120", Length = "0x8")]
		[Token(Token = "0x6002760")]
		 get { } //Length: 8
	}

	[MonoTODO]
	[Token(Token = "0x1700058F")]
	public bool IsFullyTrusted
	{
		[Address(RVA = "0x731C0AC", Offset = "0x731C0AC", Length = "0x8")]
		[Token(Token = "0x600275C")]
		 get { } //Length: 8
	}

	[Token(Token = "0x1700058D")]
	public override string Location
	{
		[Address(RVA = "0x731B3A4", Offset = "0x731B3A4", Length = "0x40")]
		[Token(Token = "0x6002734")]
		 get { } //Length: 64
	}

	[Token(Token = "0x1700058C")]
	internal override IntPtr MonoAssembly
	{
		[Address(RVA = "0x731B364", Offset = "0x731B364", Length = "0x40")]
		[Token(Token = "0x6002733")]
		internal get { } //Length: 64
	}

	[ComVisible(False)]
	[Token(Token = "0x1700058E")]
	public override bool ReflectionOnly
	{
		[Address(RVA = "0x731BFE8", Offset = "0x731BFE8", Length = "0x40")]
		[Token(Token = "0x6002758")]
		 get { } //Length: 64
	}

	[Address(RVA = "0x731C178", Offset = "0x731C178", Length = "0x8")]
	[Token(Token = "0x6002763")]
	public Assembly() { }

	[Address(RVA = "0x731C038", Offset = "0x731C038", Length = "0x74")]
	[Token(Token = "0x600275B")]
	private static Exception CreateNIE() { }

	[Address(RVA = "0x731C030", Offset = "0x731C030", Length = "0x8")]
	[Token(Token = "0x600275A")]
	public virtual bool Equals(object o) { }

	[Address(RVA = "0x731B2A4", Offset = "0x731B2A4", Length = "0x40")]
	[Token(Token = "0x6002730")]
	public override string get_CodeBase() { }

	[Address(RVA = "0x731B2E4", Offset = "0x731B2E4", Length = "0x40")]
	[Token(Token = "0x6002731")]
	public override string get_EscapedCodeBase() { }

	[Address(RVA = "0x731B324", Offset = "0x731B324", Length = "0x40")]
	[Token(Token = "0x6002732")]
	public override string get_FullName() { }

	[Address(RVA = "0x731C120", Offset = "0x731C120", Length = "0x8")]
	[Token(Token = "0x6002760")]
	public override bool get_IsDynamic() { }

	[Address(RVA = "0x731C0AC", Offset = "0x731C0AC", Length = "0x8")]
	[Token(Token = "0x600275C")]
	public bool get_IsFullyTrusted() { }

	[Address(RVA = "0x731B3A4", Offset = "0x731B3A4", Length = "0x40")]
	[Token(Token = "0x6002734")]
	public override string get_Location() { }

	[Address(RVA = "0x731B364", Offset = "0x731B364", Length = "0x40")]
	[Token(Token = "0x6002733")]
	internal override IntPtr get_MonoAssembly() { }

	[Address(RVA = "0x731BFE8", Offset = "0x731BFE8", Length = "0x40")]
	[Token(Token = "0x6002758")]
	public override bool get_ReflectionOnly() { }

	[Address(RVA = "0x731B810", Offset = "0x731B810", Length = "0xC8")]
	[Token(Token = "0x6002748")]
	public static Assembly GetAssembly(Type type) { }

	[Address(RVA = "0x731BF64", Offset = "0x731BF64", Length = "0x4")]
	[Token(Token = "0x6002755")]
	public static Assembly GetCallingAssembly() { }

	[Address(RVA = "0x731B464", Offset = "0x731B464", Length = "0x40")]
	[Token(Token = "0x6002737")]
	public override Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x731B4A4", Offset = "0x731B4A4", Length = "0x40")]
	[Token(Token = "0x6002738")]
	public override Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x731B8D8", Offset = "0x731B8D8", Length = "0x4")]
	[Token(Token = "0x6002749")]
	public static Assembly GetEntryAssembly() { }

	[Address(RVA = "0x731BF24", Offset = "0x731BF24", Length = "0x40")]
	[Token(Token = "0x6002754")]
	public static Assembly GetExecutingAssembly() { }

	[Address(RVA = "0x731B740", Offset = "0x731B740", Length = "0x2C")]
	[Token(Token = "0x600273F")]
	private AssemblyNameFlags GetFlags() { }

	[Address(RVA = "0x731C028", Offset = "0x731C028", Length = "0x8")]
	[Token(Token = "0x6002759")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x731BFA8", Offset = "0x731BFA8", Length = "0x40")]
	[Token(Token = "0x6002757")]
	public override ManifestResourceInfo GetManifestResourceInfo(string resourceName) { }

	[Address(RVA = "0x731BF68", Offset = "0x731BF68", Length = "0x40")]
	[Token(Token = "0x6002756")]
	public override String[] GetManifestResourceNames() { }

	[Address(RVA = "0x731B4E4", Offset = "0x731B4E4", Length = "0x40")]
	[Token(Token = "0x6002739")]
	public override Stream GetManifestResourceStream(string name) { }

	[Address(RVA = "0x731B6AC", Offset = "0x731B6AC", Length = "0x10")]
	[Token(Token = "0x600273B")]
	internal Stream GetManifestResourceStream(string name, ref StackCrawlMark stackMark, bool skipSecurityCheck) { }

	[Address(RVA = "0x731B524", Offset = "0x731B524", Length = "0x188")]
	[Token(Token = "0x600273A")]
	internal Stream GetManifestResourceStream(Type type, string name, bool skipSecurityCheck, ref StackCrawlMark stackMark) { }

	[Address(RVA = "0x731C0D8", Offset = "0x731C0D8", Length = "0x24")]
	[Token(Token = "0x600275E")]
	public override Module GetModule(string name) { }

	[Address(RVA = "0x731C0FC", Offset = "0x731C0FC", Length = "0x24")]
	[Token(Token = "0x600275F")]
	public override Module[] GetModules(bool getResourceModules) { }

	[Address(RVA = "0x731BED0", Offset = "0x731BED0", Length = "0x14")]
	[Token(Token = "0x6002752")]
	public override Module[] GetModules() { }

	[Address(RVA = "0x731BEE4", Offset = "0x731BEE4", Length = "0x40")]
	[Token(Token = "0x6002753")]
	internal override Module[] GetModulesInternal() { }

	[Address(RVA = "0x731B7B4", Offset = "0x731B7B4", Length = "0x40")]
	[Token(Token = "0x6002745")]
	public override AssemblyName GetName(bool copiedName) { }

	[Address(RVA = "0x731B7F4", Offset = "0x731B7F4", Length = "0x14")]
	[Token(Token = "0x6002746")]
	public override AssemblyName GetName() { }

	[Address(RVA = "0x731B3E4", Offset = "0x731B3E4", Length = "0x40")]
	[Token(Token = "0x6002735")]
	public override void GetObjectData(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x731B6E8", Offset = "0x731B6E8", Length = "0x2C")]
	[Token(Token = "0x600273D")]
	internal Byte[] GetPublicKey() { }

	[Address(RVA = "0x731B6BC", Offset = "0x731B6BC", Length = "0x2C")]
	[Token(Token = "0x600273C")]
	internal string GetSimpleName() { }

	[Address(RVA = "0x731C0B4", Offset = "0x731C0B4", Length = "0x24")]
	[Token(Token = "0x600275D")]
	public override Type GetType(string name, bool throwOnError, bool ignoreCase) { }

	[Address(RVA = "0x731B798", Offset = "0x731B798", Length = "0x18")]
	[Token(Token = "0x6002743")]
	public override Type GetType(string name) { }

	[Address(RVA = "0x731B784", Offset = "0x731B784", Length = "0x14")]
	[Token(Token = "0x6002742")]
	public override Type GetType(string name, bool throwOnError) { }

	[Address(RVA = "0x731B770", Offset = "0x731B770", Length = "0x14")]
	[Token(Token = "0x6002741")]
	public override Type[] GetTypes() { }

	[Address(RVA = "0x731B76C", Offset = "0x731B76C", Length = "0x4")]
	[Token(Token = "0x6002740")]
	internal override Type[] GetTypes(bool exportedOnly) { }

	[Address(RVA = "0x731B714", Offset = "0x731B714", Length = "0x2C")]
	[Token(Token = "0x600273E")]
	internal Version GetVersion() { }

	[Address(RVA = "0x731B8DC", Offset = "0x731B8DC", Length = "0x408")]
	[Token(Token = "0x600274A")]
	internal RuntimeAssembly InternalGetSatelliteAssembly(string name, CultureInfo culture, Version version, bool throwOnFileNotFound, ref StackCrawlMark stackMark) { }

	[Address(RVA = "0x731B7B0", Offset = "0x731B7B0", Length = "0x4")]
	[Token(Token = "0x6002744")]
	internal Type InternalGetType(Module module, string name, bool throwOnError, bool ignoreCase) { }

	[Address(RVA = "0x731B424", Offset = "0x731B424", Length = "0x40")]
	[Token(Token = "0x6002736")]
	public override bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x731BDD0", Offset = "0x731BDD0", Length = "0x28")]
	[Token(Token = "0x600274C")]
	public static Assembly Load(string assemblyString) { }

	[Address(RVA = "0x731BE54", Offset = "0x731BE54", Length = "0x4")]
	[Token(Token = "0x600274F")]
	private static Assembly load_with_partial_name(string name, Evidence e) { }

	[Address(RVA = "0x731BDCC", Offset = "0x731BDCC", Length = "0x4")]
	[Token(Token = "0x600274B")]
	private static Assembly LoadFrom(string assemblyFile, bool refOnly, ref StackCrawlMark stackMark) { }

	[Address(RVA = "0x731BE40", Offset = "0x731BE40", Length = "0xC")]
	[Obsolete("This method has been deprecated. Please use Assembly.Load() instead. http://go.microsoft.com/fwlink/?linkid=14202")]
	[Token(Token = "0x600274E")]
	public static Assembly LoadWithPartialName(string partialName) { }

	[Address(RVA = "0x731BE4C", Offset = "0x731BE4C", Length = "0x8")]
	[Obsolete("This method has been deprecated. Please use Assembly.Load() instead. http://go.microsoft.com/fwlink/?linkid=14202")]
	[Token(Token = "0x6002750")]
	public static Assembly LoadWithPartialName(string partialName, Evidence securityEvidence) { }

	[Address(RVA = "0x731BE58", Offset = "0x731BE58", Length = "0x78")]
	[Token(Token = "0x6002751")]
	internal static Assembly LoadWithPartialName(string partialName, Evidence securityEvidence, bool oldBehavior) { }

	[Address(RVA = "0x731C128", Offset = "0x731C128", Length = "0x50")]
	[Token(Token = "0x6002761")]
	public static bool op_Equality(Assembly left, Assembly right) { }

	[Address(RVA = "0x731BD74", Offset = "0x731BD74", Length = "0x58")]
	[Token(Token = "0x6002762")]
	public static bool op_Inequality(Assembly left, Assembly right) { }

	[Address(RVA = "0x731BDF8", Offset = "0x731BDF8", Length = "0x48")]
	[Token(Token = "0x600274D")]
	public static Assembly ReflectionOnlyLoad(string assemblyString) { }

	[Address(RVA = "0x731B808", Offset = "0x731B808", Length = "0x8")]
	[Token(Token = "0x6002747")]
	public virtual string ToString() { }

}

