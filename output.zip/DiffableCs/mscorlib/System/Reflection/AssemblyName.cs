namespace System.Reflection;

[ClassInterface(ClassInterfaceType::None (0))]
[ComDefaultInterface(typeof(_AssemblyName))]
[ComVisible(True)]
[Token(Token = "0x2000539")]
public sealed class AssemblyName : ICloneable, ISerializable, IDeserializationCallback, _AssemblyName
{
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x4001583")]
	private string name; //Field offset: 0x10
	[FieldOffset(Offset = "0x18")]
	[Token(Token = "0x4001584")]
	private string codebase; //Field offset: 0x18
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x4001585")]
	private int major; //Field offset: 0x20
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x4001586")]
	private int minor; //Field offset: 0x24
	[FieldOffset(Offset = "0x28")]
	[Token(Token = "0x4001587")]
	private int build; //Field offset: 0x28
	[FieldOffset(Offset = "0x2C")]
	[Token(Token = "0x4001588")]
	private int revision; //Field offset: 0x2C
	[FieldOffset(Offset = "0x30")]
	[Token(Token = "0x4001589")]
	private CultureInfo cultureinfo; //Field offset: 0x30
	[FieldOffset(Offset = "0x38")]
	[Token(Token = "0x400158A")]
	private AssemblyNameFlags flags; //Field offset: 0x38
	[FieldOffset(Offset = "0x3C")]
	[Token(Token = "0x400158B")]
	private AssemblyHashAlgorithm hashalg; //Field offset: 0x3C
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x400158C")]
	private StrongNameKeyPair keypair; //Field offset: 0x40
	[FieldOffset(Offset = "0x48")]
	[Token(Token = "0x400158D")]
	private Byte[] publicKey; //Field offset: 0x48
	[FieldOffset(Offset = "0x50")]
	[Token(Token = "0x400158E")]
	private Byte[] keyToken; //Field offset: 0x50
	[FieldOffset(Offset = "0x58")]
	[Token(Token = "0x400158F")]
	private AssemblyVersionCompatibility versioncompat; //Field offset: 0x58
	[FieldOffset(Offset = "0x60")]
	[Token(Token = "0x4001590")]
	private Version version; //Field offset: 0x60
	[FieldOffset(Offset = "0x68")]
	[Token(Token = "0x4001591")]
	private ProcessorArchitecture processor_architecture; //Field offset: 0x68
	[FieldOffset(Offset = "0x6C")]
	[Token(Token = "0x4001592")]
	private AssemblyContentType contentType; //Field offset: 0x6C

	[Token(Token = "0x17000592")]
	public CultureInfo CultureInfo
	{
		[Address(RVA = "0x731CA54", Offset = "0x731CA54", Length = "0x8")]
		[Token(Token = "0x600276B")]
		 get { } //Length: 8
		[Address(RVA = "0x731CA5C", Offset = "0x731CA5C", Length = "0x8")]
		[Token(Token = "0x600276C")]
		 set { } //Length: 8
	}

	[Token(Token = "0x17000593")]
	public AssemblyNameFlags Flags
	{
		[Address(RVA = "0x731CA64", Offset = "0x731CA64", Length = "0x8")]
		[Token(Token = "0x600276D")]
		 get { } //Length: 8
		[Address(RVA = "0x731CA6C", Offset = "0x731CA6C", Length = "0x8")]
		[Token(Token = "0x600276E")]
		 set { } //Length: 8
	}

	[Token(Token = "0x17000594")]
	public string FullName
	{
		[Address(RVA = "0x731CA74", Offset = "0x731CA74", Length = "0x35C")]
		[Token(Token = "0x600276F")]
		 get { } //Length: 860
	}

	[Token(Token = "0x17000596")]
	private bool IsPublicKeyValid
	{
		[Address(RVA = "0x731CFE4", Offset = "0x731CFE4", Length = "0xF8")]
		[Token(Token = "0x6002775")]
		private get { } //Length: 248
	}

	[Token(Token = "0x17000591")]
	public string Name
	{
		[Address(RVA = "0x731CA44", Offset = "0x731CA44", Length = "0x8")]
		[Token(Token = "0x6002769")]
		 get { } //Length: 8
		[Address(RVA = "0x731CA4C", Offset = "0x731CA4C", Length = "0x8")]
		[Token(Token = "0x600276A")]
		 set { } //Length: 8
	}

	[Token(Token = "0x17000595")]
	public Version Version
	{
		[Address(RVA = "0x731CEB8", Offset = "0x731CEB8", Length = "0x8")]
		[Token(Token = "0x6002770")]
		 get { } //Length: 8
		[Address(RVA = "0x731BD24", Offset = "0x731BD24", Length = "0x50")]
		[Token(Token = "0x6002771")]
		 set { } //Length: 80
	}

	[Address(RVA = "0x731BCE4", Offset = "0x731BCE4", Length = "0x20")]
	[Token(Token = "0x6002765")]
	public AssemblyName() { }

	[Address(RVA = "0x730F8BC", Offset = "0x730F8BC", Length = "0x270")]
	[Token(Token = "0x6002767")]
	public AssemblyName(string assemblyName) { }

	[Address(RVA = "0x731C4A0", Offset = "0x731C4A0", Length = "0x5A4")]
	[Token(Token = "0x6002768")]
	internal AssemblyName(SerializationInfo si, StreamingContext sc) { }

	[Address(RVA = "0x731D52C", Offset = "0x731D52C", Length = "0xF8")]
	[Token(Token = "0x600277C")]
	public override object Clone() { }

	[Address(RVA = "0x731D0DC", Offset = "0x731D0DC", Length = "0x88")]
	[Token(Token = "0x6002778")]
	private Byte[] ComputePublicKeyToken() { }

	[Address(RVA = "0x731D630", Offset = "0x731D630", Length = "0xCC")]
	[Token(Token = "0x6002780")]
	internal static AssemblyName Create(Assembly assembly, bool fillCodebase) { }

	[Address(RVA = "0x731C18C", Offset = "0x731C18C", Length = "0x314")]
	[Token(Token = "0x600277F")]
	internal void FillName(MonoAssemblyName* native, string codeBase, bool addVersion, bool addPublickey, bool defaultToken, bool assemblyRef) { }

	[Address(RVA = "0x731CA54", Offset = "0x731CA54", Length = "0x8")]
	[Token(Token = "0x600276B")]
	public CultureInfo get_CultureInfo() { }

	[Address(RVA = "0x731CA64", Offset = "0x731CA64", Length = "0x8")]
	[Token(Token = "0x600276D")]
	public AssemblyNameFlags get_Flags() { }

	[Address(RVA = "0x731CA74", Offset = "0x731CA74", Length = "0x35C")]
	[Token(Token = "0x600276F")]
	public string get_FullName() { }

	[Address(RVA = "0x731CFE4", Offset = "0x731CFE4", Length = "0xF8")]
	[Token(Token = "0x6002775")]
	private bool get_IsPublicKeyValid() { }

	[Address(RVA = "0x731CA44", Offset = "0x731CA44", Length = "0x8")]
	[Token(Token = "0x6002769")]
	public string get_Name() { }

	[Address(RVA = "0x731D164", Offset = "0x731D164", Length = "0x4")]
	[Token(Token = "0x6002777")]
	private static void get_public_token(Byte* token, Byte* pubkey, int len) { }

	[Address(RVA = "0x731CEB8", Offset = "0x731CEB8", Length = "0x8")]
	[Token(Token = "0x6002770")]
	public Version get_Version() { }

	[Address(RVA = "0x731D62C", Offset = "0x731D62C", Length = "0x4")]
	[Token(Token = "0x600277E")]
	private static MonoAssemblyName* GetNativeName(IntPtr assembly_ptr) { }

	[Address(RVA = "0x731D1FC", Offset = "0x731D1FC", Length = "0x330")]
	[Token(Token = "0x600277B")]
	public override void GetObjectData(SerializationInfo info, StreamingContext context) { }

	[Address(RVA = "0x731CEE8", Offset = "0x731CEE8", Length = "0x8")]
	[Token(Token = "0x6002773")]
	public Byte[] GetPublicKey() { }

	[Address(RVA = "0x731CEF0", Offset = "0x731CEF0", Length = "0xF4")]
	[Token(Token = "0x6002774")]
	public Byte[] GetPublicKeyToken() { }

	[Address(RVA = "0x731CDD0", Offset = "0x731CDD0", Length = "0xE8")]
	[Token(Token = "0x6002776")]
	private Byte[] InternalGetPublicKeyToken() { }

	[Address(RVA = "0x731D624", Offset = "0x731D624", Length = "0x8")]
	[Token(Token = "0x600277D")]
	public override void OnDeserialization(object sender) { }

	[Address(RVA = "0x731C188", Offset = "0x731C188", Length = "0x4")]
	[Token(Token = "0x6002766")]
	private static bool ParseAssemblyName(IntPtr name, out MonoAssemblyName aname, out bool is_version_definited, out bool is_token_defined) { }

	[Address(RVA = "0x731D168", Offset = "0x731D168", Length = "0x94")]
	[Token(Token = "0x6002779")]
	public static bool ReferenceMatchesDefinition(AssemblyName reference, AssemblyName definition) { }

	[Address(RVA = "0x731CA5C", Offset = "0x731CA5C", Length = "0x8")]
	[Token(Token = "0x600276C")]
	public void set_CultureInfo(CultureInfo value) { }

	[Address(RVA = "0x731CA6C", Offset = "0x731CA6C", Length = "0x8")]
	[Token(Token = "0x600276E")]
	public void set_Flags(AssemblyNameFlags value) { }

	[Address(RVA = "0x731CA4C", Offset = "0x731CA4C", Length = "0x8")]
	[Token(Token = "0x600276A")]
	public void set_Name(string value) { }

	[Address(RVA = "0x731BD24", Offset = "0x731BD24", Length = "0x50")]
	[Token(Token = "0x6002771")]
	public void set_Version(Version value) { }

	[Address(RVA = "0x731BD04", Offset = "0x731BD04", Length = "0x20")]
	[Token(Token = "0x600277A")]
	public void SetPublicKey(Byte[] publicKey) { }

	[Address(RVA = "0x731CEC0", Offset = "0x731CEC0", Length = "0x28")]
	[Token(Token = "0x6002772")]
	public virtual string ToString() { }

}

