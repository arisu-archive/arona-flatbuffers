namespace System.Reflection;

[Token(Token = "0x200052E")]
public abstract class TypeInfo : Type, IReflectableType
{
	[Token(Token = "0x4001515")]
	private const BindingFlags DeclaredOnlyLookup = 62; //Field offset: 0x0

	[Token(Token = "0x17000581")]
	public override IEnumerable<PropertyInfo> DeclaredProperties
	{
		[Address(RVA = "0x7318960", Offset = "0x7318960", Length = "0x14")]
		[Token(Token = "0x60026FF")]
		 get { } //Length: 20
	}

	[Token(Token = "0x17000582")]
	public override IEnumerable<Type> ImplementedInterfaces
	{
		[Address(RVA = "0x7318974", Offset = "0x7318974", Length = "0x10")]
		[Token(Token = "0x6002700")]
		 get { } //Length: 16
	}

	[Address(RVA = "0x7318244", Offset = "0x7318244", Length = "0x58")]
	[Token(Token = "0x60026FA")]
	protected TypeInfo() { }

	[Address(RVA = "0x731893C", Offset = "0x731893C", Length = "0x4")]
	[Token(Token = "0x60026FC")]
	public override Type AsType() { }

	[Address(RVA = "0x7318960", Offset = "0x7318960", Length = "0x14")]
	[Token(Token = "0x60026FF")]
	public override IEnumerable<PropertyInfo> get_DeclaredProperties() { }

	[Address(RVA = "0x7318974", Offset = "0x7318974", Length = "0x10")]
	[Token(Token = "0x6002700")]
	public override IEnumerable<Type> get_ImplementedInterfaces() { }

	[Address(RVA = "0x7318940", Offset = "0x7318940", Length = "0x14")]
	[Token(Token = "0x60026FD")]
	public override FieldInfo GetDeclaredField(string name) { }

	[Address(RVA = "0x7318954", Offset = "0x7318954", Length = "0xC")]
	[Token(Token = "0x60026FE")]
	public override PropertyInfo GetDeclaredProperty(string name) { }

	[Address(RVA = "0x7318938", Offset = "0x7318938", Length = "0x4")]
	[Token(Token = "0x60026FB")]
	private override TypeInfo System.Reflection.IReflectableType.GetTypeInfo() { }

}

