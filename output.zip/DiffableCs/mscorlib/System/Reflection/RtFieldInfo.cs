namespace System.Reflection;

[Token(Token = "0x2000542")]
internal abstract class RtFieldInfo : FieldInfo
{

	[Address(RVA = "0x7320358", Offset = "0x7320358", Length = "0x8")]
	[Token(Token = "0x60027D6")]
	protected RtFieldInfo() { }

	[Token(Token = "0x60027D5")]
	internal abstract void CheckConsistency(object target) { }

	[Token(Token = "0x60027D3")]
	internal abstract object UnsafeGetValue(object obj) { }

	[Token(Token = "0x60027D4")]
	internal abstract void UnsafeSetValue(object obj, object value, BindingFlags invokeAttr, Binder binder, CultureInfo culture) { }

}

