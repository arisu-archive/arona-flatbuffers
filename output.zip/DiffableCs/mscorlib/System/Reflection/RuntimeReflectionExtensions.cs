namespace System.Reflection;

[Extension]
[Token(Token = "0x200052F")]
public static class RuntimeReflectionExtensions
{

	[Address(RVA = "0x7318B1C", Offset = "0x7318B1C", Length = "0x68")]
	[Extension]
	[Token(Token = "0x6002703")]
	public static MethodInfo GetRuntimeBaseDefinition(MethodInfo method) { }

	[Address(RVA = "0x7318984", Offset = "0x7318984", Length = "0xCC")]
	[Extension]
	[Token(Token = "0x6002701")]
	public static IEnumerable<MethodInfo> GetRuntimeMethods(Type type) { }

	[Address(RVA = "0x7318A50", Offset = "0x7318A50", Length = "0xCC")]
	[Extension]
	[Token(Token = "0x6002702")]
	public static IEnumerable<PropertyInfo> GetRuntimeProperties(Type type) { }

}

