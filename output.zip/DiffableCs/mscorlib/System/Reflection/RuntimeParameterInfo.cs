namespace System.Reflection;

[ClassInterface(ClassInterfaceType::None (0))]
[ComDefaultInterface(typeof(_ParameterInfo))]
[ComVisible(True)]
[Token(Token = "0x2000548")]
internal class RuntimeParameterInfo : ParameterInfo
{
	[FieldOffset(Offset = "0x40")]
	[Token(Token = "0x40015D0")]
	internal MarshalAsAttribute marshalAs; //Field offset: 0x40

	[Token(Token = "0x170005D2")]
	public virtual object DefaultValue
	{
		[Address(RVA = "0x73242C4", Offset = "0x73242C4", Length = "0x330")]
		[Token(Token = "0x600286F")]
		 get { } //Length: 816
	}

	[Address(RVA = "0x732401C", Offset = "0x732401C", Length = "0xA8")]
	[Token(Token = "0x600286B")]
	internal RuntimeParameterInfo(string name, Type type, int position, int attrs, object defaultValue, MemberInfo member, MarshalAsAttribute marshalAs) { }

	[Address(RVA = "0x73240C4", Offset = "0x73240C4", Length = "0xBC")]
	[Token(Token = "0x600286D")]
	internal RuntimeParameterInfo(ParameterInfo pinfo, MemberInfo member) { }

	[Address(RVA = "0x7324244", Offset = "0x7324244", Length = "0x80")]
	[Token(Token = "0x600286E")]
	internal RuntimeParameterInfo(Type type, MemberInfo member, MarshalAsAttribute marshalAs) { }

	[Address(RVA = "0x73214C4", Offset = "0x73214C4", Length = "0x1F4")]
	[Token(Token = "0x600286C")]
	internal static void FormatParameters(StringBuilder sb, ParameterInfo[] p, CallingConventions callingConvention, bool serialization) { }

	[Address(RVA = "0x73242C4", Offset = "0x73242C4", Length = "0x330")]
	[Token(Token = "0x600286F")]
	public virtual object get_DefaultValue() { }

	[Address(RVA = "0x73245F4", Offset = "0x73245F4", Length = "0x5C")]
	[Token(Token = "0x6002870")]
	public virtual Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x7324650", Offset = "0x7324650", Length = "0x6C")]
	[Token(Token = "0x6002871")]
	public virtual Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7324180", Offset = "0x7324180", Length = "0xC4")]
	[Token(Token = "0x6002872")]
	internal object GetDefaultValueImpl(ParameterInfo pinfo) { }

	[Address(RVA = "0x732472C", Offset = "0x732472C", Length = "0x284")]
	[Token(Token = "0x6002874")]
	internal Object[] GetPseudoCustomAttributes() { }

	[Address(RVA = "0x73249B0", Offset = "0x73249B0", Length = "0x520")]
	[Token(Token = "0x6002875")]
	internal CustomAttributeData[] GetPseudoCustomAttributesData() { }

	[Address(RVA = "0x73246BC", Offset = "0x73246BC", Length = "0x70")]
	[Token(Token = "0x6002873")]
	public virtual bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7324ED0", Offset = "0x7324ED0", Length = "0x1070")]
	[Token(Token = "0x6002876")]
	internal static ParameterInfo New(ParameterInfo pinfo, MemberInfo member) { }

	[Address(RVA = "0x73211C8", Offset = "0x73211C8", Length = "0x78")]
	[Token(Token = "0x6002877")]
	internal static ParameterInfo New(Type type, MemberInfo member, MarshalAsAttribute marshalAs) { }

}

