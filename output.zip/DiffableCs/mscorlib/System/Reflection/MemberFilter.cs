namespace System.Reflection;

[Token(Token = "0x200050F")]
public sealed class MemberFilter : MulticastDelegate
{

	[Address(RVA = "0x7312CC4", Offset = "0x7312CC4", Length = "0x144")]
	[Token(Token = "0x6002592")]
	public MemberFilter(object object, IntPtr method) { }

	[Address(RVA = "0x7312E08", Offset = "0x7312E08", Length = "0x14")]
	[Token(Token = "0x6002593")]
	public override bool Invoke(MemberInfo m, object filterCriteria) { }

}

