namespace System.Reflection;

[Token(Token = "0x200050D")]
public class InvalidFilterCriteriaException : ApplicationException
{

	[Address(RVA = "0x7312BA0", Offset = "0x7312BA0", Length = "0x60")]
	[Token(Token = "0x600258A")]
	public InvalidFilterCriteriaException() { }

	[Address(RVA = "0x7312C00", Offset = "0x7312C00", Length = "0x28")]
	[Token(Token = "0x600258B")]
	public InvalidFilterCriteriaException(string message) { }

	[Address(RVA = "0x7312C28", Offset = "0x7312C28", Length = "0x24")]
	[Token(Token = "0x600258C")]
	public InvalidFilterCriteriaException(string message, Exception inner) { }

	[Address(RVA = "0x7312C4C", Offset = "0x7312C4C", Length = "0x8")]
	[Token(Token = "0x600258D")]
	protected InvalidFilterCriteriaException(SerializationInfo info, StreamingContext context) { }

}

