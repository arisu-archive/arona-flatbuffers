namespace System.Reflection.Emit;

[Token(Token = "0x200055C")]
public sealed class PropertyBuilder : PropertyInfo
{

	[Token(Token = "0x17000604")]
	public virtual bool CanRead
	{
		[Address(RVA = "0x7328DF8", Offset = "0x7328DF8", Length = "0x40")]
		[Token(Token = "0x6002917")]
		 get { } //Length: 64
	}

	[Token(Token = "0x17000605")]
	public virtual bool CanWrite
	{
		[Address(RVA = "0x7328E38", Offset = "0x7328E38", Length = "0x40")]
		[Token(Token = "0x6002918")]
		 get { } //Length: 64
	}

	[Token(Token = "0x17000606")]
	public virtual Type DeclaringType
	{
		[Address(RVA = "0x7328E78", Offset = "0x7328E78", Length = "0x40")]
		[Token(Token = "0x6002919")]
		 get { } //Length: 64
	}

	[Token(Token = "0x17000607")]
	public virtual string Name
	{
		[Address(RVA = "0x7328EB8", Offset = "0x7328EB8", Length = "0x40")]
		[Token(Token = "0x600291A")]
		 get { } //Length: 64
	}

	[Token(Token = "0x17000608")]
	public virtual Type PropertyType
	{
		[Address(RVA = "0x7328EF8", Offset = "0x7328EF8", Length = "0x40")]
		[Token(Token = "0x600291B")]
		 get { } //Length: 64
	}

	[Token(Token = "0x17000609")]
	public virtual Type ReflectedType
	{
		[Address(RVA = "0x7328F38", Offset = "0x7328F38", Length = "0x40")]
		[Token(Token = "0x600291C")]
		 get { } //Length: 64
	}

	[Address(RVA = "0x7328DF8", Offset = "0x7328DF8", Length = "0x40")]
	[Token(Token = "0x6002917")]
	public virtual bool get_CanRead() { }

	[Address(RVA = "0x7328E38", Offset = "0x7328E38", Length = "0x40")]
	[Token(Token = "0x6002918")]
	public virtual bool get_CanWrite() { }

	[Address(RVA = "0x7328E78", Offset = "0x7328E78", Length = "0x40")]
	[Token(Token = "0x6002919")]
	public virtual Type get_DeclaringType() { }

	[Address(RVA = "0x7328EB8", Offset = "0x7328EB8", Length = "0x40")]
	[Token(Token = "0x600291A")]
	public virtual string get_Name() { }

	[Address(RVA = "0x7328EF8", Offset = "0x7328EF8", Length = "0x40")]
	[Token(Token = "0x600291B")]
	public virtual Type get_PropertyType() { }

	[Address(RVA = "0x7328F38", Offset = "0x7328F38", Length = "0x40")]
	[Token(Token = "0x600291C")]
	public virtual Type get_ReflectedType() { }

	[Address(RVA = "0x7328F78", Offset = "0x7328F78", Length = "0x40")]
	[Token(Token = "0x600291D")]
	public virtual Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x7328FB8", Offset = "0x7328FB8", Length = "0x40")]
	[Token(Token = "0x600291E")]
	public virtual Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7328FF8", Offset = "0x7328FF8", Length = "0x40")]
	[Token(Token = "0x600291F")]
	public virtual MethodInfo GetGetMethod(bool nonPublic) { }

	[Address(RVA = "0x7329038", Offset = "0x7329038", Length = "0x40")]
	[Token(Token = "0x6002920")]
	public virtual ParameterInfo[] GetIndexParameters() { }

	[Address(RVA = "0x7329078", Offset = "0x7329078", Length = "0x40")]
	[Token(Token = "0x6002921")]
	public virtual MethodInfo GetSetMethod(bool nonPublic) { }

	[Address(RVA = "0x73290B8", Offset = "0x73290B8", Length = "0x40")]
	[Token(Token = "0x6002922")]
	public virtual object GetValue(object obj, BindingFlags invokeAttr, Binder binder, Object[] index, CultureInfo culture) { }

	[Address(RVA = "0x73290F8", Offset = "0x73290F8", Length = "0x40")]
	[Token(Token = "0x6002923")]
	public virtual bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7329138", Offset = "0x7329138", Length = "0x40")]
	[Token(Token = "0x6002924")]
	public virtual void SetValue(object obj, object value, BindingFlags invokeAttr, Binder binder, Object[] index, CultureInfo culture) { }

}

