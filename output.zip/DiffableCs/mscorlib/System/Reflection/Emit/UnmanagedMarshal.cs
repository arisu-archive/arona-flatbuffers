namespace System.Reflection.Emit;

[ComVisible(True)]
[Obsolete("An alternate API is available: Emit the MarshalAs custom attribute instead.")]
[Token(Token = "0x200055F")]
public sealed class UnmanagedMarshal
{

	[Address(RVA = "0x73299F8", Offset = "0x73299F8", Length = "0x8")]
	[Token(Token = "0x6002947")]
	private UnmanagedMarshal() { }

}

