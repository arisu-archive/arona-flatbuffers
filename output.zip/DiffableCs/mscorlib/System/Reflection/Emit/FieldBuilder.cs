namespace System.Reflection.Emit;

[Token(Token = "0x2000555")]
public sealed class FieldBuilder : FieldInfo
{

	[Token(Token = "0x170005F0")]
	public virtual FieldAttributes Attributes
	{
		[Address(RVA = "0x73281E8", Offset = "0x73281E8", Length = "0x8")]
		[Token(Token = "0x60028DE")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005F1")]
	public virtual Type DeclaringType
	{
		[Address(RVA = "0x73281F0", Offset = "0x73281F0", Length = "0x8")]
		[Token(Token = "0x60028DF")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005F2")]
	public virtual RuntimeFieldHandle FieldHandle
	{
		[Address(RVA = "0x73281F8", Offset = "0x73281F8", Length = "0x8")]
		[Token(Token = "0x60028E0")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005F3")]
	public virtual Type FieldType
	{
		[Address(RVA = "0x7328200", Offset = "0x7328200", Length = "0x8")]
		[Token(Token = "0x60028E1")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005F4")]
	public virtual string Name
	{
		[Address(RVA = "0x7328208", Offset = "0x7328208", Length = "0x8")]
		[Token(Token = "0x60028E2")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170005F5")]
	public virtual Type ReflectedType
	{
		[Address(RVA = "0x7328210", Offset = "0x7328210", Length = "0x8")]
		[Token(Token = "0x60028E3")]
		 get { } //Length: 8
	}

	[Address(RVA = "0x73281E8", Offset = "0x73281E8", Length = "0x8")]
	[Token(Token = "0x60028DE")]
	public virtual FieldAttributes get_Attributes() { }

	[Address(RVA = "0x73281F0", Offset = "0x73281F0", Length = "0x8")]
	[Token(Token = "0x60028DF")]
	public virtual Type get_DeclaringType() { }

	[Address(RVA = "0x73281F8", Offset = "0x73281F8", Length = "0x8")]
	[Token(Token = "0x60028E0")]
	public virtual RuntimeFieldHandle get_FieldHandle() { }

	[Address(RVA = "0x7328200", Offset = "0x7328200", Length = "0x8")]
	[Token(Token = "0x60028E1")]
	public virtual Type get_FieldType() { }

	[Address(RVA = "0x7328208", Offset = "0x7328208", Length = "0x8")]
	[Token(Token = "0x60028E2")]
	public virtual string get_Name() { }

	[Address(RVA = "0x7328210", Offset = "0x7328210", Length = "0x8")]
	[Token(Token = "0x60028E3")]
	public virtual Type get_ReflectedType() { }

	[Address(RVA = "0x7328218", Offset = "0x7328218", Length = "0x8")]
	[Token(Token = "0x60028E4")]
	public virtual Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x7328220", Offset = "0x7328220", Length = "0x8")]
	[Token(Token = "0x60028E5")]
	public virtual Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7328228", Offset = "0x7328228", Length = "0x8")]
	[Token(Token = "0x60028E6")]
	public virtual object GetValue(object obj) { }

	[Address(RVA = "0x7328230", Offset = "0x7328230", Length = "0x8")]
	[Token(Token = "0x60028E7")]
	public virtual bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7328238", Offset = "0x7328238", Length = "0x40")]
	[Token(Token = "0x60028E8")]
	public virtual void SetValue(object obj, object val, BindingFlags invokeAttr, Binder binder, CultureInfo culture) { }

}

