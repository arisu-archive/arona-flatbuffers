namespace System.Reflection.Emit;

[Token(Token = "0x2000550")]
public class AssemblyBuilder : Assembly
{

}

