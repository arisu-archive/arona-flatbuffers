namespace System.Reflection.Emit;

[Token(Token = "0x200055A")]
public class ModuleBuilder : Module
{

}

