namespace System.Reflection.Emit;

[Token(Token = "0x2000556")]
public sealed class GenericTypeParameterBuilder : TypeInfo
{

	[Token(Token = "0x170005F6")]
	public virtual Assembly Assembly
	{
		[Address(RVA = "0x7328278", Offset = "0x7328278", Length = "0x40")]
		[Token(Token = "0x60028E9")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005F7")]
	public virtual string AssemblyQualifiedName
	{
		[Address(RVA = "0x73282B8", Offset = "0x73282B8", Length = "0x40")]
		[Token(Token = "0x60028EA")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005F8")]
	public virtual Type BaseType
	{
		[Address(RVA = "0x73282F8", Offset = "0x73282F8", Length = "0x40")]
		[Token(Token = "0x60028EB")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005F9")]
	public virtual string FullName
	{
		[Address(RVA = "0x7328338", Offset = "0x7328338", Length = "0x40")]
		[Token(Token = "0x60028EC")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005FA")]
	public virtual Guid GUID
	{
		[Address(RVA = "0x7328378", Offset = "0x7328378", Length = "0x40")]
		[Token(Token = "0x60028ED")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005FB")]
	public virtual Module Module
	{
		[Address(RVA = "0x73283B8", Offset = "0x73283B8", Length = "0x40")]
		[Token(Token = "0x60028EE")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005FC")]
	public virtual string Name
	{
		[Address(RVA = "0x73283F8", Offset = "0x73283F8", Length = "0x40")]
		[Token(Token = "0x60028EF")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005FD")]
	public virtual string Namespace
	{
		[Address(RVA = "0x7328438", Offset = "0x7328438", Length = "0x40")]
		[Token(Token = "0x60028F0")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005FE")]
	public virtual Type UnderlyingSystemType
	{
		[Address(RVA = "0x7328478", Offset = "0x7328478", Length = "0x40")]
		[Token(Token = "0x60028F1")]
		 get { } //Length: 64
	}

	[Address(RVA = "0x7328278", Offset = "0x7328278", Length = "0x40")]
	[Token(Token = "0x60028E9")]
	public virtual Assembly get_Assembly() { }

	[Address(RVA = "0x73282B8", Offset = "0x73282B8", Length = "0x40")]
	[Token(Token = "0x60028EA")]
	public virtual string get_AssemblyQualifiedName() { }

	[Address(RVA = "0x73282F8", Offset = "0x73282F8", Length = "0x40")]
	[Token(Token = "0x60028EB")]
	public virtual Type get_BaseType() { }

	[Address(RVA = "0x7328338", Offset = "0x7328338", Length = "0x40")]
	[Token(Token = "0x60028EC")]
	public virtual string get_FullName() { }

	[Address(RVA = "0x7328378", Offset = "0x7328378", Length = "0x40")]
	[Token(Token = "0x60028ED")]
	public virtual Guid get_GUID() { }

	[Address(RVA = "0x73283B8", Offset = "0x73283B8", Length = "0x40")]
	[Token(Token = "0x60028EE")]
	public virtual Module get_Module() { }

	[Address(RVA = "0x73283F8", Offset = "0x73283F8", Length = "0x40")]
	[Token(Token = "0x60028EF")]
	public virtual string get_Name() { }

	[Address(RVA = "0x7328438", Offset = "0x7328438", Length = "0x40")]
	[Token(Token = "0x60028F0")]
	public virtual string get_Namespace() { }

	[Address(RVA = "0x7328478", Offset = "0x7328478", Length = "0x40")]
	[Token(Token = "0x60028F1")]
	public virtual Type get_UnderlyingSystemType() { }

	[Address(RVA = "0x73284B8", Offset = "0x73284B8", Length = "0x40")]
	[Token(Token = "0x60028F2")]
	protected virtual TypeAttributes GetAttributeFlagsImpl() { }

	[Address(RVA = "0x73284F8", Offset = "0x73284F8", Length = "0x40")]
	[Token(Token = "0x60028F3")]
	protected virtual ConstructorInfo GetConstructorImpl(BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers) { }

	[Address(RVA = "0x7328538", Offset = "0x7328538", Length = "0x40")]
	[ComVisible(True)]
	[Token(Token = "0x60028F4")]
	public virtual ConstructorInfo[] GetConstructors(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7328578", Offset = "0x7328578", Length = "0x40")]
	[Token(Token = "0x60028F5")]
	public virtual Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x73285B8", Offset = "0x73285B8", Length = "0x40")]
	[Token(Token = "0x60028F6")]
	public virtual Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x73285F8", Offset = "0x73285F8", Length = "0x40")]
	[Token(Token = "0x60028F7")]
	public virtual Type GetElementType() { }

	[Address(RVA = "0x7328638", Offset = "0x7328638", Length = "0x40")]
	[Token(Token = "0x60028F8")]
	public virtual EventInfo GetEvent(string name, BindingFlags bindingAttr) { }

	[Address(RVA = "0x7328678", Offset = "0x7328678", Length = "0x40")]
	[Token(Token = "0x60028F9")]
	public virtual EventInfo[] GetEvents(BindingFlags bindingAttr) { }

	[Address(RVA = "0x73286B8", Offset = "0x73286B8", Length = "0x40")]
	[Token(Token = "0x60028FA")]
	public virtual FieldInfo GetField(string name, BindingFlags bindingAttr) { }

	[Address(RVA = "0x73286F8", Offset = "0x73286F8", Length = "0x40")]
	[Token(Token = "0x60028FB")]
	public virtual FieldInfo[] GetFields(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7328738", Offset = "0x7328738", Length = "0x40")]
	[Token(Token = "0x60028FC")]
	public virtual Type[] GetInterfaces() { }

	[Address(RVA = "0x7328778", Offset = "0x7328778", Length = "0x40")]
	[Token(Token = "0x60028FD")]
	public virtual MemberInfo[] GetMembers(BindingFlags bindingAttr) { }

	[Address(RVA = "0x73287B8", Offset = "0x73287B8", Length = "0x40")]
	[Token(Token = "0x60028FE")]
	protected virtual MethodInfo GetMethodImpl(string name, BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers) { }

	[Address(RVA = "0x73287F8", Offset = "0x73287F8", Length = "0x40")]
	[Token(Token = "0x60028FF")]
	public virtual MethodInfo[] GetMethods(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7328838", Offset = "0x7328838", Length = "0x40")]
	[Token(Token = "0x6002900")]
	public virtual Type GetNestedType(string name, BindingFlags bindingAttr) { }

	[Address(RVA = "0x7328878", Offset = "0x7328878", Length = "0x40")]
	[Token(Token = "0x6002901")]
	public virtual PropertyInfo[] GetProperties(BindingFlags bindingAttr) { }

	[Address(RVA = "0x73288B8", Offset = "0x73288B8", Length = "0x40")]
	[Token(Token = "0x6002902")]
	protected virtual PropertyInfo GetPropertyImpl(string name, BindingFlags bindingAttr, Binder binder, Type returnType, Type[] types, ParameterModifier[] modifiers) { }

	[Address(RVA = "0x73288F8", Offset = "0x73288F8", Length = "0x40")]
	[Token(Token = "0x6002903")]
	protected virtual bool HasElementTypeImpl() { }

	[Address(RVA = "0x7328938", Offset = "0x7328938", Length = "0x40")]
	[Token(Token = "0x6002904")]
	public virtual object InvokeMember(string name, BindingFlags invokeAttr, Binder binder, object target, Object[] args, ParameterModifier[] modifiers, CultureInfo culture, String[] namedParameters) { }

	[Address(RVA = "0x7328978", Offset = "0x7328978", Length = "0x40")]
	[Token(Token = "0x6002905")]
	protected virtual bool IsArrayImpl() { }

	[Address(RVA = "0x73289B8", Offset = "0x73289B8", Length = "0x40")]
	[Token(Token = "0x6002906")]
	protected virtual bool IsByRefImpl() { }

	[Address(RVA = "0x73289F8", Offset = "0x73289F8", Length = "0x40")]
	[Token(Token = "0x6002907")]
	protected virtual bool IsCOMObjectImpl() { }

	[Address(RVA = "0x7328A38", Offset = "0x7328A38", Length = "0x40")]
	[Token(Token = "0x6002908")]
	public virtual bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7328A78", Offset = "0x7328A78", Length = "0x40")]
	[Token(Token = "0x6002909")]
	protected virtual bool IsPointerImpl() { }

	[Address(RVA = "0x7328AB8", Offset = "0x7328AB8", Length = "0x40")]
	[Token(Token = "0x600290A")]
	protected virtual bool IsPrimitiveImpl() { }

}

