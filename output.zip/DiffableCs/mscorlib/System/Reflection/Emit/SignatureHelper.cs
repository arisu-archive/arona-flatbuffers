namespace System.Reflection.Emit;

[Token(Token = "0x200055D")]
public class SignatureHelper
{

}

