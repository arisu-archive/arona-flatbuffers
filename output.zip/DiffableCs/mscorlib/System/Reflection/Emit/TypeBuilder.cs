namespace System.Reflection.Emit;

[Token(Token = "0x200055E")]
public sealed class TypeBuilder : TypeInfo
{
	[Token(Token = "0x40015EB")]
	public const int UnspecifiedTypeSize = 0; //Field offset: 0x0

	[Token(Token = "0x1700060A")]
	public virtual Assembly Assembly
	{
		[Address(RVA = "0x7329178", Offset = "0x7329178", Length = "0x40")]
		[Token(Token = "0x6002925")]
		 get { } //Length: 64
	}

	[Token(Token = "0x1700060B")]
	public virtual string AssemblyQualifiedName
	{
		[Address(RVA = "0x73291B8", Offset = "0x73291B8", Length = "0x40")]
		[Token(Token = "0x6002926")]
		 get { } //Length: 64
	}

	[Token(Token = "0x1700060C")]
	public virtual Type BaseType
	{
		[Address(RVA = "0x73291F8", Offset = "0x73291F8", Length = "0x40")]
		[Token(Token = "0x6002927")]
		 get { } //Length: 64
	}

	[Token(Token = "0x1700060D")]
	public virtual string FullName
	{
		[Address(RVA = "0x7329238", Offset = "0x7329238", Length = "0x40")]
		[Token(Token = "0x6002928")]
		 get { } //Length: 64
	}

	[Token(Token = "0x1700060E")]
	public virtual Guid GUID
	{
		[Address(RVA = "0x7329278", Offset = "0x7329278", Length = "0x40")]
		[Token(Token = "0x6002929")]
		 get { } //Length: 64
	}

	[Token(Token = "0x1700060F")]
	public virtual Module Module
	{
		[Address(RVA = "0x73292B8", Offset = "0x73292B8", Length = "0x40")]
		[Token(Token = "0x600292A")]
		 get { } //Length: 64
	}

	[Token(Token = "0x17000610")]
	public virtual string Name
	{
		[Address(RVA = "0x73292F8", Offset = "0x73292F8", Length = "0x40")]
		[Token(Token = "0x600292B")]
		 get { } //Length: 64
	}

	[Token(Token = "0x17000611")]
	public virtual string Namespace
	{
		[Address(RVA = "0x7329338", Offset = "0x7329338", Length = "0x40")]
		[Token(Token = "0x600292C")]
		 get { } //Length: 64
	}

	[Token(Token = "0x17000612")]
	public virtual Type UnderlyingSystemType
	{
		[Address(RVA = "0x7329378", Offset = "0x7329378", Length = "0x40")]
		[Token(Token = "0x600292D")]
		 get { } //Length: 64
	}

	[Address(RVA = "0x7329178", Offset = "0x7329178", Length = "0x40")]
	[Token(Token = "0x6002925")]
	public virtual Assembly get_Assembly() { }

	[Address(RVA = "0x73291B8", Offset = "0x73291B8", Length = "0x40")]
	[Token(Token = "0x6002926")]
	public virtual string get_AssemblyQualifiedName() { }

	[Address(RVA = "0x73291F8", Offset = "0x73291F8", Length = "0x40")]
	[Token(Token = "0x6002927")]
	public virtual Type get_BaseType() { }

	[Address(RVA = "0x7329238", Offset = "0x7329238", Length = "0x40")]
	[Token(Token = "0x6002928")]
	public virtual string get_FullName() { }

	[Address(RVA = "0x7329278", Offset = "0x7329278", Length = "0x40")]
	[Token(Token = "0x6002929")]
	public virtual Guid get_GUID() { }

	[Address(RVA = "0x73292B8", Offset = "0x73292B8", Length = "0x40")]
	[Token(Token = "0x600292A")]
	public virtual Module get_Module() { }

	[Address(RVA = "0x73292F8", Offset = "0x73292F8", Length = "0x40")]
	[Token(Token = "0x600292B")]
	public virtual string get_Name() { }

	[Address(RVA = "0x7329338", Offset = "0x7329338", Length = "0x40")]
	[Token(Token = "0x600292C")]
	public virtual string get_Namespace() { }

	[Address(RVA = "0x7329378", Offset = "0x7329378", Length = "0x40")]
	[Token(Token = "0x600292D")]
	public virtual Type get_UnderlyingSystemType() { }

	[Address(RVA = "0x73293B8", Offset = "0x73293B8", Length = "0x40")]
	[Token(Token = "0x600292E")]
	protected virtual TypeAttributes GetAttributeFlagsImpl() { }

	[Address(RVA = "0x73293F8", Offset = "0x73293F8", Length = "0x40")]
	[Token(Token = "0x600292F")]
	protected virtual ConstructorInfo GetConstructorImpl(BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers) { }

	[Address(RVA = "0x7329438", Offset = "0x7329438", Length = "0x40")]
	[ComVisible(True)]
	[Token(Token = "0x6002930")]
	public virtual ConstructorInfo[] GetConstructors(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7329478", Offset = "0x7329478", Length = "0x40")]
	[Token(Token = "0x6002931")]
	public virtual Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x73294B8", Offset = "0x73294B8", Length = "0x40")]
	[Token(Token = "0x6002932")]
	public virtual Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x73294F8", Offset = "0x73294F8", Length = "0x40")]
	[Token(Token = "0x6002933")]
	public virtual Type GetElementType() { }

	[Address(RVA = "0x7329538", Offset = "0x7329538", Length = "0x40")]
	[Token(Token = "0x6002934")]
	public virtual EventInfo GetEvent(string name, BindingFlags bindingAttr) { }

	[Address(RVA = "0x7329578", Offset = "0x7329578", Length = "0x40")]
	[Token(Token = "0x6002935")]
	public virtual EventInfo[] GetEvents(BindingFlags bindingAttr) { }

	[Address(RVA = "0x73295B8", Offset = "0x73295B8", Length = "0x40")]
	[Token(Token = "0x6002936")]
	public virtual FieldInfo GetField(string name, BindingFlags bindingAttr) { }

	[Address(RVA = "0x73295F8", Offset = "0x73295F8", Length = "0x40")]
	[Token(Token = "0x6002937")]
	public virtual FieldInfo[] GetFields(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7329638", Offset = "0x7329638", Length = "0x40")]
	[Token(Token = "0x6002938")]
	public virtual Type[] GetInterfaces() { }

	[Address(RVA = "0x7329678", Offset = "0x7329678", Length = "0x40")]
	[Token(Token = "0x6002939")]
	public virtual MemberInfo[] GetMembers(BindingFlags bindingAttr) { }

	[Address(RVA = "0x73296B8", Offset = "0x73296B8", Length = "0x40")]
	[Token(Token = "0x600293A")]
	protected virtual MethodInfo GetMethodImpl(string name, BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers) { }

	[Address(RVA = "0x73296F8", Offset = "0x73296F8", Length = "0x40")]
	[Token(Token = "0x600293B")]
	public virtual MethodInfo[] GetMethods(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7329738", Offset = "0x7329738", Length = "0x40")]
	[Token(Token = "0x600293C")]
	public virtual Type GetNestedType(string name, BindingFlags bindingAttr) { }

	[Address(RVA = "0x7329778", Offset = "0x7329778", Length = "0x40")]
	[Token(Token = "0x600293D")]
	public virtual PropertyInfo[] GetProperties(BindingFlags bindingAttr) { }

	[Address(RVA = "0x73297B8", Offset = "0x73297B8", Length = "0x40")]
	[Token(Token = "0x600293E")]
	protected virtual PropertyInfo GetPropertyImpl(string name, BindingFlags bindingAttr, Binder binder, Type returnType, Type[] types, ParameterModifier[] modifiers) { }

	[Address(RVA = "0x73297F8", Offset = "0x73297F8", Length = "0x40")]
	[Token(Token = "0x600293F")]
	protected virtual bool HasElementTypeImpl() { }

	[Address(RVA = "0x7329838", Offset = "0x7329838", Length = "0x40")]
	[Token(Token = "0x6002940")]
	public virtual object InvokeMember(string name, BindingFlags invokeAttr, Binder binder, object target, Object[] args, ParameterModifier[] modifiers, CultureInfo culture, String[] namedParameters) { }

	[Address(RVA = "0x7329878", Offset = "0x7329878", Length = "0x40")]
	[Token(Token = "0x6002941")]
	protected virtual bool IsArrayImpl() { }

	[Address(RVA = "0x73298B8", Offset = "0x73298B8", Length = "0x40")]
	[Token(Token = "0x6002942")]
	protected virtual bool IsByRefImpl() { }

	[Address(RVA = "0x73298F8", Offset = "0x73298F8", Length = "0x40")]
	[Token(Token = "0x6002943")]
	protected virtual bool IsCOMObjectImpl() { }

	[Address(RVA = "0x7329938", Offset = "0x7329938", Length = "0x40")]
	[Token(Token = "0x6002944")]
	public virtual bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7329978", Offset = "0x7329978", Length = "0x40")]
	[Token(Token = "0x6002945")]
	protected virtual bool IsPointerImpl() { }

	[Address(RVA = "0x73299B8", Offset = "0x73299B8", Length = "0x40")]
	[Token(Token = "0x6002946")]
	protected virtual bool IsPrimitiveImpl() { }

}

