namespace System.Reflection.Emit;

[Token(Token = "0x2000559")]
public sealed class MethodBuilder : MethodInfo
{

	[Token(Token = "0x170005FF")]
	public virtual MethodAttributes Attributes
	{
		[Address(RVA = "0x7328AF8", Offset = "0x7328AF8", Length = "0x40")]
		[Token(Token = "0x600290B")]
		 get { } //Length: 64
	}

	[Token(Token = "0x17000600")]
	public virtual Type DeclaringType
	{
		[Address(RVA = "0x7328B38", Offset = "0x7328B38", Length = "0x40")]
		[Token(Token = "0x600290C")]
		 get { } //Length: 64
	}

	[Token(Token = "0x17000601")]
	public virtual RuntimeMethodHandle MethodHandle
	{
		[Address(RVA = "0x7328B78", Offset = "0x7328B78", Length = "0x40")]
		[Token(Token = "0x600290D")]
		 get { } //Length: 64
	}

	[Token(Token = "0x17000602")]
	public virtual string Name
	{
		[Address(RVA = "0x7328BB8", Offset = "0x7328BB8", Length = "0x40")]
		[Token(Token = "0x600290E")]
		 get { } //Length: 64
	}

	[Token(Token = "0x17000603")]
	public virtual Type ReflectedType
	{
		[Address(RVA = "0x7328BF8", Offset = "0x7328BF8", Length = "0x40")]
		[Token(Token = "0x600290F")]
		 get { } //Length: 64
	}

	[Address(RVA = "0x7328AF8", Offset = "0x7328AF8", Length = "0x40")]
	[Token(Token = "0x600290B")]
	public virtual MethodAttributes get_Attributes() { }

	[Address(RVA = "0x7328B38", Offset = "0x7328B38", Length = "0x40")]
	[Token(Token = "0x600290C")]
	public virtual Type get_DeclaringType() { }

	[Address(RVA = "0x7328B78", Offset = "0x7328B78", Length = "0x40")]
	[Token(Token = "0x600290D")]
	public virtual RuntimeMethodHandle get_MethodHandle() { }

	[Address(RVA = "0x7328BB8", Offset = "0x7328BB8", Length = "0x40")]
	[Token(Token = "0x600290E")]
	public virtual string get_Name() { }

	[Address(RVA = "0x7328BF8", Offset = "0x7328BF8", Length = "0x40")]
	[Token(Token = "0x600290F")]
	public virtual Type get_ReflectedType() { }

	[Address(RVA = "0x7328C38", Offset = "0x7328C38", Length = "0x40")]
	[Token(Token = "0x6002910")]
	public virtual MethodInfo GetBaseDefinition() { }

	[Address(RVA = "0x7328C78", Offset = "0x7328C78", Length = "0x40")]
	[Token(Token = "0x6002911")]
	public virtual Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x7328CB8", Offset = "0x7328CB8", Length = "0x40")]
	[Token(Token = "0x6002912")]
	public virtual Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7328CF8", Offset = "0x7328CF8", Length = "0x40")]
	[Token(Token = "0x6002913")]
	public virtual MethodImplAttributes GetMethodImplementationFlags() { }

	[Address(RVA = "0x7328D38", Offset = "0x7328D38", Length = "0x40")]
	[Token(Token = "0x6002914")]
	public virtual ParameterInfo[] GetParameters() { }

	[Address(RVA = "0x7328D78", Offset = "0x7328D78", Length = "0x40")]
	[Token(Token = "0x6002915")]
	public virtual object Invoke(object obj, BindingFlags invokeAttr, Binder binder, Object[] parameters, CultureInfo culture) { }

	[Address(RVA = "0x7328DB8", Offset = "0x7328DB8", Length = "0x40")]
	[Token(Token = "0x6002916")]
	public virtual bool IsDefined(Type attributeType, bool inherit) { }

}

