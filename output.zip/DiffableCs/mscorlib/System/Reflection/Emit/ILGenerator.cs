namespace System.Reflection.Emit;

[Token(Token = "0x2000557")]
public class ILGenerator
{

}

