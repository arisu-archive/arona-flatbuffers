namespace System.Reflection.Emit;

[Token(Token = "0x2000554")]
public class EventBuilder
{

}

