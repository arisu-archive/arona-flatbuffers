namespace System.Reflection.Emit;

[Token(Token = "0x2000551")]
public class ConstructorBuilder : ConstructorInfo
{

	[Token(Token = "0x170005DD")]
	public virtual MethodAttributes Attributes
	{
		[Address(RVA = "0x7327368", Offset = "0x7327368", Length = "0x40")]
		[Token(Token = "0x60028A4")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005DE")]
	public virtual Type DeclaringType
	{
		[Address(RVA = "0x73273A8", Offset = "0x73273A8", Length = "0x40")]
		[Token(Token = "0x60028A5")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005E0")]
	public virtual RuntimeMethodHandle MethodHandle
	{
		[Address(RVA = "0x73274A8", Offset = "0x73274A8", Length = "0x40")]
		[Token(Token = "0x60028A9")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005DF")]
	public virtual string Name
	{
		[Address(RVA = "0x73273E8", Offset = "0x73273E8", Length = "0x40")]
		[Token(Token = "0x60028A6")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005E1")]
	public virtual Type ReflectedType
	{
		[Address(RVA = "0x73275E8", Offset = "0x73275E8", Length = "0x40")]
		[Token(Token = "0x60028AE")]
		 get { } //Length: 64
	}

	[Address(RVA = "0x7327368", Offset = "0x7327368", Length = "0x40")]
	[Token(Token = "0x60028A4")]
	public virtual MethodAttributes get_Attributes() { }

	[Address(RVA = "0x73273A8", Offset = "0x73273A8", Length = "0x40")]
	[Token(Token = "0x60028A5")]
	public virtual Type get_DeclaringType() { }

	[Address(RVA = "0x73274A8", Offset = "0x73274A8", Length = "0x40")]
	[Token(Token = "0x60028A9")]
	public virtual RuntimeMethodHandle get_MethodHandle() { }

	[Address(RVA = "0x73273E8", Offset = "0x73273E8", Length = "0x40")]
	[Token(Token = "0x60028A6")]
	public virtual string get_Name() { }

	[Address(RVA = "0x73275E8", Offset = "0x73275E8", Length = "0x40")]
	[Token(Token = "0x60028AE")]
	public virtual Type get_ReflectedType() { }

	[Address(RVA = "0x7327568", Offset = "0x7327568", Length = "0x40")]
	[Token(Token = "0x60028AC")]
	public virtual Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x73275A8", Offset = "0x73275A8", Length = "0x40")]
	[Token(Token = "0x60028AD")]
	public virtual Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7327468", Offset = "0x7327468", Length = "0x40")]
	[Token(Token = "0x60028A8")]
	public virtual MethodImplAttributes GetMethodImplementationFlags() { }

	[Address(RVA = "0x7327428", Offset = "0x7327428", Length = "0x40")]
	[Token(Token = "0x60028A7")]
	public virtual ParameterInfo[] GetParameters() { }

	[Address(RVA = "0x73274E8", Offset = "0x73274E8", Length = "0x40")]
	[Token(Token = "0x60028AA")]
	public virtual object Invoke(BindingFlags invokeAttr, Binder binder, Object[] parameters, CultureInfo culture) { }

	[Address(RVA = "0x7327628", Offset = "0x7327628", Length = "0x40")]
	[Token(Token = "0x60028AF")]
	public virtual object Invoke(object obj, BindingFlags invokeAttr, Binder binder, Object[] parameters, CultureInfo culture) { }

	[Address(RVA = "0x7327528", Offset = "0x7327528", Length = "0x40")]
	[Token(Token = "0x60028AB")]
	public virtual bool IsDefined(Type attributeType, bool inherit) { }

}

