namespace System.Reflection.Emit;

[Token(Token = "0x2000553")]
public sealed class EnumBuilder : TypeInfo
{

	[Token(Token = "0x170005E7")]
	public virtual Assembly Assembly
	{
		[Address(RVA = "0x7327968", Offset = "0x7327968", Length = "0x40")]
		[Token(Token = "0x60028BC")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005E8")]
	public virtual string AssemblyQualifiedName
	{
		[Address(RVA = "0x73279A8", Offset = "0x73279A8", Length = "0x40")]
		[Token(Token = "0x60028BD")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005E9")]
	public virtual Type BaseType
	{
		[Address(RVA = "0x73279E8", Offset = "0x73279E8", Length = "0x40")]
		[Token(Token = "0x60028BE")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005EA")]
	public virtual string FullName
	{
		[Address(RVA = "0x7327A28", Offset = "0x7327A28", Length = "0x40")]
		[Token(Token = "0x60028BF")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005EB")]
	public virtual Guid GUID
	{
		[Address(RVA = "0x7327A68", Offset = "0x7327A68", Length = "0x40")]
		[Token(Token = "0x60028C0")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005EC")]
	public virtual Module Module
	{
		[Address(RVA = "0x7327AA8", Offset = "0x7327AA8", Length = "0x40")]
		[Token(Token = "0x60028C1")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005ED")]
	public virtual string Name
	{
		[Address(RVA = "0x7327AE8", Offset = "0x7327AE8", Length = "0x40")]
		[Token(Token = "0x60028C2")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005EE")]
	public virtual string Namespace
	{
		[Address(RVA = "0x7327B28", Offset = "0x7327B28", Length = "0x40")]
		[Token(Token = "0x60028C3")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005EF")]
	public virtual Type UnderlyingSystemType
	{
		[Address(RVA = "0x7327B68", Offset = "0x7327B68", Length = "0x40")]
		[Token(Token = "0x60028C4")]
		 get { } //Length: 64
	}

	[Address(RVA = "0x7327968", Offset = "0x7327968", Length = "0x40")]
	[Token(Token = "0x60028BC")]
	public virtual Assembly get_Assembly() { }

	[Address(RVA = "0x73279A8", Offset = "0x73279A8", Length = "0x40")]
	[Token(Token = "0x60028BD")]
	public virtual string get_AssemblyQualifiedName() { }

	[Address(RVA = "0x73279E8", Offset = "0x73279E8", Length = "0x40")]
	[Token(Token = "0x60028BE")]
	public virtual Type get_BaseType() { }

	[Address(RVA = "0x7327A28", Offset = "0x7327A28", Length = "0x40")]
	[Token(Token = "0x60028BF")]
	public virtual string get_FullName() { }

	[Address(RVA = "0x7327A68", Offset = "0x7327A68", Length = "0x40")]
	[Token(Token = "0x60028C0")]
	public virtual Guid get_GUID() { }

	[Address(RVA = "0x7327AA8", Offset = "0x7327AA8", Length = "0x40")]
	[Token(Token = "0x60028C1")]
	public virtual Module get_Module() { }

	[Address(RVA = "0x7327AE8", Offset = "0x7327AE8", Length = "0x40")]
	[Token(Token = "0x60028C2")]
	public virtual string get_Name() { }

	[Address(RVA = "0x7327B28", Offset = "0x7327B28", Length = "0x40")]
	[Token(Token = "0x60028C3")]
	public virtual string get_Namespace() { }

	[Address(RVA = "0x7327B68", Offset = "0x7327B68", Length = "0x40")]
	[Token(Token = "0x60028C4")]
	public virtual Type get_UnderlyingSystemType() { }

	[Address(RVA = "0x7327BA8", Offset = "0x7327BA8", Length = "0x40")]
	[Token(Token = "0x60028C5")]
	protected virtual TypeAttributes GetAttributeFlagsImpl() { }

	[Address(RVA = "0x7327BE8", Offset = "0x7327BE8", Length = "0x40")]
	[Token(Token = "0x60028C6")]
	protected virtual ConstructorInfo GetConstructorImpl(BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers) { }

	[Address(RVA = "0x7327C28", Offset = "0x7327C28", Length = "0x40")]
	[ComVisible(True)]
	[Token(Token = "0x60028C7")]
	public virtual ConstructorInfo[] GetConstructors(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7327C68", Offset = "0x7327C68", Length = "0x40")]
	[Token(Token = "0x60028C8")]
	public virtual Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x7327CA8", Offset = "0x7327CA8", Length = "0x40")]
	[Token(Token = "0x60028C9")]
	public virtual Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7327CE8", Offset = "0x7327CE8", Length = "0x40")]
	[Token(Token = "0x60028CA")]
	public virtual Type GetElementType() { }

	[Address(RVA = "0x7327D28", Offset = "0x7327D28", Length = "0x40")]
	[Token(Token = "0x60028CB")]
	public virtual EventInfo GetEvent(string name, BindingFlags bindingAttr) { }

	[Address(RVA = "0x7327D68", Offset = "0x7327D68", Length = "0x40")]
	[Token(Token = "0x60028CC")]
	public virtual EventInfo[] GetEvents(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7327DA8", Offset = "0x7327DA8", Length = "0x40")]
	[Token(Token = "0x60028CD")]
	public virtual FieldInfo GetField(string name, BindingFlags bindingAttr) { }

	[Address(RVA = "0x7327DE8", Offset = "0x7327DE8", Length = "0x40")]
	[Token(Token = "0x60028CE")]
	public virtual FieldInfo[] GetFields(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7327E28", Offset = "0x7327E28", Length = "0x40")]
	[Token(Token = "0x60028CF")]
	public virtual Type[] GetInterfaces() { }

	[Address(RVA = "0x7327E68", Offset = "0x7327E68", Length = "0x40")]
	[Token(Token = "0x60028D0")]
	public virtual MemberInfo[] GetMembers(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7327EA8", Offset = "0x7327EA8", Length = "0x40")]
	[Token(Token = "0x60028D1")]
	protected virtual MethodInfo GetMethodImpl(string name, BindingFlags bindingAttr, Binder binder, CallingConventions callConvention, Type[] types, ParameterModifier[] modifiers) { }

	[Address(RVA = "0x7327EE8", Offset = "0x7327EE8", Length = "0x40")]
	[Token(Token = "0x60028D2")]
	public virtual MethodInfo[] GetMethods(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7327F28", Offset = "0x7327F28", Length = "0x40")]
	[Token(Token = "0x60028D3")]
	public virtual Type GetNestedType(string name, BindingFlags bindingAttr) { }

	[Address(RVA = "0x7327F68", Offset = "0x7327F68", Length = "0x40")]
	[Token(Token = "0x60028D4")]
	public virtual PropertyInfo[] GetProperties(BindingFlags bindingAttr) { }

	[Address(RVA = "0x7327FA8", Offset = "0x7327FA8", Length = "0x40")]
	[Token(Token = "0x60028D5")]
	protected virtual PropertyInfo GetPropertyImpl(string name, BindingFlags bindingAttr, Binder binder, Type returnType, Type[] types, ParameterModifier[] modifiers) { }

	[Address(RVA = "0x7327FE8", Offset = "0x7327FE8", Length = "0x40")]
	[Token(Token = "0x60028D6")]
	protected virtual bool HasElementTypeImpl() { }

	[Address(RVA = "0x7328028", Offset = "0x7328028", Length = "0x40")]
	[Token(Token = "0x60028D7")]
	public virtual object InvokeMember(string name, BindingFlags invokeAttr, Binder binder, object target, Object[] args, ParameterModifier[] modifiers, CultureInfo culture, String[] namedParameters) { }

	[Address(RVA = "0x7328068", Offset = "0x7328068", Length = "0x40")]
	[Token(Token = "0x60028D8")]
	protected virtual bool IsArrayImpl() { }

	[Address(RVA = "0x73280A8", Offset = "0x73280A8", Length = "0x40")]
	[Token(Token = "0x60028D9")]
	protected virtual bool IsByRefImpl() { }

	[Address(RVA = "0x73280E8", Offset = "0x73280E8", Length = "0x40")]
	[Token(Token = "0x60028DA")]
	protected virtual bool IsCOMObjectImpl() { }

	[Address(RVA = "0x7328128", Offset = "0x7328128", Length = "0x40")]
	[Token(Token = "0x60028DB")]
	public virtual bool IsDefined(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7328168", Offset = "0x7328168", Length = "0x40")]
	[Token(Token = "0x60028DC")]
	protected virtual bool IsPointerImpl() { }

	[Address(RVA = "0x73281A8", Offset = "0x73281A8", Length = "0x40")]
	[Token(Token = "0x60028DD")]
	protected virtual bool IsPrimitiveImpl() { }

}

