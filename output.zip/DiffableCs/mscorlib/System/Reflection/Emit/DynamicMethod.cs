namespace System.Reflection.Emit;

[Token(Token = "0x2000552")]
public sealed class DynamicMethod : MethodInfo
{

	[Token(Token = "0x170005E2")]
	public virtual MethodAttributes Attributes
	{
		[Address(RVA = "0x7327668", Offset = "0x7327668", Length = "0x40")]
		[Token(Token = "0x60028B0")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005E3")]
	public virtual Type DeclaringType
	{
		[Address(RVA = "0x73276A8", Offset = "0x73276A8", Length = "0x40")]
		[Token(Token = "0x60028B1")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005E5")]
	public virtual RuntimeMethodHandle MethodHandle
	{
		[Address(RVA = "0x7327768", Offset = "0x7327768", Length = "0x40")]
		[Token(Token = "0x60028B4")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005E4")]
	public virtual string Name
	{
		[Address(RVA = "0x73276E8", Offset = "0x73276E8", Length = "0x40")]
		[Token(Token = "0x60028B2")]
		 get { } //Length: 64
	}

	[Token(Token = "0x170005E6")]
	public virtual Type ReflectedType
	{
		[Address(RVA = "0x73277A8", Offset = "0x73277A8", Length = "0x40")]
		[Token(Token = "0x60028B5")]
		 get { } //Length: 64
	}

	[Address(RVA = "0x7327668", Offset = "0x7327668", Length = "0x40")]
	[Token(Token = "0x60028B0")]
	public virtual MethodAttributes get_Attributes() { }

	[Address(RVA = "0x73276A8", Offset = "0x73276A8", Length = "0x40")]
	[Token(Token = "0x60028B1")]
	public virtual Type get_DeclaringType() { }

	[Address(RVA = "0x7327768", Offset = "0x7327768", Length = "0x40")]
	[Token(Token = "0x60028B4")]
	public virtual RuntimeMethodHandle get_MethodHandle() { }

	[Address(RVA = "0x73276E8", Offset = "0x73276E8", Length = "0x40")]
	[Token(Token = "0x60028B2")]
	public virtual string get_Name() { }

	[Address(RVA = "0x73277A8", Offset = "0x73277A8", Length = "0x40")]
	[Token(Token = "0x60028B5")]
	public virtual Type get_ReflectedType() { }

	[Address(RVA = "0x73278A8", Offset = "0x73278A8", Length = "0x40")]
	[Token(Token = "0x60028B9")]
	public virtual MethodInfo GetBaseDefinition() { }

	[Address(RVA = "0x73277E8", Offset = "0x73277E8", Length = "0x40")]
	[Token(Token = "0x60028B6")]
	public virtual Object[] GetCustomAttributes(bool inherit) { }

	[Address(RVA = "0x7327828", Offset = "0x7327828", Length = "0x40")]
	[Token(Token = "0x60028B7")]
	public virtual Object[] GetCustomAttributes(Type attributeType, bool inherit) { }

	[Address(RVA = "0x7327868", Offset = "0x7327868", Length = "0x40")]
	[Token(Token = "0x60028B8")]
	public virtual MethodImplAttributes GetMethodImplementationFlags() { }

	[Address(RVA = "0x7327728", Offset = "0x7327728", Length = "0x40")]
	[Token(Token = "0x60028B3")]
	public virtual ParameterInfo[] GetParameters() { }

	[Address(RVA = "0x73278E8", Offset = "0x73278E8", Length = "0x40")]
	[Token(Token = "0x60028BA")]
	public virtual object Invoke(object obj, BindingFlags invokeAttr, Binder binder, Object[] parameters, CultureInfo culture) { }

	[Address(RVA = "0x7327928", Offset = "0x7327928", Length = "0x40")]
	[Token(Token = "0x60028BB")]
	public virtual bool IsDefined(Type attributeType, bool inherit) { }

}

