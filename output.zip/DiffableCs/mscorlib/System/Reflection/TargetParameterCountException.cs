namespace System.Reflection;

[Token(Token = "0x200052A")]
public sealed class TargetParameterCountException : ApplicationException
{

	[Address(RVA = "0x73181BC", Offset = "0x73181BC", Length = "0x5C")]
	[Token(Token = "0x60026CA")]
	public TargetParameterCountException() { }

	[Address(RVA = "0x7318218", Offset = "0x7318218", Length = "0x24")]
	[Token(Token = "0x60026CB")]
	public TargetParameterCountException(string message) { }

	[Address(RVA = "0x731823C", Offset = "0x731823C", Length = "0x8")]
	[Token(Token = "0x60026CC")]
	internal TargetParameterCountException(SerializationInfo info, StreamingContext context) { }

}

