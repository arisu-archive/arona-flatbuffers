namespace System.Reflection;

[Extension]
[Token(Token = "0x2000527")]
internal static class SignatureTypeExtensions
{

	[Address(RVA = "0x73175F0", Offset = "0x73175F0", Length = "0x3AC")]
	[Extension]
	[Token(Token = "0x60026BB")]
	internal static bool MatchesExactly(SignatureType pattern, Type actual) { }

	[Address(RVA = "0x7317534", Offset = "0x7317534", Length = "0xBC")]
	[Extension]
	[Token(Token = "0x60026BA")]
	public static bool MatchesParameterTypeExactly(Type pattern, ParameterInfo parameter) { }

	[Address(RVA = "0x7317DC0", Offset = "0x7317DC0", Length = "0x9C")]
	[Extension]
	[Token(Token = "0x60026BE")]
	private static Type TryMakeArrayType(Type type) { }

	[Address(RVA = "0x7317E5C", Offset = "0x7317E5C", Length = "0x9C")]
	[Extension]
	[Token(Token = "0x60026BF")]
	private static Type TryMakeArrayType(Type type, int rank) { }

	[Address(RVA = "0x7317EF8", Offset = "0x7317EF8", Length = "0x9C")]
	[Extension]
	[Token(Token = "0x60026C0")]
	private static Type TryMakeByRefType(Type type) { }

	[Address(RVA = "0x7318030", Offset = "0x7318030", Length = "0x9C")]
	[Extension]
	[Token(Token = "0x60026C2")]
	private static Type TryMakeGenericType(Type type, Type[] instantiation) { }

	[Address(RVA = "0x7317F94", Offset = "0x7317F94", Length = "0x9C")]
	[Extension]
	[Token(Token = "0x60026C1")]
	private static Type TryMakePointerType(Type type) { }

	[Address(RVA = "0x73179D4", Offset = "0x73179D4", Length = "0x3EC")]
	[Extension]
	[Token(Token = "0x60026BD")]
	private static Type TryResolve(SignatureType signatureType, Type[] genericMethodParameters) { }

	[Address(RVA = "0x731799C", Offset = "0x731799C", Length = "0x38")]
	[Extension]
	[Token(Token = "0x60026BC")]
	internal static Type TryResolveAgainstGenericMethod(SignatureType signatureType, MethodInfo genericMethod) { }

}

