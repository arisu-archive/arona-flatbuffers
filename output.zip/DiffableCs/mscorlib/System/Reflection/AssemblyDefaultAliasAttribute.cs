namespace System.Reflection;

[AttributeUsage(AttributeTargets::Assembly (1), Inherited = False)]
[Token(Token = "0x20004F1")]
public sealed class AssemblyDefaultAliasAttribute : Attribute
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x400142D")]
	private readonly string <DefaultAlias>k__BackingField; //Field offset: 0x10

	[Address(RVA = "0x7310B88", Offset = "0x7310B88", Length = "0x30")]
	[Token(Token = "0x6002532")]
	public AssemblyDefaultAliasAttribute(string defaultAlias) { }

}

