namespace System.Reflection;

[Token(Token = "0x20004EC")]
public sealed class AmbiguousMatchException : SystemException
{

	[Address(RVA = "0x7310A70", Offset = "0x7310A70", Length = "0x5C")]
	[Token(Token = "0x600252C")]
	public AmbiguousMatchException() { }

	[Address(RVA = "0x7310ACC", Offset = "0x7310ACC", Length = "0x24")]
	[Token(Token = "0x600252D")]
	public AmbiguousMatchException(string message) { }

	[Address(RVA = "0x7310AF0", Offset = "0x7310AF0", Length = "0x8")]
	[Token(Token = "0x600252E")]
	internal AmbiguousMatchException(SerializationInfo info, StreamingContext context) { }

}

