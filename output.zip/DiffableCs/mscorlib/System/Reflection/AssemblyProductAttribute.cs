namespace System.Reflection;

[AttributeUsage(AttributeTargets::Assembly (1), Inherited = False)]
[Token(Token = "0x20004FA")]
public sealed class AssemblyProductAttribute : Attribute
{
	[CompilerGenerated]
	[FieldOffset(Offset = "0x10")]
	[Token(Token = "0x400143C")]
	private readonly string <Product>k__BackingField; //Field offset: 0x10

	[Address(RVA = "0x7310D64", Offset = "0x7310D64", Length = "0x30")]
	[Token(Token = "0x600253A")]
	public AssemblyProductAttribute(string product) { }

}

