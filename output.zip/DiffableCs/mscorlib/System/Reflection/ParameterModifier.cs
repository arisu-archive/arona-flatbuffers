namespace System.Reflection;

[DefaultMember("Item")]
[IsReadOnly]
[Token(Token = "0x200051A")]
public struct ParameterModifier
{
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40014D5")]
	private readonly Boolean[] _byRef; //Field offset: 0x0

}

