namespace System.Reflection;

[Token(Token = "0x2000521")]
internal sealed class SignatureArrayType : SignatureHasElementType
{
	[FieldOffset(Offset = "0x20")]
	[Token(Token = "0x40014EE")]
	private readonly int _rank; //Field offset: 0x20
	[FieldOffset(Offset = "0x24")]
	[Token(Token = "0x40014EF")]
	private readonly bool _isMultiDim; //Field offset: 0x24

	[Token(Token = "0x17000531")]
	public virtual bool IsSZArray
	{
		[Address(RVA = "0x7315788", Offset = "0x7315788", Length = "0x10")]
		[Token(Token = "0x6002627")]
		 get { } //Length: 16
	}

	[Token(Token = "0x17000532")]
	public virtual bool IsVariableBoundArray
	{
		[Address(RVA = "0x7315798", Offset = "0x7315798", Length = "0x8")]
		[Token(Token = "0x6002628")]
		 get { } //Length: 8
	}

	[Token(Token = "0x17000533")]
	protected virtual string Suffix
	{
		[Address(RVA = "0x73157A8", Offset = "0x73157A8", Length = "0xC8")]
		[Token(Token = "0x600262A")]
		 get { } //Length: 200
	}

	[Address(RVA = "0x73156FC", Offset = "0x73156FC", Length = "0x48")]
	[Token(Token = "0x6002623")]
	internal SignatureArrayType(SignatureType elementType, int rank, bool isMultiDim) { }

	[Address(RVA = "0x7315788", Offset = "0x7315788", Length = "0x10")]
	[Token(Token = "0x6002627")]
	public virtual bool get_IsSZArray() { }

	[Address(RVA = "0x7315798", Offset = "0x7315798", Length = "0x8")]
	[Token(Token = "0x6002628")]
	public virtual bool get_IsVariableBoundArray() { }

	[Address(RVA = "0x73157A8", Offset = "0x73157A8", Length = "0xC8")]
	[Token(Token = "0x600262A")]
	protected virtual string get_Suffix() { }

	[Address(RVA = "0x73157A0", Offset = "0x73157A0", Length = "0x8")]
	[Token(Token = "0x6002629")]
	public virtual int GetArrayRank() { }

	[Address(RVA = "0x7315770", Offset = "0x7315770", Length = "0x8")]
	[Token(Token = "0x6002624")]
	protected virtual bool IsArrayImpl() { }

	[Address(RVA = "0x7315778", Offset = "0x7315778", Length = "0x8")]
	[Token(Token = "0x6002625")]
	protected virtual bool IsByRefImpl() { }

	[Address(RVA = "0x7315780", Offset = "0x7315780", Length = "0x8")]
	[Token(Token = "0x6002626")]
	protected virtual bool IsPointerImpl() { }

}

