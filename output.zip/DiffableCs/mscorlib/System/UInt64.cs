namespace System;

[CLSCompliant(False)]
[IsReadOnly]
[Token(Token = "0x200012E")]
public struct ulong : IComparable, IConvertible, IFormattable, IComparable<UInt64>, IEquatable<UInt64>, ISpanFormattable
{
	[Token(Token = "0x4000444")]
	public const ulong MaxValue = 18446744073709551615; //Field offset: 0x0
	[Token(Token = "0x4000445")]
	public const ulong MinValue = 0; //Field offset: 0x0
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x4000443")]
	private readonly ulong m_value; //Field offset: 0x0

	[Address(RVA = "0x741C058", Offset = "0x741C058", Length = "0xD0")]
	[Token(Token = "0x6000C23")]
	public override int CompareTo(object value) { }

	[Address(RVA = "0x741C128", Offset = "0x741C128", Length = "0x14")]
	[Token(Token = "0x6000C24")]
	public override int CompareTo(ulong value) { }

	[Address(RVA = "0x741C13C", Offset = "0x741C13C", Length = "0x78")]
	[Token(Token = "0x6000C25")]
	public virtual bool Equals(object obj) { }

	[Address(RVA = "0x741C1B4", Offset = "0x741C1B4", Length = "0x10")]
	[NonVersionable]
	[Token(Token = "0x6000C26")]
	public override bool Equals(ulong obj) { }

	[Address(RVA = "0x741C1C4", Offset = "0x741C1C4", Length = "0xC")]
	[Token(Token = "0x6000C27")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x741C924", Offset = "0x741C924", Length = "0x8")]
	[Token(Token = "0x6000C32")]
	public override TypeCode GetTypeCode() { }

	[Address(RVA = "0x741C514", Offset = "0x741C514", Length = "0xB4")]
	[CLSCompliant(False)]
	[Token(Token = "0x6000C2D")]
	public static ulong Parse(string s) { }

	[Address(RVA = "0x741C5C8", Offset = "0x741C5C8", Length = "0xCC")]
	[CLSCompliant(False)]
	[Token(Token = "0x6000C2E")]
	public static ulong Parse(string s, NumberStyles style) { }

	[Address(RVA = "0x741C694", Offset = "0x741C694", Length = "0xC4")]
	[CLSCompliant(False)]
	[Token(Token = "0x6000C2F")]
	public static ulong Parse(string s, IFormatProvider provider) { }

	[Address(RVA = "0x741C758", Offset = "0x741C758", Length = "0xD4")]
	[CLSCompliant(False)]
	[Token(Token = "0x6000C30")]
	public static ulong Parse(string s, NumberStyles style, IFormatProvider provider) { }

	[Address(RVA = "0x741C92C", Offset = "0x741C92C", Length = "0x5C")]
	[Token(Token = "0x6000C33")]
	private override bool System.IConvertible.ToBoolean(IFormatProvider provider) { }

	[Address(RVA = "0x741CA40", Offset = "0x741CA40", Length = "0x5C")]
	[Token(Token = "0x6000C36")]
	private override byte System.IConvertible.ToByte(IFormatProvider provider) { }

	[Address(RVA = "0x741C988", Offset = "0x741C988", Length = "0x5C")]
	[Token(Token = "0x6000C34")]
	private override char System.IConvertible.ToChar(IFormatProvider provider) { }

	[Address(RVA = "0x741CD84", Offset = "0x741CD84", Length = "0x8C")]
	[Token(Token = "0x6000C40")]
	private override DateTime System.IConvertible.ToDateTime(IFormatProvider provider) { }

	[Address(RVA = "0x741CD28", Offset = "0x741CD28", Length = "0x5C")]
	[Token(Token = "0x6000C3F")]
	private override decimal System.IConvertible.ToDecimal(IFormatProvider provider) { }

	[Address(RVA = "0x741CCCC", Offset = "0x741CCCC", Length = "0x5C")]
	[Token(Token = "0x6000C3E")]
	private override double System.IConvertible.ToDouble(IFormatProvider provider) { }

	[Address(RVA = "0x741CA9C", Offset = "0x741CA9C", Length = "0x5C")]
	[Token(Token = "0x6000C37")]
	private override short System.IConvertible.ToInt16(IFormatProvider provider) { }

	[Address(RVA = "0x741CB54", Offset = "0x741CB54", Length = "0x5C")]
	[Token(Token = "0x6000C39")]
	private override int System.IConvertible.ToInt32(IFormatProvider provider) { }

	[Address(RVA = "0x741CC0C", Offset = "0x741CC0C", Length = "0x5C")]
	[Token(Token = "0x6000C3B")]
	private override long System.IConvertible.ToInt64(IFormatProvider provider) { }

	[Address(RVA = "0x741C9E4", Offset = "0x741C9E4", Length = "0x5C")]
	[Token(Token = "0x6000C35")]
	private override sbyte System.IConvertible.ToSByte(IFormatProvider provider) { }

	[Address(RVA = "0x741CC70", Offset = "0x741CC70", Length = "0x5C")]
	[Token(Token = "0x6000C3D")]
	private override float System.IConvertible.ToSingle(IFormatProvider provider) { }

	[Address(RVA = "0x741CE10", Offset = "0x741CE10", Length = "0xAC")]
	[Token(Token = "0x6000C41")]
	private override object System.IConvertible.ToType(Type type, IFormatProvider provider) { }

	[Address(RVA = "0x741CAF8", Offset = "0x741CAF8", Length = "0x5C")]
	[Token(Token = "0x6000C38")]
	private override ushort System.IConvertible.ToUInt16(IFormatProvider provider) { }

	[Address(RVA = "0x741CBB0", Offset = "0x741CBB0", Length = "0x5C")]
	[Token(Token = "0x6000C3A")]
	private override uint System.IConvertible.ToUInt32(IFormatProvider provider) { }

	[Address(RVA = "0x741CC68", Offset = "0x741CC68", Length = "0x8")]
	[Token(Token = "0x6000C3C")]
	private override ulong System.IConvertible.ToUInt64(IFormatProvider provider) { }

	[Address(RVA = "0x741C1D0", Offset = "0x741C1D0", Length = "0x98")]
	[Token(Token = "0x6000C28")]
	public virtual string ToString() { }

	[Address(RVA = "0x741C3B8", Offset = "0x741C3B8", Length = "0xB8")]
	[Token(Token = "0x6000C2B")]
	public override string ToString(string format, IFormatProvider provider) { }

	[Address(RVA = "0x741C304", Offset = "0x741C304", Length = "0xB4")]
	[Token(Token = "0x6000C2A")]
	public string ToString(string format) { }

	[Address(RVA = "0x741C268", Offset = "0x741C268", Length = "0x9C")]
	[Token(Token = "0x6000C29")]
	public override string ToString(IFormatProvider provider) { }

	[Address(RVA = "0x741C470", Offset = "0x741C470", Length = "0xA4")]
	[Token(Token = "0x6000C2C")]
	public override bool TryFormat(Span<Char> destination, out int charsWritten, ReadOnlySpan<Char> format = null, IFormatProvider provider = null) { }

	[Address(RVA = "0x741C82C", Offset = "0x741C82C", Length = "0xF8")]
	[CLSCompliant(False)]
	[Token(Token = "0x6000C31")]
	public static bool TryParse(string s, NumberStyles style, IFormatProvider provider, out ulong result) { }

}

