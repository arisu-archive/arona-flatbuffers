namespace System;

[Token(Token = "0x2000114")]
internal sealed class OrdinalIgnoreCaseComparer : OrdinalComparer, ISerializable
{

	[Address(RVA = "0x7413EC4", Offset = "0x7413EC4", Length = "0x8")]
	[Token(Token = "0x6000A69")]
	public OrdinalIgnoreCaseComparer() { }

	[Address(RVA = "0x741485C", Offset = "0x741485C", Length = "0x14")]
	[Token(Token = "0x6000A6A")]
	public virtual int Compare(string x, string y) { }

	[Address(RVA = "0x7414870", Offset = "0x7414870", Length = "0x14")]
	[Token(Token = "0x6000A6B")]
	public virtual bool Equals(string x, string y) { }

	[Address(RVA = "0x7414884", Offset = "0x7414884", Length = "0x64")]
	[Token(Token = "0x6000A6C")]
	public virtual int GetHashCode(string obj) { }

	[Address(RVA = "0x74148E8", Offset = "0x74148E8", Length = "0xB4")]
	[Token(Token = "0x6000A6D")]
	public override void GetObjectData(SerializationInfo info, StreamingContext context) { }

}

