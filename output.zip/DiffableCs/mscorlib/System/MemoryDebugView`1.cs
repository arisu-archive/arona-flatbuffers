namespace System;

[Token(Token = "0x20000EC")]
internal sealed class MemoryDebugView
{

}

