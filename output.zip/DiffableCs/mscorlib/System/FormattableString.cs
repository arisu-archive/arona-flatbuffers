namespace System;

[Token(Token = "0x20000B3")]
public abstract class FormattableString : IFormattable
{

	[Token(Token = "0x1700008B")]
	public abstract int ArgumentCount
	{
		[Token(Token = "0x60006DA")]
		 get { } //Length: 0
	}

	[Token(Token = "0x1700008A")]
	public abstract string Format
	{
		[Token(Token = "0x60006D8")]
		 get { } //Length: 0
	}

	[Address(RVA = "0x73E32B0", Offset = "0x73E32B0", Length = "0x8")]
	[Token(Token = "0x60006DF")]
	protected FormattableString() { }

	[Token(Token = "0x60006DA")]
	public abstract int get_ArgumentCount() { }

	[Token(Token = "0x60006D8")]
	public abstract string get_Format() { }

	[Token(Token = "0x60006DB")]
	public abstract object GetArgument(int index) { }

	[Token(Token = "0x60006D9")]
	public abstract Object[] GetArguments() { }

	[Address(RVA = "0x73E3238", Offset = "0x73E3238", Length = "0x10")]
	[Token(Token = "0x60006DD")]
	private override string System.IFormattable.ToString(string ignored, IFormatProvider formatProvider) { }

	[Token(Token = "0x60006DC")]
	public abstract string ToString(IFormatProvider formatProvider) { }

	[Address(RVA = "0x73E3248", Offset = "0x73E3248", Length = "0x68")]
	[Token(Token = "0x60006DE")]
	public virtual string ToString() { }

}

