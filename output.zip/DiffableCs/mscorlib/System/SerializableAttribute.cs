namespace System;

[AttributeUsage(4124, Inherited = False)]
[Token(Token = "0x200010A")]
public sealed class SerializableAttribute : Attribute
{

	[Address(RVA = "0x740F450", Offset = "0x740F450", Length = "0x8")]
	[Token(Token = "0x60009F0")]
	public SerializableAttribute() { }

}

