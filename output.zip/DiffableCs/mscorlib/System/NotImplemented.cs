namespace System;

[Token(Token = "0x200013F")]
internal static class NotImplemented
{

	[Token(Token = "0x17000149")]
	internal static Exception ByDesign
	{
		[Address(RVA = "0x74183C4", Offset = "0x74183C4", Length = "0x5C")]
		[Token(Token = "0x6000CF8")]
		internal get { } //Length: 92
	}

	[Address(RVA = "0x74183C4", Offset = "0x74183C4", Length = "0x5C")]
	[Token(Token = "0x6000CF8")]
	internal static Exception get_ByDesign() { }

}

