namespace System;

[Obsolete("This type previously indicated an unspecified fatal error in the runtime. The runtime no longer raises this exception so this type is obsolete.")]
[Token(Token = "0x20000AF")]
public sealed class ExecutionEngineException : SystemException
{

	[Address(RVA = "0x73E3074", Offset = "0x73E3074", Length = "0x5C")]
	[Token(Token = "0x60006CD")]
	public ExecutionEngineException() { }

	[Address(RVA = "0x73E30D0", Offset = "0x73E30D0", Length = "0x24")]
	[Token(Token = "0x60006CE")]
	public ExecutionEngineException(string message) { }

	[Address(RVA = "0x73E30F4", Offset = "0x73E30F4", Length = "0x8")]
	[Token(Token = "0x60006CF")]
	internal ExecutionEngineException(SerializationInfo info, StreamingContext context) { }

}

