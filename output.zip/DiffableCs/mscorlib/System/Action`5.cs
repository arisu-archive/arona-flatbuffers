namespace System;

[Token(Token = "0x200007A")]
public sealed class Action : MulticastDelegate
{

	[Address(RVA = "0x4FA3540", Offset = "0x4FA3540", Length = "0xD8")]
	[Token(Token = "0x60003BC")]
	public Action`5(object object, IntPtr method) { }

	[Address(RVA = "0x4FA3618", Offset = "0x4FA3618", Length = "0x14")]
	[Token(Token = "0x60003BD")]
	public override void Invoke(T1 arg1, T2 arg2, T3 arg3, T4 arg4, T5 arg5) { }

}

