namespace System;

[IsReadOnly]
[Token(Token = "0x200011A")]
public struct TimeSpan : IComparable, IComparable<TimeSpan>, IEquatable<TimeSpan>, IFormattable, ISpanFormattable
{
	[Token(Token = "0x40003DF")]
	public const long TicksPerMillisecond = 10000; //Field offset: 0x0
	[Token(Token = "0x40003F2")]
	public static readonly TimeSpan Zero; //Field offset: 0x0
	[Token(Token = "0x40003F1")]
	internal const long TicksPerTenthSecond = 1000000; //Field offset: 0x0
	[Token(Token = "0x40003F0")]
	internal const long MinMilliSeconds = -922337203685477; //Field offset: 0x0
	[Token(Token = "0x40003EF")]
	internal const long MaxMilliSeconds = 922337203685477; //Field offset: 0x0
	[Token(Token = "0x40003EE")]
	internal const long MinSeconds = -922337203685; //Field offset: 0x0
	[Token(Token = "0x40003ED")]
	internal const long MaxSeconds = 922337203685; //Field offset: 0x0
	[Token(Token = "0x40003EC")]
	private const int MillisPerDay = 86400000; //Field offset: 0x0
	[Token(Token = "0x40003EB")]
	private const int MillisPerHour = 3600000; //Field offset: 0x0
	[Token(Token = "0x40003E9")]
	private const int MillisPerSecond = 1000; //Field offset: 0x0
	[Token(Token = "0x40003EA")]
	private const int MillisPerMinute = 60000; //Field offset: 0x0
	[Token(Token = "0x40003E7")]
	public const long TicksPerDay = 864000000000; //Field offset: 0x0
	[Token(Token = "0x40003E6")]
	private const double HoursPerTick = 2.7777777777777777E-11; //Field offset: 0x0
	[Token(Token = "0x40003E5")]
	public const long TicksPerHour = 36000000000; //Field offset: 0x0
	[Token(Token = "0x40003E4")]
	private const double MinutesPerTick = 1.6666666666666667E-09; //Field offset: 0x0
	[Token(Token = "0x40003E3")]
	public const long TicksPerMinute = 600000000; //Field offset: 0x0
	[Token(Token = "0x40003E2")]
	private const double SecondsPerTick = 1E-07; //Field offset: 0x0
	[Token(Token = "0x40003E1")]
	public const long TicksPerSecond = 10000000; //Field offset: 0x0
	[Token(Token = "0x40003E0")]
	private const double MillisecondsPerTick = 0.0001; //Field offset: 0x0
	[Token(Token = "0x40003E8")]
	private const double DaysPerTick = 1.1574074074074074E-12; //Field offset: 0x0
	[Token(Token = "0x40003F3")]
	public static readonly TimeSpan MaxValue; //Field offset: 0x8
	[Token(Token = "0x40003F4")]
	public static readonly TimeSpan MinValue; //Field offset: 0x10
	[FieldOffset(Offset = "0x0")]
	[Token(Token = "0x40003F5")]
	internal readonly long _ticks; //Field offset: 0x0

	[Token(Token = "0x170000B3")]
	public int Days
	{
		[Address(RVA = "0x7414C98", Offset = "0x7414C98", Length = "0x2C")]
		[Token(Token = "0x6000A78")]
		 get { } //Length: 44
	}

	[Token(Token = "0x170000B4")]
	public int Hours
	{
		[Address(RVA = "0x7414CC4", Offset = "0x7414CC4", Length = "0x44")]
		[Token(Token = "0x6000A79")]
		 get { } //Length: 68
	}

	[Token(Token = "0x170000B5")]
	public int Milliseconds
	{
		[Address(RVA = "0x7414D08", Offset = "0x7414D08", Length = "0x4C")]
		[Token(Token = "0x6000A7A")]
		 get { } //Length: 76
	}

	[Token(Token = "0x170000B6")]
	public int Minutes
	{
		[Address(RVA = "0x7414D54", Offset = "0x7414D54", Length = "0x48")]
		[Token(Token = "0x6000A7B")]
		 get { } //Length: 72
	}

	[Token(Token = "0x170000B7")]
	public int Seconds
	{
		[Address(RVA = "0x7414D9C", Offset = "0x7414D9C", Length = "0x4C")]
		[Token(Token = "0x6000A7C")]
		 get { } //Length: 76
	}

	[Token(Token = "0x170000B2")]
	public long Ticks
	{
		[Address(RVA = "0x7414C90", Offset = "0x7414C90", Length = "0x8")]
		[Token(Token = "0x6000A77")]
		 get { } //Length: 8
	}

	[Token(Token = "0x170000B8")]
	public double TotalDays
	{
		[Address(RVA = "0x7414DE8", Offset = "0x7414DE8", Length = "0x18")]
		[Token(Token = "0x6000A7D")]
		 get { } //Length: 24
	}

	[Token(Token = "0x170000B9")]
	public double TotalHours
	{
		[Address(RVA = "0x7414E00", Offset = "0x7414E00", Length = "0x18")]
		[Token(Token = "0x6000A7E")]
		 get { } //Length: 24
	}

	[Token(Token = "0x170000BA")]
	public double TotalMilliseconds
	{
		[Address(RVA = "0x7414E18", Offset = "0x7414E18", Length = "0x34")]
		[Token(Token = "0x6000A7F")]
		 get { } //Length: 52
	}

	[Token(Token = "0x170000BB")]
	public double TotalMinutes
	{
		[Address(RVA = "0x7414E4C", Offset = "0x7414E4C", Length = "0x18")]
		[Token(Token = "0x6000A80")]
		 get { } //Length: 24
	}

	[Token(Token = "0x170000BC")]
	public double TotalSeconds
	{
		[Address(RVA = "0x7414E64", Offset = "0x7414E64", Length = "0x18")]
		[Token(Token = "0x6000A81")]
		 get { } //Length: 24
	}

	[Address(RVA = "0x7415C54", Offset = "0x7415C54", Length = "0x58")]
	[Token(Token = "0x6000AA6")]
	private static TimeSpan() { }

	[Address(RVA = "0x7414BD0", Offset = "0x7414BD0", Length = "0xC0")]
	[Token(Token = "0x6000A76")]
	public TimeSpan(int days, int hours, int minutes, int seconds, int milliseconds) { }

	[Address(RVA = "0x7414AAC", Offset = "0x7414AAC", Length = "0x8")]
	[Token(Token = "0x6000A74")]
	public TimeSpan(long ticks) { }

	[Address(RVA = "0x7414AB4", Offset = "0x7414AB4", Length = "0x80")]
	[Token(Token = "0x6000A75")]
	public TimeSpan(int hours, int minutes, int seconds) { }

	[Address(RVA = "0x7414E7C", Offset = "0x7414E7C", Length = "0x6C")]
	[Token(Token = "0x6000A82")]
	public TimeSpan Add(TimeSpan ts) { }

	[Address(RVA = "0x7414EE8", Offset = "0x7414EE8", Length = "0x10")]
	[Token(Token = "0x6000A83")]
	public static int Compare(TimeSpan t1, TimeSpan t2) { }

	[Address(RVA = "0x7414FC0", Offset = "0x7414FC0", Length = "0x14")]
	[Token(Token = "0x6000A85")]
	public override int CompareTo(TimeSpan value) { }

	[Address(RVA = "0x7414EF8", Offset = "0x7414EF8", Length = "0xC8")]
	[Token(Token = "0x6000A84")]
	public override int CompareTo(object value) { }

	[Address(RVA = "0x7415184", Offset = "0x7415184", Length = "0xB8")]
	[Token(Token = "0x6000A87")]
	public TimeSpan Duration() { }

	[Address(RVA = "0x74152B4", Offset = "0x74152B4", Length = "0x10")]
	[Token(Token = "0x6000A89")]
	public override bool Equals(TimeSpan obj) { }

	[Address(RVA = "0x741523C", Offset = "0x741523C", Length = "0x78")]
	[Token(Token = "0x6000A88")]
	public virtual bool Equals(object value) { }

	[Address(RVA = "0x7414FD4", Offset = "0x7414FD4", Length = "0x64")]
	[Token(Token = "0x6000A86")]
	public static TimeSpan FromDays(double value) { }

	[Address(RVA = "0x74152D0", Offset = "0x74152D0", Length = "0x64")]
	[Token(Token = "0x6000A8B")]
	public static TimeSpan FromHours(double value) { }

	[Address(RVA = "0x7415334", Offset = "0x7415334", Length = "0x60")]
	[Token(Token = "0x6000A8D")]
	public static TimeSpan FromMilliseconds(double value) { }

	[Address(RVA = "0x7415394", Offset = "0x7415394", Length = "0x60")]
	[Token(Token = "0x6000A8E")]
	public static TimeSpan FromMinutes(double value) { }

	[Address(RVA = "0x74154A8", Offset = "0x74154A8", Length = "0x60")]
	[Token(Token = "0x6000A90")]
	public static TimeSpan FromSeconds(double value) { }

	[Address(RVA = "0x7415574", Offset = "0x7415574", Length = "0x4")]
	[Token(Token = "0x6000A92")]
	public static TimeSpan FromTicks(long value) { }

	[Address(RVA = "0x7414C98", Offset = "0x7414C98", Length = "0x2C")]
	[Token(Token = "0x6000A78")]
	public int get_Days() { }

	[Address(RVA = "0x7414CC4", Offset = "0x7414CC4", Length = "0x44")]
	[Token(Token = "0x6000A79")]
	public int get_Hours() { }

	[Address(RVA = "0x7414D08", Offset = "0x7414D08", Length = "0x4C")]
	[Token(Token = "0x6000A7A")]
	public int get_Milliseconds() { }

	[Address(RVA = "0x7414D54", Offset = "0x7414D54", Length = "0x48")]
	[Token(Token = "0x6000A7B")]
	public int get_Minutes() { }

	[Address(RVA = "0x7414D9C", Offset = "0x7414D9C", Length = "0x4C")]
	[Token(Token = "0x6000A7C")]
	public int get_Seconds() { }

	[Address(RVA = "0x7414C90", Offset = "0x7414C90", Length = "0x8")]
	[Token(Token = "0x6000A77")]
	public long get_Ticks() { }

	[Address(RVA = "0x7414DE8", Offset = "0x7414DE8", Length = "0x18")]
	[Token(Token = "0x6000A7D")]
	public double get_TotalDays() { }

	[Address(RVA = "0x7414E00", Offset = "0x7414E00", Length = "0x18")]
	[Token(Token = "0x6000A7E")]
	public double get_TotalHours() { }

	[Address(RVA = "0x7414E18", Offset = "0x7414E18", Length = "0x34")]
	[Token(Token = "0x6000A7F")]
	public double get_TotalMilliseconds() { }

	[Address(RVA = "0x7414E4C", Offset = "0x7414E4C", Length = "0x18")]
	[Token(Token = "0x6000A80")]
	public double get_TotalMinutes() { }

	[Address(RVA = "0x7414E64", Offset = "0x7414E64", Length = "0x18")]
	[Token(Token = "0x6000A81")]
	public double get_TotalSeconds() { }

	[Address(RVA = "0x74152C4", Offset = "0x74152C4", Length = "0xC")]
	[Token(Token = "0x6000A8A")]
	public virtual int GetHashCode() { }

	[Address(RVA = "0x7415038", Offset = "0x7415038", Length = "0x14C")]
	[Token(Token = "0x6000A8C")]
	private static TimeSpan Interval(double value, int scale) { }

	[Address(RVA = "0x74153F4", Offset = "0x74153F4", Length = "0xB4")]
	[Token(Token = "0x6000A8F")]
	public TimeSpan Negate() { }

	[Address(RVA = "0x7415BA4", Offset = "0x7415BA4", Length = "0x68")]
	[Token(Token = "0x6000A9F")]
	public static TimeSpan op_Addition(TimeSpan t1, TimeSpan t2) { }

	[Address(RVA = "0x7415C0C", Offset = "0x7415C0C", Length = "0xC")]
	[Token(Token = "0x6000AA0")]
	public static bool op_Equality(TimeSpan t1, TimeSpan t2) { }

	[Address(RVA = "0x7415C3C", Offset = "0x7415C3C", Length = "0xC")]
	[Token(Token = "0x6000AA4")]
	public static bool op_GreaterThan(TimeSpan t1, TimeSpan t2) { }

	[Address(RVA = "0x7415C48", Offset = "0x7415C48", Length = "0xC")]
	[Token(Token = "0x6000AA5")]
	public static bool op_GreaterThanOrEqual(TimeSpan t1, TimeSpan t2) { }

	[Address(RVA = "0x7415C18", Offset = "0x7415C18", Length = "0xC")]
	[Token(Token = "0x6000AA1")]
	public static bool op_Inequality(TimeSpan t1, TimeSpan t2) { }

	[Address(RVA = "0x7415C24", Offset = "0x7415C24", Length = "0xC")]
	[Token(Token = "0x6000AA2")]
	public static bool op_LessThan(TimeSpan t1, TimeSpan t2) { }

	[Address(RVA = "0x7415C30", Offset = "0x7415C30", Length = "0xC")]
	[Token(Token = "0x6000AA3")]
	public static bool op_LessThanOrEqual(TimeSpan t1, TimeSpan t2) { }

	[Address(RVA = "0x7415B3C", Offset = "0x7415B3C", Length = "0x68")]
	[Token(Token = "0x6000A9E")]
	public static TimeSpan op_Subtraction(TimeSpan t1, TimeSpan t2) { }

	[Address(RVA = "0x7415A8C", Offset = "0x7415A8C", Length = "0xB0")]
	[Token(Token = "0x6000A9D")]
	public static TimeSpan op_UnaryNegation(TimeSpan t) { }

	[Address(RVA = "0x74155E0", Offset = "0x74155E0", Length = "0x5C")]
	[Token(Token = "0x6000A95")]
	public static TimeSpan Parse(string s) { }

	[Address(RVA = "0x741563C", Offset = "0x741563C", Length = "0x60")]
	[Token(Token = "0x6000A96")]
	public static TimeSpan Parse(string input, IFormatProvider formatProvider) { }

	[Address(RVA = "0x7415508", Offset = "0x7415508", Length = "0x6C")]
	[Token(Token = "0x6000A91")]
	public TimeSpan Subtract(TimeSpan ts) { }

	[Address(RVA = "0x7414B34", Offset = "0x7414B34", Length = "0x9C")]
	[Token(Token = "0x6000A93")]
	internal static long TimeToTicks(int hour, int minute, int second) { }

	[Address(RVA = "0x7415904", Offset = "0x7415904", Length = "0x70")]
	[Token(Token = "0x6000A9A")]
	public string ToString(string format) { }

	[Address(RVA = "0x7415974", Offset = "0x7415974", Length = "0x74")]
	[Token(Token = "0x6000A9B")]
	public override string ToString(string format, IFormatProvider formatProvider) { }

	[Address(RVA = "0x74158A0", Offset = "0x74158A0", Length = "0x64")]
	[Token(Token = "0x6000A99")]
	public virtual string ToString() { }

	[Address(RVA = "0x74159E8", Offset = "0x74159E8", Length = "0xA4")]
	[Token(Token = "0x6000A9C")]
	public override bool TryFormat(Span<Char> destination, out int charsWritten, ReadOnlySpan<Char> format = null, IFormatProvider formatProvider = null) { }

	[Address(RVA = "0x7415770", Offset = "0x7415770", Length = "0x130")]
	[Token(Token = "0x6000A98")]
	public static bool TryParseExact(string input, string format, IFormatProvider formatProvider, TimeSpanStyles styles, out TimeSpan result) { }

	[Address(RVA = "0x741569C", Offset = "0x741569C", Length = "0xD4")]
	[Token(Token = "0x6000A97")]
	public static bool TryParseExact(string input, string format, IFormatProvider formatProvider, out TimeSpan result) { }

	[Address(RVA = "0x7415578", Offset = "0x7415578", Length = "0x68")]
	[Token(Token = "0x6000A94")]
	private static void ValidateStyles(TimeSpanStyles style, string parameterName) { }

}

